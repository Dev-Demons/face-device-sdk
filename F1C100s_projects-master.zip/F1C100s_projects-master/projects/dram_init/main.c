#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "io.h"
#include "sys_dram.h"
#include "f1c100s_gpio.h"

int main(void) {
    sys_dram_init();

    while(1) {

    }

    return 0;
}

#pragma once

#include <stdint.h>

void display_init_lvgl(void);
void display_init(void);
void display_set_bl(uint8_t duty);

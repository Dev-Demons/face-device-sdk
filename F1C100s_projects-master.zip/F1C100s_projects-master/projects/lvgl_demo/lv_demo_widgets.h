#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void lv_demo_widgets(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#pragma once

void system_init(void);

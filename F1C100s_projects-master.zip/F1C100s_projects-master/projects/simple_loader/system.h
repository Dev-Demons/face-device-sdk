#pragma once

void system_init(void);
void _putchar(char c);

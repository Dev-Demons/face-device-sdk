#pragma once

#include <stdint.h>

void display_init(void);
void display_set_bl(uint8_t duty);

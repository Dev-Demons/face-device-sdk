﻿namespace CSharpDemo
{
    partial class SDK_CSDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button ImageBackButton;
            this.CloseSessionButton = new System.Windows.Forms.Button();
            this.OpenSessionButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.InfoMsgBox = new System.Windows.Forms.TextBox();
            this.PrinterStatusButton = new System.Windows.Forms.Button();
            this.TabControl = new System.Windows.Forms.TabControl();
            this.Main = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ErrorResponseButton = new System.Windows.Forms.Button();
            this.ErrorResponseCombo = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ClearPrinterMsgButton = new System.Windows.Forms.Button();
            this.PrinterMsgBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.PrinterSetRadio = new System.Windows.Forms.RadioButton();
            this.PrinterGetRadio = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.IPGatewayLabel = new System.Windows.Forms.Label();
            this.IPSubnetLabel = new System.Windows.Forms.Label();
            this.IPAddrLabel = new System.Windows.Forms.Label();
            this.IPGatewayBox = new System.Windows.Forms.TextBox();
            this.IPSubnetBox = new System.Windows.Forms.TextBox();
            this.IPAddressBox = new System.Windows.Forms.TextBox();
            this.IPSettingsButton = new System.Windows.Forms.Button();
            this.IPModeLabel = new System.Windows.Forms.Label();
            this.IPModeCombo = new System.Windows.Forms.ComboBox();
            this.EjectModeButton = new System.Windows.Forms.Button();
            this.EjectModeCombo = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SessionConfigCombo = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.MoveCardCombo = new System.Windows.Forms.ComboBox();
            this.RestartButton = new System.Windows.Forms.Button();
            this.MoveCardButton = new System.Windows.Forms.Button();
            this.TestCardButton = new System.Windows.Forms.Button();
            this.CleanPrinterButton = new System.Windows.Forms.Button();
            this.Information = new System.Windows.Forms.TabPage();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.PrinterTypeButton = new System.Windows.Forms.Button();
            this.SDKBitsButton = new System.Windows.Forms.Button();
            this.LastMessageButton = new System.Windows.Forms.Button();
            this.TemperatureButton = new System.Windows.Forms.Button();
            this.PrinterInfoButton = new System.Windows.Forms.Button();
            this.PrinterModelButton = new System.Windows.Forms.Button();
            this.ConnectionTypeButton = new System.Windows.Forms.Button();
            this.SDKVersionButton = new System.Windows.Forms.Button();
            this.ClearMsgBoxButton = new System.Windows.Forms.Button();
            this.MagEncoding = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.StartPosn = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.EncodingSetRadio = new System.Windows.Forms.RadioButton();
            this.EncodingGetRadio = new System.Windows.Forms.RadioButton();
            this.MagStartButton = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.Track3Read = new System.Windows.Forms.CheckBox();
            this.Track2Read = new System.Windows.Forms.CheckBox();
            this.Track1Read = new System.Windows.Forms.CheckBox();
            this.ReadMagTracks = new System.Windows.Forms.Button();
            this.EncodingBox = new System.Windows.Forms.TextBox();
            this.ReadMagButton = new System.Windows.Forms.Button();
            this.ClearEncodingBoxButton = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label112 = new System.Windows.Forms.Label();
            this.BitsPerInchLabel = new System.Windows.Forms.Label();
            this.BitsPerCharLabel = new System.Windows.Forms.Label();
            this.T1_BPICombo = new System.Windows.Forms.ComboBox();
            this.Track3SettingsLabel = new System.Windows.Forms.Label();
            this.Track2SettingsLabel = new System.Windows.Forms.Label();
            this.Track1SettingsLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.JIS2Label = new System.Windows.Forms.Label();
            this.Track3Label = new System.Windows.Forms.Label();
            this.Track2Label = new System.Windows.Forms.Label();
            this.Track1Data = new System.Windows.Forms.TextBox();
            this.Track2Data = new System.Windows.Forms.TextBox();
            this.Track3Data = new System.Windows.Forms.TextBox();
            this.Track1Write = new System.Windows.Forms.CheckBox();
            this.Track2Write = new System.Windows.Forms.CheckBox();
            this.Track3Write = new System.Windows.Forms.CheckBox();
            this.EncodingTypeCombo = new System.Windows.Forms.ComboBox();
            this.CoercivityCombo = new System.Windows.Forms.ComboBox();
            this.Verify = new System.Windows.Forms.CheckBox();
            this.T1_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T2_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T2_BPICombo = new System.Windows.Forms.ComboBox();
            this.T3_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T3_BPICombo = new System.Windows.Forms.ComboBox();
            this.EncodeMagButton = new System.Windows.Forms.Button();
            this.Track1Label = new System.Windows.Forms.Label();
            this.DriverSettings1 = new System.Windows.Forms.TabPage();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label86 = new System.Windows.Forms.Label();
            this.ColourAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.ColourAreaNo = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaSideCombo = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.ColourAreaCorrectionCombo = new System.Windows.Forms.ComboBox();
            this.label106 = new System.Windows.Forms.Label();
            this.ColourAreaButton = new System.Windows.Forms.Button();
            this.GUIPrinter = new System.Windows.Forms.CheckBox();
            this.GUIUser = new System.Windows.Forms.CheckBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.ResinAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaNoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.ResinAreaSideCombo = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.ResinAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.ResinAreaButton = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.OvercoatPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.YMCPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.PowerLevelButton = new System.Windows.Forms.Button();
            this.ColourCorrectionButton = new System.Windows.Forms.Button();
            this.CorrectionCombo = new System.Windows.Forms.ComboBox();
            this.SharpnessUpDown = new System.Windows.Forms.NumericUpDown();
            this.GUIControlButton = new System.Windows.Forms.Button();
            this.SharpnessButton = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.Driver1SetRadio = new System.Windows.Forms.RadioButton();
            this.Driver1GetRadio = new System.Windows.Forms.RadioButton();
            this.ClearDriver1MsgBoxButton = new System.Windows.Forms.Button();
            this.Driver1MsgBox = new System.Windows.Forms.TextBox();
            this.DriverSettings2 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.HoloKoteIDSlot = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.HoloKoteIDButton = new System.Windows.Forms.Button();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.ColourAdjust_WhiteRef = new System.Windows.Forms.NumericUpDown();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.ColourAdjust_BlackRef = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Illuminant = new System.Windows.Forms.ComboBox();
            this.label118 = new System.Windows.Forms.Label();
            this.ColourAdjust_Negative = new System.Windows.Forms.CheckBox();
            this.ColourAdjust_DarkPic = new System.Windows.Forms.CheckBox();
            this.ColourAdjust_Blue = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Green = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Red = new System.Windows.Forms.NumericUpDown();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.ColourAdjust_Tint = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Colour = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Brightness = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Contrast = new System.Windows.Forms.NumericUpDown();
            this.label111 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.ColourAdjustBtn = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.HoloKotePreviewButton = new System.Windows.Forms.Button();
            this.HoloKoteImageUpDown = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.HoloKoteSideCombo = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.HoloKoteRotationCombo = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.HoloKoteButton = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.Rotate = new System.Windows.Forms.CheckBox();
            this.Overcoat = new System.Windows.Forms.CheckBox();
            this.CardSettingsSideCombo = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.OrientationCombo = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.ColourFormatCombo = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.CardSettingsButton = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.CardSizeCombo = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.CopyCountUpDown = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.DuplexCombo = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.PrintSettingsButton = new System.Windows.Forms.Button();
            this.ClearDriver2MsgBoxButton = new System.Windows.Forms.Button();
            this.Driver2MsgBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Driver2SetRadio = new System.Windows.Forms.RadioButton();
            this.Driver2GetRadio = new System.Windows.Forms.RadioButton();
            this.PrintDemo = new System.Windows.Forms.TabPage();
            this.nativePrint = new System.Windows.Forms.CheckBox();
            this.CardSide = new System.Windows.Forms.TabControl();
            this.Front = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Track3MagData = new System.Windows.Forms.TextBox();
            this.Track2MagData = new System.Windows.Forms.TextBox();
            this.Track1MagData = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MagDataEnabled = new System.Windows.Forms.CheckBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.ImageFrontResin = new System.Windows.Forms.CheckBox();
            this.ImageFrontEnabled = new System.Windows.Forms.CheckBox();
            this.ImageFrontButton = new System.Windows.Forms.Button();
            this.ImageFrontFileBox = new System.Windows.Forms.TextBox();
            this.ImageFrontP2UpDown = new System.Windows.Forms.NumericUpDown();
            this.label69 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.ImageFrontP1UpDown = new System.Windows.Forms.NumericUpDown();
            this.ImageFrontYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label79 = new System.Windows.Forms.Label();
            this.ImageFrontXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.LineFrontEnabled = new System.Windows.Forms.CheckBox();
            this.label89 = new System.Windows.Forms.Label();
            this.LineFrontWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.label90 = new System.Windows.Forms.Label();
            this.LineFrontStartYUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineFrontEndYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.LineFrontResin = new System.Windows.Forms.CheckBox();
            this.LineFrontEndXUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineFrontColourCombo = new System.Windows.Forms.ComboBox();
            this.LineFrontStartXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.ShapeFrontEnabled = new System.Windows.Forms.CheckBox();
            this.ShapeFrontFillCombo = new System.Windows.Forms.ComboBox();
            this.label97 = new System.Windows.Forms.Label();
            this.ShapeFrontWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeFrontOutlineCombo = new System.Windows.Forms.ComboBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.ShapeFrontBUpDown = new System.Windows.Forms.NumericUpDown();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.ShapeFrontResin = new System.Windows.Forms.CheckBox();
            this.ShapeFrontRUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeFrontTUpDown = new System.Windows.Forms.NumericUpDown();
            this.label102 = new System.Windows.Forms.Label();
            this.ShapeFrontLUpDown = new System.Windows.Forms.NumericUpDown();
            this.label103 = new System.Windows.Forms.Label();
            this.ShapeFrontCombo = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.TextFrontEnabled = new System.Windows.Forms.CheckBox();
            this.TextFrontResin = new System.Windows.Forms.CheckBox();
            this.TextFrontSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label125 = new System.Windows.Forms.Label();
            this.TextFrontYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label126 = new System.Windows.Forms.Label();
            this.TextFrontXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label127 = new System.Windows.Forms.Label();
            this.TextFrontStrikethrough = new System.Windows.Forms.CheckBox();
            this.TextFrontItalic = new System.Windows.Forms.CheckBox();
            this.TextFrontUnderline = new System.Windows.Forms.CheckBox();
            this.TextFrontBold = new System.Windows.Forms.CheckBox();
            this.TextFrontColourCombo = new System.Windows.Forms.ComboBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.TextFrontBox = new System.Windows.Forms.TextBox();
            this.Back = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ImageBackResin = new System.Windows.Forms.CheckBox();
            this.ImageBackEnabled = new System.Windows.Forms.CheckBox();
            this.ImageBackFileBox = new System.Windows.Forms.TextBox();
            this.ImageBackP2UpDown = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ImageBackP1UpDown = new System.Windows.Forms.NumericUpDown();
            this.ImageBackYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label54 = new System.Windows.Forms.Label();
            this.ImageBackXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.LineBackEnabled = new System.Windows.Forms.CheckBox();
            this.label58 = new System.Windows.Forms.Label();
            this.LineBackWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.LineBackStartYUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineBackEndYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.LineBackResin = new System.Windows.Forms.CheckBox();
            this.LineBackEndXUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineBackColourCombo = new System.Windows.Forms.ComboBox();
            this.LineBackStartXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.ShapeBackEnabled = new System.Windows.Forms.CheckBox();
            this.ShapeBackFillCombo = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.ShapeBackWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeBackOutlineCombo = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.ShapeBackBUpDown = new System.Windows.Forms.NumericUpDown();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.ShapeBackResin = new System.Windows.Forms.CheckBox();
            this.ShapeBackRUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeBackTUpDown = new System.Windows.Forms.NumericUpDown();
            this.label72 = new System.Windows.Forms.Label();
            this.ShapeBackLUpDown = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.ShapeBackCombo = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.TextBackEnabled = new System.Windows.Forms.CheckBox();
            this.TextBackResin = new System.Windows.Forms.CheckBox();
            this.TextBackSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label76 = new System.Windows.Forms.Label();
            this.TextBackYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label77 = new System.Windows.Forms.Label();
            this.TextBackXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label81 = new System.Windows.Forms.Label();
            this.TextBackStrikethrough = new System.Windows.Forms.CheckBox();
            this.TextBackItalic = new System.Windows.Forms.CheckBox();
            this.TextBackUnderline = new System.Windows.Forms.CheckBox();
            this.TextBackBold = new System.Windows.Forms.CheckBox();
            this.TextBackColourCombo = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.TextBackBox = new System.Windows.Forms.TextBox();
            this.CardBack = new System.Windows.Forms.CheckBox();
            this.CardFront = new System.Windows.Forms.CheckBox();
            this.PrintButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PrinterID = new System.Windows.Forms.Label();
            this.PrinterPrefs = new System.Windows.Forms.Button();
            ImageBackButton = new System.Windows.Forms.Button();
            this.TabControl.SuspendLayout();
            this.Main.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.Information.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.MagEncoding.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StartPosn)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.DriverSettings1.SuspendLayout();
            this.groupBox23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaLeftUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaNo)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaNoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaLeftUpDown)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OvercoatPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YMCPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpnessUpDown)).BeginInit();
            this.DriverSettings2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_WhiteRef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_BlackRef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Blue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Tint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Colour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Brightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Contrast)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteImageUpDown)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CopyCountUpDown)).BeginInit();
            this.PrintDemo.SuspendLayout();
            this.CardSide.SuspendLayout();
            this.Front.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP2UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP1UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontXUpDown)).BeginInit();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndXUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartXUpDown)).BeginInit();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontBUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontRUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontTUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontLUpDown)).BeginInit();
            this.groupBox33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontSizeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).BeginInit();
            this.Back.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP2UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP1UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackXUpDown)).BeginInit();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndXUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartXUpDown)).BeginInit();
            this.groupBox21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackBUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackRUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackTUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackLUpDown)).BeginInit();
            this.groupBox22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackSizeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackXUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // ImageBackButton
            // 
            ImageBackButton.Enabled = false;
            ImageBackButton.Location = new System.Drawing.Point(400, 10);
            ImageBackButton.Name = "ImageBackButton";
            ImageBackButton.Size = new System.Drawing.Size(28, 24);
            ImageBackButton.TabIndex = 70;
            ImageBackButton.Text = "...";
            ImageBackButton.UseVisualStyleBackColor = true;
            ImageBackButton.Click += new System.EventHandler(this.ImageBackButton_Click);
            // 
            // CloseSessionButton
            // 
            this.CloseSessionButton.Location = new System.Drawing.Point(95, 13);
            this.CloseSessionButton.Name = "CloseSessionButton";
            this.CloseSessionButton.Size = new System.Drawing.Size(90, 24);
            this.CloseSessionButton.TabIndex = 3;
            this.CloseSessionButton.Text = "CloseSession";
            this.CloseSessionButton.UseVisualStyleBackColor = true;
            this.CloseSessionButton.Visible = false;
            this.CloseSessionButton.Click += new System.EventHandler(this.CloseSession_Click);
            // 
            // OpenSessionButton
            // 
            this.OpenSessionButton.Location = new System.Drawing.Point(3, 13);
            this.OpenSessionButton.Name = "OpenSessionButton";
            this.OpenSessionButton.Size = new System.Drawing.Size(90, 24);
            this.OpenSessionButton.TabIndex = 2;
            this.OpenSessionButton.Text = "OpenSession";
            this.OpenSessionButton.UseVisualStyleBackColor = true;
            this.OpenSessionButton.Click += new System.EventHandler(this.OpenSession_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(390, 598);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(74, 24);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // InfoMsgBox
            // 
            this.InfoMsgBox.Location = new System.Drawing.Point(164, 14);
            this.InfoMsgBox.Multiline = true;
            this.InfoMsgBox.Name = "InfoMsgBox";
            this.InfoMsgBox.ReadOnly = true;
            this.InfoMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InfoMsgBox.Size = new System.Drawing.Size(292, 507);
            this.InfoMsgBox.TabIndex = 7;
            this.InfoMsgBox.WordWrap = false;
            // 
            // PrinterStatusButton
            // 
            this.PrinterStatusButton.Location = new System.Drawing.Point(14, 164);
            this.PrinterStatusButton.Name = "PrinterStatusButton";
            this.PrinterStatusButton.Size = new System.Drawing.Size(142, 24);
            this.PrinterStatusButton.TabIndex = 1;
            this.PrinterStatusButton.Text = "PrinterStatus";
            this.PrinterStatusButton.UseVisualStyleBackColor = true;
            this.PrinterStatusButton.Click += new System.EventHandler(this.PrinterStatusButton_Click);
            // 
            // TabControl
            // 
            this.TabControl.Controls.Add(this.Main);
            this.TabControl.Controls.Add(this.Information);
            this.TabControl.Controls.Add(this.MagEncoding);
            this.TabControl.Controls.Add(this.DriverSettings1);
            this.TabControl.Controls.Add(this.DriverSettings2);
            this.TabControl.Controls.Add(this.PrintDemo);
            this.TabControl.Location = new System.Drawing.Point(3, 0);
            this.TabControl.Multiline = true;
            this.TabControl.Name = "TabControl";
            this.TabControl.SelectedIndex = 0;
            this.TabControl.Size = new System.Drawing.Size(472, 592);
            this.TabControl.TabIndex = 10;
            this.TabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);
            // 
            // Main
            // 
            this.Main.Controls.Add(this.groupBox4);
            this.Main.Controls.Add(this.groupBox3);
            this.Main.Controls.Add(this.groupBox1);
            this.Main.Controls.Add(this.groupBox2);
            this.Main.Location = new System.Drawing.Point(4, 22);
            this.Main.Name = "Main";
            this.Main.Size = new System.Drawing.Size(464, 566);
            this.Main.TabIndex = 2;
            this.Main.Text = "Printer";
            this.Main.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ErrorResponseButton);
            this.groupBox4.Controls.Add(this.ErrorResponseCombo);
            this.groupBox4.Location = new System.Drawing.Point(282, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(175, 161);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Error Handling";
            // 
            // ErrorResponseButton
            // 
            this.ErrorResponseButton.Enabled = false;
            this.ErrorResponseButton.Location = new System.Drawing.Point(47, 46);
            this.ErrorResponseButton.Name = "ErrorResponseButton";
            this.ErrorResponseButton.Size = new System.Drawing.Size(90, 24);
            this.ErrorResponseButton.TabIndex = 22;
            this.ErrorResponseButton.Text = "ErrorResponse";
            this.ErrorResponseButton.UseVisualStyleBackColor = true;
            this.ErrorResponseButton.Click += new System.EventHandler(this.ErrorResponse_Click);
            // 
            // ErrorResponseCombo
            // 
            this.ErrorResponseCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ErrorResponseCombo.Enabled = false;
            this.ErrorResponseCombo.FormattingEnabled = true;
            this.ErrorResponseCombo.Location = new System.Drawing.Point(35, 19);
            this.ErrorResponseCombo.Name = "ErrorResponseCombo";
            this.ErrorResponseCombo.Size = new System.Drawing.Size(115, 21);
            this.ErrorResponseCombo.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ClearPrinterMsgButton);
            this.groupBox3.Controls.Add(this.PrinterMsgBox);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.PrinterSetRadio);
            this.groupBox3.Controls.Add(this.PrinterGetRadio);
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.EjectModeButton);
            this.groupBox3.Controls.Add(this.EjectModeCombo);
            this.groupBox3.Location = new System.Drawing.Point(5, 164);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(452, 402);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Printer Config";
            // 
            // ClearPrinterMsgButton
            // 
            this.ClearPrinterMsgButton.Location = new System.Drawing.Point(287, 372);
            this.ClearPrinterMsgButton.Name = "ClearPrinterMsgButton";
            this.ClearPrinterMsgButton.Size = new System.Drawing.Size(90, 24);
            this.ClearPrinterMsgButton.TabIndex = 36;
            this.ClearPrinterMsgButton.Text = "Clear";
            this.ClearPrinterMsgButton.UseVisualStyleBackColor = true;
            this.ClearPrinterMsgButton.Click += new System.EventHandler(this.ClearPrinterMsgButton_Click);
            // 
            // PrinterMsgBox
            // 
            this.PrinterMsgBox.Location = new System.Drawing.Point(219, 11);
            this.PrinterMsgBox.Multiline = true;
            this.PrinterMsgBox.Name = "PrinterMsgBox";
            this.PrinterMsgBox.ReadOnly = true;
            this.PrinterMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.PrinterMsgBox.Size = new System.Drawing.Size(227, 355);
            this.PrinterMsgBox.TabIndex = 35;
            this.PrinterMsgBox.WordWrap = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "Action:";
            // 
            // PrinterSetRadio
            // 
            this.PrinterSetRadio.AutoSize = true;
            this.PrinterSetRadio.Enabled = false;
            this.PrinterSetRadio.Location = new System.Drawing.Point(88, 21);
            this.PrinterSetRadio.Name = "PrinterSetRadio";
            this.PrinterSetRadio.Size = new System.Drawing.Size(41, 17);
            this.PrinterSetRadio.TabIndex = 29;
            this.PrinterSetRadio.Text = "Set";
            this.PrinterSetRadio.UseVisualStyleBackColor = true;
            this.PrinterSetRadio.CheckedChanged += new System.EventHandler(this.PrinterActionSet_CheckedChanged);
            // 
            // PrinterGetRadio
            // 
            this.PrinterGetRadio.AutoSize = true;
            this.PrinterGetRadio.Checked = true;
            this.PrinterGetRadio.Enabled = false;
            this.PrinterGetRadio.Location = new System.Drawing.Point(46, 21);
            this.PrinterGetRadio.Name = "PrinterGetRadio";
            this.PrinterGetRadio.Size = new System.Drawing.Size(42, 17);
            this.PrinterGetRadio.TabIndex = 28;
            this.PrinterGetRadio.TabStop = true;
            this.PrinterGetRadio.Text = "Get";
            this.PrinterGetRadio.UseVisualStyleBackColor = true;
            this.PrinterGetRadio.CheckedChanged += new System.EventHandler(this.PrinterActionGetRadio_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.IPGatewayLabel);
            this.groupBox7.Controls.Add(this.IPSubnetLabel);
            this.groupBox7.Controls.Add(this.IPAddrLabel);
            this.groupBox7.Controls.Add(this.IPGatewayBox);
            this.groupBox7.Controls.Add(this.IPSubnetBox);
            this.groupBox7.Controls.Add(this.IPAddressBox);
            this.groupBox7.Controls.Add(this.IPSettingsButton);
            this.groupBox7.Controls.Add(this.IPModeLabel);
            this.groupBox7.Controls.Add(this.IPModeCombo);
            this.groupBox7.Location = new System.Drawing.Point(0, 71);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(210, 156);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            // 
            // IPGatewayLabel
            // 
            this.IPGatewayLabel.AutoSize = true;
            this.IPGatewayLabel.Location = new System.Drawing.Point(6, 98);
            this.IPGatewayLabel.Name = "IPGatewayLabel";
            this.IPGatewayLabel.Size = new System.Drawing.Size(49, 13);
            this.IPGatewayLabel.TabIndex = 44;
            this.IPGatewayLabel.Text = "Gateway";
            // 
            // IPSubnetLabel
            // 
            this.IPSubnetLabel.AutoSize = true;
            this.IPSubnetLabel.Location = new System.Drawing.Point(6, 71);
            this.IPSubnetLabel.Name = "IPSubnetLabel";
            this.IPSubnetLabel.Size = new System.Drawing.Size(41, 13);
            this.IPSubnetLabel.TabIndex = 43;
            this.IPSubnetLabel.Text = "Subnet";
            // 
            // IPAddrLabel
            // 
            this.IPAddrLabel.AutoSize = true;
            this.IPAddrLabel.Location = new System.Drawing.Point(6, 44);
            this.IPAddrLabel.Name = "IPAddrLabel";
            this.IPAddrLabel.Size = new System.Drawing.Size(42, 13);
            this.IPAddrLabel.TabIndex = 42;
            this.IPAddrLabel.Text = "IP Addr";
            // 
            // IPGatewayBox
            // 
            this.IPGatewayBox.Enabled = false;
            this.IPGatewayBox.Location = new System.Drawing.Point(68, 94);
            this.IPGatewayBox.Name = "IPGatewayBox";
            this.IPGatewayBox.Size = new System.Drawing.Size(131, 20);
            this.IPGatewayBox.TabIndex = 41;
            this.IPGatewayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSubnetBox
            // 
            this.IPSubnetBox.Enabled = false;
            this.IPSubnetBox.Location = new System.Drawing.Point(68, 67);
            this.IPSubnetBox.Name = "IPSubnetBox";
            this.IPSubnetBox.Size = new System.Drawing.Size(131, 20);
            this.IPSubnetBox.TabIndex = 40;
            this.IPSubnetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPAddressBox
            // 
            this.IPAddressBox.Enabled = false;
            this.IPAddressBox.Location = new System.Drawing.Point(68, 40);
            this.IPAddressBox.Name = "IPAddressBox";
            this.IPAddressBox.Size = new System.Drawing.Size(131, 20);
            this.IPAddressBox.TabIndex = 26;
            this.IPAddressBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSettingsButton
            // 
            this.IPSettingsButton.Enabled = false;
            this.IPSettingsButton.Location = new System.Drawing.Point(63, 126);
            this.IPSettingsButton.Name = "IPSettingsButton";
            this.IPSettingsButton.Size = new System.Drawing.Size(90, 24);
            this.IPSettingsButton.TabIndex = 39;
            this.IPSettingsButton.Text = "IP Settings";
            this.IPSettingsButton.UseVisualStyleBackColor = true;
            this.IPSettingsButton.Click += new System.EventHandler(this.IPSettingsButton_Click);
            // 
            // IPModeLabel
            // 
            this.IPModeLabel.AutoSize = true;
            this.IPModeLabel.Location = new System.Drawing.Point(6, 16);
            this.IPModeLabel.Name = "IPModeLabel";
            this.IPModeLabel.Size = new System.Drawing.Size(34, 13);
            this.IPModeLabel.TabIndex = 37;
            this.IPModeLabel.Text = "Mode";
            // 
            // IPModeCombo
            // 
            this.IPModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.IPModeCombo.Enabled = false;
            this.IPModeCombo.FormattingEnabled = true;
            this.IPModeCombo.Location = new System.Drawing.Point(68, 12);
            this.IPModeCombo.Name = "IPModeCombo";
            this.IPModeCombo.Size = new System.Drawing.Size(131, 21);
            this.IPModeCombo.TabIndex = 38;
            // 
            // EjectModeButton
            // 
            this.EjectModeButton.Enabled = false;
            this.EjectModeButton.Location = new System.Drawing.Point(3, 41);
            this.EjectModeButton.Name = "EjectModeButton";
            this.EjectModeButton.Size = new System.Drawing.Size(90, 24);
            this.EjectModeButton.TabIndex = 21;
            this.EjectModeButton.Text = "EjectMode";
            this.EjectModeButton.UseVisualStyleBackColor = true;
            this.EjectModeButton.Click += new System.EventHandler(this.EjectModeButton_Click);
            // 
            // EjectModeCombo
            // 
            this.EjectModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EjectModeCombo.Enabled = false;
            this.EjectModeCombo.FormattingEnabled = true;
            this.EjectModeCombo.Location = new System.Drawing.Point(96, 43);
            this.EjectModeCombo.Name = "EjectModeCombo";
            this.EjectModeCombo.Size = new System.Drawing.Size(106, 21);
            this.EjectModeCombo.TabIndex = 15;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SessionConfigCombo);
            this.groupBox1.Controls.Add(this.OpenSessionButton);
            this.groupBox1.Controls.Add(this.CloseSessionButton);
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(271, 43);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // SessionConfigCombo
            // 
            this.SessionConfigCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SessionConfigCombo.FormattingEnabled = true;
            this.SessionConfigCombo.Location = new System.Drawing.Point(96, 15);
            this.SessionConfigCombo.Name = "SessionConfigCombo";
            this.SessionConfigCombo.Size = new System.Drawing.Size(155, 21);
            this.SessionConfigCombo.TabIndex = 38;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.MoveCardCombo);
            this.groupBox2.Controls.Add(this.RestartButton);
            this.groupBox2.Controls.Add(this.MoveCardButton);
            this.groupBox2.Controls.Add(this.TestCardButton);
            this.groupBox2.Controls.Add(this.CleanPrinterButton);
            this.groupBox2.Location = new System.Drawing.Point(5, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(271, 121);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Printer Control";
            // 
            // MoveCardCombo
            // 
            this.MoveCardCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MoveCardCombo.Enabled = false;
            this.MoveCardCombo.Location = new System.Drawing.Point(96, 21);
            this.MoveCardCombo.Name = "MoveCardCombo";
            this.MoveCardCombo.Size = new System.Drawing.Size(155, 21);
            this.MoveCardCombo.TabIndex = 26;
            // 
            // RestartButton
            // 
            this.RestartButton.Enabled = false;
            this.RestartButton.Location = new System.Drawing.Point(96, 43);
            this.RestartButton.Name = "RestartButton";
            this.RestartButton.Size = new System.Drawing.Size(90, 24);
            this.RestartButton.TabIndex = 24;
            this.RestartButton.Text = "RestartPrinter";
            this.RestartButton.UseVisualStyleBackColor = true;
            this.RestartButton.Click += new System.EventHandler(this.RestartButton_Click);
            // 
            // MoveCardButton
            // 
            this.MoveCardButton.Enabled = false;
            this.MoveCardButton.Location = new System.Drawing.Point(3, 19);
            this.MoveCardButton.Name = "MoveCardButton";
            this.MoveCardButton.Size = new System.Drawing.Size(90, 24);
            this.MoveCardButton.TabIndex = 17;
            this.MoveCardButton.Text = "MoveCard";
            this.MoveCardButton.UseVisualStyleBackColor = true;
            this.MoveCardButton.Click += new System.EventHandler(this.MoveCardButton_Click);
            // 
            // TestCardButton
            // 
            this.TestCardButton.Enabled = false;
            this.TestCardButton.Location = new System.Drawing.Point(3, 67);
            this.TestCardButton.Name = "TestCardButton";
            this.TestCardButton.Size = new System.Drawing.Size(90, 24);
            this.TestCardButton.TabIndex = 23;
            this.TestCardButton.Text = "PrintTestCard";
            this.TestCardButton.UseVisualStyleBackColor = true;
            this.TestCardButton.Click += new System.EventHandler(this.PrintTestCardButton_Click);
            // 
            // CleanPrinterButton
            // 
            this.CleanPrinterButton.Enabled = false;
            this.CleanPrinterButton.Location = new System.Drawing.Point(3, 43);
            this.CleanPrinterButton.Name = "CleanPrinterButton";
            this.CleanPrinterButton.Size = new System.Drawing.Size(90, 24);
            this.CleanPrinterButton.TabIndex = 20;
            this.CleanPrinterButton.Text = "CleanPrinter";
            this.CleanPrinterButton.UseVisualStyleBackColor = true;
            this.CleanPrinterButton.Click += new System.EventHandler(this.CleanPrinterButton_Click);
            // 
            // Information
            // 
            this.Information.Controls.Add(this.groupBox27);
            this.Information.Location = new System.Drawing.Point(4, 22);
            this.Information.Name = "Information";
            this.Information.Padding = new System.Windows.Forms.Padding(3);
            this.Information.Size = new System.Drawing.Size(464, 566);
            this.Information.TabIndex = 3;
            this.Information.Text = "Information";
            this.Information.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.PrinterTypeButton);
            this.groupBox27.Controls.Add(this.SDKBitsButton);
            this.groupBox27.Controls.Add(this.LastMessageButton);
            this.groupBox27.Controls.Add(this.TemperatureButton);
            this.groupBox27.Controls.Add(this.PrinterInfoButton);
            this.groupBox27.Controls.Add(this.PrinterModelButton);
            this.groupBox27.Controls.Add(this.ConnectionTypeButton);
            this.groupBox27.Controls.Add(this.SDKVersionButton);
            this.groupBox27.Controls.Add(this.ClearMsgBoxButton);
            this.groupBox27.Controls.Add(this.InfoMsgBox);
            this.groupBox27.Controls.Add(this.PrinterStatusButton);
            this.groupBox27.Location = new System.Drawing.Point(1, 6);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(460, 557);
            this.groupBox27.TabIndex = 14;
            this.groupBox27.TabStop = false;
            // 
            // PrinterTypeButton
            // 
            this.PrinterTypeButton.Location = new System.Drawing.Point(14, 74);
            this.PrinterTypeButton.Name = "PrinterTypeButton";
            this.PrinterTypeButton.Size = new System.Drawing.Size(142, 24);
            this.PrinterTypeButton.TabIndex = 18;
            this.PrinterTypeButton.Text = "PrinterType";
            this.PrinterTypeButton.UseVisualStyleBackColor = true;
            this.PrinterTypeButton.Click += new System.EventHandler(this.PrinterTypeButton_Click);
            // 
            // SDKBitsButton
            // 
            this.SDKBitsButton.Location = new System.Drawing.Point(14, 44);
            this.SDKBitsButton.Name = "SDKBitsButton";
            this.SDKBitsButton.Size = new System.Drawing.Size(142, 24);
            this.SDKBitsButton.TabIndex = 17;
            this.SDKBitsButton.Text = "SDKBits";
            this.SDKBitsButton.UseVisualStyleBackColor = true;
            this.SDKBitsButton.Click += new System.EventHandler(this.SDKBitsButton_Click);
            // 
            // LastMessageButton
            // 
            this.LastMessageButton.Location = new System.Drawing.Point(14, 254);
            this.LastMessageButton.Name = "LastMessageButton";
            this.LastMessageButton.Size = new System.Drawing.Size(142, 24);
            this.LastMessageButton.TabIndex = 16;
            this.LastMessageButton.Text = "LastMessage";
            this.LastMessageButton.UseVisualStyleBackColor = true;
            this.LastMessageButton.Click += new System.EventHandler(this.LastMessageButton_Click);
            // 
            // TemperatureButton
            // 
            this.TemperatureButton.Location = new System.Drawing.Point(14, 224);
            this.TemperatureButton.Name = "TemperatureButton";
            this.TemperatureButton.Size = new System.Drawing.Size(142, 24);
            this.TemperatureButton.TabIndex = 15;
            this.TemperatureButton.Text = "Temperature";
            this.TemperatureButton.UseVisualStyleBackColor = true;
            this.TemperatureButton.Click += new System.EventHandler(this.TemperatureButton_Click);
            // 
            // PrinterInfoButton
            // 
            this.PrinterInfoButton.Location = new System.Drawing.Point(14, 194);
            this.PrinterInfoButton.Name = "PrinterInfoButton";
            this.PrinterInfoButton.Size = new System.Drawing.Size(142, 24);
            this.PrinterInfoButton.TabIndex = 14;
            this.PrinterInfoButton.Text = "PrinterInfo";
            this.PrinterInfoButton.UseVisualStyleBackColor = true;
            this.PrinterInfoButton.Click += new System.EventHandler(this.PrinterInfoButton_Click);
            // 
            // PrinterModelButton
            // 
            this.PrinterModelButton.Location = new System.Drawing.Point(14, 104);
            this.PrinterModelButton.Name = "PrinterModelButton";
            this.PrinterModelButton.Size = new System.Drawing.Size(142, 24);
            this.PrinterModelButton.TabIndex = 13;
            this.PrinterModelButton.Text = "PrinterModel";
            this.PrinterModelButton.UseVisualStyleBackColor = true;
            this.PrinterModelButton.Click += new System.EventHandler(this.PrinterModelButton_Click);
            // 
            // ConnectionTypeButton
            // 
            this.ConnectionTypeButton.Location = new System.Drawing.Point(14, 134);
            this.ConnectionTypeButton.Name = "ConnectionTypeButton";
            this.ConnectionTypeButton.Size = new System.Drawing.Size(142, 24);
            this.ConnectionTypeButton.TabIndex = 12;
            this.ConnectionTypeButton.Text = "ConnectionType";
            this.ConnectionTypeButton.UseVisualStyleBackColor = true;
            this.ConnectionTypeButton.Click += new System.EventHandler(this.ConnectionTypeButton_Click);
            // 
            // SDKVersionButton
            // 
            this.SDKVersionButton.Location = new System.Drawing.Point(14, 14);
            this.SDKVersionButton.Name = "SDKVersionButton";
            this.SDKVersionButton.Size = new System.Drawing.Size(142, 24);
            this.SDKVersionButton.TabIndex = 11;
            this.SDKVersionButton.Text = "SDKVersion";
            this.SDKVersionButton.UseVisualStyleBackColor = true;
            this.SDKVersionButton.Click += new System.EventHandler(this.SDKVersionButton_Click);
            // 
            // ClearMsgBoxButton
            // 
            this.ClearMsgBoxButton.Location = new System.Drawing.Point(265, 527);
            this.ClearMsgBoxButton.Name = "ClearMsgBoxButton";
            this.ClearMsgBoxButton.Size = new System.Drawing.Size(90, 24);
            this.ClearMsgBoxButton.TabIndex = 10;
            this.ClearMsgBoxButton.Text = "Clear";
            this.ClearMsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearMsgBoxButton.Click += new System.EventHandler(this.ClearMsgBoxButton_Click);
            // 
            // MagEncoding
            // 
            this.MagEncoding.Controls.Add(this.groupBox5);
            this.MagEncoding.Controls.Add(this.groupBox8);
            this.MagEncoding.Controls.Add(this.groupBox9);
            this.MagEncoding.Location = new System.Drawing.Point(4, 22);
            this.MagEncoding.Name = "MagEncoding";
            this.MagEncoding.Padding = new System.Windows.Forms.Padding(3);
            this.MagEncoding.Size = new System.Drawing.Size(464, 566);
            this.MagEncoding.TabIndex = 0;
            this.MagEncoding.Text = "Encoding";
            this.MagEncoding.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.StartPosn);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.EncodingSetRadio);
            this.groupBox5.Controls.Add(this.EncodingGetRadio);
            this.groupBox5.Controls.Add(this.MagStartButton);
            this.groupBox5.Location = new System.Drawing.Point(5, 194);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(456, 51);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            // 
            // StartPosn
            // 
            this.StartPosn.Location = new System.Drawing.Point(136, 21);
            this.StartPosn.Maximum = new decimal(new int[] {
            85000,
            0,
            0,
            0});
            this.StartPosn.Name = "StartPosn";
            this.StartPosn.Size = new System.Drawing.Size(120, 20);
            this.StartPosn.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 62;
            this.label1.Text = "Start Position";
            // 
            // EncodingSetRadio
            // 
            this.EncodingSetRadio.AutoSize = true;
            this.EncodingSetRadio.Location = new System.Drawing.Point(13, 31);
            this.EncodingSetRadio.Name = "EncodingSetRadio";
            this.EncodingSetRadio.Size = new System.Drawing.Size(41, 17);
            this.EncodingSetRadio.TabIndex = 41;
            this.EncodingSetRadio.TabStop = true;
            this.EncodingSetRadio.Text = "Set";
            this.EncodingSetRadio.UseVisualStyleBackColor = true;
            this.EncodingSetRadio.CheckedChanged += new System.EventHandler(this.EncodingSetRadio_CheckedChanged);
            // 
            // EncodingGetRadio
            // 
            this.EncodingGetRadio.AutoSize = true;
            this.EncodingGetRadio.Checked = true;
            this.EncodingGetRadio.Location = new System.Drawing.Point(13, 8);
            this.EncodingGetRadio.Name = "EncodingGetRadio";
            this.EncodingGetRadio.Size = new System.Drawing.Size(42, 17);
            this.EncodingGetRadio.TabIndex = 40;
            this.EncodingGetRadio.TabStop = true;
            this.EncodingGetRadio.Text = "Get";
            this.EncodingGetRadio.UseVisualStyleBackColor = true;
            // 
            // MagStartButton
            // 
            this.MagStartButton.Location = new System.Drawing.Point(339, 19);
            this.MagStartButton.Name = "MagStartButton";
            this.MagStartButton.Size = new System.Drawing.Size(111, 24);
            this.MagStartButton.TabIndex = 12;
            this.MagStartButton.Text = "MagStart";
            this.MagStartButton.UseVisualStyleBackColor = true;
            this.MagStartButton.Click += new System.EventHandler(this.MagStartButton_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.Track3Read);
            this.groupBox8.Controls.Add(this.Track2Read);
            this.groupBox8.Controls.Add(this.Track1Read);
            this.groupBox8.Controls.Add(this.ReadMagTracks);
            this.groupBox8.Controls.Add(this.EncodingBox);
            this.groupBox8.Controls.Add(this.ReadMagButton);
            this.groupBox8.Controls.Add(this.ClearEncodingBoxButton);
            this.groupBox8.Location = new System.Drawing.Point(6, 254);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(456, 306);
            this.groupBox8.TabIndex = 15;
            this.groupBox8.TabStop = false;
            // 
            // Track3Read
            // 
            this.Track3Read.AutoSize = true;
            this.Track3Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track3Read.Checked = true;
            this.Track3Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track3Read.Location = new System.Drawing.Point(2, 54);
            this.Track3Read.Name = "Track3Read";
            this.Track3Read.Size = new System.Drawing.Size(63, 17);
            this.Track3Read.TabIndex = 64;
            this.Track3Read.Text = "Track 3";
            this.Track3Read.UseVisualStyleBackColor = true;
            // 
            // Track2Read
            // 
            this.Track2Read.AutoSize = true;
            this.Track2Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track2Read.Checked = true;
            this.Track2Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track2Read.Location = new System.Drawing.Point(2, 33);
            this.Track2Read.Name = "Track2Read";
            this.Track2Read.Size = new System.Drawing.Size(63, 17);
            this.Track2Read.TabIndex = 63;
            this.Track2Read.Text = "Track 2";
            this.Track2Read.UseVisualStyleBackColor = true;
            // 
            // Track1Read
            // 
            this.Track1Read.AutoSize = true;
            this.Track1Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track1Read.Checked = true;
            this.Track1Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track1Read.Location = new System.Drawing.Point(2, 10);
            this.Track1Read.Name = "Track1Read";
            this.Track1Read.Size = new System.Drawing.Size(63, 17);
            this.Track1Read.TabIndex = 62;
            this.Track1Read.Text = "Track 1";
            this.Track1Read.UseVisualStyleBackColor = true;
            // 
            // ReadMagTracks
            // 
            this.ReadMagTracks.Location = new System.Drawing.Point(79, 29);
            this.ReadMagTracks.Name = "ReadMagTracks";
            this.ReadMagTracks.Size = new System.Drawing.Size(144, 24);
            this.ReadMagTracks.TabIndex = 13;
            this.ReadMagTracks.Text = "ReadMagTracks";
            this.ReadMagTracks.UseVisualStyleBackColor = true;
            this.ReadMagTracks.Click += new System.EventHandler(this.ReadMagTracks_Click);
            // 
            // EncodingBox
            // 
            this.EncodingBox.Location = new System.Drawing.Point(6, 77);
            this.EncodingBox.Multiline = true;
            this.EncodingBox.Name = "EncodingBox";
            this.EncodingBox.ReadOnly = true;
            this.EncodingBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.EncodingBox.Size = new System.Drawing.Size(444, 193);
            this.EncodingBox.TabIndex = 8;
            this.EncodingBox.WordWrap = false;
            // 
            // ReadMagButton
            // 
            this.ReadMagButton.Location = new System.Drawing.Point(339, 29);
            this.ReadMagButton.Name = "ReadMagButton";
            this.ReadMagButton.Size = new System.Drawing.Size(111, 24);
            this.ReadMagButton.TabIndex = 11;
            this.ReadMagButton.Text = "ReadMag";
            this.ReadMagButton.UseVisualStyleBackColor = true;
            this.ReadMagButton.Click += new System.EventHandler(this.ReadMagButton_Click);
            // 
            // ClearEncodingBoxButton
            // 
            this.ClearEncodingBoxButton.Location = new System.Drawing.Point(182, 276);
            this.ClearEncodingBoxButton.Name = "ClearEncodingBoxButton";
            this.ClearEncodingBoxButton.Size = new System.Drawing.Size(90, 24);
            this.ClearEncodingBoxButton.TabIndex = 12;
            this.ClearEncodingBoxButton.Text = "Clear";
            this.ClearEncodingBoxButton.UseVisualStyleBackColor = true;
            this.ClearEncodingBoxButton.Click += new System.EventHandler(this.ClearEncodingBoxButton_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label112);
            this.groupBox9.Controls.Add(this.BitsPerInchLabel);
            this.groupBox9.Controls.Add(this.BitsPerCharLabel);
            this.groupBox9.Controls.Add(this.T1_BPICombo);
            this.groupBox9.Controls.Add(this.Track3SettingsLabel);
            this.groupBox9.Controls.Add(this.Track2SettingsLabel);
            this.groupBox9.Controls.Add(this.Track1SettingsLabel);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.JIS2Label);
            this.groupBox9.Controls.Add(this.Track3Label);
            this.groupBox9.Controls.Add(this.Track2Label);
            this.groupBox9.Controls.Add(this.Track1Data);
            this.groupBox9.Controls.Add(this.Track2Data);
            this.groupBox9.Controls.Add(this.Track3Data);
            this.groupBox9.Controls.Add(this.Track1Write);
            this.groupBox9.Controls.Add(this.Track2Write);
            this.groupBox9.Controls.Add(this.Track3Write);
            this.groupBox9.Controls.Add(this.EncodingTypeCombo);
            this.groupBox9.Controls.Add(this.CoercivityCombo);
            this.groupBox9.Controls.Add(this.Verify);
            this.groupBox9.Controls.Add(this.T1_BPCCombo);
            this.groupBox9.Controls.Add(this.T2_BPCCombo);
            this.groupBox9.Controls.Add(this.T2_BPICombo);
            this.groupBox9.Controls.Add(this.T3_BPCCombo);
            this.groupBox9.Controls.Add(this.T3_BPICombo);
            this.groupBox9.Controls.Add(this.EncodeMagButton);
            this.groupBox9.Controls.Add(this.Track1Label);
            this.groupBox9.Location = new System.Drawing.Point(5, 5);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(456, 183);
            this.groupBox9.TabIndex = 16;
            this.groupBox9.TabStop = false;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(133, 20);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(53, 13);
            this.label112.TabIndex = 60;
            this.label112.Text = "Coercivity";
            // 
            // BitsPerInchLabel
            // 
            this.BitsPerInchLabel.AutoSize = true;
            this.BitsPerInchLabel.Location = new System.Drawing.Point(5, 158);
            this.BitsPerInchLabel.Name = "BitsPerInchLabel";
            this.BitsPerInchLabel.Size = new System.Drawing.Size(67, 13);
            this.BitsPerInchLabel.TabIndex = 57;
            this.BitsPerInchLabel.Text = "Bits Per Inch";
            // 
            // BitsPerCharLabel
            // 
            this.BitsPerCharLabel.AutoSize = true;
            this.BitsPerCharLabel.Location = new System.Drawing.Point(5, 129);
            this.BitsPerCharLabel.Name = "BitsPerCharLabel";
            this.BitsPerCharLabel.Size = new System.Drawing.Size(68, 13);
            this.BitsPerCharLabel.TabIndex = 56;
            this.BitsPerCharLabel.Text = "Bits Per Char";
            // 
            // T1_BPICombo
            // 
            this.T1_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPICombo.Location = new System.Drawing.Point(79, 154);
            this.T1_BPICombo.Name = "T1_BPICombo";
            this.T1_BPICombo.Size = new System.Drawing.Size(78, 21);
            this.T1_BPICombo.TabIndex = 33;
            // 
            // Track3SettingsLabel
            // 
            this.Track3SettingsLabel.AutoSize = true;
            this.Track3SettingsLabel.Enabled = false;
            this.Track3SettingsLabel.Location = new System.Drawing.Point(264, 110);
            this.Track3SettingsLabel.Name = "Track3SettingsLabel";
            this.Track3SettingsLabel.Size = new System.Drawing.Size(44, 13);
            this.Track3SettingsLabel.TabIndex = 55;
            this.Track3SettingsLabel.Text = "Track 3";
            // 
            // Track2SettingsLabel
            // 
            this.Track2SettingsLabel.AutoSize = true;
            this.Track2SettingsLabel.Enabled = false;
            this.Track2SettingsLabel.Location = new System.Drawing.Point(180, 110);
            this.Track2SettingsLabel.Name = "Track2SettingsLabel";
            this.Track2SettingsLabel.Size = new System.Drawing.Size(44, 13);
            this.Track2SettingsLabel.TabIndex = 54;
            this.Track2SettingsLabel.Text = "Track 2";
            // 
            // Track1SettingsLabel
            // 
            this.Track1SettingsLabel.AutoSize = true;
            this.Track1SettingsLabel.Location = new System.Drawing.Point(96, 110);
            this.Track1SettingsLabel.Name = "Track1SettingsLabel";
            this.Track1SettingsLabel.Size = new System.Drawing.Size(44, 13);
            this.Track1SettingsLabel.TabIndex = 53;
            this.Track1SettingsLabel.Text = "Track 1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 52;
            this.label13.Text = "Type";
            // 
            // JIS2Label
            // 
            this.JIS2Label.AutoSize = true;
            this.JIS2Label.Location = new System.Drawing.Point(8, 44);
            this.JIS2Label.Name = "JIS2Label";
            this.JIS2Label.Size = new System.Drawing.Size(30, 13);
            this.JIS2Label.TabIndex = 51;
            this.JIS2Label.Text = "Data";
            this.JIS2Label.Visible = false;
            // 
            // Track3Label
            // 
            this.Track3Label.AutoSize = true;
            this.Track3Label.Enabled = false;
            this.Track3Label.Location = new System.Drawing.Point(8, 90);
            this.Track3Label.Name = "Track3Label";
            this.Track3Label.Size = new System.Drawing.Size(44, 13);
            this.Track3Label.TabIndex = 50;
            this.Track3Label.Text = "Track 3";
            // 
            // Track2Label
            // 
            this.Track2Label.AutoSize = true;
            this.Track2Label.Enabled = false;
            this.Track2Label.Location = new System.Drawing.Point(8, 67);
            this.Track2Label.Name = "Track2Label";
            this.Track2Label.Size = new System.Drawing.Size(44, 13);
            this.Track2Label.TabIndex = 48;
            this.Track2Label.Text = "Track 2";
            // 
            // Track1Data
            // 
            this.Track1Data.Location = new System.Drawing.Point(79, 41);
            this.Track1Data.Name = "Track1Data";
            this.Track1Data.Size = new System.Drawing.Size(371, 20);
            this.Track1Data.TabIndex = 18;
            this.Track1Data.Text = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
            // 
            // Track2Data
            // 
            this.Track2Data.Enabled = false;
            this.Track2Data.Location = new System.Drawing.Point(79, 64);
            this.Track2Data.Name = "Track2Data";
            this.Track2Data.Size = new System.Drawing.Size(371, 20);
            this.Track2Data.TabIndex = 13;
            // 
            // Track3Data
            // 
            this.Track3Data.Enabled = false;
            this.Track3Data.Location = new System.Drawing.Point(79, 87);
            this.Track3Data.Name = "Track3Data";
            this.Track3Data.Size = new System.Drawing.Size(371, 20);
            this.Track3Data.TabIndex = 19;
            // 
            // Track1Write
            // 
            this.Track1Write.AutoSize = true;
            this.Track1Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track1Write.Checked = true;
            this.Track1Write.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track1Write.Location = new System.Drawing.Point(56, 43);
            this.Track1Write.Name = "Track1Write";
            this.Track1Write.Size = new System.Drawing.Size(15, 14);
            this.Track1Write.TabIndex = 14;
            this.Track1Write.UseVisualStyleBackColor = true;
            this.Track1Write.CheckedChanged += new System.EventHandler(this.Track1Write_CheckedChanged);
            // 
            // Track2Write
            // 
            this.Track2Write.AutoSize = true;
            this.Track2Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track2Write.Location = new System.Drawing.Point(56, 66);
            this.Track2Write.Name = "Track2Write";
            this.Track2Write.Size = new System.Drawing.Size(15, 14);
            this.Track2Write.TabIndex = 16;
            this.Track2Write.UseVisualStyleBackColor = true;
            this.Track2Write.CheckedChanged += new System.EventHandler(this.Track2Write_CheckedChanged);
            // 
            // Track3Write
            // 
            this.Track3Write.AutoSize = true;
            this.Track3Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track3Write.Location = new System.Drawing.Point(56, 89);
            this.Track3Write.Name = "Track3Write";
            this.Track3Write.Size = new System.Drawing.Size(15, 14);
            this.Track3Write.TabIndex = 17;
            this.Track3Write.UseVisualStyleBackColor = true;
            this.Track3Write.CheckedChanged += new System.EventHandler(this.Track3Write_CheckedChanged);
            // 
            // EncodingTypeCombo
            // 
            this.EncodingTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EncodingTypeCombo.Location = new System.Drawing.Point(47, 16);
            this.EncodingTypeCombo.Name = "EncodingTypeCombo";
            this.EncodingTypeCombo.Size = new System.Drawing.Size(59, 21);
            this.EncodingTypeCombo.TabIndex = 24;
            this.EncodingTypeCombo.SelectedIndexChanged += new System.EventHandler(this.EncodingTypeBox_SelectedIndexChanged);
            // 
            // CoercivityCombo
            // 
            this.CoercivityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoercivityCombo.Location = new System.Drawing.Point(194, 16);
            this.CoercivityCombo.Name = "CoercivityCombo";
            this.CoercivityCombo.Size = new System.Drawing.Size(186, 21);
            this.CoercivityCombo.TabIndex = 26;
            // 
            // Verify
            // 
            this.Verify.AutoSize = true;
            this.Verify.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Verify.Checked = true;
            this.Verify.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Verify.Location = new System.Drawing.Point(398, 18);
            this.Verify.Name = "Verify";
            this.Verify.Size = new System.Drawing.Size(52, 17);
            this.Verify.TabIndex = 27;
            this.Verify.Text = "Verify";
            this.Verify.UseVisualStyleBackColor = true;
            // 
            // T1_BPCCombo
            // 
            this.T1_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPCCombo.Location = new System.Drawing.Point(79, 126);
            this.T1_BPCCombo.Name = "T1_BPCCombo";
            this.T1_BPCCombo.Size = new System.Drawing.Size(78, 21);
            this.T1_BPCCombo.TabIndex = 28;
            // 
            // T2_BPCCombo
            // 
            this.T2_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPCCombo.Enabled = false;
            this.T2_BPCCombo.Location = new System.Drawing.Point(163, 126);
            this.T2_BPCCombo.Name = "T2_BPCCombo";
            this.T2_BPCCombo.Size = new System.Drawing.Size(78, 21);
            this.T2_BPCCombo.TabIndex = 36;
            // 
            // T2_BPICombo
            // 
            this.T2_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPICombo.Enabled = false;
            this.T2_BPICombo.Location = new System.Drawing.Point(163, 153);
            this.T2_BPICombo.Name = "T2_BPICombo";
            this.T2_BPICombo.Size = new System.Drawing.Size(78, 21);
            this.T2_BPICombo.TabIndex = 38;
            // 
            // T3_BPCCombo
            // 
            this.T3_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_BPCCombo.Enabled = false;
            this.T3_BPCCombo.Location = new System.Drawing.Point(247, 126);
            this.T3_BPCCombo.Name = "T3_BPCCombo";
            this.T3_BPCCombo.Size = new System.Drawing.Size(78, 21);
            this.T3_BPCCombo.TabIndex = 37;
            // 
            // T3_BPICombo
            // 
            this.T3_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_BPICombo.Enabled = false;
            this.T3_BPICombo.Location = new System.Drawing.Point(247, 153);
            this.T3_BPICombo.Name = "T3_BPICombo";
            this.T3_BPICombo.Size = new System.Drawing.Size(78, 21);
            this.T3_BPICombo.TabIndex = 39;
            // 
            // EncodeMagButton
            // 
            this.EncodeMagButton.Location = new System.Drawing.Point(339, 138);
            this.EncodeMagButton.Name = "EncodeMagButton";
            this.EncodeMagButton.Size = new System.Drawing.Size(111, 24);
            this.EncodeMagButton.TabIndex = 10;
            this.EncodeMagButton.Text = "EncodeMag";
            this.EncodeMagButton.UseVisualStyleBackColor = true;
            this.EncodeMagButton.Click += new System.EventHandler(this.EncodeMagButton_Click);
            // 
            // Track1Label
            // 
            this.Track1Label.AutoSize = true;
            this.Track1Label.Location = new System.Drawing.Point(8, 44);
            this.Track1Label.Name = "Track1Label";
            this.Track1Label.Size = new System.Drawing.Size(44, 13);
            this.Track1Label.TabIndex = 61;
            this.Track1Label.Text = "Track 1";
            // 
            // DriverSettings1
            // 
            this.DriverSettings1.Controls.Add(this.groupBox23);
            this.DriverSettings1.Controls.Add(this.GUIPrinter);
            this.DriverSettings1.Controls.Add(this.GUIUser);
            this.DriverSettings1.Controls.Add(this.groupBox11);
            this.DriverSettings1.Controls.Add(this.groupBox10);
            this.DriverSettings1.Controls.Add(this.ColourCorrectionButton);
            this.DriverSettings1.Controls.Add(this.CorrectionCombo);
            this.DriverSettings1.Controls.Add(this.SharpnessUpDown);
            this.DriverSettings1.Controls.Add(this.GUIControlButton);
            this.DriverSettings1.Controls.Add(this.SharpnessButton);
            this.DriverSettings1.Controls.Add(this.label16);
            this.DriverSettings1.Controls.Add(this.Driver1SetRadio);
            this.DriverSettings1.Controls.Add(this.Driver1GetRadio);
            this.DriverSettings1.Controls.Add(this.ClearDriver1MsgBoxButton);
            this.DriverSettings1.Controls.Add(this.Driver1MsgBox);
            this.DriverSettings1.Location = new System.Drawing.Point(4, 22);
            this.DriverSettings1.Name = "DriverSettings1";
            this.DriverSettings1.Padding = new System.Windows.Forms.Padding(3);
            this.DriverSettings1.Size = new System.Drawing.Size(464, 566);
            this.DriverSettings1.TabIndex = 5;
            this.DriverSettings1.Text = "Driver 1";
            this.DriverSettings1.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label86);
            this.groupBox23.Controls.Add(this.ColourAreaHeightUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaBottomUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaWidthUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaLeftUpDown);
            this.groupBox23.Controls.Add(this.label107);
            this.groupBox23.Controls.Add(this.label108);
            this.groupBox23.Controls.Add(this.label109);
            this.groupBox23.Controls.Add(this.ColourAreaNo);
            this.groupBox23.Controls.Add(this.ColourAreaSideCombo);
            this.groupBox23.Controls.Add(this.label85);
            this.groupBox23.Controls.Add(this.ColourAreaCorrectionCombo);
            this.groupBox23.Controls.Add(this.label106);
            this.groupBox23.Controls.Add(this.ColourAreaButton);
            this.groupBox23.Location = new System.Drawing.Point(3, 281);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(191, 123);
            this.groupBox23.TabIndex = 69;
            this.groupBox23.TabStop = false;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(153, 58);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(15, 13);
            this.label86.TabIndex = 78;
            this.label86.Text = "H";
            // 
            // ColourAreaHeightUpDown
            // 
            this.ColourAreaHeightUpDown.Enabled = false;
            this.ColourAreaHeightUpDown.Location = new System.Drawing.Point(138, 73);
            this.ColourAreaHeightUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ColourAreaHeightUpDown.Name = "ColourAreaHeightUpDown";
            this.ColourAreaHeightUpDown.Size = new System.Drawing.Size(45, 20);
            this.ColourAreaHeightUpDown.TabIndex = 77;
            this.ColourAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaBottomUpDown
            // 
            this.ColourAreaBottomUpDown.Enabled = false;
            this.ColourAreaBottomUpDown.Location = new System.Drawing.Point(93, 73);
            this.ColourAreaBottomUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ColourAreaBottomUpDown.Name = "ColourAreaBottomUpDown";
            this.ColourAreaBottomUpDown.Size = new System.Drawing.Size(45, 20);
            this.ColourAreaBottomUpDown.TabIndex = 76;
            this.ColourAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaWidthUpDown
            // 
            this.ColourAreaWidthUpDown.Enabled = false;
            this.ColourAreaWidthUpDown.Location = new System.Drawing.Point(48, 73);
            this.ColourAreaWidthUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ColourAreaWidthUpDown.Name = "ColourAreaWidthUpDown";
            this.ColourAreaWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.ColourAreaWidthUpDown.TabIndex = 75;
            this.ColourAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaLeftUpDown
            // 
            this.ColourAreaLeftUpDown.Enabled = false;
            this.ColourAreaLeftUpDown.Location = new System.Drawing.Point(3, 73);
            this.ColourAreaLeftUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ColourAreaLeftUpDown.Name = "ColourAreaLeftUpDown";
            this.ColourAreaLeftUpDown.Size = new System.Drawing.Size(45, 20);
            this.ColourAreaLeftUpDown.TabIndex = 71;
            this.ColourAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(108, 58);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(14, 13);
            this.label107.TabIndex = 74;
            this.label107.Text = "B";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(61, 58);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(18, 13);
            this.label108.TabIndex = 73;
            this.label108.Text = "W";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(19, 58);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(13, 13);
            this.label109.TabIndex = 72;
            this.label109.Text = "L";
            // 
            // ColourAreaNo
            // 
            this.ColourAreaNo.Location = new System.Drawing.Point(136, 12);
            this.ColourAreaNo.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ColourAreaNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ColourAreaNo.Name = "ColourAreaNo";
            this.ColourAreaNo.Size = new System.Drawing.Size(49, 20);
            this.ColourAreaNo.TabIndex = 70;
            this.ColourAreaNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAreaNo.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // ColourAreaSideCombo
            // 
            this.ColourAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAreaSideCombo.FormattingEnabled = true;
            this.ColourAreaSideCombo.Location = new System.Drawing.Point(37, 12);
            this.ColourAreaSideCombo.Name = "ColourAreaSideCombo";
            this.ColourAreaSideCombo.Size = new System.Drawing.Size(84, 21);
            this.ColourAreaSideCombo.TabIndex = 63;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(6, 16);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(28, 13);
            this.label85.TabIndex = 62;
            this.label85.Text = "Side";
            // 
            // ColourAreaCorrectionCombo
            // 
            this.ColourAreaCorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAreaCorrectionCombo.Enabled = false;
            this.ColourAreaCorrectionCombo.FormattingEnabled = true;
            this.ColourAreaCorrectionCombo.Location = new System.Drawing.Point(84, 37);
            this.ColourAreaCorrectionCombo.Name = "ColourAreaCorrectionCombo";
            this.ColourAreaCorrectionCombo.Size = new System.Drawing.Size(101, 21);
            this.ColourAreaCorrectionCombo.TabIndex = 56;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(6, 41);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(55, 13);
            this.label106.TabIndex = 56;
            this.label106.Text = "Correction";
            // 
            // ColourAreaButton
            // 
            this.ColourAreaButton.Location = new System.Drawing.Point(54, 97);
            this.ColourAreaButton.Name = "ColourAreaButton";
            this.ColourAreaButton.Size = new System.Drawing.Size(90, 24);
            this.ColourAreaButton.TabIndex = 50;
            this.ColourAreaButton.Text = "Colour Area";
            this.ColourAreaButton.UseVisualStyleBackColor = true;
            this.ColourAreaButton.Click += new System.EventHandler(this.ColourAreaButton_Click);
            // 
            // GUIPrinter
            // 
            this.GUIPrinter.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GUIPrinter.Enabled = false;
            this.GUIPrinter.Location = new System.Drawing.Point(144, 22);
            this.GUIPrinter.Name = "GUIPrinter";
            this.GUIPrinter.Size = new System.Drawing.Size(57, 24);
            this.GUIPrinter.TabIndex = 68;
            this.GUIPrinter.Text = "Printer";
            this.GUIPrinter.UseVisualStyleBackColor = true;
            // 
            // GUIUser
            // 
            this.GUIUser.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GUIUser.Enabled = false;
            this.GUIUser.Location = new System.Drawing.Point(96, 22);
            this.GUIUser.Name = "GUIUser";
            this.GUIUser.Size = new System.Drawing.Size(48, 24);
            this.GUIUser.TabIndex = 67;
            this.GUIUser.Text = "User";
            this.GUIUser.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label26);
            this.groupBox11.Controls.Add(this.ResinAreaHeightUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaNoUpDown);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Controls.Add(this.ResinAreaSideCombo);
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.ResinAreaBottomUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaWidthUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaLeftUpDown);
            this.groupBox11.Controls.Add(this.label21);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Controls.Add(this.ResinAreaButton);
            this.groupBox11.Location = new System.Drawing.Point(3, 177);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(191, 98);
            this.groupBox11.TabIndex = 55;
            this.groupBox11.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(153, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(15, 13);
            this.label26.TabIndex = 59;
            this.label26.Text = "H";
            // 
            // ResinAreaHeightUpDown
            // 
            this.ResinAreaHeightUpDown.Enabled = false;
            this.ResinAreaHeightUpDown.Location = new System.Drawing.Point(138, 48);
            this.ResinAreaHeightUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ResinAreaHeightUpDown.Name = "ResinAreaHeightUpDown";
            this.ResinAreaHeightUpDown.Size = new System.Drawing.Size(45, 20);
            this.ResinAreaHeightUpDown.TabIndex = 58;
            this.ResinAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaNoUpDown
            // 
            this.ResinAreaNoUpDown.Location = new System.Drawing.Point(134, 9);
            this.ResinAreaNoUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ResinAreaNoUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ResinAreaNoUpDown.Name = "ResinAreaNoUpDown";
            this.ResinAreaNoUpDown.Size = new System.Drawing.Size(49, 20);
            this.ResinAreaNoUpDown.TabIndex = 56;
            this.ResinAreaNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ResinAreaNoUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(104, 13);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(24, 13);
            this.label25.TabIndex = 57;
            this.label25.Text = "No.";
            // 
            // ResinAreaSideCombo
            // 
            this.ResinAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResinAreaSideCombo.FormattingEnabled = true;
            this.ResinAreaSideCombo.Location = new System.Drawing.Point(37, 9);
            this.ResinAreaSideCombo.Name = "ResinAreaSideCombo";
            this.ResinAreaSideCombo.Size = new System.Drawing.Size(61, 21);
            this.ResinAreaSideCombo.TabIndex = 56;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 13);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(28, 13);
            this.label24.TabIndex = 56;
            this.label24.Text = "Side";
            // 
            // ResinAreaBottomUpDown
            // 
            this.ResinAreaBottomUpDown.Enabled = false;
            this.ResinAreaBottomUpDown.Location = new System.Drawing.Point(93, 48);
            this.ResinAreaBottomUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ResinAreaBottomUpDown.Name = "ResinAreaBottomUpDown";
            this.ResinAreaBottomUpDown.Size = new System.Drawing.Size(45, 20);
            this.ResinAreaBottomUpDown.TabIndex = 54;
            this.ResinAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaWidthUpDown
            // 
            this.ResinAreaWidthUpDown.Enabled = false;
            this.ResinAreaWidthUpDown.Location = new System.Drawing.Point(48, 48);
            this.ResinAreaWidthUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ResinAreaWidthUpDown.Name = "ResinAreaWidthUpDown";
            this.ResinAreaWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.ResinAreaWidthUpDown.TabIndex = 53;
            this.ResinAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaLeftUpDown
            // 
            this.ResinAreaLeftUpDown.Enabled = false;
            this.ResinAreaLeftUpDown.Location = new System.Drawing.Point(3, 48);
            this.ResinAreaLeftUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ResinAreaLeftUpDown.Name = "ResinAreaLeftUpDown";
            this.ResinAreaLeftUpDown.Size = new System.Drawing.Size(45, 20);
            this.ResinAreaLeftUpDown.TabIndex = 50;
            this.ResinAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(108, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(14, 13);
            this.label21.TabIndex = 52;
            this.label21.Text = "B";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(61, 33);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 13);
            this.label22.TabIndex = 51;
            this.label22.Text = "W";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(19, 33);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 13);
            this.label23.TabIndex = 50;
            this.label23.Text = "L";
            // 
            // ResinAreaButton
            // 
            this.ResinAreaButton.Location = new System.Drawing.Point(57, 70);
            this.ResinAreaButton.Name = "ResinAreaButton";
            this.ResinAreaButton.Size = new System.Drawing.Size(90, 24);
            this.ResinAreaButton.TabIndex = 50;
            this.ResinAreaButton.Text = "ResinArea";
            this.ResinAreaButton.UseVisualStyleBackColor = true;
            this.ResinAreaButton.Click += new System.EventHandler(this.ResinAreaButton_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.OvercoatPowerUpDown);
            this.groupBox10.Controls.Add(this.ResinPowerUpDown);
            this.groupBox10.Controls.Add(this.YMCPowerUpDown);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.PowerLevelButton);
            this.groupBox10.Location = new System.Drawing.Point(3, 99);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(191, 76);
            this.groupBox10.TabIndex = 49;
            this.groupBox10.TabStop = false;
            // 
            // OvercoatPowerUpDown
            // 
            this.OvercoatPowerUpDown.Enabled = false;
            this.OvercoatPowerUpDown.Location = new System.Drawing.Point(125, 26);
            this.OvercoatPowerUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.OvercoatPowerUpDown.Name = "OvercoatPowerUpDown";
            this.OvercoatPowerUpDown.Size = new System.Drawing.Size(61, 20);
            this.OvercoatPowerUpDown.TabIndex = 54;
            this.OvercoatPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinPowerUpDown
            // 
            this.ResinPowerUpDown.Enabled = false;
            this.ResinPowerUpDown.Location = new System.Drawing.Point(64, 26);
            this.ResinPowerUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ResinPowerUpDown.Name = "ResinPowerUpDown";
            this.ResinPowerUpDown.Size = new System.Drawing.Size(61, 20);
            this.ResinPowerUpDown.TabIndex = 53;
            this.ResinPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // YMCPowerUpDown
            // 
            this.YMCPowerUpDown.Enabled = false;
            this.YMCPowerUpDown.Location = new System.Drawing.Point(3, 26);
            this.YMCPowerUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.YMCPowerUpDown.Name = "YMCPowerUpDown";
            this.YMCPowerUpDown.Size = new System.Drawing.Size(61, 20);
            this.YMCPowerUpDown.TabIndex = 50;
            this.YMCPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(132, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 13);
            this.label20.TabIndex = 52;
            this.label20.Text = "Overcoat";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(82, 11);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(14, 13);
            this.label19.TabIndex = 51;
            this.label19.Text = "K";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 13);
            this.label18.TabIndex = 50;
            this.label18.Text = "YMC";
            // 
            // PowerLevelButton
            // 
            this.PowerLevelButton.Location = new System.Drawing.Point(57, 48);
            this.PowerLevelButton.Name = "PowerLevelButton";
            this.PowerLevelButton.Size = new System.Drawing.Size(90, 24);
            this.PowerLevelButton.TabIndex = 50;
            this.PowerLevelButton.Text = "Power Level";
            this.PowerLevelButton.UseVisualStyleBackColor = true;
            this.PowerLevelButton.Click += new System.EventHandler(this.PowerLevelButton_Click);
            // 
            // ColourCorrectionButton
            // 
            this.ColourCorrectionButton.Location = new System.Drawing.Point(5, 70);
            this.ColourCorrectionButton.Name = "ColourCorrectionButton";
            this.ColourCorrectionButton.Size = new System.Drawing.Size(90, 24);
            this.ColourCorrectionButton.TabIndex = 45;
            this.ColourCorrectionButton.Text = "Colour Corr.";
            this.ColourCorrectionButton.UseVisualStyleBackColor = true;
            this.ColourCorrectionButton.Click += new System.EventHandler(this.ColourCorrectionButton_Click);
            // 
            // CorrectionCombo
            // 
            this.CorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CorrectionCombo.Enabled = false;
            this.CorrectionCombo.FormattingEnabled = true;
            this.CorrectionCombo.Location = new System.Drawing.Point(101, 72);
            this.CorrectionCombo.Name = "CorrectionCombo";
            this.CorrectionCombo.Size = new System.Drawing.Size(95, 21);
            this.CorrectionCombo.TabIndex = 46;
            // 
            // SharpnessUpDown
            // 
            this.SharpnessUpDown.Enabled = false;
            this.SharpnessUpDown.Location = new System.Drawing.Point(101, 48);
            this.SharpnessUpDown.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.SharpnessUpDown.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.SharpnessUpDown.Name = "SharpnessUpDown";
            this.SharpnessUpDown.ReadOnly = true;
            this.SharpnessUpDown.Size = new System.Drawing.Size(95, 20);
            this.SharpnessUpDown.TabIndex = 41;
            this.SharpnessUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // GUIControlButton
            // 
            this.GUIControlButton.Location = new System.Drawing.Point(5, 22);
            this.GUIControlButton.Name = "GUIControlButton";
            this.GUIControlButton.Size = new System.Drawing.Size(90, 24);
            this.GUIControlButton.TabIndex = 42;
            this.GUIControlButton.Text = "GUI Control";
            this.GUIControlButton.UseVisualStyleBackColor = true;
            this.GUIControlButton.Click += new System.EventHandler(this.GUIControlButton_Click);
            // 
            // SharpnessButton
            // 
            this.SharpnessButton.Location = new System.Drawing.Point(5, 46);
            this.SharpnessButton.Name = "SharpnessButton";
            this.SharpnessButton.Size = new System.Drawing.Size(90, 24);
            this.SharpnessButton.TabIndex = 44;
            this.SharpnessButton.Text = "Sharpness";
            this.SharpnessButton.UseVisualStyleBackColor = true;
            this.SharpnessButton.Click += new System.EventHandler(this.SharpnessButton_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(29, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "Action:";
            // 
            // Driver1SetRadio
            // 
            this.Driver1SetRadio.AutoSize = true;
            this.Driver1SetRadio.Location = new System.Drawing.Point(111, 4);
            this.Driver1SetRadio.Name = "Driver1SetRadio";
            this.Driver1SetRadio.Size = new System.Drawing.Size(41, 17);
            this.Driver1SetRadio.TabIndex = 39;
            this.Driver1SetRadio.TabStop = true;
            this.Driver1SetRadio.Text = "Set";
            this.Driver1SetRadio.UseVisualStyleBackColor = true;
            this.Driver1SetRadio.CheckedChanged += new System.EventHandler(this.Driver1ActionSetRadio_CheckedChanged);
            // 
            // Driver1GetRadio
            // 
            this.Driver1GetRadio.AutoSize = true;
            this.Driver1GetRadio.Checked = true;
            this.Driver1GetRadio.Location = new System.Drawing.Point(69, 4);
            this.Driver1GetRadio.Name = "Driver1GetRadio";
            this.Driver1GetRadio.Size = new System.Drawing.Size(42, 17);
            this.Driver1GetRadio.TabIndex = 38;
            this.Driver1GetRadio.TabStop = true;
            this.Driver1GetRadio.Text = "Get";
            this.Driver1GetRadio.UseVisualStyleBackColor = true;
            this.Driver1GetRadio.CheckedChanged += new System.EventHandler(this.Driver1ActionGetRadio_CheckedChanged);
            // 
            // ClearDriver1MsgBoxButton
            // 
            this.ClearDriver1MsgBoxButton.Location = new System.Drawing.Point(295, 539);
            this.ClearDriver1MsgBoxButton.Name = "ClearDriver1MsgBoxButton";
            this.ClearDriver1MsgBoxButton.Size = new System.Drawing.Size(90, 24);
            this.ClearDriver1MsgBoxButton.TabIndex = 37;
            this.ClearDriver1MsgBoxButton.Text = "Clear";
            this.ClearDriver1MsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearDriver1MsgBoxButton.Click += new System.EventHandler(this.ClearDriver1MsgBoxButton_Click);
            // 
            // Driver1MsgBox
            // 
            this.Driver1MsgBox.Location = new System.Drawing.Point(202, 6);
            this.Driver1MsgBox.Multiline = true;
            this.Driver1MsgBox.Name = "Driver1MsgBox";
            this.Driver1MsgBox.ReadOnly = true;
            this.Driver1MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Driver1MsgBox.Size = new System.Drawing.Size(256, 527);
            this.Driver1MsgBox.TabIndex = 11;
            this.Driver1MsgBox.WordWrap = false;
            // 
            // DriverSettings2
            // 
            this.DriverSettings2.Controls.Add(this.groupBox6);
            this.DriverSettings2.Controls.Add(this.groupBox29);
            this.DriverSettings2.Controls.Add(this.groupBox16);
            this.DriverSettings2.Controls.Add(this.groupBox15);
            this.DriverSettings2.Controls.Add(this.groupBox14);
            this.DriverSettings2.Controls.Add(this.ClearDriver2MsgBoxButton);
            this.DriverSettings2.Controls.Add(this.Driver2MsgBox);
            this.DriverSettings2.Controls.Add(this.label17);
            this.DriverSettings2.Controls.Add(this.Driver2SetRadio);
            this.DriverSettings2.Controls.Add(this.Driver2GetRadio);
            this.DriverSettings2.Location = new System.Drawing.Point(4, 22);
            this.DriverSettings2.Name = "DriverSettings2";
            this.DriverSettings2.Padding = new System.Windows.Forms.Padding(3);
            this.DriverSettings2.Size = new System.Drawing.Size(464, 566);
            this.DriverSettings2.TabIndex = 6;
            this.DriverSettings2.Text = "Driver 2";
            this.DriverSettings2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.HoloKoteIDSlot);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.HoloKoteIDButton);
            this.groupBox6.Location = new System.Drawing.Point(8, 326);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(191, 80);
            this.groupBox6.TabIndex = 69;
            this.groupBox6.TabStop = false;
            // 
            // HoloKoteIDSlot
            // 
            this.HoloKoteIDSlot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HoloKoteIDSlot.Enabled = false;
            this.HoloKoteIDSlot.FormattingEnabled = true;
            this.HoloKoteIDSlot.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.HoloKoteIDSlot.Location = new System.Drawing.Point(61, 19);
            this.HoloKoteIDSlot.MaxDropDownItems = 11;
            this.HoloKoteIDSlot.Name = "HoloKoteIDSlot";
            this.HoloKoteIDSlot.Size = new System.Drawing.Size(101, 21);
            this.HoloKoteIDSlot.TabIndex = 61;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 60;
            this.label4.Text = "Slot No.";
            // 
            // HoloKoteIDButton
            // 
            this.HoloKoteIDButton.Location = new System.Drawing.Point(60, 46);
            this.HoloKoteIDButton.Name = "HoloKoteIDButton";
            this.HoloKoteIDButton.Size = new System.Drawing.Size(90, 24);
            this.HoloKoteIDButton.TabIndex = 50;
            this.HoloKoteIDButton.Text = "HoloKote ID";
            this.HoloKoteIDButton.UseVisualStyleBackColor = true;
            this.HoloKoteIDButton.Click += new System.EventHandler(this.HoloKoteIDButton_Click);
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.ColourAdjust_WhiteRef);
            this.groupBox29.Controls.Add(this.label120);
            this.groupBox29.Controls.Add(this.label119);
            this.groupBox29.Controls.Add(this.ColourAdjust_BlackRef);
            this.groupBox29.Controls.Add(this.ColourAdjust_Illuminant);
            this.groupBox29.Controls.Add(this.label118);
            this.groupBox29.Controls.Add(this.ColourAdjust_Negative);
            this.groupBox29.Controls.Add(this.ColourAdjust_DarkPic);
            this.groupBox29.Controls.Add(this.ColourAdjust_Blue);
            this.groupBox29.Controls.Add(this.ColourAdjust_Green);
            this.groupBox29.Controls.Add(this.ColourAdjust_Red);
            this.groupBox29.Controls.Add(this.label115);
            this.groupBox29.Controls.Add(this.label116);
            this.groupBox29.Controls.Add(this.label117);
            this.groupBox29.Controls.Add(this.label110);
            this.groupBox29.Controls.Add(this.ColourAdjust_Tint);
            this.groupBox29.Controls.Add(this.ColourAdjust_Colour);
            this.groupBox29.Controls.Add(this.ColourAdjust_Brightness);
            this.groupBox29.Controls.Add(this.ColourAdjust_Contrast);
            this.groupBox29.Controls.Add(this.label111);
            this.groupBox29.Controls.Add(this.label113);
            this.groupBox29.Controls.Add(this.label114);
            this.groupBox29.Controls.Add(this.ColourAdjustBtn);
            this.groupBox29.Location = new System.Drawing.Point(202, 0);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(255, 196);
            this.groupBox29.TabIndex = 62;
            this.groupBox29.TabStop = false;
            // 
            // ColourAdjust_WhiteRef
            // 
            this.ColourAdjust_WhiteRef.Enabled = false;
            this.ColourAdjust_WhiteRef.Location = new System.Drawing.Point(181, 135);
            this.ColourAdjust_WhiteRef.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ColourAdjust_WhiteRef.Minimum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.ColourAdjust_WhiteRef.Name = "ColourAdjust_WhiteRef";
            this.ColourAdjust_WhiteRef.Size = new System.Drawing.Size(61, 20);
            this.ColourAdjust_WhiteRef.TabIndex = 81;
            this.ColourAdjust_WhiteRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_WhiteRef.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(125, 139);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(55, 13);
            this.label120.TabIndex = 80;
            this.label120.Text = "White Ref";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(4, 139);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(54, 13);
            this.label119.TabIndex = 79;
            this.label119.Text = "Black Ref";
            // 
            // ColourAdjust_BlackRef
            // 
            this.ColourAdjust_BlackRef.Enabled = false;
            this.ColourAdjust_BlackRef.Location = new System.Drawing.Point(59, 135);
            this.ColourAdjust_BlackRef.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
            this.ColourAdjust_BlackRef.Name = "ColourAdjust_BlackRef";
            this.ColourAdjust_BlackRef.Size = new System.Drawing.Size(61, 20);
            this.ColourAdjust_BlackRef.TabIndex = 78;
            this.ColourAdjust_BlackRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Illuminant
            // 
            this.ColourAdjust_Illuminant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAdjust_Illuminant.Enabled = false;
            this.ColourAdjust_Illuminant.FormattingEnabled = true;
            this.ColourAdjust_Illuminant.Location = new System.Drawing.Point(67, 108);
            this.ColourAdjust_Illuminant.Name = "ColourAdjust_Illuminant";
            this.ColourAdjust_Illuminant.Size = new System.Drawing.Size(182, 21);
            this.ColourAdjust_Illuminant.TabIndex = 77;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(5, 111);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(51, 13);
            this.label118.TabIndex = 76;
            this.label118.Text = "Illuminant";
            // 
            // ColourAdjust_Negative
            // 
            this.ColourAdjust_Negative.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ColourAdjust_Negative.Enabled = false;
            this.ColourAdjust_Negative.Location = new System.Drawing.Point(154, 84);
            this.ColourAdjust_Negative.Name = "ColourAdjust_Negative";
            this.ColourAdjust_Negative.Size = new System.Drawing.Size(80, 17);
            this.ColourAdjust_Negative.TabIndex = 75;
            this.ColourAdjust_Negative.Text = "Negative";
            this.ColourAdjust_Negative.UseVisualStyleBackColor = true;
            // 
            // ColourAdjust_DarkPic
            // 
            this.ColourAdjust_DarkPic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ColourAdjust_DarkPic.Enabled = false;
            this.ColourAdjust_DarkPic.Location = new System.Drawing.Point(5, 84);
            this.ColourAdjust_DarkPic.Name = "ColourAdjust_DarkPic";
            this.ColourAdjust_DarkPic.Size = new System.Drawing.Size(85, 17);
            this.ColourAdjust_DarkPic.TabIndex = 74;
            this.ColourAdjust_DarkPic.Text = "Dark Picture";
            this.ColourAdjust_DarkPic.UseVisualStyleBackColor = true;
            // 
            // ColourAdjust_Blue
            // 
            this.ColourAdjust_Blue.Enabled = false;
            this.ColourAdjust_Blue.Location = new System.Drawing.Point(168, 58);
            this.ColourAdjust_Blue.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Blue.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Blue.Name = "ColourAdjust_Blue";
            this.ColourAdjust_Blue.Size = new System.Drawing.Size(80, 20);
            this.ColourAdjust_Blue.TabIndex = 73;
            this.ColourAdjust_Blue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Blue.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // ColourAdjust_Green
            // 
            this.ColourAdjust_Green.Enabled = false;
            this.ColourAdjust_Green.Location = new System.Drawing.Point(87, 58);
            this.ColourAdjust_Green.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Green.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Green.Name = "ColourAdjust_Green";
            this.ColourAdjust_Green.Size = new System.Drawing.Size(80, 20);
            this.ColourAdjust_Green.TabIndex = 72;
            this.ColourAdjust_Green.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Green.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // ColourAdjust_Red
            // 
            this.ColourAdjust_Red.Enabled = false;
            this.ColourAdjust_Red.Location = new System.Drawing.Point(6, 58);
            this.ColourAdjust_Red.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Red.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Red.Name = "ColourAdjust_Red";
            this.ColourAdjust_Red.Size = new System.Drawing.Size(80, 20);
            this.ColourAdjust_Red.TabIndex = 69;
            this.ColourAdjust_Red.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Red.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(234, 44);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(14, 13);
            this.label115.TabIndex = 71;
            this.label115.Text = "B";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(120, 44);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(15, 13);
            this.label116.TabIndex = 70;
            this.label116.Text = "G";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(39, 44);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(15, 13);
            this.label117.TabIndex = 68;
            this.label117.Text = "R";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(204, 10);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(25, 13);
            this.label110.TabIndex = 67;
            this.label110.Text = "Tint";
            // 
            // ColourAdjust_Tint
            // 
            this.ColourAdjust_Tint.Enabled = false;
            this.ColourAdjust_Tint.Location = new System.Drawing.Point(186, 24);
            this.ColourAdjust_Tint.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Tint.Name = "ColourAdjust_Tint";
            this.ColourAdjust_Tint.Size = new System.Drawing.Size(60, 20);
            this.ColourAdjust_Tint.TabIndex = 66;
            this.ColourAdjust_Tint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Colour
            // 
            this.ColourAdjust_Colour.Enabled = false;
            this.ColourAdjust_Colour.Location = new System.Drawing.Point(126, 24);
            this.ColourAdjust_Colour.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Colour.Name = "ColourAdjust_Colour";
            this.ColourAdjust_Colour.Size = new System.Drawing.Size(60, 20);
            this.ColourAdjust_Colour.TabIndex = 65;
            this.ColourAdjust_Colour.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Brightness
            // 
            this.ColourAdjust_Brightness.Enabled = false;
            this.ColourAdjust_Brightness.Location = new System.Drawing.Point(66, 24);
            this.ColourAdjust_Brightness.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Brightness.Name = "ColourAdjust_Brightness";
            this.ColourAdjust_Brightness.Size = new System.Drawing.Size(60, 20);
            this.ColourAdjust_Brightness.TabIndex = 64;
            this.ColourAdjust_Brightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Contrast
            // 
            this.ColourAdjust_Contrast.Enabled = false;
            this.ColourAdjust_Contrast.Location = new System.Drawing.Point(6, 24);
            this.ColourAdjust_Contrast.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Contrast.Name = "ColourAdjust_Contrast";
            this.ColourAdjust_Contrast.Size = new System.Drawing.Size(60, 20);
            this.ColourAdjust_Contrast.TabIndex = 60;
            this.ColourAdjust_Contrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(138, 10);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(37, 13);
            this.label111.TabIndex = 63;
            this.label111.Text = "Colour";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(79, 10);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(34, 13);
            this.label113.TabIndex = 62;
            this.label113.Text = "Bright";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(13, 10);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(46, 13);
            this.label114.TabIndex = 61;
            this.label114.Text = "Contrast";
            // 
            // ColourAdjustBtn
            // 
            this.ColourAdjustBtn.Location = new System.Drawing.Point(85, 166);
            this.ColourAdjustBtn.Name = "ColourAdjustBtn";
            this.ColourAdjustBtn.Size = new System.Drawing.Size(90, 24);
            this.ColourAdjustBtn.TabIndex = 50;
            this.ColourAdjustBtn.Text = "Colour Adjust";
            this.ColourAdjustBtn.UseVisualStyleBackColor = true;
            this.ColourAdjustBtn.Click += new System.EventHandler(this.ColourAdjustBtn_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.HoloKotePreviewButton);
            this.groupBox16.Controls.Add(this.HoloKoteImageUpDown);
            this.groupBox16.Controls.Add(this.label52);
            this.groupBox16.Controls.Add(this.HoloKoteSideCombo);
            this.groupBox16.Controls.Add(this.label49);
            this.groupBox16.Controls.Add(this.HoloKoteRotationCombo);
            this.groupBox16.Controls.Add(this.label50);
            this.groupBox16.Controls.Add(this.HoloKoteButton);
            this.groupBox16.Location = new System.Drawing.Point(8, 221);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(191, 99);
            this.groupBox16.TabIndex = 66;
            this.groupBox16.TabStop = false;
            // 
            // HoloKotePreviewButton
            // 
            this.HoloKotePreviewButton.Location = new System.Drawing.Point(84, 66);
            this.HoloKotePreviewButton.Name = "HoloKotePreviewButton";
            this.HoloKotePreviewButton.Size = new System.Drawing.Size(101, 24);
            this.HoloKotePreviewButton.TabIndex = 69;
            this.HoloKotePreviewButton.Text = "HoloKote Preview";
            this.HoloKotePreviewButton.UseVisualStyleBackColor = true;
            this.HoloKotePreviewButton.Click += new System.EventHandler(this.HoloKotePreviewButton_Click);
            // 
            // HoloKoteImageUpDown
            // 
            this.HoloKoteImageUpDown.Enabled = false;
            this.HoloKoteImageUpDown.Location = new System.Drawing.Point(145, 12);
            this.HoloKoteImageUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.HoloKoteImageUpDown.Name = "HoloKoteImageUpDown";
            this.HoloKoteImageUpDown.Size = new System.Drawing.Size(40, 20);
            this.HoloKoteImageUpDown.TabIndex = 62;
            this.HoloKoteImageUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.HoloKoteImageUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(103, 16);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(36, 13);
            this.label52.TabIndex = 68;
            this.label52.Text = "Image";
            // 
            // HoloKoteSideCombo
            // 
            this.HoloKoteSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HoloKoteSideCombo.FormattingEnabled = true;
            this.HoloKoteSideCombo.Location = new System.Drawing.Point(37, 12);
            this.HoloKoteSideCombo.Name = "HoloKoteSideCombo";
            this.HoloKoteSideCombo.Size = new System.Drawing.Size(61, 21);
            this.HoloKoteSideCombo.TabIndex = 63;
            this.HoloKoteSideCombo.SelectedIndexChanged += new System.EventHandler(this.HoloKoteSide_Changed);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 16);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(28, 13);
            this.label49.TabIndex = 62;
            this.label49.Text = "Side";
            // 
            // HoloKoteRotationCombo
            // 
            this.HoloKoteRotationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HoloKoteRotationCombo.Enabled = false;
            this.HoloKoteRotationCombo.FormattingEnabled = true;
            this.HoloKoteRotationCombo.Location = new System.Drawing.Point(84, 39);
            this.HoloKoteRotationCombo.Name = "HoloKoteRotationCombo";
            this.HoloKoteRotationCombo.Size = new System.Drawing.Size(101, 21);
            this.HoloKoteRotationCombo.TabIndex = 61;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 43);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(47, 13);
            this.label50.TabIndex = 60;
            this.label50.Text = "Rotation";
            // 
            // HoloKoteButton
            // 
            this.HoloKoteButton.Location = new System.Drawing.Point(8, 66);
            this.HoloKoteButton.Name = "HoloKoteButton";
            this.HoloKoteButton.Size = new System.Drawing.Size(67, 24);
            this.HoloKoteButton.TabIndex = 50;
            this.HoloKoteButton.Text = "HoloKote";
            this.HoloKoteButton.UseVisualStyleBackColor = true;
            this.HoloKoteButton.Click += new System.EventHandler(this.HoloKoteButton_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Rotate);
            this.groupBox15.Controls.Add(this.Overcoat);
            this.groupBox15.Controls.Add(this.CardSettingsSideCombo);
            this.groupBox15.Controls.Add(this.label47);
            this.groupBox15.Controls.Add(this.OrientationCombo);
            this.groupBox15.Controls.Add(this.label44);
            this.groupBox15.Controls.Add(this.ColourFormatCombo);
            this.groupBox15.Controls.Add(this.label48);
            this.groupBox15.Controls.Add(this.CardSettingsButton);
            this.groupBox15.Location = new System.Drawing.Point(8, 109);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(191, 112);
            this.groupBox15.TabIndex = 62;
            this.groupBox15.TabStop = false;
            // 
            // Rotate
            // 
            this.Rotate.AutoSize = true;
            this.Rotate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Rotate.Enabled = false;
            this.Rotate.Location = new System.Drawing.Point(114, 14);
            this.Rotate.Name = "Rotate";
            this.Rotate.Size = new System.Drawing.Size(58, 17);
            this.Rotate.TabIndex = 65;
            this.Rotate.Text = "Rotate";
            this.Rotate.UseVisualStyleBackColor = true;
            // 
            // Overcoat
            // 
            this.Overcoat.AutoSize = true;
            this.Overcoat.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Overcoat.Enabled = false;
            this.Overcoat.Location = new System.Drawing.Point(6, 86);
            this.Overcoat.Name = "Overcoat";
            this.Overcoat.Size = new System.Drawing.Size(70, 17);
            this.Overcoat.TabIndex = 64;
            this.Overcoat.Text = "Overcoat";
            this.Overcoat.UseVisualStyleBackColor = true;
            // 
            // CardSettingsSideCombo
            // 
            this.CardSettingsSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CardSettingsSideCombo.FormattingEnabled = true;
            this.CardSettingsSideCombo.Location = new System.Drawing.Point(37, 12);
            this.CardSettingsSideCombo.Name = "CardSettingsSideCombo";
            this.CardSettingsSideCombo.Size = new System.Drawing.Size(61, 21);
            this.CardSettingsSideCombo.TabIndex = 63;
            this.CardSettingsSideCombo.SelectedIndexChanged += new System.EventHandler(this.CardSettingsSide_Changed);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 16);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(28, 13);
            this.label47.TabIndex = 62;
            this.label47.Text = "Side";
            // 
            // OrientationCombo
            // 
            this.OrientationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrientationCombo.Enabled = false;
            this.OrientationCombo.FormattingEnabled = true;
            this.OrientationCombo.Location = new System.Drawing.Point(84, 59);
            this.OrientationCombo.Name = "OrientationCombo";
            this.OrientationCombo.Size = new System.Drawing.Size(101, 21);
            this.OrientationCombo.TabIndex = 61;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 63);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(58, 13);
            this.label44.TabIndex = 60;
            this.label44.Text = "Orientation";
            // 
            // ColourFormatCombo
            // 
            this.ColourFormatCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourFormatCombo.Enabled = false;
            this.ColourFormatCombo.FormattingEnabled = true;
            this.ColourFormatCombo.Location = new System.Drawing.Point(84, 37);
            this.ColourFormatCombo.Name = "ColourFormatCombo";
            this.ColourFormatCombo.Size = new System.Drawing.Size(101, 21);
            this.ColourFormatCombo.TabIndex = 56;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 41);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(72, 13);
            this.label48.TabIndex = 56;
            this.label48.Text = "Colour Format";
            // 
            // CardSettingsButton
            // 
            this.CardSettingsButton.Location = new System.Drawing.Point(95, 82);
            this.CardSettingsButton.Name = "CardSettingsButton";
            this.CardSettingsButton.Size = new System.Drawing.Size(90, 24);
            this.CardSettingsButton.TabIndex = 50;
            this.CardSettingsButton.Text = "Card Settings";
            this.CardSettingsButton.UseVisualStyleBackColor = true;
            this.CardSettingsButton.Click += new System.EventHandler(this.CardSettingsButton_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.CardSizeCombo);
            this.groupBox14.Controls.Add(this.label43);
            this.groupBox14.Controls.Add(this.CopyCountUpDown);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.DuplexCombo);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.PrintSettingsButton);
            this.groupBox14.Location = new System.Drawing.Point(8, 22);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(191, 87);
            this.groupBox14.TabIndex = 61;
            this.groupBox14.TabStop = false;
            // 
            // CardSizeCombo
            // 
            this.CardSizeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CardSizeCombo.Enabled = false;
            this.CardSizeCombo.FormattingEnabled = true;
            this.CardSizeCombo.Location = new System.Drawing.Point(72, 31);
            this.CardSizeCombo.Name = "CardSizeCombo";
            this.CardSizeCombo.Size = new System.Drawing.Size(113, 21);
            this.CardSizeCombo.TabIndex = 61;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 35);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 13);
            this.label43.TabIndex = 60;
            this.label43.Text = "Card Size";
            // 
            // CopyCountUpDown
            // 
            this.CopyCountUpDown.Enabled = false;
            this.CopyCountUpDown.Location = new System.Drawing.Point(32, 59);
            this.CopyCountUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.CopyCountUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CopyCountUpDown.Name = "CopyCountUpDown";
            this.CopyCountUpDown.Size = new System.Drawing.Size(49, 20);
            this.CopyCountUpDown.TabIndex = 56;
            this.CopyCountUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.CopyCountUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 63);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(24, 13);
            this.label45.TabIndex = 57;
            this.label45.Text = "No:";
            // 
            // DuplexCombo
            // 
            this.DuplexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DuplexCombo.Enabled = false;
            this.DuplexCombo.FormattingEnabled = true;
            this.DuplexCombo.Location = new System.Drawing.Point(72, 9);
            this.DuplexCombo.Name = "DuplexCombo";
            this.DuplexCombo.Size = new System.Drawing.Size(113, 21);
            this.DuplexCombo.TabIndex = 56;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 13);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(69, 13);
            this.label46.TabIndex = 56;
            this.label46.Text = "Sides to Print";
            // 
            // PrintSettingsButton
            // 
            this.PrintSettingsButton.Location = new System.Drawing.Point(95, 57);
            this.PrintSettingsButton.Name = "PrintSettingsButton";
            this.PrintSettingsButton.Size = new System.Drawing.Size(90, 24);
            this.PrintSettingsButton.TabIndex = 50;
            this.PrintSettingsButton.Text = "Print Settings";
            this.PrintSettingsButton.UseVisualStyleBackColor = true;
            this.PrintSettingsButton.Click += new System.EventHandler(this.PrintSettingsButton_Click);
            // 
            // ClearDriver2MsgBoxButton
            // 
            this.ClearDriver2MsgBoxButton.Location = new System.Drawing.Point(295, 539);
            this.ClearDriver2MsgBoxButton.Name = "ClearDriver2MsgBoxButton";
            this.ClearDriver2MsgBoxButton.Size = new System.Drawing.Size(90, 24);
            this.ClearDriver2MsgBoxButton.TabIndex = 48;
            this.ClearDriver2MsgBoxButton.Text = "Clear";
            this.ClearDriver2MsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearDriver2MsgBoxButton.Click += new System.EventHandler(this.ClearDriver2MsgBoxButton_Click);
            // 
            // Driver2MsgBox
            // 
            this.Driver2MsgBox.Location = new System.Drawing.Point(202, 202);
            this.Driver2MsgBox.Multiline = true;
            this.Driver2MsgBox.Name = "Driver2MsgBox";
            this.Driver2MsgBox.ReadOnly = true;
            this.Driver2MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Driver2MsgBox.Size = new System.Drawing.Size(256, 331);
            this.Driver2MsgBox.TabIndex = 47;
            this.Driver2MsgBox.WordWrap = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(29, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 46;
            this.label17.Text = "Action:";
            // 
            // Driver2SetRadio
            // 
            this.Driver2SetRadio.AutoSize = true;
            this.Driver2SetRadio.Location = new System.Drawing.Point(111, 4);
            this.Driver2SetRadio.Name = "Driver2SetRadio";
            this.Driver2SetRadio.Size = new System.Drawing.Size(41, 17);
            this.Driver2SetRadio.TabIndex = 45;
            this.Driver2SetRadio.Text = "Set";
            this.Driver2SetRadio.UseVisualStyleBackColor = true;
            this.Driver2SetRadio.CheckedChanged += new System.EventHandler(this.Driver2ActionSetRadio_CheckedChanged);
            // 
            // Driver2GetRadio
            // 
            this.Driver2GetRadio.AutoSize = true;
            this.Driver2GetRadio.Checked = true;
            this.Driver2GetRadio.Location = new System.Drawing.Point(69, 4);
            this.Driver2GetRadio.Name = "Driver2GetRadio";
            this.Driver2GetRadio.Size = new System.Drawing.Size(42, 17);
            this.Driver2GetRadio.TabIndex = 44;
            this.Driver2GetRadio.TabStop = true;
            this.Driver2GetRadio.Text = "Get";
            this.Driver2GetRadio.UseVisualStyleBackColor = true;
            this.Driver2GetRadio.CheckedChanged += new System.EventHandler(this.Driver2ActionGetRadio_CheckedChanged);
            // 
            // PrintDemo
            // 
            this.PrintDemo.Controls.Add(this.PrinterPrefs);
            this.PrintDemo.Controls.Add(this.nativePrint);
            this.PrintDemo.Controls.Add(this.CardSide);
            this.PrintDemo.Controls.Add(this.CardBack);
            this.PrintDemo.Controls.Add(this.CardFront);
            this.PrintDemo.Controls.Add(this.PrintButton);
            this.PrintDemo.Location = new System.Drawing.Point(4, 22);
            this.PrintDemo.Name = "PrintDemo";
            this.PrintDemo.Padding = new System.Windows.Forms.Padding(3);
            this.PrintDemo.Size = new System.Drawing.Size(464, 566);
            this.PrintDemo.TabIndex = 7;
            this.PrintDemo.Text = "Print";
            this.PrintDemo.UseVisualStyleBackColor = true;
            // 
            // nativePrint
            // 
            this.nativePrint.AutoSize = true;
            this.nativePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nativePrint.Location = new System.Drawing.Point(171, 532);
            this.nativePrint.Name = "nativePrint";
            this.nativePrint.Size = new System.Drawing.Size(117, 17);
            this.nativePrint.TabIndex = 89;
            this.nativePrint.Text = "Use Native Printing";
            this.nativePrint.UseVisualStyleBackColor = true;
            this.nativePrint.CheckedChanged += new System.EventHandler(this.nativePrint_CheckedChanged);
            // 
            // CardSide
            // 
            this.CardSide.Controls.Add(this.Front);
            this.CardSide.Controls.Add(this.Back);
            this.CardSide.Location = new System.Drawing.Point(4, 28);
            this.CardSide.Name = "CardSide";
            this.CardSide.SelectedIndex = 0;
            this.CardSide.Size = new System.Drawing.Size(451, 493);
            this.CardSide.TabIndex = 68;
            // 
            // Front
            // 
            this.Front.Controls.Add(this.groupBox18);
            this.Front.Controls.Add(this.groupBox24);
            this.Front.Controls.Add(this.groupBox25);
            this.Front.Controls.Add(this.groupBox26);
            this.Front.Controls.Add(this.groupBox33);
            this.Front.Location = new System.Drawing.Point(4, 22);
            this.Front.Name = "Front";
            this.Front.Padding = new System.Windows.Forms.Padding(3);
            this.Front.Size = new System.Drawing.Size(443, 467);
            this.Front.TabIndex = 0;
            this.Front.Text = "Front";
            this.Front.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Track3MagData);
            this.groupBox18.Controls.Add(this.Track2MagData);
            this.groupBox18.Controls.Add(this.Track1MagData);
            this.groupBox18.Controls.Add(this.label11);
            this.groupBox18.Controls.Add(this.label10);
            this.groupBox18.Controls.Add(this.label6);
            this.groupBox18.Controls.Add(this.MagDataEnabled);
            this.groupBox18.Location = new System.Drawing.Point(3, 354);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(437, 107);
            this.groupBox18.TabIndex = 88;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Magnetic Encoding";
            // 
            // Track3MagData
            // 
            this.Track3MagData.Location = new System.Drawing.Point(56, 78);
            this.Track3MagData.Name = "Track3MagData";
            this.Track3MagData.Size = new System.Drawing.Size(375, 20);
            this.Track3MagData.TabIndex = 91;
            // 
            // Track2MagData
            // 
            this.Track2MagData.Location = new System.Drawing.Point(56, 54);
            this.Track2MagData.Name = "Track2MagData";
            this.Track2MagData.Size = new System.Drawing.Size(375, 20);
            this.Track2MagData.TabIndex = 90;
            // 
            // Track1MagData
            // 
            this.Track1MagData.Location = new System.Drawing.Point(56, 30);
            this.Track1MagData.Name = "Track1MagData";
            this.Track1MagData.Size = new System.Drawing.Size(375, 20);
            this.Track1MagData.TabIndex = 89;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 88;
            this.label11.Text = "Track 3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 87;
            this.label10.Text = "Track 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 86;
            this.label6.Text = "Track 1";
            // 
            // MagDataEnabled
            // 
            this.MagDataEnabled.AutoSize = true;
            this.MagDataEnabled.Location = new System.Drawing.Point(6, 14);
            this.MagDataEnabled.Name = "MagDataEnabled";
            this.MagDataEnabled.Size = new System.Drawing.Size(65, 17);
            this.MagDataEnabled.TabIndex = 85;
            this.MagDataEnabled.Text = "Enabled";
            this.MagDataEnabled.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.ImageFrontResin);
            this.groupBox24.Controls.Add(this.ImageFrontEnabled);
            this.groupBox24.Controls.Add(this.ImageFrontButton);
            this.groupBox24.Controls.Add(this.ImageFrontFileBox);
            this.groupBox24.Controls.Add(this.ImageFrontP2UpDown);
            this.groupBox24.Controls.Add(this.label69);
            this.groupBox24.Controls.Add(this.label78);
            this.groupBox24.Controls.Add(this.ImageFrontP1UpDown);
            this.groupBox24.Controls.Add(this.ImageFrontYUpDown);
            this.groupBox24.Controls.Add(this.label79);
            this.groupBox24.Controls.Add(this.ImageFrontXUpDown);
            this.groupBox24.Controls.Add(this.label80);
            this.groupBox24.Controls.Add(this.label87);
            this.groupBox24.Controls.Add(this.label88);
            this.groupBox24.Location = new System.Drawing.Point(3, 273);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(437, 75);
            this.groupBox24.TabIndex = 87;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Image";
            // 
            // ImageFrontResin
            // 
            this.ImageFrontResin.AutoSize = true;
            this.ImageFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ImageFrontResin.Location = new System.Drawing.Point(356, 42);
            this.ImageFrontResin.Name = "ImageFrontResin";
            this.ImageFrontResin.Size = new System.Drawing.Size(75, 17);
            this.ImageFrontResin.TabIndex = 87;
            this.ImageFrontResin.Text = "Use Resin";
            this.ImageFrontResin.UseVisualStyleBackColor = true;
            // 
            // ImageFrontEnabled
            // 
            this.ImageFrontEnabled.AutoSize = true;
            this.ImageFrontEnabled.Location = new System.Drawing.Point(6, 14);
            this.ImageFrontEnabled.Name = "ImageFrontEnabled";
            this.ImageFrontEnabled.Size = new System.Drawing.Size(65, 17);
            this.ImageFrontEnabled.TabIndex = 85;
            this.ImageFrontEnabled.Text = "Enabled";
            this.ImageFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // ImageFrontButton
            // 
            this.ImageFrontButton.Location = new System.Drawing.Point(400, 10);
            this.ImageFrontButton.Name = "ImageFrontButton";
            this.ImageFrontButton.Size = new System.Drawing.Size(28, 24);
            this.ImageFrontButton.TabIndex = 70;
            this.ImageFrontButton.Text = "...";
            this.ImageFrontButton.UseVisualStyleBackColor = true;
            this.ImageFrontButton.Click += new System.EventHandler(this.ImageFrontButton_Click);
            // 
            // ImageFrontFileBox
            // 
            this.ImageFrontFileBox.Location = new System.Drawing.Point(127, 12);
            this.ImageFrontFileBox.Name = "ImageFrontFileBox";
            this.ImageFrontFileBox.Size = new System.Drawing.Size(273, 20);
            this.ImageFrontFileBox.TabIndex = 83;
            // 
            // ImageFrontP2UpDown
            // 
            this.ImageFrontP2UpDown.Location = new System.Drawing.Point(258, 40);
            this.ImageFrontP2UpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ImageFrontP2UpDown.Name = "ImageFrontP2UpDown";
            this.ImageFrontP2UpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageFrontP2UpDown.TabIndex = 82;
            this.ImageFrontP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(238, 44);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(20, 13);
            this.label69.TabIndex = 81;
            this.label69.Text = "P2";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(173, 44);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(20, 13);
            this.label78.TabIndex = 80;
            this.label78.Text = "P1";
            // 
            // ImageFrontP1UpDown
            // 
            this.ImageFrontP1UpDown.Location = new System.Drawing.Point(193, 40);
            this.ImageFrontP1UpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ImageFrontP1UpDown.Name = "ImageFrontP1UpDown";
            this.ImageFrontP1UpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageFrontP1UpDown.TabIndex = 78;
            this.ImageFrontP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ImageFrontYUpDown
            // 
            this.ImageFrontYUpDown.Location = new System.Drawing.Point(128, 40);
            this.ImageFrontYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ImageFrontYUpDown.Name = "ImageFrontYUpDown";
            this.ImageFrontYUpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageFrontYUpDown.TabIndex = 76;
            this.ImageFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(114, 44);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(14, 13);
            this.label79.TabIndex = 75;
            this.label79.Text = "Y";
            // 
            // ImageFrontXUpDown
            // 
            this.ImageFrontXUpDown.Location = new System.Drawing.Point(69, 40);
            this.ImageFrontXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ImageFrontXUpDown.Name = "ImageFrontXUpDown";
            this.ImageFrontXUpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageFrontXUpDown.TabIndex = 74;
            this.ImageFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(56, 44);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(14, 13);
            this.label80.TabIndex = 73;
            this.label80.Text = "X";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(6, 44);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(47, 13);
            this.label87.TabIndex = 33;
            this.label87.Text = "Position:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(91, 16);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(23, 13);
            this.label88.TabIndex = 32;
            this.label88.Text = "File";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.LineFrontEnabled);
            this.groupBox25.Controls.Add(this.label89);
            this.groupBox25.Controls.Add(this.LineFrontWidthUpDown);
            this.groupBox25.Controls.Add(this.label90);
            this.groupBox25.Controls.Add(this.LineFrontStartYUpDown);
            this.groupBox25.Controls.Add(this.LineFrontEndYUpDown);
            this.groupBox25.Controls.Add(this.label91);
            this.groupBox25.Controls.Add(this.label92);
            this.groupBox25.Controls.Add(this.label93);
            this.groupBox25.Controls.Add(this.label94);
            this.groupBox25.Controls.Add(this.LineFrontResin);
            this.groupBox25.Controls.Add(this.LineFrontEndXUpDown);
            this.groupBox25.Controls.Add(this.LineFrontColourCombo);
            this.groupBox25.Controls.Add(this.LineFrontStartXUpDown);
            this.groupBox25.Controls.Add(this.label95);
            this.groupBox25.Controls.Add(this.label96);
            this.groupBox25.Location = new System.Drawing.Point(3, 182);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(437, 85);
            this.groupBox25.TabIndex = 86;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Line";
            // 
            // LineFrontEnabled
            // 
            this.LineFrontEnabled.AutoSize = true;
            this.LineFrontEnabled.Checked = true;
            this.LineFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LineFrontEnabled.Location = new System.Drawing.Point(6, 14);
            this.LineFrontEnabled.Name = "LineFrontEnabled";
            this.LineFrontEnabled.Size = new System.Drawing.Size(65, 17);
            this.LineFrontEnabled.TabIndex = 84;
            this.LineFrontEnabled.Text = "Enabled";
            this.LineFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(188, 63);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(29, 13);
            this.label89.TabIndex = 82;
            this.label89.Text = "End:";
            // 
            // LineFrontWidthUpDown
            // 
            this.LineFrontWidthUpDown.Location = new System.Drawing.Point(234, 32);
            this.LineFrontWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.LineFrontWidthUpDown.Name = "LineFrontWidthUpDown";
            this.LineFrontWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineFrontWidthUpDown.TabIndex = 81;
            this.LineFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(201, 36);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(35, 13);
            this.label90.TabIndex = 80;
            this.label90.Text = "Width";
            // 
            // LineFrontStartYUpDown
            // 
            this.LineFrontStartYUpDown.Location = new System.Drawing.Point(115, 59);
            this.LineFrontStartYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.LineFrontStartYUpDown.Name = "LineFrontStartYUpDown";
            this.LineFrontStartYUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineFrontStartYUpDown.TabIndex = 76;
            this.LineFrontStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineFrontEndYUpDown
            // 
            this.LineFrontEndYUpDown.Location = new System.Drawing.Point(295, 59);
            this.LineFrontEndYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.LineFrontEndYUpDown.Name = "LineFrontEndYUpDown";
            this.LineFrontEndYUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineFrontEndYUpDown.TabIndex = 82;
            this.LineFrontEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(6, 62);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(32, 13);
            this.label91.TabIndex = 80;
            this.label91.Text = "Start:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(281, 63);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(14, 13);
            this.label92.TabIndex = 81;
            this.label92.Text = "Y";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(42, 63);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(14, 13);
            this.label93.TabIndex = 73;
            this.label93.Text = "X";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(220, 63);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(14, 13);
            this.label94.TabIndex = 80;
            this.label94.Text = "X";
            // 
            // LineFrontResin
            // 
            this.LineFrontResin.AutoSize = true;
            this.LineFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LineFrontResin.Location = new System.Drawing.Point(356, 14);
            this.LineFrontResin.Name = "LineFrontResin";
            this.LineFrontResin.Size = new System.Drawing.Size(75, 17);
            this.LineFrontResin.TabIndex = 79;
            this.LineFrontResin.Text = "Use Resin";
            this.LineFrontResin.UseVisualStyleBackColor = true;
            // 
            // LineFrontEndXUpDown
            // 
            this.LineFrontEndXUpDown.Location = new System.Drawing.Point(234, 59);
            this.LineFrontEndXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.LineFrontEndXUpDown.Name = "LineFrontEndXUpDown";
            this.LineFrontEndXUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineFrontEndXUpDown.TabIndex = 78;
            this.LineFrontEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineFrontColourCombo
            // 
            this.LineFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LineFrontColourCombo.Location = new System.Drawing.Point(56, 32);
            this.LineFrontColourCombo.Name = "LineFrontColourCombo";
            this.LineFrontColourCombo.Size = new System.Drawing.Size(139, 21);
            this.LineFrontColourCombo.TabIndex = 34;
            // 
            // LineFrontStartXUpDown
            // 
            this.LineFrontStartXUpDown.Location = new System.Drawing.Point(56, 59);
            this.LineFrontStartXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.LineFrontStartXUpDown.Name = "LineFrontStartXUpDown";
            this.LineFrontStartXUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineFrontStartXUpDown.TabIndex = 74;
            this.LineFrontStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(6, 36);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(37, 13);
            this.label95.TabIndex = 32;
            this.label95.Text = "Colour";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(101, 63);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(14, 13);
            this.label96.TabIndex = 75;
            this.label96.Text = "Y";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.ShapeFrontEnabled);
            this.groupBox26.Controls.Add(this.ShapeFrontFillCombo);
            this.groupBox26.Controls.Add(this.label97);
            this.groupBox26.Controls.Add(this.ShapeFrontWidthUpDown);
            this.groupBox26.Controls.Add(this.ShapeFrontOutlineCombo);
            this.groupBox26.Controls.Add(this.label98);
            this.groupBox26.Controls.Add(this.label99);
            this.groupBox26.Controls.Add(this.ShapeFrontBUpDown);
            this.groupBox26.Controls.Add(this.label100);
            this.groupBox26.Controls.Add(this.label101);
            this.groupBox26.Controls.Add(this.ShapeFrontResin);
            this.groupBox26.Controls.Add(this.ShapeFrontRUpDown);
            this.groupBox26.Controls.Add(this.ShapeFrontTUpDown);
            this.groupBox26.Controls.Add(this.label102);
            this.groupBox26.Controls.Add(this.ShapeFrontLUpDown);
            this.groupBox26.Controls.Add(this.label103);
            this.groupBox26.Controls.Add(this.ShapeFrontCombo);
            this.groupBox26.Controls.Add(this.label104);
            this.groupBox26.Controls.Add(this.label105);
            this.groupBox26.Location = new System.Drawing.Point(3, 91);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(437, 85);
            this.groupBox26.TabIndex = 85;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Shape";
            // 
            // ShapeFrontEnabled
            // 
            this.ShapeFrontEnabled.AutoSize = true;
            this.ShapeFrontEnabled.Checked = true;
            this.ShapeFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ShapeFrontEnabled.Location = new System.Drawing.Point(6, 14);
            this.ShapeFrontEnabled.Name = "ShapeFrontEnabled";
            this.ShapeFrontEnabled.Size = new System.Drawing.Size(65, 17);
            this.ShapeFrontEnabled.TabIndex = 83;
            this.ShapeFrontEnabled.Text = "Enabled";
            this.ShapeFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // ShapeFrontFillCombo
            // 
            this.ShapeFrontFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontFillCombo.Items.AddRange(new object[] {
            "Red",
            "Green",
            "Blue",
            "Cyan",
            "Magenta",
            "Yellow",
            "White",
            "Black",
            "Transparent"});
            this.ShapeFrontFillCombo.Location = new System.Drawing.Point(251, 60);
            this.ShapeFrontFillCombo.Name = "ShapeFrontFillCombo";
            this.ShapeFrontFillCombo.Size = new System.Drawing.Size(127, 21);
            this.ShapeFrontFillCombo.TabIndex = 81;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(232, 64);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(19, 13);
            this.label97.TabIndex = 80;
            this.label97.Text = "Fill";
            // 
            // ShapeFrontWidthUpDown
            // 
            this.ShapeFrontWidthUpDown.Location = new System.Drawing.Point(176, 60);
            this.ShapeFrontWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ShapeFrontWidthUpDown.Name = "ShapeFrontWidthUpDown";
            this.ShapeFrontWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeFrontWidthUpDown.TabIndex = 81;
            this.ShapeFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeFrontOutlineCombo
            // 
            this.ShapeFrontOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontOutlineCombo.Location = new System.Drawing.Point(52, 60);
            this.ShapeFrontOutlineCombo.Name = "ShapeFrontOutlineCombo";
            this.ShapeFrontOutlineCombo.Size = new System.Drawing.Size(85, 21);
            this.ShapeFrontOutlineCombo.TabIndex = 81;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(143, 64);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(35, 13);
            this.label98.TabIndex = 80;
            this.label98.Text = "Width";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(6, 64);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(40, 13);
            this.label99.TabIndex = 80;
            this.label99.Text = "Outline";
            // 
            // ShapeFrontBUpDown
            // 
            this.ShapeFrontBUpDown.Location = new System.Drawing.Point(378, 37);
            this.ShapeFrontBUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ShapeFrontBUpDown.Name = "ShapeFrontBUpDown";
            this.ShapeFrontBUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeFrontBUpDown.TabIndex = 82;
            this.ShapeFrontBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(364, 41);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(14, 13);
            this.label100.TabIndex = 81;
            this.label100.Text = "B";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(304, 41);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(15, 13);
            this.label101.TabIndex = 80;
            this.label101.Text = "R";
            // 
            // ShapeFrontResin
            // 
            this.ShapeFrontResin.AutoSize = true;
            this.ShapeFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShapeFrontResin.Location = new System.Drawing.Point(356, 14);
            this.ShapeFrontResin.Name = "ShapeFrontResin";
            this.ShapeFrontResin.Size = new System.Drawing.Size(75, 17);
            this.ShapeFrontResin.TabIndex = 79;
            this.ShapeFrontResin.Text = "Use Resin";
            this.ShapeFrontResin.UseVisualStyleBackColor = true;
            // 
            // ShapeFrontRUpDown
            // 
            this.ShapeFrontRUpDown.Location = new System.Drawing.Point(319, 37);
            this.ShapeFrontRUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ShapeFrontRUpDown.Name = "ShapeFrontRUpDown";
            this.ShapeFrontRUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeFrontRUpDown.TabIndex = 78;
            this.ShapeFrontRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeFrontTUpDown
            // 
            this.ShapeFrontTUpDown.Location = new System.Drawing.Point(259, 37);
            this.ShapeFrontTUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ShapeFrontTUpDown.Name = "ShapeFrontTUpDown";
            this.ShapeFrontTUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeFrontTUpDown.TabIndex = 76;
            this.ShapeFrontTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(245, 41);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(14, 13);
            this.label102.TabIndex = 75;
            this.label102.Text = "T";
            // 
            // ShapeFrontLUpDown
            // 
            this.ShapeFrontLUpDown.Location = new System.Drawing.Point(200, 37);
            this.ShapeFrontLUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ShapeFrontLUpDown.Name = "ShapeFrontLUpDown";
            this.ShapeFrontLUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeFrontLUpDown.TabIndex = 74;
            this.ShapeFrontLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(187, 41);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(13, 13);
            this.label103.TabIndex = 73;
            this.label103.Text = "L";
            // 
            // ShapeFrontCombo
            // 
            this.ShapeFrontCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontCombo.Location = new System.Drawing.Point(52, 37);
            this.ShapeFrontCombo.Name = "ShapeFrontCombo";
            this.ShapeFrontCombo.Size = new System.Drawing.Size(85, 21);
            this.ShapeFrontCombo.TabIndex = 34;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(140, 41);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(47, 13);
            this.label104.TabIndex = 33;
            this.label104.Text = "Position:";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(6, 41);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(38, 13);
            this.label105.TabIndex = 32;
            this.label105.Text = "Shape";
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.TextFrontEnabled);
            this.groupBox33.Controls.Add(this.TextFrontResin);
            this.groupBox33.Controls.Add(this.TextFrontSizeUpDown);
            this.groupBox33.Controls.Add(this.label125);
            this.groupBox33.Controls.Add(this.TextFrontYUpDown);
            this.groupBox33.Controls.Add(this.label126);
            this.groupBox33.Controls.Add(this.TextFrontXUpDown);
            this.groupBox33.Controls.Add(this.label127);
            this.groupBox33.Controls.Add(this.TextFrontStrikethrough);
            this.groupBox33.Controls.Add(this.TextFrontItalic);
            this.groupBox33.Controls.Add(this.TextFrontUnderline);
            this.groupBox33.Controls.Add(this.TextFrontBold);
            this.groupBox33.Controls.Add(this.TextFrontColourCombo);
            this.groupBox33.Controls.Add(this.label128);
            this.groupBox33.Controls.Add(this.label129);
            this.groupBox33.Controls.Add(this.label130);
            this.groupBox33.Controls.Add(this.TextFrontBox);
            this.groupBox33.Location = new System.Drawing.Point(3, 0);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(437, 85);
            this.groupBox33.TabIndex = 1;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Text";
            // 
            // TextFrontEnabled
            // 
            this.TextFrontEnabled.AutoSize = true;
            this.TextFrontEnabled.Checked = true;
            this.TextFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TextFrontEnabled.Location = new System.Drawing.Point(6, 14);
            this.TextFrontEnabled.Name = "TextFrontEnabled";
            this.TextFrontEnabled.Size = new System.Drawing.Size(65, 17);
            this.TextFrontEnabled.TabIndex = 80;
            this.TextFrontEnabled.Text = "Enabled";
            this.TextFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // TextFrontResin
            // 
            this.TextFrontResin.AutoSize = true;
            this.TextFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontResin.Location = new System.Drawing.Point(356, 62);
            this.TextFrontResin.Name = "TextFrontResin";
            this.TextFrontResin.Size = new System.Drawing.Size(75, 17);
            this.TextFrontResin.TabIndex = 79;
            this.TextFrontResin.Text = "Use Resin";
            this.TextFrontResin.UseVisualStyleBackColor = true;
            // 
            // TextFrontSizeUpDown
            // 
            this.TextFrontSizeUpDown.Location = new System.Drawing.Point(241, 60);
            this.TextFrontSizeUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.TextFrontSizeUpDown.Name = "TextFrontSizeUpDown";
            this.TextFrontSizeUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextFrontSizeUpDown.TabIndex = 78;
            this.TextFrontSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(214, 64);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(27, 13);
            this.label125.TabIndex = 77;
            this.label125.Text = "Size";
            // 
            // TextFrontYUpDown
            // 
            this.TextFrontYUpDown.Location = new System.Drawing.Point(144, 60);
            this.TextFrontYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.TextFrontYUpDown.Name = "TextFrontYUpDown";
            this.TextFrontYUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextFrontYUpDown.TabIndex = 76;
            this.TextFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(124, 64);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(14, 13);
            this.label126.TabIndex = 75;
            this.label126.Text = "Y";
            // 
            // TextFrontXUpDown
            // 
            this.TextFrontXUpDown.Location = new System.Drawing.Point(73, 60);
            this.TextFrontXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.TextFrontXUpDown.Name = "TextFrontXUpDown";
            this.TextFrontXUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextFrontXUpDown.TabIndex = 74;
            this.TextFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(53, 64);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(14, 13);
            this.label127.TabIndex = 73;
            this.label127.Text = "X";
            // 
            // TextFrontStrikethrough
            // 
            this.TextFrontStrikethrough.AutoSize = true;
            this.TextFrontStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontStrikethrough.Location = new System.Drawing.Point(342, 39);
            this.TextFrontStrikethrough.Name = "TextFrontStrikethrough";
            this.TextFrontStrikethrough.Size = new System.Drawing.Size(89, 17);
            this.TextFrontStrikethrough.TabIndex = 72;
            this.TextFrontStrikethrough.Text = "Strikethrough";
            this.TextFrontStrikethrough.UseVisualStyleBackColor = true;
            // 
            // TextFrontItalic
            // 
            this.TextFrontItalic.AutoSize = true;
            this.TextFrontItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontItalic.Location = new System.Drawing.Point(282, 39);
            this.TextFrontItalic.Name = "TextFrontItalic";
            this.TextFrontItalic.Size = new System.Drawing.Size(48, 17);
            this.TextFrontItalic.TabIndex = 71;
            this.TextFrontItalic.Text = "Italic";
            this.TextFrontItalic.UseVisualStyleBackColor = true;
            // 
            // TextFrontUnderline
            // 
            this.TextFrontUnderline.AutoSize = true;
            this.TextFrontUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontUnderline.Location = new System.Drawing.Point(201, 39);
            this.TextFrontUnderline.Name = "TextFrontUnderline";
            this.TextFrontUnderline.Size = new System.Drawing.Size(71, 17);
            this.TextFrontUnderline.TabIndex = 70;
            this.TextFrontUnderline.Text = "Underline";
            this.TextFrontUnderline.UseVisualStyleBackColor = true;
            // 
            // TextFrontBold
            // 
            this.TextFrontBold.AutoSize = true;
            this.TextFrontBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontBold.Location = new System.Drawing.Point(144, 39);
            this.TextFrontBold.Name = "TextFrontBold";
            this.TextFrontBold.Size = new System.Drawing.Size(47, 17);
            this.TextFrontBold.TabIndex = 69;
            this.TextFrontBold.Text = "Bold";
            this.TextFrontBold.UseVisualStyleBackColor = true;
            // 
            // TextFrontColourCombo
            // 
            this.TextFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TextFrontColourCombo.Location = new System.Drawing.Point(53, 37);
            this.TextFrontColourCombo.Name = "TextFrontColourCombo";
            this.TextFrontColourCombo.Size = new System.Drawing.Size(85, 21);
            this.TextFrontColourCombo.TabIndex = 34;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(6, 64);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(47, 13);
            this.label128.TabIndex = 33;
            this.label128.Text = "Position:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(6, 41);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(37, 13);
            this.label129.TabIndex = 32;
            this.label129.Text = "Colour";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(110, 16);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(28, 13);
            this.label130.TabIndex = 31;
            this.label130.Text = "Text";
            // 
            // TextFrontBox
            // 
            this.TextFrontBox.Location = new System.Drawing.Point(144, 12);
            this.TextFrontBox.Name = "TextFrontBox";
            this.TextFrontBox.Size = new System.Drawing.Size(287, 20);
            this.TextFrontBox.TabIndex = 14;
            this.TextFrontBox.Text = "Front - First Line of C# Text";
            // 
            // Back
            // 
            this.Back.Controls.Add(this.groupBox19);
            this.Back.Controls.Add(this.groupBox20);
            this.Back.Controls.Add(this.groupBox21);
            this.Back.Controls.Add(this.groupBox22);
            this.Back.Location = new System.Drawing.Point(4, 22);
            this.Back.Name = "Back";
            this.Back.Padding = new System.Windows.Forms.Padding(3);
            this.Back.Size = new System.Drawing.Size(443, 467);
            this.Back.TabIndex = 1;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.ImageBackResin);
            this.groupBox19.Controls.Add(this.ImageBackEnabled);
            this.groupBox19.Controls.Add(ImageBackButton);
            this.groupBox19.Controls.Add(this.ImageBackFileBox);
            this.groupBox19.Controls.Add(this.ImageBackP2UpDown);
            this.groupBox19.Controls.Add(this.label14);
            this.groupBox19.Controls.Add(this.label15);
            this.groupBox19.Controls.Add(this.ImageBackP1UpDown);
            this.groupBox19.Controls.Add(this.ImageBackYUpDown);
            this.groupBox19.Controls.Add(this.label54);
            this.groupBox19.Controls.Add(this.ImageBackXUpDown);
            this.groupBox19.Controls.Add(this.label55);
            this.groupBox19.Controls.Add(this.label56);
            this.groupBox19.Controls.Add(this.label57);
            this.groupBox19.Location = new System.Drawing.Point(3, 273);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(437, 75);
            this.groupBox19.TabIndex = 91;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Image";
            // 
            // ImageBackResin
            // 
            this.ImageBackResin.AutoSize = true;
            this.ImageBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ImageBackResin.Enabled = false;
            this.ImageBackResin.Location = new System.Drawing.Point(356, 42);
            this.ImageBackResin.Name = "ImageBackResin";
            this.ImageBackResin.Size = new System.Drawing.Size(75, 17);
            this.ImageBackResin.TabIndex = 86;
            this.ImageBackResin.Text = "Use Resin";
            this.ImageBackResin.UseVisualStyleBackColor = true;
            // 
            // ImageBackEnabled
            // 
            this.ImageBackEnabled.AutoSize = true;
            this.ImageBackEnabled.Enabled = false;
            this.ImageBackEnabled.Location = new System.Drawing.Point(6, 14);
            this.ImageBackEnabled.Name = "ImageBackEnabled";
            this.ImageBackEnabled.Size = new System.Drawing.Size(65, 17);
            this.ImageBackEnabled.TabIndex = 85;
            this.ImageBackEnabled.Text = "Enabled";
            this.ImageBackEnabled.UseVisualStyleBackColor = true;
            // 
            // ImageBackFileBox
            // 
            this.ImageBackFileBox.Enabled = false;
            this.ImageBackFileBox.Location = new System.Drawing.Point(127, 12);
            this.ImageBackFileBox.Name = "ImageBackFileBox";
            this.ImageBackFileBox.Size = new System.Drawing.Size(273, 20);
            this.ImageBackFileBox.TabIndex = 83;
            // 
            // ImageBackP2UpDown
            // 
            this.ImageBackP2UpDown.Enabled = false;
            this.ImageBackP2UpDown.Location = new System.Drawing.Point(258, 40);
            this.ImageBackP2UpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ImageBackP2UpDown.Name = "ImageBackP2UpDown";
            this.ImageBackP2UpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageBackP2UpDown.TabIndex = 82;
            this.ImageBackP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(238, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 13);
            this.label14.TabIndex = 81;
            this.label14.Text = "P2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(173, 44);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 13);
            this.label15.TabIndex = 80;
            this.label15.Text = "P1";
            // 
            // ImageBackP1UpDown
            // 
            this.ImageBackP1UpDown.Enabled = false;
            this.ImageBackP1UpDown.Location = new System.Drawing.Point(193, 40);
            this.ImageBackP1UpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ImageBackP1UpDown.Name = "ImageBackP1UpDown";
            this.ImageBackP1UpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageBackP1UpDown.TabIndex = 78;
            this.ImageBackP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ImageBackYUpDown
            // 
            this.ImageBackYUpDown.Enabled = false;
            this.ImageBackYUpDown.Location = new System.Drawing.Point(128, 40);
            this.ImageBackYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ImageBackYUpDown.Name = "ImageBackYUpDown";
            this.ImageBackYUpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageBackYUpDown.TabIndex = 76;
            this.ImageBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(114, 44);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(14, 13);
            this.label54.TabIndex = 75;
            this.label54.Text = "Y";
            // 
            // ImageBackXUpDown
            // 
            this.ImageBackXUpDown.Enabled = false;
            this.ImageBackXUpDown.Location = new System.Drawing.Point(69, 40);
            this.ImageBackXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ImageBackXUpDown.Name = "ImageBackXUpDown";
            this.ImageBackXUpDown.Size = new System.Drawing.Size(45, 20);
            this.ImageBackXUpDown.TabIndex = 74;
            this.ImageBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(56, 44);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(14, 13);
            this.label55.TabIndex = 73;
            this.label55.Text = "X";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(6, 44);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(47, 13);
            this.label56.TabIndex = 33;
            this.label56.Text = "Position:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(91, 16);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(23, 13);
            this.label57.TabIndex = 32;
            this.label57.Text = "File";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.LineBackEnabled);
            this.groupBox20.Controls.Add(this.label58);
            this.groupBox20.Controls.Add(this.LineBackWidthUpDown);
            this.groupBox20.Controls.Add(this.label59);
            this.groupBox20.Controls.Add(this.LineBackStartYUpDown);
            this.groupBox20.Controls.Add(this.LineBackEndYUpDown);
            this.groupBox20.Controls.Add(this.label60);
            this.groupBox20.Controls.Add(this.label61);
            this.groupBox20.Controls.Add(this.label62);
            this.groupBox20.Controls.Add(this.label63);
            this.groupBox20.Controls.Add(this.LineBackResin);
            this.groupBox20.Controls.Add(this.LineBackEndXUpDown);
            this.groupBox20.Controls.Add(this.LineBackColourCombo);
            this.groupBox20.Controls.Add(this.LineBackStartXUpDown);
            this.groupBox20.Controls.Add(this.label64);
            this.groupBox20.Controls.Add(this.label65);
            this.groupBox20.Location = new System.Drawing.Point(3, 182);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(437, 85);
            this.groupBox20.TabIndex = 90;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Line";
            // 
            // LineBackEnabled
            // 
            this.LineBackEnabled.AutoSize = true;
            this.LineBackEnabled.Enabled = false;
            this.LineBackEnabled.Location = new System.Drawing.Point(6, 14);
            this.LineBackEnabled.Name = "LineBackEnabled";
            this.LineBackEnabled.Size = new System.Drawing.Size(65, 17);
            this.LineBackEnabled.TabIndex = 84;
            this.LineBackEnabled.Text = "Enabled";
            this.LineBackEnabled.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(188, 63);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(29, 13);
            this.label58.TabIndex = 82;
            this.label58.Text = "End:";
            // 
            // LineBackWidthUpDown
            // 
            this.LineBackWidthUpDown.Enabled = false;
            this.LineBackWidthUpDown.Location = new System.Drawing.Point(234, 32);
            this.LineBackWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.LineBackWidthUpDown.Name = "LineBackWidthUpDown";
            this.LineBackWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineBackWidthUpDown.TabIndex = 81;
            this.LineBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(201, 36);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(35, 13);
            this.label59.TabIndex = 80;
            this.label59.Text = "Width";
            // 
            // LineBackStartYUpDown
            // 
            this.LineBackStartYUpDown.Enabled = false;
            this.LineBackStartYUpDown.Location = new System.Drawing.Point(115, 59);
            this.LineBackStartYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.LineBackStartYUpDown.Name = "LineBackStartYUpDown";
            this.LineBackStartYUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineBackStartYUpDown.TabIndex = 76;
            this.LineBackStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineBackEndYUpDown
            // 
            this.LineBackEndYUpDown.Enabled = false;
            this.LineBackEndYUpDown.Location = new System.Drawing.Point(295, 59);
            this.LineBackEndYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.LineBackEndYUpDown.Name = "LineBackEndYUpDown";
            this.LineBackEndYUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineBackEndYUpDown.TabIndex = 82;
            this.LineBackEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(6, 62);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(32, 13);
            this.label60.TabIndex = 80;
            this.label60.Text = "Start:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(281, 63);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(14, 13);
            this.label61.TabIndex = 81;
            this.label61.Text = "Y";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(42, 63);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(14, 13);
            this.label62.TabIndex = 73;
            this.label62.Text = "X";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(220, 63);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(14, 13);
            this.label63.TabIndex = 80;
            this.label63.Text = "X";
            // 
            // LineBackResin
            // 
            this.LineBackResin.AutoSize = true;
            this.LineBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LineBackResin.Enabled = false;
            this.LineBackResin.Location = new System.Drawing.Point(356, 14);
            this.LineBackResin.Name = "LineBackResin";
            this.LineBackResin.Size = new System.Drawing.Size(75, 17);
            this.LineBackResin.TabIndex = 79;
            this.LineBackResin.Text = "Use Resin";
            this.LineBackResin.UseVisualStyleBackColor = true;
            // 
            // LineBackEndXUpDown
            // 
            this.LineBackEndXUpDown.Enabled = false;
            this.LineBackEndXUpDown.Location = new System.Drawing.Point(234, 59);
            this.LineBackEndXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.LineBackEndXUpDown.Name = "LineBackEndXUpDown";
            this.LineBackEndXUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineBackEndXUpDown.TabIndex = 78;
            this.LineBackEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineBackColourCombo
            // 
            this.LineBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LineBackColourCombo.Enabled = false;
            this.LineBackColourCombo.Location = new System.Drawing.Point(56, 32);
            this.LineBackColourCombo.Name = "LineBackColourCombo";
            this.LineBackColourCombo.Size = new System.Drawing.Size(139, 21);
            this.LineBackColourCombo.TabIndex = 34;
            // 
            // LineBackStartXUpDown
            // 
            this.LineBackStartXUpDown.Enabled = false;
            this.LineBackStartXUpDown.Location = new System.Drawing.Point(56, 59);
            this.LineBackStartXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.LineBackStartXUpDown.Name = "LineBackStartXUpDown";
            this.LineBackStartXUpDown.Size = new System.Drawing.Size(45, 20);
            this.LineBackStartXUpDown.TabIndex = 74;
            this.LineBackStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(6, 36);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(37, 13);
            this.label64.TabIndex = 32;
            this.label64.Text = "Colour";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(101, 63);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(14, 13);
            this.label65.TabIndex = 75;
            this.label65.Text = "Y";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.ShapeBackEnabled);
            this.groupBox21.Controls.Add(this.ShapeBackFillCombo);
            this.groupBox21.Controls.Add(this.label66);
            this.groupBox21.Controls.Add(this.ShapeBackWidthUpDown);
            this.groupBox21.Controls.Add(this.ShapeBackOutlineCombo);
            this.groupBox21.Controls.Add(this.label67);
            this.groupBox21.Controls.Add(this.label68);
            this.groupBox21.Controls.Add(this.ShapeBackBUpDown);
            this.groupBox21.Controls.Add(this.label70);
            this.groupBox21.Controls.Add(this.label71);
            this.groupBox21.Controls.Add(this.ShapeBackResin);
            this.groupBox21.Controls.Add(this.ShapeBackRUpDown);
            this.groupBox21.Controls.Add(this.ShapeBackTUpDown);
            this.groupBox21.Controls.Add(this.label72);
            this.groupBox21.Controls.Add(this.ShapeBackLUpDown);
            this.groupBox21.Controls.Add(this.label73);
            this.groupBox21.Controls.Add(this.ShapeBackCombo);
            this.groupBox21.Controls.Add(this.label74);
            this.groupBox21.Controls.Add(this.label75);
            this.groupBox21.Location = new System.Drawing.Point(3, 91);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(437, 85);
            this.groupBox21.TabIndex = 89;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Shape";
            // 
            // ShapeBackEnabled
            // 
            this.ShapeBackEnabled.AutoSize = true;
            this.ShapeBackEnabled.Enabled = false;
            this.ShapeBackEnabled.Location = new System.Drawing.Point(6, 14);
            this.ShapeBackEnabled.Name = "ShapeBackEnabled";
            this.ShapeBackEnabled.Size = new System.Drawing.Size(65, 17);
            this.ShapeBackEnabled.TabIndex = 83;
            this.ShapeBackEnabled.Text = "Enabled";
            this.ShapeBackEnabled.UseVisualStyleBackColor = true;
            // 
            // ShapeBackFillCombo
            // 
            this.ShapeBackFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackFillCombo.Enabled = false;
            this.ShapeBackFillCombo.Items.AddRange(new object[] {
            "Red",
            "Green",
            "Blue",
            "Cyan",
            "Magenta",
            "Yellow",
            "White",
            "Black",
            "Transparent"});
            this.ShapeBackFillCombo.Location = new System.Drawing.Point(251, 60);
            this.ShapeBackFillCombo.Name = "ShapeBackFillCombo";
            this.ShapeBackFillCombo.Size = new System.Drawing.Size(127, 21);
            this.ShapeBackFillCombo.TabIndex = 81;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(232, 64);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(19, 13);
            this.label66.TabIndex = 80;
            this.label66.Text = "Fill";
            // 
            // ShapeBackWidthUpDown
            // 
            this.ShapeBackWidthUpDown.Enabled = false;
            this.ShapeBackWidthUpDown.Location = new System.Drawing.Point(176, 60);
            this.ShapeBackWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ShapeBackWidthUpDown.Name = "ShapeBackWidthUpDown";
            this.ShapeBackWidthUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeBackWidthUpDown.TabIndex = 81;
            this.ShapeBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeBackOutlineCombo
            // 
            this.ShapeBackOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackOutlineCombo.Enabled = false;
            this.ShapeBackOutlineCombo.Location = new System.Drawing.Point(52, 60);
            this.ShapeBackOutlineCombo.Name = "ShapeBackOutlineCombo";
            this.ShapeBackOutlineCombo.Size = new System.Drawing.Size(85, 21);
            this.ShapeBackOutlineCombo.TabIndex = 81;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(143, 64);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(35, 13);
            this.label67.TabIndex = 80;
            this.label67.Text = "Width";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(6, 64);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(40, 13);
            this.label68.TabIndex = 80;
            this.label68.Text = "Outline";
            // 
            // ShapeBackBUpDown
            // 
            this.ShapeBackBUpDown.Enabled = false;
            this.ShapeBackBUpDown.Location = new System.Drawing.Point(378, 37);
            this.ShapeBackBUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ShapeBackBUpDown.Name = "ShapeBackBUpDown";
            this.ShapeBackBUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeBackBUpDown.TabIndex = 82;
            this.ShapeBackBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(364, 41);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(14, 13);
            this.label70.TabIndex = 81;
            this.label70.Text = "B";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(304, 41);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(15, 13);
            this.label71.TabIndex = 80;
            this.label71.Text = "R";
            // 
            // ShapeBackResin
            // 
            this.ShapeBackResin.AutoSize = true;
            this.ShapeBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShapeBackResin.Enabled = false;
            this.ShapeBackResin.Location = new System.Drawing.Point(356, 14);
            this.ShapeBackResin.Name = "ShapeBackResin";
            this.ShapeBackResin.Size = new System.Drawing.Size(75, 17);
            this.ShapeBackResin.TabIndex = 79;
            this.ShapeBackResin.Text = "Use Resin";
            this.ShapeBackResin.UseVisualStyleBackColor = true;
            // 
            // ShapeBackRUpDown
            // 
            this.ShapeBackRUpDown.Enabled = false;
            this.ShapeBackRUpDown.Location = new System.Drawing.Point(319, 37);
            this.ShapeBackRUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ShapeBackRUpDown.Name = "ShapeBackRUpDown";
            this.ShapeBackRUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeBackRUpDown.TabIndex = 78;
            this.ShapeBackRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeBackTUpDown
            // 
            this.ShapeBackTUpDown.Enabled = false;
            this.ShapeBackTUpDown.Location = new System.Drawing.Point(259, 37);
            this.ShapeBackTUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.ShapeBackTUpDown.Name = "ShapeBackTUpDown";
            this.ShapeBackTUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeBackTUpDown.TabIndex = 76;
            this.ShapeBackTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(245, 41);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(14, 13);
            this.label72.TabIndex = 75;
            this.label72.Text = "T";
            // 
            // ShapeBackLUpDown
            // 
            this.ShapeBackLUpDown.Enabled = false;
            this.ShapeBackLUpDown.Location = new System.Drawing.Point(200, 37);
            this.ShapeBackLUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.ShapeBackLUpDown.Name = "ShapeBackLUpDown";
            this.ShapeBackLUpDown.Size = new System.Drawing.Size(45, 20);
            this.ShapeBackLUpDown.TabIndex = 74;
            this.ShapeBackLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(187, 41);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(13, 13);
            this.label73.TabIndex = 73;
            this.label73.Text = "L";
            // 
            // ShapeBackCombo
            // 
            this.ShapeBackCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackCombo.Enabled = false;
            this.ShapeBackCombo.Location = new System.Drawing.Point(52, 37);
            this.ShapeBackCombo.Name = "ShapeBackCombo";
            this.ShapeBackCombo.Size = new System.Drawing.Size(85, 21);
            this.ShapeBackCombo.TabIndex = 34;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(140, 41);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(47, 13);
            this.label74.TabIndex = 33;
            this.label74.Text = "Position:";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(6, 41);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(38, 13);
            this.label75.TabIndex = 32;
            this.label75.Text = "Shape";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.TextBackEnabled);
            this.groupBox22.Controls.Add(this.TextBackResin);
            this.groupBox22.Controls.Add(this.TextBackSizeUpDown);
            this.groupBox22.Controls.Add(this.label76);
            this.groupBox22.Controls.Add(this.TextBackYUpDown);
            this.groupBox22.Controls.Add(this.label77);
            this.groupBox22.Controls.Add(this.TextBackXUpDown);
            this.groupBox22.Controls.Add(this.label81);
            this.groupBox22.Controls.Add(this.TextBackStrikethrough);
            this.groupBox22.Controls.Add(this.TextBackItalic);
            this.groupBox22.Controls.Add(this.TextBackUnderline);
            this.groupBox22.Controls.Add(this.TextBackBold);
            this.groupBox22.Controls.Add(this.TextBackColourCombo);
            this.groupBox22.Controls.Add(this.label82);
            this.groupBox22.Controls.Add(this.label83);
            this.groupBox22.Controls.Add(this.label84);
            this.groupBox22.Controls.Add(this.TextBackBox);
            this.groupBox22.Location = new System.Drawing.Point(3, 0);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(437, 85);
            this.groupBox22.TabIndex = 88;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Text";
            // 
            // TextBackEnabled
            // 
            this.TextBackEnabled.AutoSize = true;
            this.TextBackEnabled.Enabled = false;
            this.TextBackEnabled.Location = new System.Drawing.Point(6, 14);
            this.TextBackEnabled.Name = "TextBackEnabled";
            this.TextBackEnabled.Size = new System.Drawing.Size(65, 17);
            this.TextBackEnabled.TabIndex = 80;
            this.TextBackEnabled.Text = "Enabled";
            this.TextBackEnabled.UseVisualStyleBackColor = true;
            // 
            // TextBackResin
            // 
            this.TextBackResin.AutoSize = true;
            this.TextBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackResin.Enabled = false;
            this.TextBackResin.Location = new System.Drawing.Point(356, 62);
            this.TextBackResin.Name = "TextBackResin";
            this.TextBackResin.Size = new System.Drawing.Size(75, 17);
            this.TextBackResin.TabIndex = 79;
            this.TextBackResin.Text = "Use Resin";
            this.TextBackResin.UseVisualStyleBackColor = true;
            // 
            // TextBackSizeUpDown
            // 
            this.TextBackSizeUpDown.Enabled = false;
            this.TextBackSizeUpDown.Location = new System.Drawing.Point(241, 60);
            this.TextBackSizeUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.TextBackSizeUpDown.Name = "TextBackSizeUpDown";
            this.TextBackSizeUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextBackSizeUpDown.TabIndex = 78;
            this.TextBackSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(214, 64);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(27, 13);
            this.label76.TabIndex = 77;
            this.label76.Text = "Size";
            // 
            // TextBackYUpDown
            // 
            this.TextBackYUpDown.Enabled = false;
            this.TextBackYUpDown.Location = new System.Drawing.Point(144, 60);
            this.TextBackYUpDown.Maximum = new decimal(new int[] {
            664,
            0,
            0,
            0});
            this.TextBackYUpDown.Name = "TextBackYUpDown";
            this.TextBackYUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextBackYUpDown.TabIndex = 76;
            this.TextBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(124, 64);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(14, 13);
            this.label77.TabIndex = 75;
            this.label77.Text = "Y";
            // 
            // TextBackXUpDown
            // 
            this.TextBackXUpDown.Enabled = false;
            this.TextBackXUpDown.Location = new System.Drawing.Point(73, 60);
            this.TextBackXUpDown.Maximum = new decimal(new int[] {
            1036,
            0,
            0,
            0});
            this.TextBackXUpDown.Name = "TextBackXUpDown";
            this.TextBackXUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextBackXUpDown.TabIndex = 74;
            this.TextBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(53, 64);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(14, 13);
            this.label81.TabIndex = 73;
            this.label81.Text = "X";
            // 
            // TextBackStrikethrough
            // 
            this.TextBackStrikethrough.AutoSize = true;
            this.TextBackStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackStrikethrough.Enabled = false;
            this.TextBackStrikethrough.Location = new System.Drawing.Point(342, 39);
            this.TextBackStrikethrough.Name = "TextBackStrikethrough";
            this.TextBackStrikethrough.Size = new System.Drawing.Size(89, 17);
            this.TextBackStrikethrough.TabIndex = 72;
            this.TextBackStrikethrough.Text = "Strikethrough";
            this.TextBackStrikethrough.UseVisualStyleBackColor = true;
            // 
            // TextBackItalic
            // 
            this.TextBackItalic.AutoSize = true;
            this.TextBackItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackItalic.Enabled = false;
            this.TextBackItalic.Location = new System.Drawing.Point(282, 39);
            this.TextBackItalic.Name = "TextBackItalic";
            this.TextBackItalic.Size = new System.Drawing.Size(48, 17);
            this.TextBackItalic.TabIndex = 71;
            this.TextBackItalic.Text = "Italic";
            this.TextBackItalic.UseVisualStyleBackColor = true;
            // 
            // TextBackUnderline
            // 
            this.TextBackUnderline.AutoSize = true;
            this.TextBackUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackUnderline.Enabled = false;
            this.TextBackUnderline.Location = new System.Drawing.Point(201, 39);
            this.TextBackUnderline.Name = "TextBackUnderline";
            this.TextBackUnderline.Size = new System.Drawing.Size(71, 17);
            this.TextBackUnderline.TabIndex = 70;
            this.TextBackUnderline.Text = "Underline";
            this.TextBackUnderline.UseVisualStyleBackColor = true;
            // 
            // TextBackBold
            // 
            this.TextBackBold.AutoSize = true;
            this.TextBackBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackBold.Enabled = false;
            this.TextBackBold.Location = new System.Drawing.Point(144, 39);
            this.TextBackBold.Name = "TextBackBold";
            this.TextBackBold.Size = new System.Drawing.Size(47, 17);
            this.TextBackBold.TabIndex = 69;
            this.TextBackBold.Text = "Bold";
            this.TextBackBold.UseVisualStyleBackColor = true;
            // 
            // TextBackColourCombo
            // 
            this.TextBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TextBackColourCombo.Enabled = false;
            this.TextBackColourCombo.Location = new System.Drawing.Point(53, 37);
            this.TextBackColourCombo.Name = "TextBackColourCombo";
            this.TextBackColourCombo.Size = new System.Drawing.Size(85, 21);
            this.TextBackColourCombo.TabIndex = 34;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(6, 64);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(47, 13);
            this.label82.TabIndex = 33;
            this.label82.Text = "Position:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(6, 41);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(37, 13);
            this.label83.TabIndex = 32;
            this.label83.Text = "Colour";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(110, 16);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(28, 13);
            this.label84.TabIndex = 31;
            this.label84.Text = "Text";
            // 
            // TextBackBox
            // 
            this.TextBackBox.Enabled = false;
            this.TextBackBox.Location = new System.Drawing.Point(144, 12);
            this.TextBackBox.Name = "TextBackBox";
            this.TextBackBox.Size = new System.Drawing.Size(287, 20);
            this.TextBackBox.TabIndex = 14;
            this.TextBackBox.Text = "Back - First Line of C# Text";
            // 
            // CardBack
            // 
            this.CardBack.AutoSize = true;
            this.CardBack.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CardBack.Location = new System.Drawing.Point(248, 8);
            this.CardBack.Name = "CardBack";
            this.CardBack.Size = new System.Drawing.Size(76, 17);
            this.CardBack.TabIndex = 67;
            this.CardBack.Text = "Card Back";
            this.CardBack.UseVisualStyleBackColor = true;
            this.CardBack.CheckedChanged += new System.EventHandler(this.CardBackCheck_CheckedChanged);
            // 
            // CardFront
            // 
            this.CardFront.AutoSize = true;
            this.CardFront.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CardFront.Checked = true;
            this.CardFront.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CardFront.Location = new System.Drawing.Point(140, 8);
            this.CardFront.Name = "CardFront";
            this.CardFront.Size = new System.Drawing.Size(75, 17);
            this.CardFront.TabIndex = 66;
            this.CardFront.Text = "Card Front";
            this.CardFront.UseVisualStyleBackColor = true;
            this.CardFront.CheckedChanged += new System.EventHandler(this.CardFront_CheckedChanged);
            // 
            // PrintButton
            // 
            this.PrintButton.Location = new System.Drawing.Point(361, 528);
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(90, 24);
            this.PrintButton.TabIndex = 17;
            this.PrintButton.Text = "Print";
            this.PrintButton.UseVisualStyleBackColor = true;
            this.PrintButton.Click += new System.EventHandler(this.PrintButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(135, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 25;
            // 
            // PrinterID
            // 
            this.PrinterID.AutoSize = true;
            this.PrinterID.Location = new System.Drawing.Point(9, 604);
            this.PrinterID.Name = "PrinterID";
            this.PrinterID.Size = new System.Drawing.Size(40, 13);
            this.PrinterID.TabIndex = 12;
            this.PrinterID.Text = "Printer:";
            this.PrinterID.Visible = false;
            // 
            // PrinterPrefs
            // 
            this.PrinterPrefs.Location = new System.Drawing.Point(8, 528);
            this.PrinterPrefs.Name = "PrinterPrefs";
            this.PrinterPrefs.Size = new System.Drawing.Size(108, 24);
            this.PrinterPrefs.TabIndex = 38;
            this.PrinterPrefs.Text = "Printer Preferences";
            this.PrinterPrefs.UseVisualStyleBackColor = true;
            this.PrinterPrefs.Visible = false;
            this.PrinterPrefs.Click += new System.EventHandler(this.PrinterPrefs_Click);
            // 
            // SDK_CSDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 634);
            this.Controls.Add(this.PrinterID);
            this.Controls.Add(this.TabControl);
            this.Controls.Add(this.ExitButton);
            this.Name = "SDK_CSDemo";
            this.Text = "Ultima SDK C# Demo (64)";
            this.TabControl.ResumeLayout(false);
            this.Main.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.Information.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.MagEncoding.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StartPosn)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.DriverSettings1.ResumeLayout(false);
            this.DriverSettings1.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaLeftUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaNo)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaNoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaLeftUpDown)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OvercoatPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YMCPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpnessUpDown)).EndInit();
            this.DriverSettings2.ResumeLayout(false);
            this.DriverSettings2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_WhiteRef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_BlackRef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Blue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Tint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Colour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Brightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Contrast)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteImageUpDown)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CopyCountUpDown)).EndInit();
            this.PrintDemo.ResumeLayout(false);
            this.PrintDemo.PerformLayout();
            this.CardSide.ResumeLayout(false);
            this.Front.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP2UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP1UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontXUpDown)).EndInit();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndXUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartXUpDown)).EndInit();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontBUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontRUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontTUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontLUpDown)).EndInit();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontSizeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).EndInit();
            this.Back.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP2UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP1UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackXUpDown)).EndInit();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndXUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartXUpDown)).EndInit();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackBUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackRUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackTUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackLUpDown)).EndInit();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackSizeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackXUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseSessionButton;
        private System.Windows.Forms.Button OpenSessionButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TextBox InfoMsgBox;
        private System.Windows.Forms.Button PrinterStatusButton;
        private System.Windows.Forms.TabControl TabControl;
        private System.Windows.Forms.TabPage Main;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox EjectModeCombo;
        private System.Windows.Forms.Button RestartButton;
        private System.Windows.Forms.Button MoveCardButton;
        private System.Windows.Forms.Button CleanPrinterButton;
        private System.Windows.Forms.Button EjectModeButton;
        private System.Windows.Forms.Button TestCardButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ClearMsgBoxButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button ErrorResponseButton;
        private System.Windows.Forms.ComboBox ErrorResponseCombo;
        private System.Windows.Forms.TabPage DriverSettings1;
        private System.Windows.Forms.TabPage DriverSettings2;
        private System.Windows.Forms.TabPage PrintDemo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton PrinterSetRadio;
        private System.Windows.Forms.RadioButton PrinterGetRadio;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button SDKVersionButton;
        private System.Windows.Forms.Button ConnectionTypeButton;
        private System.Windows.Forms.TextBox PrinterMsgBox;
        private System.Windows.Forms.Button PrintButton;
        private System.Windows.Forms.Button ClearPrinterMsgButton;
        private System.Windows.Forms.Button ClearDriver1MsgBoxButton;
        private System.Windows.Forms.TextBox Driver1MsgBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton Driver1SetRadio;
        private System.Windows.Forms.RadioButton Driver1GetRadio;
        private System.Windows.Forms.Button ClearDriver2MsgBoxButton;
        private System.Windows.Forms.TextBox Driver2MsgBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton Driver2SetRadio;
        private System.Windows.Forms.RadioButton Driver2GetRadio;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown OvercoatPowerUpDown;
        private System.Windows.Forms.NumericUpDown ResinPowerUpDown;
        private System.Windows.Forms.NumericUpDown YMCPowerUpDown;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button PowerLevelButton;
        private System.Windows.Forms.Button ColourCorrectionButton;
        private System.Windows.Forms.ComboBox CorrectionCombo;
        private System.Windows.Forms.NumericUpDown SharpnessUpDown;
        private System.Windows.Forms.Button GUIControlButton;
        private System.Windows.Forms.Button SharpnessButton;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown ResinAreaNoUpDown;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox ResinAreaSideCombo;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown ResinAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown ResinAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown ResinAreaLeftUpDown;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button ResinAreaButton;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown ResinAreaHeightUpDown;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.ComboBox CardSettingsSideCombo;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox OrientationCombo;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox ColourFormatCombo;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button CardSettingsButton;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox CardSizeCombo;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown CopyCountUpDown;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox DuplexCombo;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button PrintSettingsButton;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.NumericUpDown HoloKoteImageUpDown;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox HoloKoteSideCombo;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox HoloKoteRotationCombo;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button HoloKoteButton;
        private System.Windows.Forms.CheckBox Rotate;
        private System.Windows.Forms.CheckBox Overcoat;
        private System.Windows.Forms.CheckBox CardFront;
        private System.Windows.Forms.Label IPModeLabel;
        private System.Windows.Forms.ComboBox IPModeCombo;
        private System.Windows.Forms.TabPage Information;
        private System.Windows.Forms.TabPage MagEncoding;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox EncodingBox;
        private System.Windows.Forms.Button ReadMagButton;
        private System.Windows.Forms.Button ClearEncodingBoxButton;
        private System.Windows.Forms.TextBox Track2Data;
        private System.Windows.Forms.CheckBox Track1Write;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox Track2Write;
        private System.Windows.Forms.CheckBox Track3Write;
        private System.Windows.Forms.TextBox Track1Data;
        private System.Windows.Forms.TextBox Track3Data;
        private System.Windows.Forms.ComboBox EncodingTypeCombo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CoercivityCombo;
        private System.Windows.Forms.CheckBox Verify;
        private System.Windows.Forms.ComboBox T1_BPCCombo;
        private System.Windows.Forms.ComboBox T1_BPICombo;
        private System.Windows.Forms.Button EncodeMagButton;
        private System.Windows.Forms.ComboBox T2_BPCCombo;
        private System.Windows.Forms.ComboBox T3_BPCCombo;
        private System.Windows.Forms.ComboBox T2_BPICombo;
        private System.Windows.Forms.ComboBox T3_BPICombo;
        private System.Windows.Forms.Label Track3Label;
        private System.Windows.Forms.Label Track2Label;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label JIS2Label;
        private System.Windows.Forms.Label BitsPerInchLabel;
        private System.Windows.Forms.Label BitsPerCharLabel;
        private System.Windows.Forms.Label Track3SettingsLabel;
        private System.Windows.Forms.Label Track2SettingsLabel;
        private System.Windows.Forms.Label Track1SettingsLabel;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label Track1Label;
        private System.Windows.Forms.Button IPSettingsButton;
        private System.Windows.Forms.Label IPGatewayLabel;
        private System.Windows.Forms.Label IPSubnetLabel;
        private System.Windows.Forms.Label IPAddrLabel;
        private System.Windows.Forms.TextBox IPGatewayBox;
        private System.Windows.Forms.TextBox IPSubnetBox;
        private System.Windows.Forms.TextBox IPAddressBox;
        private System.Windows.Forms.CheckBox GUIPrinter;
        private System.Windows.Forms.CheckBox GUIUser;
        private System.Windows.Forms.ComboBox SessionConfigCombo;
        private System.Windows.Forms.Button PrinterModelButton;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.ComboBox MoveCardCombo;
        private System.Windows.Forms.CheckBox CardBack;
        private System.Windows.Forms.TabControl CardSide;
        private System.Windows.Forms.TabPage Front;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button ImageFrontButton;
        private System.Windows.Forms.TextBox ImageFrontFileBox;
        private System.Windows.Forms.NumericUpDown ImageFrontP2UpDown;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.NumericUpDown ImageFrontP1UpDown;
        private System.Windows.Forms.NumericUpDown ImageFrontYUpDown;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.NumericUpDown ImageFrontXUpDown;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.NumericUpDown LineFrontWidthUpDown;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown LineFrontStartYUpDown;
        private System.Windows.Forms.NumericUpDown LineFrontEndYUpDown;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.CheckBox LineFrontResin;
        private System.Windows.Forms.NumericUpDown LineFrontEndXUpDown;
        private System.Windows.Forms.ComboBox LineFrontColourCombo;
        private System.Windows.Forms.NumericUpDown LineFrontStartXUpDown;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.ComboBox ShapeFrontFillCombo;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.NumericUpDown ShapeFrontWidthUpDown;
        private System.Windows.Forms.ComboBox ShapeFrontOutlineCombo;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.NumericUpDown ShapeFrontBUpDown;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.CheckBox ShapeFrontResin;
        private System.Windows.Forms.NumericUpDown ShapeFrontRUpDown;
        private System.Windows.Forms.NumericUpDown ShapeFrontTUpDown;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.NumericUpDown ShapeFrontLUpDown;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.ComboBox ShapeFrontCombo;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.CheckBox TextFrontResin;
        private System.Windows.Forms.NumericUpDown TextFrontSizeUpDown;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.NumericUpDown TextFrontYUpDown;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.NumericUpDown TextFrontXUpDown;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.CheckBox TextFrontStrikethrough;
        private System.Windows.Forms.CheckBox TextFrontItalic;
        private System.Windows.Forms.CheckBox TextFrontUnderline;
        private System.Windows.Forms.CheckBox TextFrontBold;
        private System.Windows.Forms.ComboBox TextFrontColourCombo;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox TextFrontBox;
        private System.Windows.Forms.TabPage Back;
        private System.Windows.Forms.CheckBox ShapeFrontEnabled;
        private System.Windows.Forms.CheckBox TextFrontEnabled;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox Track3MagData;
        private System.Windows.Forms.TextBox Track2MagData;
        private System.Windows.Forms.TextBox Track1MagData;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox MagDataEnabled;
        private System.Windows.Forms.CheckBox ImageFrontEnabled;
        private System.Windows.Forms.CheckBox LineFrontEnabled;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox ImageBackEnabled;
        private System.Windows.Forms.TextBox ImageBackFileBox;
        private System.Windows.Forms.NumericUpDown ImageBackP2UpDown;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown ImageBackP1UpDown;
        private System.Windows.Forms.NumericUpDown ImageBackYUpDown;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.NumericUpDown ImageBackXUpDown;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox LineBackEnabled;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown LineBackWidthUpDown;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.NumericUpDown LineBackStartYUpDown;
        private System.Windows.Forms.NumericUpDown LineBackEndYUpDown;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.CheckBox LineBackResin;
        private System.Windows.Forms.NumericUpDown LineBackEndXUpDown;
        private System.Windows.Forms.ComboBox LineBackColourCombo;
        private System.Windows.Forms.NumericUpDown LineBackStartXUpDown;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.CheckBox ShapeBackEnabled;
        private System.Windows.Forms.ComboBox ShapeBackFillCombo;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.NumericUpDown ShapeBackWidthUpDown;
        private System.Windows.Forms.ComboBox ShapeBackOutlineCombo;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown ShapeBackBUpDown;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.CheckBox ShapeBackResin;
        private System.Windows.Forms.NumericUpDown ShapeBackRUpDown;
        private System.Windows.Forms.NumericUpDown ShapeBackTUpDown;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown ShapeBackLUpDown;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox ShapeBackCombo;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.CheckBox TextBackEnabled;
        private System.Windows.Forms.CheckBox TextBackResin;
        private System.Windows.Forms.NumericUpDown TextBackSizeUpDown;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.NumericUpDown TextBackYUpDown;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.NumericUpDown TextBackXUpDown;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.CheckBox TextBackStrikethrough;
        private System.Windows.Forms.CheckBox TextBackItalic;
        private System.Windows.Forms.CheckBox TextBackUnderline;
        private System.Windows.Forms.CheckBox TextBackBold;
        private System.Windows.Forms.ComboBox TextBackColourCombo;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox TextBackBox;
        private System.Windows.Forms.CheckBox ImageFrontResin;
        private System.Windows.Forms.CheckBox ImageBackResin;
        private System.Windows.Forms.Button PrinterInfoButton;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton EncodingSetRadio;
        private System.Windows.Forms.RadioButton EncodingGetRadio;
        private System.Windows.Forms.Button MagStartButton;
        private System.Windows.Forms.NumericUpDown StartPosn;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.NumericUpDown ColourAreaHeightUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaLeftUpDown;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.NumericUpDown ColourAreaNo;
        private System.Windows.Forms.ComboBox ColourAreaSideCombo;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.ComboBox ColourAreaCorrectionCombo;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Button ColourAreaButton;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.NumericUpDown ColourAdjust_WhiteRef;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.NumericUpDown ColourAdjust_BlackRef;
        private System.Windows.Forms.ComboBox ColourAdjust_Illuminant;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.CheckBox ColourAdjust_Negative;
        private System.Windows.Forms.CheckBox ColourAdjust_DarkPic;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Blue;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Green;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Red;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Tint;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Colour;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Brightness;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Contrast;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Button ColourAdjustBtn;
        private System.Windows.Forms.CheckBox Track3Read;
        private System.Windows.Forms.CheckBox Track2Read;
        private System.Windows.Forms.CheckBox Track1Read;
        private System.Windows.Forms.Button ReadMagTracks;
        private System.Windows.Forms.Button TemperatureButton;
        private System.Windows.Forms.Button LastMessageButton;
        private System.Windows.Forms.Button SDKBitsButton;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox HoloKoteIDSlot;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button HoloKoteIDButton;
        private System.Windows.Forms.Label PrinterID;
        private System.Windows.Forms.Button PrinterPrefs;
        private System.Windows.Forms.Button HoloKotePreviewButton;
        private System.Windows.Forms.Button PrinterTypeButton;
        private System.Windows.Forms.CheckBox nativePrint;
    }
}


#pragma once
#include "afxwin.h"

// CInfoPage dialog
class CInfoPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CInfoPage)

public:
	CInfoPage();
	virtual ~CInfoPage();
	virtual BOOL OnInitDialog();


// Dialog Data
	enum { IDD = IDD_INFOPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedSDKVersionBtn();
	afx_msg void OnBnClickedConnectionTypeBtn();
	afx_msg void OnBnClickedLastMessageBtn();
	afx_msg void OnBnClickedPrinterStatusBtn();
	afx_msg void OnBnClickedPrinterInfoBtn();
	afx_msg void OnBnClickedPrinterModelBtn();
	afx_msg void OnBnClickedBtnGetlastmsg();
	afx_msg void OnBnClickedInfoMsgClrBtn();
	afx_msg void OnBnClickedSDKBitsBtn();
	afx_msg void OnBnClickedBtnPrintertype();
	afx_msg void OnBnClickedTemperatureBtn();

private:
	CMainSheet *Parent;

	CButton ConnectionType;
	CButton SDKVersion;
	CEdit InfoMessage;

	void OutputBurstMessage(TCHAR *str);
	void AddInfoMessage(CString pMessage);

};

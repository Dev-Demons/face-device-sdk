/**
 * @file optima_types.h
 *
 * @brief Portable type definitions.
 *
 * Revision information:
 *
 * $HeadURL: http://ultrasvn/svn/Magicard/Optima/SharedHeaders/trunk/optima_types.h $
 * $LastChangedDate: 2015-01-26 14:03:52 +0000 (Mon, 26 Jan 2015) $
 * $LastChangedRevision: 5514 $
 * $LastChangedBy: aaicken $
 *
 * @copyright Ultra Electronics Ltd.
 *
 ******************************************************************************/

#ifndef _OPTIMA_TYPES_H
#define _OPTIMA_TYPES_H

/******************************************************************************/

typedef unsigned char      uint8;
typedef unsigned short int uint16;
typedef unsigned long int  uint32;

typedef signed char        int8;
typedef signed short int   int16;
typedef signed long int    int32;

typedef volatile uint8     vuint8;
typedef volatile uint16    vuint16;
typedef volatile uint32    vuint32;

typedef volatile int8      vint8;
typedef volatile int16     vint16;
typedef volatile int32     vint32;

#ifndef __cplusplus
typedef uint32             bool;
#endif

/******************************************************************************/

#endif

// SDK_CPPDemo.h : main header file for the SDKDemo application
//

#if !defined(AFX_MAGICARDDEMO_H__F839DA68_3EB6_48B3_9788_ECC386C2F126__INCLUDED_)
#define AFX_MAGICARDDEMO_H__F839DA68_3EB6_48B3_9788_ECC386C2F126__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

//#############################################################################

/////////////////////////////////////////////////////////////////////////////
// CSDKDemoApp:
// See SDKDemo.cpp for the implementation of this class
/////////////////////////////////////////////////////////////////////////////

class CSDKDemoApp : public CWinApp
{
public:
	CSDKDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDKDemoApp)
public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSDKDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAGICARDDEMO_H__F839DA68_3EB6_48B3_9788_ECC386C2F126__INCLUDED_)

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ImageBackButton As System.Windows.Forms.Button
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.Printer = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MoveCardCombo = New System.Windows.Forms.ComboBox()
        Me.RestartButton = New System.Windows.Forms.Button()
        Me.MoveCardButton = New System.Windows.Forms.Button()
        Me.CleanPrinterButton = New System.Windows.Forms.Button()
        Me.PrintTestCardButton = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SessionConfigCombo = New System.Windows.Forms.ComboBox()
        Me.OpenSessionButton = New System.Windows.Forms.Button()
        Me.CloseSessionButton = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ErrorResponseCombo = New System.Windows.Forms.ComboBox()
        Me.ErrorResponseButton = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.groupBox7 = New System.Windows.Forms.GroupBox()
        Me.IPGatewayLabel = New System.Windows.Forms.Label()
        Me.IPSubnetLabel = New System.Windows.Forms.Label()
        Me.IPAddrLabel = New System.Windows.Forms.Label()
        Me.IPGatewayBox = New System.Windows.Forms.TextBox()
        Me.IPSubnetBox = New System.Windows.Forms.TextBox()
        Me.IPAddressBox = New System.Windows.Forms.TextBox()
        Me.IPSettingsButton = New System.Windows.Forms.Button()
        Me.IPModeLabel = New System.Windows.Forms.Label()
        Me.IPModeCombo = New System.Windows.Forms.ComboBox()
        Me.ClearPrinterMsgButton = New System.Windows.Forms.Button()
        Me.label7 = New System.Windows.Forms.Label()
        Me.PrinterSetRadio = New System.Windows.Forms.RadioButton()
        Me.PrinterGetRadio = New System.Windows.Forms.RadioButton()
        Me.EjectModeCombo = New System.Windows.Forms.ComboBox()
        Me.EjectModeButton = New System.Windows.Forms.Button()
        Me.PrinterMsgBox = New System.Windows.Forms.TextBox()
        Me.Information = New System.Windows.Forms.TabPage()
        Me.ClearMsgBoxButton = New System.Windows.Forms.Button()
        Me.GroupBox27 = New System.Windows.Forms.GroupBox()
        Me.PrinterTypeButton = New System.Windows.Forms.Button()
        Me.SDKBitsButton = New System.Windows.Forms.Button()
        Me.LastMessageButton = New System.Windows.Forms.Button()
        Me.TemperatureButton = New System.Windows.Forms.Button()
        Me.PrinterInfoButton = New System.Windows.Forms.Button()
        Me.PrinterModelButton = New System.Windows.Forms.Button()
        Me.InfoMsgBox = New System.Windows.Forms.TextBox()
        Me.ConnectionTypeButton = New System.Windows.Forms.Button()
        Me.PrinterStatusButton = New System.Windows.Forms.Button()
        Me.SDKVersionButton = New System.Windows.Forms.Button()
        Me.Encoding = New System.Windows.Forms.TabPage()
        Me.groupBox5 = New System.Windows.Forms.GroupBox()
        Me.MagStartPosition = New System.Windows.Forms.NumericUpDown()
        Me.label1 = New System.Windows.Forms.Label()
        Me.EncodingSetRadio = New System.Windows.Forms.RadioButton()
        Me.EncodingGetRadio = New System.Windows.Forms.RadioButton()
        Me.MagStartButton = New System.Windows.Forms.Button()
        Me.groupBox9 = New System.Windows.Forms.GroupBox()
        Me.JIS2Label = New System.Windows.Forms.Label()
        Me.label112 = New System.Windows.Forms.Label()
        Me.Track2Data = New System.Windows.Forms.TextBox()
        Me.BitsPerInchLabel = New System.Windows.Forms.Label()
        Me.EncodeMagButton = New System.Windows.Forms.Button()
        Me.BitsPerCharLabel = New System.Windows.Forms.Label()
        Me.Track3SettingsLabel = New System.Windows.Forms.Label()
        Me.Track2SettingsLabel = New System.Windows.Forms.Label()
        Me.Track1SettingsLabel = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.Track3Label = New System.Windows.Forms.Label()
        Me.Track2Label = New System.Windows.Forms.Label()
        Me.Track1Data = New System.Windows.Forms.TextBox()
        Me.Track3Data = New System.Windows.Forms.TextBox()
        Me.Track1 = New System.Windows.Forms.CheckBox()
        Me.Track2 = New System.Windows.Forms.CheckBox()
        Me.Track3 = New System.Windows.Forms.CheckBox()
        Me.EncodingTypeCombo = New System.Windows.Forms.ComboBox()
        Me.CoercivityCombo = New System.Windows.Forms.ComboBox()
        Me.Verify = New System.Windows.Forms.CheckBox()
        Me.T1_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T1_BPICombo = New System.Windows.Forms.ComboBox()
        Me.T2_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T2_BPICombo = New System.Windows.Forms.ComboBox()
        Me.T3_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T3_BPICombo = New System.Windows.Forms.ComboBox()
        Me.Track1Label = New System.Windows.Forms.Label()
        Me.groupBox8 = New System.Windows.Forms.GroupBox()
        Me.Track3Read = New System.Windows.Forms.CheckBox()
        Me.Track2Read = New System.Windows.Forms.CheckBox()
        Me.Track1Read = New System.Windows.Forms.CheckBox()
        Me.ReadMagTracks = New System.Windows.Forms.Button()
        Me.ClearEncodingBoxButton = New System.Windows.Forms.Button()
        Me.ReadMagButton = New System.Windows.Forms.Button()
        Me.EncodingBox = New System.Windows.Forms.TextBox()
        Me.Driver1 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ColourAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ColourAreaNo = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaSideCombo = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ColourAreaCorrectionCombo = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.ColourAreaButton = New System.Windows.Forms.Button()
        Me.GUIPrinterCheck = New System.Windows.Forms.CheckBox()
        Me.GUIUserCheck = New System.Windows.Forms.CheckBox()
        Me.groupBox11 = New System.Windows.Forms.GroupBox()
        Me.label26 = New System.Windows.Forms.Label()
        Me.ResinAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaNoUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label25 = New System.Windows.Forms.Label()
        Me.ResinAreaSideCombo = New System.Windows.Forms.ComboBox()
        Me.label24 = New System.Windows.Forms.Label()
        Me.ResinAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label21 = New System.Windows.Forms.Label()
        Me.label22 = New System.Windows.Forms.Label()
        Me.label23 = New System.Windows.Forms.Label()
        Me.ResinAreaButton = New System.Windows.Forms.Button()
        Me.groupBox10 = New System.Windows.Forms.GroupBox()
        Me.OvercoatPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.YMCPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label19 = New System.Windows.Forms.Label()
        Me.label18 = New System.Windows.Forms.Label()
        Me.PowerLevelButton = New System.Windows.Forms.Button()
        Me.ColourCorrectionButton = New System.Windows.Forms.Button()
        Me.CorrectionCombo = New System.Windows.Forms.ComboBox()
        Me.SharpnessUpDown = New System.Windows.Forms.NumericUpDown()
        Me.GUIControlButton = New System.Windows.Forms.Button()
        Me.SharpnessButton = New System.Windows.Forms.Button()
        Me.label16 = New System.Windows.Forms.Label()
        Me.Driver1SetRadio = New System.Windows.Forms.RadioButton()
        Me.Driver1GetRadio = New System.Windows.Forms.RadioButton()
        Me.ClearDriver1MsgBoxButton = New System.Windows.Forms.Button()
        Me.Driver1MsgBox = New System.Windows.Forms.TextBox()
        Me.Driver2 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.HoloKoteIDSlot = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.HoloKoteIDButton = New System.Windows.Forms.Button()
        Me.groupBox16 = New System.Windows.Forms.GroupBox()
        Me.HoloKotePreviewButton = New System.Windows.Forms.Button()
        Me.HoloKoteImageUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label52 = New System.Windows.Forms.Label()
        Me.HoloKoteSideCombo = New System.Windows.Forms.ComboBox()
        Me.label49 = New System.Windows.Forms.Label()
        Me.HoloKoteRotationCombo = New System.Windows.Forms.ComboBox()
        Me.label50 = New System.Windows.Forms.Label()
        Me.HoloKoteButton = New System.Windows.Forms.Button()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.ColourAdjust_WhiteRef = New System.Windows.Forms.NumericUpDown()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.ColourAdjust_BlackRef = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Illuminant = New System.Windows.Forms.ComboBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.ColourAdjust_Negative = New System.Windows.Forms.CheckBox()
        Me.ColourAdjust_DarkPic = New System.Windows.Forms.CheckBox()
        Me.ColourAdjust_Blue = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Green = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Red = New System.Windows.Forms.NumericUpDown()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.ColourAdjust_Tint = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Colour = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Brightness = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Contrast = New System.Windows.Forms.NumericUpDown()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.ColourAdjustBtn = New System.Windows.Forms.Button()
        Me.groupBox15 = New System.Windows.Forms.GroupBox()
        Me.Rotate = New System.Windows.Forms.CheckBox()
        Me.Overcoat = New System.Windows.Forms.CheckBox()
        Me.CardSettingsSideCombo = New System.Windows.Forms.ComboBox()
        Me.label47 = New System.Windows.Forms.Label()
        Me.OrientationCombo = New System.Windows.Forms.ComboBox()
        Me.label44 = New System.Windows.Forms.Label()
        Me.ColourFormatCombo = New System.Windows.Forms.ComboBox()
        Me.label48 = New System.Windows.Forms.Label()
        Me.CardSettingsButton = New System.Windows.Forms.Button()
        Me.groupBox14 = New System.Windows.Forms.GroupBox()
        Me.CardSizeCombo = New System.Windows.Forms.ComboBox()
        Me.label43 = New System.Windows.Forms.Label()
        Me.CopyCountUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label45 = New System.Windows.Forms.Label()
        Me.DuplexCombo = New System.Windows.Forms.ComboBox()
        Me.label46 = New System.Windows.Forms.Label()
        Me.PrintSettingsButton = New System.Windows.Forms.Button()
        Me.ClearDriver2MsgBoxButton = New System.Windows.Forms.Button()
        Me.Driver2MsgBox = New System.Windows.Forms.TextBox()
        Me.label17 = New System.Windows.Forms.Label()
        Me.Driver2SetRadio = New System.Windows.Forms.RadioButton()
        Me.Driver2GetRadio = New System.Windows.Forms.RadioButton()
        Me.PrintDemo = New System.Windows.Forms.TabPage()
        Me.nativePrint = New System.Windows.Forms.CheckBox()
        Me.CardSide = New System.Windows.Forms.TabControl()
        Me.Front = New System.Windows.Forms.TabPage()
        Me.GroupBox29 = New System.Windows.Forms.GroupBox()
        Me.Track3MagData = New System.Windows.Forms.TextBox()
        Me.Track2MagData = New System.Windows.Forms.TextBox()
        Me.Track1MagData = New System.Windows.Forms.TextBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.MagDataEnabled = New System.Windows.Forms.CheckBox()
        Me.GroupBox30 = New System.Windows.Forms.GroupBox()
        Me.ImageFrontResin = New System.Windows.Forms.CheckBox()
        Me.ImageFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.ImageFrontButton = New System.Windows.Forms.Button()
        Me.ImageFrontFileBox = New System.Windows.Forms.TextBox()
        Me.ImageFrontP2UpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ImageFrontP1UpDown = New System.Windows.Forms.NumericUpDown()
        Me.ImageFrontYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ImageFrontXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.GroupBox31 = New System.Windows.Forms.GroupBox()
        Me.LineFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.LineFrontWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.LineFrontStartYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineFrontEndYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.LineFrontResin = New System.Windows.Forms.CheckBox()
        Me.LineFrontEndXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineFrontColourCombo = New System.Windows.Forms.ComboBox()
        Me.LineFrontStartXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.GroupBox32 = New System.Windows.Forms.GroupBox()
        Me.ShapeFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.ShapeFrontFillCombo = New System.Windows.Forms.ComboBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.ShapeFrontWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeFrontOutlineCombo = New System.Windows.Forms.ComboBox()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.ShapeFrontBUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.ShapeFrontResin = New System.Windows.Forms.CheckBox()
        Me.ShapeFrontRUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeFrontTUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.ShapeFrontLUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.ShapeFrontCombo = New System.Windows.Forms.ComboBox()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.groupBox33 = New System.Windows.Forms.GroupBox()
        Me.TextFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.TextFrontResin = New System.Windows.Forms.CheckBox()
        Me.TextFrontSizeUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.TextFrontYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.TextFrontXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.TextFrontStrikethrough = New System.Windows.Forms.CheckBox()
        Me.TextFrontItalic = New System.Windows.Forms.CheckBox()
        Me.TextFrontUnderline = New System.Windows.Forms.CheckBox()
        Me.TextFrontBold = New System.Windows.Forms.CheckBox()
        Me.TextFrontColourCombo = New System.Windows.Forms.ComboBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.TextFrontBox = New System.Windows.Forms.TextBox()
        Me.Back = New System.Windows.Forms.TabPage()
        Me.GroupBox34 = New System.Windows.Forms.GroupBox()
        Me.ImageBackResin = New System.Windows.Forms.CheckBox()
        Me.ImageBackEnabled = New System.Windows.Forms.CheckBox()
        Me.ImageBackFileBox = New System.Windows.Forms.TextBox()
        Me.ImageBackP2UpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.ImageBackP1UpDown = New System.Windows.Forms.NumericUpDown()
        Me.ImageBackYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.ImageBackXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.GroupBox35 = New System.Windows.Forms.GroupBox()
        Me.LineBackEnabled = New System.Windows.Forms.CheckBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.LineBackWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.LineBackStartYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineBackEndYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.LineBackResin = New System.Windows.Forms.CheckBox()
        Me.LineBackEndXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineBackColourCombo = New System.Windows.Forms.ComboBox()
        Me.LineBackStartXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.GroupBox36 = New System.Windows.Forms.GroupBox()
        Me.ShapeBackEnabled = New System.Windows.Forms.CheckBox()
        Me.ShapeBackFillCombo = New System.Windows.Forms.ComboBox()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.ShapeBackWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeBackOutlineCombo = New System.Windows.Forms.ComboBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.ShapeBackBUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.ShapeBackResin = New System.Windows.Forms.CheckBox()
        Me.ShapeBackRUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeBackTUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.ShapeBackLUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.ShapeBackCombo = New System.Windows.Forms.ComboBox()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.GroupBox37 = New System.Windows.Forms.GroupBox()
        Me.TextBackEnabled = New System.Windows.Forms.CheckBox()
        Me.TextBackResin = New System.Windows.Forms.CheckBox()
        Me.TextBackSizeUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.TextBackYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.TextBackXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.TextBackStrikethrough = New System.Windows.Forms.CheckBox()
        Me.TextBackItalic = New System.Windows.Forms.CheckBox()
        Me.TextBackUnderline = New System.Windows.Forms.CheckBox()
        Me.TextBackBold = New System.Windows.Forms.CheckBox()
        Me.TextBackColourCombo = New System.Windows.Forms.ComboBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.TextBackBox = New System.Windows.Forms.TextBox()
        Me.CardBack = New System.Windows.Forms.CheckBox()
        Me.CardFront = New System.Windows.Forms.CheckBox()
        Me.PrintButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.PrinterID = New System.Windows.Forms.Label()
        Me.PrinterPrefs = New System.Windows.Forms.Button()
        ImageBackButton = New System.Windows.Forms.Button()
        Me.TabControl.SuspendLayout()
        Me.Printer.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.groupBox7.SuspendLayout()
        Me.Information.SuspendLayout()
        Me.GroupBox27.SuspendLayout()
        Me.Encoding.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        CType(Me.MagStartPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox9.SuspendLayout()
        Me.groupBox8.SuspendLayout()
        Me.Driver1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.ColourAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaNo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox11.SuspendLayout()
        CType(Me.ResinAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaNoUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox10.SuspendLayout()
        CType(Me.OvercoatPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YMCPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SharpnessUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Driver2.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.groupBox16.SuspendLayout()
        CType(Me.HoloKoteImageUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox18.SuspendLayout()
        CType(Me.ColourAdjust_WhiteRef, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_BlackRef, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Blue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Green, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Red, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Tint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Colour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Brightness, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Contrast, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox15.SuspendLayout()
        Me.groupBox14.SuspendLayout()
        CType(Me.CopyCountUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PrintDemo.SuspendLayout()
        Me.CardSide.SuspendLayout()
        Me.Front.SuspendLayout()
        Me.GroupBox29.SuspendLayout()
        Me.GroupBox30.SuspendLayout()
        CType(Me.ImageFrontP2UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontP1UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox31.SuspendLayout()
        CType(Me.LineFrontWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontStartYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontEndYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontEndXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontStartXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox32.SuspendLayout()
        CType(Me.ShapeFrontWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontBUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontRUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontTUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontLUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox33.SuspendLayout()
        CType(Me.TextFrontSizeUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextFrontYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextFrontXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Back.SuspendLayout()
        Me.GroupBox34.SuspendLayout()
        CType(Me.ImageBackP2UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackP1UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox35.SuspendLayout()
        CType(Me.LineBackWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackStartYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackEndYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackEndXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackStartXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox36.SuspendLayout()
        CType(Me.ShapeBackWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackBUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackRUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackTUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackLUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox37.SuspendLayout()
        CType(Me.TextBackSizeUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBackYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBackXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ImageBackButton
        '
        ImageBackButton.Enabled = False
        ImageBackButton.Location = New System.Drawing.Point(400, 10)
        ImageBackButton.Name = "ImageBackButton"
        ImageBackButton.Size = New System.Drawing.Size(28, 24)
        ImageBackButton.TabIndex = 70
        ImageBackButton.Text = "..."
        ImageBackButton.UseVisualStyleBackColor = True
        AddHandler ImageBackButton.Click, AddressOf Me.ImageBackButton_Click
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.Printer)
        Me.TabControl.Controls.Add(Me.Information)
        Me.TabControl.Controls.Add(Me.Encoding)
        Me.TabControl.Controls.Add(Me.Driver1)
        Me.TabControl.Controls.Add(Me.Driver2)
        Me.TabControl.Controls.Add(Me.PrintDemo)
        Me.TabControl.Location = New System.Drawing.Point(3, 0)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(472, 592)
        Me.TabControl.TabIndex = 1
        '
        'Printer
        '
        Me.Printer.Controls.Add(Me.GroupBox2)
        Me.Printer.Controls.Add(Me.GroupBox1)
        Me.Printer.Controls.Add(Me.GroupBox4)
        Me.Printer.Controls.Add(Me.GroupBox3)
        Me.Printer.Location = New System.Drawing.Point(4, 22)
        Me.Printer.Name = "Printer"
        Me.Printer.Padding = New System.Windows.Forms.Padding(3)
        Me.Printer.Size = New System.Drawing.Size(464, 566)
        Me.Printer.TabIndex = 0
        Me.Printer.Text = "Printer"
        Me.Printer.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MoveCardCombo)
        Me.GroupBox2.Controls.Add(Me.RestartButton)
        Me.GroupBox2.Controls.Add(Me.MoveCardButton)
        Me.GroupBox2.Controls.Add(Me.CleanPrinterButton)
        Me.GroupBox2.Controls.Add(Me.PrintTestCardButton)
        Me.GroupBox2.Location = New System.Drawing.Point(5, 43)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(271, 121)
        Me.GroupBox2.TabIndex = 30
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Printer Control"
        '
        'MoveCardCombo
        '
        Me.MoveCardCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MoveCardCombo.Enabled = False
        Me.MoveCardCombo.FormattingEnabled = True
        Me.MoveCardCombo.Location = New System.Drawing.Point(96, 21)
        Me.MoveCardCombo.Name = "MoveCardCombo"
        Me.MoveCardCombo.Size = New System.Drawing.Size(155, 21)
        Me.MoveCardCombo.TabIndex = 26
        '
        'RestartButton
        '
        Me.RestartButton.Enabled = False
        Me.RestartButton.Location = New System.Drawing.Point(96, 43)
        Me.RestartButton.Name = "RestartButton"
        Me.RestartButton.Size = New System.Drawing.Size(90, 24)
        Me.RestartButton.TabIndex = 24
        Me.RestartButton.Text = "RestartPrinter"
        Me.RestartButton.UseVisualStyleBackColor = True
        '
        'MoveCardButton
        '
        Me.MoveCardButton.Enabled = False
        Me.MoveCardButton.Location = New System.Drawing.Point(3, 19)
        Me.MoveCardButton.Name = "MoveCardButton"
        Me.MoveCardButton.Size = New System.Drawing.Size(90, 24)
        Me.MoveCardButton.TabIndex = 17
        Me.MoveCardButton.Text = "MoveCard"
        Me.MoveCardButton.UseVisualStyleBackColor = True
        '
        'CleanPrinterButton
        '
        Me.CleanPrinterButton.Enabled = False
        Me.CleanPrinterButton.Location = New System.Drawing.Point(3, 43)
        Me.CleanPrinterButton.Name = "CleanPrinterButton"
        Me.CleanPrinterButton.Size = New System.Drawing.Size(90, 24)
        Me.CleanPrinterButton.TabIndex = 20
        Me.CleanPrinterButton.Text = "CleanPrinter"
        Me.CleanPrinterButton.UseVisualStyleBackColor = True
        '
        'PrintTestCardButton
        '
        Me.PrintTestCardButton.Enabled = False
        Me.PrintTestCardButton.Location = New System.Drawing.Point(3, 67)
        Me.PrintTestCardButton.Name = "PrintTestCardButton"
        Me.PrintTestCardButton.Size = New System.Drawing.Size(90, 24)
        Me.PrintTestCardButton.TabIndex = 23
        Me.PrintTestCardButton.Text = "PrintTestCard"
        Me.PrintTestCardButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SessionConfigCombo)
        Me.GroupBox1.Controls.Add(Me.OpenSessionButton)
        Me.GroupBox1.Controls.Add(Me.CloseSessionButton)
        Me.GroupBox1.Location = New System.Drawing.Point(5, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(271, 43)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        '
        'SessionConfigCombo
        '
        Me.SessionConfigCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SessionConfigCombo.FormattingEnabled = True
        Me.SessionConfigCombo.Location = New System.Drawing.Point(96, 15)
        Me.SessionConfigCombo.Name = "SessionConfigCombo"
        Me.SessionConfigCombo.Size = New System.Drawing.Size(155, 21)
        Me.SessionConfigCombo.TabIndex = 39
        '
        'OpenSessionButton
        '
        Me.OpenSessionButton.Location = New System.Drawing.Point(3, 13)
        Me.OpenSessionButton.Name = "OpenSessionButton"
        Me.OpenSessionButton.Size = New System.Drawing.Size(90, 24)
        Me.OpenSessionButton.TabIndex = 2
        Me.OpenSessionButton.Text = "OpenSession"
        Me.OpenSessionButton.UseVisualStyleBackColor = True
        '
        'CloseSessionButton
        '
        Me.CloseSessionButton.Location = New System.Drawing.Point(95, 13)
        Me.CloseSessionButton.Name = "CloseSessionButton"
        Me.CloseSessionButton.Size = New System.Drawing.Size(90, 24)
        Me.CloseSessionButton.TabIndex = 3
        Me.CloseSessionButton.Text = "CloseSession"
        Me.CloseSessionButton.UseVisualStyleBackColor = True
        Me.CloseSessionButton.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ErrorResponseCombo)
        Me.GroupBox4.Controls.Add(Me.ErrorResponseButton)
        Me.GroupBox4.Location = New System.Drawing.Point(282, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(175, 161)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Error Handling"
        '
        'ErrorResponseCombo
        '
        Me.ErrorResponseCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ErrorResponseCombo.Enabled = False
        Me.ErrorResponseCombo.FormattingEnabled = True
        Me.ErrorResponseCombo.Location = New System.Drawing.Point(35, 19)
        Me.ErrorResponseCombo.Name = "ErrorResponseCombo"
        Me.ErrorResponseCombo.Size = New System.Drawing.Size(115, 21)
        Me.ErrorResponseCombo.TabIndex = 19
        '
        'ErrorResponseButton
        '
        Me.ErrorResponseButton.Enabled = False
        Me.ErrorResponseButton.Location = New System.Drawing.Point(47, 46)
        Me.ErrorResponseButton.Name = "ErrorResponseButton"
        Me.ErrorResponseButton.Size = New System.Drawing.Size(90, 24)
        Me.ErrorResponseButton.TabIndex = 23
        Me.ErrorResponseButton.Text = "ErrorResponse"
        Me.ErrorResponseButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.groupBox7)
        Me.GroupBox3.Controls.Add(Me.ClearPrinterMsgButton)
        Me.GroupBox3.Controls.Add(Me.label7)
        Me.GroupBox3.Controls.Add(Me.PrinterSetRadio)
        Me.GroupBox3.Controls.Add(Me.PrinterGetRadio)
        Me.GroupBox3.Controls.Add(Me.EjectModeCombo)
        Me.GroupBox3.Controls.Add(Me.EjectModeButton)
        Me.GroupBox3.Controls.Add(Me.PrinterMsgBox)
        Me.GroupBox3.Location = New System.Drawing.Point(5, 164)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(452, 402)
        Me.GroupBox3.TabIndex = 31
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Printer Config"
        '
        'groupBox7
        '
        Me.groupBox7.Controls.Add(Me.IPGatewayLabel)
        Me.groupBox7.Controls.Add(Me.IPSubnetLabel)
        Me.groupBox7.Controls.Add(Me.IPAddrLabel)
        Me.groupBox7.Controls.Add(Me.IPGatewayBox)
        Me.groupBox7.Controls.Add(Me.IPSubnetBox)
        Me.groupBox7.Controls.Add(Me.IPAddressBox)
        Me.groupBox7.Controls.Add(Me.IPSettingsButton)
        Me.groupBox7.Controls.Add(Me.IPModeLabel)
        Me.groupBox7.Controls.Add(Me.IPModeCombo)
        Me.groupBox7.Location = New System.Drawing.Point(0, 71)
        Me.groupBox7.Name = "groupBox7"
        Me.groupBox7.Size = New System.Drawing.Size(210, 156)
        Me.groupBox7.TabIndex = 42
        Me.groupBox7.TabStop = False
        '
        'IPGatewayLabel
        '
        Me.IPGatewayLabel.AutoSize = True
        Me.IPGatewayLabel.Location = New System.Drawing.Point(6, 98)
        Me.IPGatewayLabel.Name = "IPGatewayLabel"
        Me.IPGatewayLabel.Size = New System.Drawing.Size(49, 13)
        Me.IPGatewayLabel.TabIndex = 44
        Me.IPGatewayLabel.Text = "Gateway"
        '
        'IPSubnetLabel
        '
        Me.IPSubnetLabel.AutoSize = True
        Me.IPSubnetLabel.Location = New System.Drawing.Point(6, 71)
        Me.IPSubnetLabel.Name = "IPSubnetLabel"
        Me.IPSubnetLabel.Size = New System.Drawing.Size(41, 13)
        Me.IPSubnetLabel.TabIndex = 43
        Me.IPSubnetLabel.Text = "Subnet"
        '
        'IPAddrLabel
        '
        Me.IPAddrLabel.AutoSize = True
        Me.IPAddrLabel.Location = New System.Drawing.Point(6, 44)
        Me.IPAddrLabel.Name = "IPAddrLabel"
        Me.IPAddrLabel.Size = New System.Drawing.Size(42, 13)
        Me.IPAddrLabel.TabIndex = 42
        Me.IPAddrLabel.Text = "IP Addr"
        '
        'IPGatewayBox
        '
        Me.IPGatewayBox.Enabled = False
        Me.IPGatewayBox.Location = New System.Drawing.Point(68, 94)
        Me.IPGatewayBox.Name = "IPGatewayBox"
        Me.IPGatewayBox.Size = New System.Drawing.Size(131, 20)
        Me.IPGatewayBox.TabIndex = 41
        Me.IPGatewayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPSubnetBox
        '
        Me.IPSubnetBox.Enabled = False
        Me.IPSubnetBox.Location = New System.Drawing.Point(68, 67)
        Me.IPSubnetBox.Name = "IPSubnetBox"
        Me.IPSubnetBox.Size = New System.Drawing.Size(131, 20)
        Me.IPSubnetBox.TabIndex = 40
        Me.IPSubnetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPAddressBox
        '
        Me.IPAddressBox.Enabled = False
        Me.IPAddressBox.Location = New System.Drawing.Point(68, 40)
        Me.IPAddressBox.Name = "IPAddressBox"
        Me.IPAddressBox.Size = New System.Drawing.Size(131, 20)
        Me.IPAddressBox.TabIndex = 26
        Me.IPAddressBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPSettingsButton
        '
        Me.IPSettingsButton.Enabled = False
        Me.IPSettingsButton.Location = New System.Drawing.Point(63, 126)
        Me.IPSettingsButton.Name = "IPSettingsButton"
        Me.IPSettingsButton.Size = New System.Drawing.Size(90, 24)
        Me.IPSettingsButton.TabIndex = 39
        Me.IPSettingsButton.Text = "IP Settings"
        Me.IPSettingsButton.UseVisualStyleBackColor = True
        '
        'IPModeLabel
        '
        Me.IPModeLabel.AutoSize = True
        Me.IPModeLabel.Location = New System.Drawing.Point(6, 16)
        Me.IPModeLabel.Name = "IPModeLabel"
        Me.IPModeLabel.Size = New System.Drawing.Size(34, 13)
        Me.IPModeLabel.TabIndex = 37
        Me.IPModeLabel.Text = "Mode"
        '
        'IPModeCombo
        '
        Me.IPModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IPModeCombo.Enabled = False
        Me.IPModeCombo.FormattingEnabled = True
        Me.IPModeCombo.Location = New System.Drawing.Point(68, 12)
        Me.IPModeCombo.Name = "IPModeCombo"
        Me.IPModeCombo.Size = New System.Drawing.Size(131, 21)
        Me.IPModeCombo.TabIndex = 38
        '
        'ClearPrinterMsgButton
        '
        Me.ClearPrinterMsgButton.Location = New System.Drawing.Point(287, 372)
        Me.ClearPrinterMsgButton.Name = "ClearPrinterMsgButton"
        Me.ClearPrinterMsgButton.Size = New System.Drawing.Size(90, 24)
        Me.ClearPrinterMsgButton.TabIndex = 44
        Me.ClearPrinterMsgButton.Text = "Clear"
        Me.ClearPrinterMsgButton.UseVisualStyleBackColor = True
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(6, 23)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(40, 13)
        Me.label7.TabIndex = 41
        Me.label7.Text = "Action:"
        '
        'PrinterSetRadio
        '
        Me.PrinterSetRadio.AutoSize = True
        Me.PrinterSetRadio.Enabled = False
        Me.PrinterSetRadio.Location = New System.Drawing.Point(88, 21)
        Me.PrinterSetRadio.Name = "PrinterSetRadio"
        Me.PrinterSetRadio.Size = New System.Drawing.Size(41, 17)
        Me.PrinterSetRadio.TabIndex = 40
        Me.PrinterSetRadio.Text = "Set"
        Me.PrinterSetRadio.UseVisualStyleBackColor = True
        '
        'PrinterGetRadio
        '
        Me.PrinterGetRadio.AutoSize = True
        Me.PrinterGetRadio.Checked = True
        Me.PrinterGetRadio.Enabled = False
        Me.PrinterGetRadio.Location = New System.Drawing.Point(46, 21)
        Me.PrinterGetRadio.Name = "PrinterGetRadio"
        Me.PrinterGetRadio.Size = New System.Drawing.Size(42, 17)
        Me.PrinterGetRadio.TabIndex = 39
        Me.PrinterGetRadio.TabStop = True
        Me.PrinterGetRadio.Text = "Get"
        Me.PrinterGetRadio.UseVisualStyleBackColor = True
        '
        'EjectModeCombo
        '
        Me.EjectModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EjectModeCombo.Enabled = False
        Me.EjectModeCombo.FormattingEnabled = True
        Me.EjectModeCombo.Location = New System.Drawing.Point(96, 43)
        Me.EjectModeCombo.Name = "EjectModeCombo"
        Me.EjectModeCombo.Size = New System.Drawing.Size(106, 21)
        Me.EjectModeCombo.TabIndex = 15
        '
        'EjectModeButton
        '
        Me.EjectModeButton.Enabled = False
        Me.EjectModeButton.Location = New System.Drawing.Point(3, 41)
        Me.EjectModeButton.Name = "EjectModeButton"
        Me.EjectModeButton.Size = New System.Drawing.Size(90, 24)
        Me.EjectModeButton.TabIndex = 21
        Me.EjectModeButton.Text = "EjectMode"
        Me.EjectModeButton.UseVisualStyleBackColor = True
        '
        'PrinterMsgBox
        '
        Me.PrinterMsgBox.Location = New System.Drawing.Point(219, 11)
        Me.PrinterMsgBox.Multiline = True
        Me.PrinterMsgBox.Name = "PrinterMsgBox"
        Me.PrinterMsgBox.ReadOnly = True
        Me.PrinterMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.PrinterMsgBox.Size = New System.Drawing.Size(227, 355)
        Me.PrinterMsgBox.TabIndex = 43
        Me.PrinterMsgBox.WordWrap = False
        '
        'Information
        '
        Me.Information.Controls.Add(Me.ClearMsgBoxButton)
        Me.Information.Controls.Add(Me.GroupBox27)
        Me.Information.Location = New System.Drawing.Point(4, 22)
        Me.Information.Name = "Information"
        Me.Information.Padding = New System.Windows.Forms.Padding(3)
        Me.Information.Size = New System.Drawing.Size(464, 566)
        Me.Information.TabIndex = 1
        Me.Information.Text = "Information"
        Me.Information.UseVisualStyleBackColor = True
        '
        'ClearMsgBoxButton
        '
        Me.ClearMsgBoxButton.Location = New System.Drawing.Point(265, 536)
        Me.ClearMsgBoxButton.Name = "ClearMsgBoxButton"
        Me.ClearMsgBoxButton.Size = New System.Drawing.Size(90, 24)
        Me.ClearMsgBoxButton.TabIndex = 14
        Me.ClearMsgBoxButton.Text = "Clear"
        Me.ClearMsgBoxButton.UseVisualStyleBackColor = True
        '
        'GroupBox27
        '
        Me.GroupBox27.Controls.Add(Me.PrinterTypeButton)
        Me.GroupBox27.Controls.Add(Me.SDKBitsButton)
        Me.GroupBox27.Controls.Add(Me.LastMessageButton)
        Me.GroupBox27.Controls.Add(Me.TemperatureButton)
        Me.GroupBox27.Controls.Add(Me.PrinterInfoButton)
        Me.GroupBox27.Controls.Add(Me.PrinterModelButton)
        Me.GroupBox27.Controls.Add(Me.InfoMsgBox)
        Me.GroupBox27.Controls.Add(Me.ConnectionTypeButton)
        Me.GroupBox27.Controls.Add(Me.PrinterStatusButton)
        Me.GroupBox27.Controls.Add(Me.SDKVersionButton)
        Me.GroupBox27.Location = New System.Drawing.Point(1, 6)
        Me.GroupBox27.Name = "GroupBox27"
        Me.GroupBox27.Size = New System.Drawing.Size(460, 557)
        Me.GroupBox27.TabIndex = 104
        Me.GroupBox27.TabStop = False
        '
        'PrinterTypeButton
        '
        Me.PrinterTypeButton.Location = New System.Drawing.Point(14, 74)
        Me.PrinterTypeButton.Name = "PrinterTypeButton"
        Me.PrinterTypeButton.Size = New System.Drawing.Size(142, 24)
        Me.PrinterTypeButton.TabIndex = 108
        Me.PrinterTypeButton.Text = "PrinterType"
        Me.PrinterTypeButton.UseVisualStyleBackColor = True
        '
        'SDKBitsButton
        '
        Me.SDKBitsButton.Location = New System.Drawing.Point(14, 44)
        Me.SDKBitsButton.Name = "SDKBitsButton"
        Me.SDKBitsButton.Size = New System.Drawing.Size(142, 24)
        Me.SDKBitsButton.TabIndex = 107
        Me.SDKBitsButton.Text = "SDKBits"
        Me.SDKBitsButton.UseVisualStyleBackColor = True
        '
        'LastMessageButton
        '
        Me.LastMessageButton.Location = New System.Drawing.Point(14, 254)
        Me.LastMessageButton.Name = "LastMessageButton"
        Me.LastMessageButton.Size = New System.Drawing.Size(142, 24)
        Me.LastMessageButton.TabIndex = 106
        Me.LastMessageButton.Text = "LastMessage"
        Me.LastMessageButton.UseVisualStyleBackColor = True
        '
        'TemperatureButton
        '
        Me.TemperatureButton.Location = New System.Drawing.Point(14, 224)
        Me.TemperatureButton.Name = "TemperatureButton"
        Me.TemperatureButton.Size = New System.Drawing.Size(142, 24)
        Me.TemperatureButton.TabIndex = 105
        Me.TemperatureButton.Text = "Temperature"
        Me.TemperatureButton.UseVisualStyleBackColor = True
        '
        'PrinterInfoButton
        '
        Me.PrinterInfoButton.Location = New System.Drawing.Point(14, 194)
        Me.PrinterInfoButton.Name = "PrinterInfoButton"
        Me.PrinterInfoButton.Size = New System.Drawing.Size(142, 24)
        Me.PrinterInfoButton.TabIndex = 104
        Me.PrinterInfoButton.Text = "PrinterInfo"
        Me.PrinterInfoButton.UseVisualStyleBackColor = True
        '
        'PrinterModelButton
        '
        Me.PrinterModelButton.Location = New System.Drawing.Point(14, 104)
        Me.PrinterModelButton.Name = "PrinterModelButton"
        Me.PrinterModelButton.Size = New System.Drawing.Size(142, 24)
        Me.PrinterModelButton.TabIndex = 103
        Me.PrinterModelButton.Text = "PrinterModel"
        Me.PrinterModelButton.UseVisualStyleBackColor = True
        '
        'InfoMsgBox
        '
        Me.InfoMsgBox.Location = New System.Drawing.Point(164, 14)
        Me.InfoMsgBox.Multiline = True
        Me.InfoMsgBox.Name = "InfoMsgBox"
        Me.InfoMsgBox.ReadOnly = True
        Me.InfoMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.InfoMsgBox.Size = New System.Drawing.Size(292, 507)
        Me.InfoMsgBox.TabIndex = 8
        Me.InfoMsgBox.WordWrap = False
        '
        'ConnectionTypeButton
        '
        Me.ConnectionTypeButton.Location = New System.Drawing.Point(14, 134)
        Me.ConnectionTypeButton.Name = "ConnectionTypeButton"
        Me.ConnectionTypeButton.Size = New System.Drawing.Size(142, 24)
        Me.ConnectionTypeButton.TabIndex = 102
        Me.ConnectionTypeButton.Text = "ConnectionType"
        Me.ConnectionTypeButton.UseVisualStyleBackColor = True
        '
        'PrinterStatusButton
        '
        Me.PrinterStatusButton.Location = New System.Drawing.Point(14, 164)
        Me.PrinterStatusButton.Name = "PrinterStatusButton"
        Me.PrinterStatusButton.Size = New System.Drawing.Size(142, 24)
        Me.PrinterStatusButton.TabIndex = 11
        Me.PrinterStatusButton.Text = "PrinterStatus"
        Me.PrinterStatusButton.UseVisualStyleBackColor = True
        '
        'SDKVersionButton
        '
        Me.SDKVersionButton.Location = New System.Drawing.Point(14, 14)
        Me.SDKVersionButton.Name = "SDKVersionButton"
        Me.SDKVersionButton.Size = New System.Drawing.Size(142, 24)
        Me.SDKVersionButton.TabIndex = 100
        Me.SDKVersionButton.Text = "SDKVersion"
        Me.SDKVersionButton.UseVisualStyleBackColor = True
        '
        'Encoding
        '
        Me.Encoding.Controls.Add(Me.groupBox5)
        Me.Encoding.Controls.Add(Me.groupBox9)
        Me.Encoding.Controls.Add(Me.groupBox8)
        Me.Encoding.Location = New System.Drawing.Point(4, 22)
        Me.Encoding.Name = "Encoding"
        Me.Encoding.Padding = New System.Windows.Forms.Padding(3)
        Me.Encoding.Size = New System.Drawing.Size(464, 566)
        Me.Encoding.TabIndex = 2
        Me.Encoding.Text = "Encoding"
        Me.Encoding.UseVisualStyleBackColor = True
        '
        'groupBox5
        '
        Me.groupBox5.Controls.Add(Me.MagStartPosition)
        Me.groupBox5.Controls.Add(Me.label1)
        Me.groupBox5.Controls.Add(Me.EncodingSetRadio)
        Me.groupBox5.Controls.Add(Me.EncodingGetRadio)
        Me.groupBox5.Controls.Add(Me.MagStartButton)
        Me.groupBox5.Location = New System.Drawing.Point(5, 194)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Size = New System.Drawing.Size(456, 51)
        Me.groupBox5.TabIndex = 18
        Me.groupBox5.TabStop = False
        '
        'MagStartPosition
        '
        Me.MagStartPosition.Location = New System.Drawing.Point(136, 21)
        Me.MagStartPosition.Maximum = New Decimal(New Integer() {85000, 0, 0, 0})
        Me.MagStartPosition.Name = "MagStartPosition"
        Me.MagStartPosition.Size = New System.Drawing.Size(120, 20)
        Me.MagStartPosition.TabIndex = 63
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(61, 25)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(69, 13)
        Me.label1.TabIndex = 62
        Me.label1.Text = "Start Position"
        '
        'EncodingSetRadio
        '
        Me.EncodingSetRadio.AutoSize = True
        Me.EncodingSetRadio.Location = New System.Drawing.Point(13, 31)
        Me.EncodingSetRadio.Name = "EncodingSetRadio"
        Me.EncodingSetRadio.Size = New System.Drawing.Size(41, 17)
        Me.EncodingSetRadio.TabIndex = 41
        Me.EncodingSetRadio.TabStop = True
        Me.EncodingSetRadio.Text = "Set"
        Me.EncodingSetRadio.UseVisualStyleBackColor = True
        '
        'EncodingGetRadio
        '
        Me.EncodingGetRadio.AutoSize = True
        Me.EncodingGetRadio.Checked = True
        Me.EncodingGetRadio.Location = New System.Drawing.Point(13, 8)
        Me.EncodingGetRadio.Name = "EncodingGetRadio"
        Me.EncodingGetRadio.Size = New System.Drawing.Size(42, 17)
        Me.EncodingGetRadio.TabIndex = 40
        Me.EncodingGetRadio.TabStop = True
        Me.EncodingGetRadio.Text = "Get"
        Me.EncodingGetRadio.UseVisualStyleBackColor = True
        '
        'MagStartButton
        '
        Me.MagStartButton.Location = New System.Drawing.Point(320, 19)
        Me.MagStartButton.Name = "MagStartButton"
        Me.MagStartButton.Size = New System.Drawing.Size(90, 24)
        Me.MagStartButton.TabIndex = 12
        Me.MagStartButton.Text = "MagStart"
        Me.MagStartButton.UseVisualStyleBackColor = True
        '
        'groupBox9
        '
        Me.groupBox9.Controls.Add(Me.JIS2Label)
        Me.groupBox9.Controls.Add(Me.label112)
        Me.groupBox9.Controls.Add(Me.Track2Data)
        Me.groupBox9.Controls.Add(Me.BitsPerInchLabel)
        Me.groupBox9.Controls.Add(Me.EncodeMagButton)
        Me.groupBox9.Controls.Add(Me.BitsPerCharLabel)
        Me.groupBox9.Controls.Add(Me.Track3SettingsLabel)
        Me.groupBox9.Controls.Add(Me.Track2SettingsLabel)
        Me.groupBox9.Controls.Add(Me.Track1SettingsLabel)
        Me.groupBox9.Controls.Add(Me.label13)
        Me.groupBox9.Controls.Add(Me.Track3Label)
        Me.groupBox9.Controls.Add(Me.Track2Label)
        Me.groupBox9.Controls.Add(Me.Track1Data)
        Me.groupBox9.Controls.Add(Me.Track3Data)
        Me.groupBox9.Controls.Add(Me.Track1)
        Me.groupBox9.Controls.Add(Me.Track2)
        Me.groupBox9.Controls.Add(Me.Track3)
        Me.groupBox9.Controls.Add(Me.EncodingTypeCombo)
        Me.groupBox9.Controls.Add(Me.CoercivityCombo)
        Me.groupBox9.Controls.Add(Me.Verify)
        Me.groupBox9.Controls.Add(Me.T1_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T1_BPICombo)
        Me.groupBox9.Controls.Add(Me.T2_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T2_BPICombo)
        Me.groupBox9.Controls.Add(Me.T3_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T3_BPICombo)
        Me.groupBox9.Controls.Add(Me.Track1Label)
        Me.groupBox9.Location = New System.Drawing.Point(5, 5)
        Me.groupBox9.Name = "groupBox9"
        Me.groupBox9.Size = New System.Drawing.Size(456, 183)
        Me.groupBox9.TabIndex = 17
        Me.groupBox9.TabStop = False
        '
        'JIS2Label
        '
        Me.JIS2Label.AutoSize = True
        Me.JIS2Label.Location = New System.Drawing.Point(8, 44)
        Me.JIS2Label.Name = "JIS2Label"
        Me.JIS2Label.Size = New System.Drawing.Size(30, 13)
        Me.JIS2Label.TabIndex = 62
        Me.JIS2Label.Text = "Data"
        Me.JIS2Label.Visible = False
        '
        'label112
        '
        Me.label112.AutoSize = True
        Me.label112.Location = New System.Drawing.Point(133, 20)
        Me.label112.Name = "label112"
        Me.label112.Size = New System.Drawing.Size(53, 13)
        Me.label112.TabIndex = 60
        Me.label112.Text = "Coercivity"
        '
        'Track2Data
        '
        Me.Track2Data.Enabled = False
        Me.Track2Data.Location = New System.Drawing.Point(79, 64)
        Me.Track2Data.Name = "Track2Data"
        Me.Track2Data.Size = New System.Drawing.Size(371, 20)
        Me.Track2Data.TabIndex = 14
        '
        'BitsPerInchLabel
        '
        Me.BitsPerInchLabel.AutoSize = True
        Me.BitsPerInchLabel.Location = New System.Drawing.Point(8, 155)
        Me.BitsPerInchLabel.Name = "BitsPerInchLabel"
        Me.BitsPerInchLabel.Size = New System.Drawing.Size(67, 13)
        Me.BitsPerInchLabel.TabIndex = 57
        Me.BitsPerInchLabel.Text = "Bits Per Inch"
        '
        'EncodeMagButton
        '
        Me.EncodeMagButton.Enabled = False
        Me.EncodeMagButton.Location = New System.Drawing.Point(339, 138)
        Me.EncodeMagButton.Name = "EncodeMagButton"
        Me.EncodeMagButton.Size = New System.Drawing.Size(111, 24)
        Me.EncodeMagButton.TabIndex = 11
        Me.EncodeMagButton.Text = "EncodeMag"
        Me.EncodeMagButton.UseVisualStyleBackColor = True
        '
        'BitsPerCharLabel
        '
        Me.BitsPerCharLabel.AutoSize = True
        Me.BitsPerCharLabel.Location = New System.Drawing.Point(8, 130)
        Me.BitsPerCharLabel.Name = "BitsPerCharLabel"
        Me.BitsPerCharLabel.Size = New System.Drawing.Size(68, 13)
        Me.BitsPerCharLabel.TabIndex = 56
        Me.BitsPerCharLabel.Text = "Bits Per Char"
        '
        'Track3SettingsLabel
        '
        Me.Track3SettingsLabel.AutoSize = True
        Me.Track3SettingsLabel.Enabled = False
        Me.Track3SettingsLabel.Location = New System.Drawing.Point(264, 110)
        Me.Track3SettingsLabel.Name = "Track3SettingsLabel"
        Me.Track3SettingsLabel.Size = New System.Drawing.Size(44, 13)
        Me.Track3SettingsLabel.TabIndex = 55
        Me.Track3SettingsLabel.Text = "Track 3"
        '
        'Track2SettingsLabel
        '
        Me.Track2SettingsLabel.AutoSize = True
        Me.Track2SettingsLabel.Enabled = False
        Me.Track2SettingsLabel.Location = New System.Drawing.Point(180, 110)
        Me.Track2SettingsLabel.Name = "Track2SettingsLabel"
        Me.Track2SettingsLabel.Size = New System.Drawing.Size(44, 13)
        Me.Track2SettingsLabel.TabIndex = 54
        Me.Track2SettingsLabel.Text = "Track 2"
        '
        'Track1SettingsLabel
        '
        Me.Track1SettingsLabel.AutoSize = True
        Me.Track1SettingsLabel.Location = New System.Drawing.Point(96, 110)
        Me.Track1SettingsLabel.Name = "Track1SettingsLabel"
        Me.Track1SettingsLabel.Size = New System.Drawing.Size(44, 13)
        Me.Track1SettingsLabel.TabIndex = 53
        Me.Track1SettingsLabel.Text = "Track 1"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(8, 20)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(31, 13)
        Me.label13.TabIndex = 52
        Me.label13.Text = "Type"
        '
        'Track3Label
        '
        Me.Track3Label.AutoSize = True
        Me.Track3Label.Enabled = False
        Me.Track3Label.Location = New System.Drawing.Point(8, 90)
        Me.Track3Label.Name = "Track3Label"
        Me.Track3Label.Size = New System.Drawing.Size(44, 13)
        Me.Track3Label.TabIndex = 50
        Me.Track3Label.Text = "Track 3"
        '
        'Track2Label
        '
        Me.Track2Label.AutoSize = True
        Me.Track2Label.Enabled = False
        Me.Track2Label.Location = New System.Drawing.Point(8, 67)
        Me.Track2Label.Name = "Track2Label"
        Me.Track2Label.Size = New System.Drawing.Size(44, 13)
        Me.Track2Label.TabIndex = 48
        Me.Track2Label.Text = "Track 2"
        '
        'Track1Data
        '
        Me.Track1Data.Location = New System.Drawing.Point(79, 41)
        Me.Track1Data.Name = "Track1Data"
        Me.Track1Data.Size = New System.Drawing.Size(371, 20)
        Me.Track1Data.TabIndex = 18
        Me.Track1Data.Text = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"
        '
        'Track3Data
        '
        Me.Track3Data.Enabled = False
        Me.Track3Data.Location = New System.Drawing.Point(79, 87)
        Me.Track3Data.Name = "Track3Data"
        Me.Track3Data.Size = New System.Drawing.Size(371, 20)
        Me.Track3Data.TabIndex = 19
        '
        'Track1
        '
        Me.Track1.AutoSize = True
        Me.Track1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track1.Checked = True
        Me.Track1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Track1.Location = New System.Drawing.Point(56, 43)
        Me.Track1.Name = "Track1"
        Me.Track1.Size = New System.Drawing.Size(15, 14)
        Me.Track1.TabIndex = 14
        Me.Track1.UseVisualStyleBackColor = True
        '
        'Track2
        '
        Me.Track2.AutoSize = True
        Me.Track2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track2.Location = New System.Drawing.Point(56, 66)
        Me.Track2.Name = "Track2"
        Me.Track2.Size = New System.Drawing.Size(15, 14)
        Me.Track2.TabIndex = 16
        Me.Track2.UseVisualStyleBackColor = True
        '
        'Track3
        '
        Me.Track3.AutoSize = True
        Me.Track3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track3.Location = New System.Drawing.Point(56, 89)
        Me.Track3.Name = "Track3"
        Me.Track3.Size = New System.Drawing.Size(15, 14)
        Me.Track3.TabIndex = 17
        Me.Track3.UseVisualStyleBackColor = True
        '
        'EncodingTypeCombo
        '
        Me.EncodingTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EncodingTypeCombo.Location = New System.Drawing.Point(47, 16)
        Me.EncodingTypeCombo.Name = "EncodingTypeCombo"
        Me.EncodingTypeCombo.Size = New System.Drawing.Size(59, 21)
        Me.EncodingTypeCombo.TabIndex = 24
        '
        'CoercivityCombo
        '
        Me.CoercivityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CoercivityCombo.Location = New System.Drawing.Point(194, 16)
        Me.CoercivityCombo.Name = "CoercivityCombo"
        Me.CoercivityCombo.Size = New System.Drawing.Size(116, 21)
        Me.CoercivityCombo.TabIndex = 26
        '
        'Verify
        '
        Me.Verify.AutoSize = True
        Me.Verify.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Verify.Checked = True
        Me.Verify.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Verify.Location = New System.Drawing.Point(349, 18)
        Me.Verify.Name = "Verify"
        Me.Verify.Size = New System.Drawing.Size(52, 17)
        Me.Verify.TabIndex = 27
        Me.Verify.Text = "Verify"
        Me.Verify.UseVisualStyleBackColor = True
        '
        'T1_BPCCombo
        '
        Me.T1_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_BPCCombo.Location = New System.Drawing.Point(79, 126)
        Me.T1_BPCCombo.Name = "T1_BPCCombo"
        Me.T1_BPCCombo.Size = New System.Drawing.Size(78, 21)
        Me.T1_BPCCombo.TabIndex = 28
        '
        'T1_BPICombo
        '
        Me.T1_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_BPICombo.Location = New System.Drawing.Point(79, 151)
        Me.T1_BPICombo.Name = "T1_BPICombo"
        Me.T1_BPICombo.Size = New System.Drawing.Size(78, 21)
        Me.T1_BPICombo.TabIndex = 33
        '
        'T2_BPCCombo
        '
        Me.T2_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_BPCCombo.Enabled = False
        Me.T2_BPCCombo.Location = New System.Drawing.Point(163, 126)
        Me.T2_BPCCombo.Name = "T2_BPCCombo"
        Me.T2_BPCCombo.Size = New System.Drawing.Size(78, 21)
        Me.T2_BPCCombo.TabIndex = 36
        '
        'T2_BPICombo
        '
        Me.T2_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_BPICombo.Enabled = False
        Me.T2_BPICombo.Location = New System.Drawing.Point(163, 151)
        Me.T2_BPICombo.Name = "T2_BPICombo"
        Me.T2_BPICombo.Size = New System.Drawing.Size(78, 21)
        Me.T2_BPICombo.TabIndex = 38
        '
        'T3_BPCCombo
        '
        Me.T3_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_BPCCombo.Enabled = False
        Me.T3_BPCCombo.Location = New System.Drawing.Point(247, 126)
        Me.T3_BPCCombo.Name = "T3_BPCCombo"
        Me.T3_BPCCombo.Size = New System.Drawing.Size(78, 21)
        Me.T3_BPCCombo.TabIndex = 37
        '
        'T3_BPICombo
        '
        Me.T3_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_BPICombo.Enabled = False
        Me.T3_BPICombo.Location = New System.Drawing.Point(247, 151)
        Me.T3_BPICombo.Name = "T3_BPICombo"
        Me.T3_BPICombo.Size = New System.Drawing.Size(78, 21)
        Me.T3_BPICombo.TabIndex = 39
        '
        'Track1Label
        '
        Me.Track1Label.AutoSize = True
        Me.Track1Label.Location = New System.Drawing.Point(8, 44)
        Me.Track1Label.Name = "Track1Label"
        Me.Track1Label.Size = New System.Drawing.Size(44, 13)
        Me.Track1Label.TabIndex = 61
        Me.Track1Label.Text = "Track 1"
        '
        'groupBox8
        '
        Me.groupBox8.Controls.Add(Me.Track3Read)
        Me.groupBox8.Controls.Add(Me.Track2Read)
        Me.groupBox8.Controls.Add(Me.Track1Read)
        Me.groupBox8.Controls.Add(Me.ReadMagTracks)
        Me.groupBox8.Controls.Add(Me.ClearEncodingBoxButton)
        Me.groupBox8.Controls.Add(Me.ReadMagButton)
        Me.groupBox8.Controls.Add(Me.EncodingBox)
        Me.groupBox8.Location = New System.Drawing.Point(6, 254)
        Me.groupBox8.Name = "groupBox8"
        Me.groupBox8.Size = New System.Drawing.Size(456, 306)
        Me.groupBox8.TabIndex = 16
        Me.groupBox8.TabStop = False
        '
        'Track3Read
        '
        Me.Track3Read.AutoSize = True
        Me.Track3Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track3Read.Location = New System.Drawing.Point(124, 23)
        Me.Track3Read.Name = "Track3Read"
        Me.Track3Read.Size = New System.Drawing.Size(63, 17)
        Me.Track3Read.TabIndex = 68
        Me.Track3Read.Text = "Track 3"
        Me.Track3Read.UseVisualStyleBackColor = True
        '
        'Track2Read
        '
        Me.Track2Read.AutoSize = True
        Me.Track2Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track2Read.Location = New System.Drawing.Point(62, 23)
        Me.Track2Read.Name = "Track2Read"
        Me.Track2Read.Size = New System.Drawing.Size(63, 17)
        Me.Track2Read.TabIndex = 67
        Me.Track2Read.Text = "Track 2"
        Me.Track2Read.UseVisualStyleBackColor = True
        '
        'Track1Read
        '
        Me.Track1Read.AutoSize = True
        Me.Track1Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track1Read.Location = New System.Drawing.Point(0, 23)
        Me.Track1Read.Name = "Track1Read"
        Me.Track1Read.Size = New System.Drawing.Size(63, 17)
        Me.Track1Read.TabIndex = 66
        Me.Track1Read.Text = "Track 1"
        Me.Track1Read.UseVisualStyleBackColor = True
        '
        'ReadMagTracks
        '
        Me.ReadMagTracks.Location = New System.Drawing.Point(199, 19)
        Me.ReadMagTracks.Name = "ReadMagTracks"
        Me.ReadMagTracks.Size = New System.Drawing.Size(113, 24)
        Me.ReadMagTracks.TabIndex = 65
        Me.ReadMagTracks.Text = "ReadMagTracks"
        Me.ReadMagTracks.UseVisualStyleBackColor = True
        '
        'ClearEncodingBoxButton
        '
        Me.ClearEncodingBoxButton.Location = New System.Drawing.Point(184, 276)
        Me.ClearEncodingBoxButton.Name = "ClearEncodingBoxButton"
        Me.ClearEncodingBoxButton.Size = New System.Drawing.Size(90, 24)
        Me.ClearEncodingBoxButton.TabIndex = 13
        Me.ClearEncodingBoxButton.Text = "Clear"
        Me.ClearEncodingBoxButton.UseVisualStyleBackColor = True
        '
        'ReadMagButton
        '
        Me.ReadMagButton.Location = New System.Drawing.Point(338, 19)
        Me.ReadMagButton.Name = "ReadMagButton"
        Me.ReadMagButton.Size = New System.Drawing.Size(113, 24)
        Me.ReadMagButton.TabIndex = 12
        Me.ReadMagButton.Text = "ReadMag"
        Me.ReadMagButton.UseVisualStyleBackColor = True
        '
        'EncodingBox
        '
        Me.EncodingBox.Location = New System.Drawing.Point(7, 49)
        Me.EncodingBox.Multiline = True
        Me.EncodingBox.Name = "EncodingBox"
        Me.EncodingBox.ReadOnly = True
        Me.EncodingBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.EncodingBox.Size = New System.Drawing.Size(444, 221)
        Me.EncodingBox.TabIndex = 9
        Me.EncodingBox.WordWrap = False
        '
        'Driver1
        '
        Me.Driver1.Controls.Add(Me.GroupBox6)
        Me.Driver1.Controls.Add(Me.GUIPrinterCheck)
        Me.Driver1.Controls.Add(Me.GUIUserCheck)
        Me.Driver1.Controls.Add(Me.groupBox11)
        Me.Driver1.Controls.Add(Me.groupBox10)
        Me.Driver1.Controls.Add(Me.ColourCorrectionButton)
        Me.Driver1.Controls.Add(Me.CorrectionCombo)
        Me.Driver1.Controls.Add(Me.SharpnessUpDown)
        Me.Driver1.Controls.Add(Me.GUIControlButton)
        Me.Driver1.Controls.Add(Me.SharpnessButton)
        Me.Driver1.Controls.Add(Me.label16)
        Me.Driver1.Controls.Add(Me.Driver1SetRadio)
        Me.Driver1.Controls.Add(Me.Driver1GetRadio)
        Me.Driver1.Controls.Add(Me.ClearDriver1MsgBoxButton)
        Me.Driver1.Controls.Add(Me.Driver1MsgBox)
        Me.Driver1.Location = New System.Drawing.Point(4, 22)
        Me.Driver1.Name = "Driver1"
        Me.Driver1.Size = New System.Drawing.Size(464, 566)
        Me.Driver1.TabIndex = 3
        Me.Driver1.Text = "Driver 1"
        Me.Driver1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label2)
        Me.GroupBox6.Controls.Add(Me.ColourAreaHeightUpDown)
        Me.GroupBox6.Controls.Add(Me.ColourAreaBottomUpDown)
        Me.GroupBox6.Controls.Add(Me.ColourAreaWidthUpDown)
        Me.GroupBox6.Controls.Add(Me.ColourAreaLeftUpDown)
        Me.GroupBox6.Controls.Add(Me.Label3)
        Me.GroupBox6.Controls.Add(Me.Label4)
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.ColourAreaNo)
        Me.GroupBox6.Controls.Add(Me.ColourAreaSideCombo)
        Me.GroupBox6.Controls.Add(Me.Label9)
        Me.GroupBox6.Controls.Add(Me.ColourAreaCorrectionCombo)
        Me.GroupBox6.Controls.Add(Me.Label27)
        Me.GroupBox6.Controls.Add(Me.ColourAreaButton)
        Me.GroupBox6.Location = New System.Drawing.Point(3, 281)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(191, 123)
        Me.GroupBox6.TabIndex = 82
        Me.GroupBox6.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(153, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 13)
        Me.Label2.TabIndex = 78
        Me.Label2.Text = "H"
        '
        'ColourAreaHeightUpDown
        '
        Me.ColourAreaHeightUpDown.Enabled = False
        Me.ColourAreaHeightUpDown.Location = New System.Drawing.Point(138, 73)
        Me.ColourAreaHeightUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ColourAreaHeightUpDown.Name = "ColourAreaHeightUpDown"
        Me.ColourAreaHeightUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ColourAreaHeightUpDown.TabIndex = 77
        Me.ColourAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaBottomUpDown
        '
        Me.ColourAreaBottomUpDown.Enabled = False
        Me.ColourAreaBottomUpDown.Location = New System.Drawing.Point(93, 73)
        Me.ColourAreaBottomUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ColourAreaBottomUpDown.Name = "ColourAreaBottomUpDown"
        Me.ColourAreaBottomUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ColourAreaBottomUpDown.TabIndex = 76
        Me.ColourAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaWidthUpDown
        '
        Me.ColourAreaWidthUpDown.Enabled = False
        Me.ColourAreaWidthUpDown.Location = New System.Drawing.Point(48, 73)
        Me.ColourAreaWidthUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ColourAreaWidthUpDown.Name = "ColourAreaWidthUpDown"
        Me.ColourAreaWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ColourAreaWidthUpDown.TabIndex = 75
        Me.ColourAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaLeftUpDown
        '
        Me.ColourAreaLeftUpDown.Enabled = False
        Me.ColourAreaLeftUpDown.Location = New System.Drawing.Point(3, 73)
        Me.ColourAreaLeftUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ColourAreaLeftUpDown.Name = "ColourAreaLeftUpDown"
        Me.ColourAreaLeftUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ColourAreaLeftUpDown.TabIndex = 71
        Me.ColourAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(108, 58)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 74
        Me.Label3.Text = "B"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(61, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(18, 13)
        Me.Label4.TabIndex = 73
        Me.Label4.Text = "W"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(19, 58)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(13, 13)
        Me.Label5.TabIndex = 72
        Me.Label5.Text = "L"
        '
        'ColourAreaNo
        '
        Me.ColourAreaNo.Location = New System.Drawing.Point(136, 12)
        Me.ColourAreaNo.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.ColourAreaNo.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ColourAreaNo.Name = "ColourAreaNo"
        Me.ColourAreaNo.Size = New System.Drawing.Size(49, 20)
        Me.ColourAreaNo.TabIndex = 70
        Me.ColourAreaNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAreaNo.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ColourAreaSideCombo
        '
        Me.ColourAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAreaSideCombo.FormattingEnabled = True
        Me.ColourAreaSideCombo.Location = New System.Drawing.Point(37, 12)
        Me.ColourAreaSideCombo.Name = "ColourAreaSideCombo"
        Me.ColourAreaSideCombo.Size = New System.Drawing.Size(84, 21)
        Me.ColourAreaSideCombo.TabIndex = 63
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 13)
        Me.Label9.TabIndex = 62
        Me.Label9.Text = "Side"
        '
        'ColourAreaCorrectionCombo
        '
        Me.ColourAreaCorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAreaCorrectionCombo.Enabled = False
        Me.ColourAreaCorrectionCombo.FormattingEnabled = True
        Me.ColourAreaCorrectionCombo.Location = New System.Drawing.Point(84, 37)
        Me.ColourAreaCorrectionCombo.Name = "ColourAreaCorrectionCombo"
        Me.ColourAreaCorrectionCombo.Size = New System.Drawing.Size(101, 21)
        Me.ColourAreaCorrectionCombo.TabIndex = 56
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(6, 41)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(55, 13)
        Me.Label27.TabIndex = 56
        Me.Label27.Text = "Correction"
        '
        'ColourAreaButton
        '
        Me.ColourAreaButton.Location = New System.Drawing.Point(54, 97)
        Me.ColourAreaButton.Name = "ColourAreaButton"
        Me.ColourAreaButton.Size = New System.Drawing.Size(90, 24)
        Me.ColourAreaButton.TabIndex = 50
        Me.ColourAreaButton.Text = "Colour Area"
        Me.ColourAreaButton.UseVisualStyleBackColor = True
        '
        'GUIPrinterCheck
        '
        Me.GUIPrinterCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.GUIPrinterCheck.Location = New System.Drawing.Point(144, 22)
        Me.GUIPrinterCheck.Name = "GUIPrinterCheck"
        Me.GUIPrinterCheck.Size = New System.Drawing.Size(57, 24)
        Me.GUIPrinterCheck.TabIndex = 81
        Me.GUIPrinterCheck.Text = "Printer"
        Me.GUIPrinterCheck.UseVisualStyleBackColor = True
        '
        'GUIUserCheck
        '
        Me.GUIUserCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.GUIUserCheck.Location = New System.Drawing.Point(96, 22)
        Me.GUIUserCheck.Name = "GUIUserCheck"
        Me.GUIUserCheck.Size = New System.Drawing.Size(48, 24)
        Me.GUIUserCheck.TabIndex = 80
        Me.GUIUserCheck.Text = "User"
        Me.GUIUserCheck.UseVisualStyleBackColor = True
        '
        'groupBox11
        '
        Me.groupBox11.Controls.Add(Me.label26)
        Me.groupBox11.Controls.Add(Me.ResinAreaHeightUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaNoUpDown)
        Me.groupBox11.Controls.Add(Me.label25)
        Me.groupBox11.Controls.Add(Me.ResinAreaSideCombo)
        Me.groupBox11.Controls.Add(Me.label24)
        Me.groupBox11.Controls.Add(Me.ResinAreaBottomUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaWidthUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaLeftUpDown)
        Me.groupBox11.Controls.Add(Me.label21)
        Me.groupBox11.Controls.Add(Me.label22)
        Me.groupBox11.Controls.Add(Me.label23)
        Me.groupBox11.Controls.Add(Me.ResinAreaButton)
        Me.groupBox11.Location = New System.Drawing.Point(3, 177)
        Me.groupBox11.Name = "groupBox11"
        Me.groupBox11.Size = New System.Drawing.Size(191, 98)
        Me.groupBox11.TabIndex = 77
        Me.groupBox11.TabStop = False
        '
        'label26
        '
        Me.label26.AutoSize = True
        Me.label26.Location = New System.Drawing.Point(153, 33)
        Me.label26.Name = "label26"
        Me.label26.Size = New System.Drawing.Size(15, 13)
        Me.label26.TabIndex = 59
        Me.label26.Text = "H"
        '
        'ResinAreaHeightUpDown
        '
        Me.ResinAreaHeightUpDown.Enabled = False
        Me.ResinAreaHeightUpDown.Location = New System.Drawing.Point(138, 48)
        Me.ResinAreaHeightUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ResinAreaHeightUpDown.Name = "ResinAreaHeightUpDown"
        Me.ResinAreaHeightUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ResinAreaHeightUpDown.TabIndex = 58
        Me.ResinAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaNoUpDown
        '
        Me.ResinAreaNoUpDown.Location = New System.Drawing.Point(134, 9)
        Me.ResinAreaNoUpDown.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.ResinAreaNoUpDown.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ResinAreaNoUpDown.Name = "ResinAreaNoUpDown"
        Me.ResinAreaNoUpDown.Size = New System.Drawing.Size(49, 20)
        Me.ResinAreaNoUpDown.TabIndex = 56
        Me.ResinAreaNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ResinAreaNoUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Location = New System.Drawing.Point(104, 13)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(24, 13)
        Me.label25.TabIndex = 57
        Me.label25.Text = "No."
        '
        'ResinAreaSideCombo
        '
        Me.ResinAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ResinAreaSideCombo.FormattingEnabled = True
        Me.ResinAreaSideCombo.Location = New System.Drawing.Point(37, 9)
        Me.ResinAreaSideCombo.Name = "ResinAreaSideCombo"
        Me.ResinAreaSideCombo.Size = New System.Drawing.Size(61, 21)
        Me.ResinAreaSideCombo.TabIndex = 56
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Location = New System.Drawing.Point(6, 13)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(28, 13)
        Me.label24.TabIndex = 56
        Me.label24.Text = "Side"
        '
        'ResinAreaBottomUpDown
        '
        Me.ResinAreaBottomUpDown.Enabled = False
        Me.ResinAreaBottomUpDown.Location = New System.Drawing.Point(93, 48)
        Me.ResinAreaBottomUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ResinAreaBottomUpDown.Name = "ResinAreaBottomUpDown"
        Me.ResinAreaBottomUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ResinAreaBottomUpDown.TabIndex = 54
        Me.ResinAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaWidthUpDown
        '
        Me.ResinAreaWidthUpDown.Enabled = False
        Me.ResinAreaWidthUpDown.Location = New System.Drawing.Point(48, 48)
        Me.ResinAreaWidthUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ResinAreaWidthUpDown.Name = "ResinAreaWidthUpDown"
        Me.ResinAreaWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ResinAreaWidthUpDown.TabIndex = 53
        Me.ResinAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaLeftUpDown
        '
        Me.ResinAreaLeftUpDown.Enabled = False
        Me.ResinAreaLeftUpDown.Location = New System.Drawing.Point(3, 48)
        Me.ResinAreaLeftUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ResinAreaLeftUpDown.Name = "ResinAreaLeftUpDown"
        Me.ResinAreaLeftUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ResinAreaLeftUpDown.TabIndex = 50
        Me.ResinAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(108, 33)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(14, 13)
        Me.label21.TabIndex = 52
        Me.label21.Text = "B"
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Location = New System.Drawing.Point(61, 33)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(18, 13)
        Me.label22.TabIndex = 51
        Me.label22.Text = "W"
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Location = New System.Drawing.Point(19, 33)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(13, 13)
        Me.label23.TabIndex = 50
        Me.label23.Text = "L"
        '
        'ResinAreaButton
        '
        Me.ResinAreaButton.Location = New System.Drawing.Point(57, 70)
        Me.ResinAreaButton.Name = "ResinAreaButton"
        Me.ResinAreaButton.Size = New System.Drawing.Size(90, 24)
        Me.ResinAreaButton.TabIndex = 50
        Me.ResinAreaButton.Text = "ResinArea"
        Me.ResinAreaButton.UseVisualStyleBackColor = True
        '
        'groupBox10
        '
        Me.groupBox10.Controls.Add(Me.OvercoatPowerUpDown)
        Me.groupBox10.Controls.Add(Me.ResinPowerUpDown)
        Me.groupBox10.Controls.Add(Me.YMCPowerUpDown)
        Me.groupBox10.Controls.Add(Me.label20)
        Me.groupBox10.Controls.Add(Me.label19)
        Me.groupBox10.Controls.Add(Me.label18)
        Me.groupBox10.Controls.Add(Me.PowerLevelButton)
        Me.groupBox10.Location = New System.Drawing.Point(3, 99)
        Me.groupBox10.Name = "groupBox10"
        Me.groupBox10.Size = New System.Drawing.Size(191, 76)
        Me.groupBox10.TabIndex = 76
        Me.groupBox10.TabStop = False
        '
        'OvercoatPowerUpDown
        '
        Me.OvercoatPowerUpDown.Enabled = False
        Me.OvercoatPowerUpDown.Location = New System.Drawing.Point(125, 26)
        Me.OvercoatPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.OvercoatPowerUpDown.Name = "OvercoatPowerUpDown"
        Me.OvercoatPowerUpDown.Size = New System.Drawing.Size(61, 20)
        Me.OvercoatPowerUpDown.TabIndex = 54
        Me.OvercoatPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinPowerUpDown
        '
        Me.ResinPowerUpDown.Enabled = False
        Me.ResinPowerUpDown.Location = New System.Drawing.Point(64, 26)
        Me.ResinPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ResinPowerUpDown.Name = "ResinPowerUpDown"
        Me.ResinPowerUpDown.Size = New System.Drawing.Size(61, 20)
        Me.ResinPowerUpDown.TabIndex = 53
        Me.ResinPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'YMCPowerUpDown
        '
        Me.YMCPowerUpDown.Enabled = False
        Me.YMCPowerUpDown.Location = New System.Drawing.Point(3, 26)
        Me.YMCPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.YMCPowerUpDown.Name = "YMCPowerUpDown"
        Me.YMCPowerUpDown.Size = New System.Drawing.Size(61, 20)
        Me.YMCPowerUpDown.TabIndex = 50
        Me.YMCPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Location = New System.Drawing.Point(140, 11)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(51, 13)
        Me.label20.TabIndex = 52
        Me.label20.Text = "Overcoat"
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Location = New System.Drawing.Point(79, 11)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(34, 13)
        Me.label19.TabIndex = 51
        Me.label19.Text = "Resin"
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Location = New System.Drawing.Point(18, 11)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(30, 13)
        Me.label18.TabIndex = 50
        Me.label18.Text = "YMC"
        '
        'PowerLevelButton
        '
        Me.PowerLevelButton.Location = New System.Drawing.Point(57, 48)
        Me.PowerLevelButton.Name = "PowerLevelButton"
        Me.PowerLevelButton.Size = New System.Drawing.Size(90, 24)
        Me.PowerLevelButton.TabIndex = 50
        Me.PowerLevelButton.Text = "Power Level"
        Me.PowerLevelButton.UseVisualStyleBackColor = True
        '
        'ColourCorrectionButton
        '
        Me.ColourCorrectionButton.Location = New System.Drawing.Point(6, 70)
        Me.ColourCorrectionButton.Name = "ColourCorrectionButton"
        Me.ColourCorrectionButton.Size = New System.Drawing.Size(90, 24)
        Me.ColourCorrectionButton.TabIndex = 72
        Me.ColourCorrectionButton.Text = "Colour Corr."
        Me.ColourCorrectionButton.UseVisualStyleBackColor = True
        '
        'CorrectionCombo
        '
        Me.CorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CorrectionCombo.Enabled = False
        Me.CorrectionCombo.FormattingEnabled = True
        Me.CorrectionCombo.Location = New System.Drawing.Point(102, 72)
        Me.CorrectionCombo.Name = "CorrectionCombo"
        Me.CorrectionCombo.Size = New System.Drawing.Size(95, 21)
        Me.CorrectionCombo.TabIndex = 73
        '
        'SharpnessUpDown
        '
        Me.SharpnessUpDown.Enabled = False
        Me.SharpnessUpDown.Location = New System.Drawing.Point(102, 48)
        Me.SharpnessUpDown.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.SharpnessUpDown.Minimum = New Decimal(New Integer() {2, 0, 0, -2147483648})
        Me.SharpnessUpDown.Name = "SharpnessUpDown"
        Me.SharpnessUpDown.Size = New System.Drawing.Size(95, 20)
        Me.SharpnessUpDown.TabIndex = 68
        Me.SharpnessUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GUIControlButton
        '
        Me.GUIControlButton.Location = New System.Drawing.Point(6, 22)
        Me.GUIControlButton.Name = "GUIControlButton"
        Me.GUIControlButton.Size = New System.Drawing.Size(90, 24)
        Me.GUIControlButton.TabIndex = 69
        Me.GUIControlButton.Text = "GUI Control"
        Me.GUIControlButton.UseVisualStyleBackColor = True
        '
        'SharpnessButton
        '
        Me.SharpnessButton.Location = New System.Drawing.Point(6, 46)
        Me.SharpnessButton.Name = "SharpnessButton"
        Me.SharpnessButton.Size = New System.Drawing.Size(90, 24)
        Me.SharpnessButton.TabIndex = 71
        Me.SharpnessButton.Text = "Sharpness"
        Me.SharpnessButton.UseVisualStyleBackColor = True
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Location = New System.Drawing.Point(30, 6)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(40, 13)
        Me.label16.TabIndex = 67
        Me.label16.Text = "Action:"
        '
        'Driver1SetRadio
        '
        Me.Driver1SetRadio.AutoSize = True
        Me.Driver1SetRadio.Location = New System.Drawing.Point(112, 4)
        Me.Driver1SetRadio.Name = "Driver1SetRadio"
        Me.Driver1SetRadio.Size = New System.Drawing.Size(41, 17)
        Me.Driver1SetRadio.TabIndex = 66
        Me.Driver1SetRadio.TabStop = True
        Me.Driver1SetRadio.Text = "Set"
        Me.Driver1SetRadio.UseVisualStyleBackColor = True
        '
        'Driver1GetRadio
        '
        Me.Driver1GetRadio.AutoSize = True
        Me.Driver1GetRadio.Checked = True
        Me.Driver1GetRadio.Location = New System.Drawing.Point(70, 4)
        Me.Driver1GetRadio.Name = "Driver1GetRadio"
        Me.Driver1GetRadio.Size = New System.Drawing.Size(42, 17)
        Me.Driver1GetRadio.TabIndex = 65
        Me.Driver1GetRadio.TabStop = True
        Me.Driver1GetRadio.Text = "Get"
        Me.Driver1GetRadio.UseVisualStyleBackColor = True
        '
        'ClearDriver1MsgBoxButton
        '
        Me.ClearDriver1MsgBoxButton.Location = New System.Drawing.Point(296, 539)
        Me.ClearDriver1MsgBoxButton.Name = "ClearDriver1MsgBoxButton"
        Me.ClearDriver1MsgBoxButton.Size = New System.Drawing.Size(90, 24)
        Me.ClearDriver1MsgBoxButton.TabIndex = 64
        Me.ClearDriver1MsgBoxButton.Text = "Clear"
        Me.ClearDriver1MsgBoxButton.UseVisualStyleBackColor = True
        '
        'Driver1MsgBox
        '
        Me.Driver1MsgBox.Location = New System.Drawing.Point(203, 6)
        Me.Driver1MsgBox.Multiline = True
        Me.Driver1MsgBox.Name = "Driver1MsgBox"
        Me.Driver1MsgBox.ReadOnly = True
        Me.Driver1MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Driver1MsgBox.Size = New System.Drawing.Size(256, 527)
        Me.Driver1MsgBox.TabIndex = 63
        Me.Driver1MsgBox.WordWrap = False
        '
        'Driver2
        '
        Me.Driver2.Controls.Add(Me.GroupBox12)
        Me.Driver2.Controls.Add(Me.groupBox16)
        Me.Driver2.Controls.Add(Me.GroupBox18)
        Me.Driver2.Controls.Add(Me.groupBox15)
        Me.Driver2.Controls.Add(Me.groupBox14)
        Me.Driver2.Controls.Add(Me.ClearDriver2MsgBoxButton)
        Me.Driver2.Controls.Add(Me.Driver2MsgBox)
        Me.Driver2.Controls.Add(Me.label17)
        Me.Driver2.Controls.Add(Me.Driver2SetRadio)
        Me.Driver2.Controls.Add(Me.Driver2GetRadio)
        Me.Driver2.Location = New System.Drawing.Point(4, 22)
        Me.Driver2.Name = "Driver2"
        Me.Driver2.Size = New System.Drawing.Size(464, 566)
        Me.Driver2.TabIndex = 4
        Me.Driver2.Text = "Driver 2"
        Me.Driver2.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.HoloKoteIDSlot)
        Me.GroupBox12.Controls.Add(Me.Label28)
        Me.GroupBox12.Controls.Add(Me.HoloKoteIDButton)
        Me.GroupBox12.Location = New System.Drawing.Point(8, 326)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(191, 80)
        Me.GroupBox12.TabIndex = 79
        Me.GroupBox12.TabStop = False
        '
        'HoloKoteIDSlot
        '
        Me.HoloKoteIDSlot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HoloKoteIDSlot.FormattingEnabled = True
        Me.HoloKoteIDSlot.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.HoloKoteIDSlot.Location = New System.Drawing.Point(61, 19)
        Me.HoloKoteIDSlot.MaxDropDownItems = 11
        Me.HoloKoteIDSlot.Name = "HoloKoteIDSlot"
        Me.HoloKoteIDSlot.Size = New System.Drawing.Size(101, 21)
        Me.HoloKoteIDSlot.TabIndex = 61
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(6, 23)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(45, 13)
        Me.Label28.TabIndex = 60
        Me.Label28.Text = "Slot No."
        '
        'HoloKoteIDButton
        '
        Me.HoloKoteIDButton.Location = New System.Drawing.Point(60, 46)
        Me.HoloKoteIDButton.Name = "HoloKoteIDButton"
        Me.HoloKoteIDButton.Size = New System.Drawing.Size(90, 24)
        Me.HoloKoteIDButton.TabIndex = 50
        Me.HoloKoteIDButton.Text = "HoloKote ID"
        Me.HoloKoteIDButton.UseVisualStyleBackColor = True
        '
        'groupBox16
        '
        Me.groupBox16.Controls.Add(Me.HoloKotePreviewButton)
        Me.groupBox16.Controls.Add(Me.HoloKoteImageUpDown)
        Me.groupBox16.Controls.Add(Me.label52)
        Me.groupBox16.Controls.Add(Me.HoloKoteSideCombo)
        Me.groupBox16.Controls.Add(Me.label49)
        Me.groupBox16.Controls.Add(Me.HoloKoteRotationCombo)
        Me.groupBox16.Controls.Add(Me.label50)
        Me.groupBox16.Controls.Add(Me.HoloKoteButton)
        Me.groupBox16.Location = New System.Drawing.Point(8, 221)
        Me.groupBox16.Name = "groupBox16"
        Me.groupBox16.Size = New System.Drawing.Size(191, 99)
        Me.groupBox16.TabIndex = 75
        Me.groupBox16.TabStop = False
        '
        'HoloKotePreviewButton
        '
        Me.HoloKotePreviewButton.Location = New System.Drawing.Point(81, 66)
        Me.HoloKotePreviewButton.Name = "HoloKotePreviewButton"
        Me.HoloKotePreviewButton.Size = New System.Drawing.Size(102, 24)
        Me.HoloKotePreviewButton.TabIndex = 84
        Me.HoloKotePreviewButton.Text = "HoloKote Preview"
        Me.HoloKotePreviewButton.UseVisualStyleBackColor = True
        '
        'HoloKoteImageUpDown
        '
        Me.HoloKoteImageUpDown.Enabled = False
        Me.HoloKoteImageUpDown.Location = New System.Drawing.Point(145, 12)
        Me.HoloKoteImageUpDown.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.HoloKoteImageUpDown.Name = "HoloKoteImageUpDown"
        Me.HoloKoteImageUpDown.Size = New System.Drawing.Size(40, 20)
        Me.HoloKoteImageUpDown.TabIndex = 62
        Me.HoloKoteImageUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.HoloKoteImageUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label52
        '
        Me.label52.AutoSize = True
        Me.label52.Location = New System.Drawing.Point(103, 16)
        Me.label52.Name = "label52"
        Me.label52.Size = New System.Drawing.Size(36, 13)
        Me.label52.TabIndex = 68
        Me.label52.Text = "Image"
        '
        'HoloKoteSideCombo
        '
        Me.HoloKoteSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HoloKoteSideCombo.FormattingEnabled = True
        Me.HoloKoteSideCombo.Location = New System.Drawing.Point(37, 12)
        Me.HoloKoteSideCombo.Name = "HoloKoteSideCombo"
        Me.HoloKoteSideCombo.Size = New System.Drawing.Size(61, 21)
        Me.HoloKoteSideCombo.TabIndex = 63
        '
        'label49
        '
        Me.label49.AutoSize = True
        Me.label49.Location = New System.Drawing.Point(6, 16)
        Me.label49.Name = "label49"
        Me.label49.Size = New System.Drawing.Size(28, 13)
        Me.label49.TabIndex = 62
        Me.label49.Text = "Side"
        '
        'HoloKoteRotationCombo
        '
        Me.HoloKoteRotationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HoloKoteRotationCombo.Enabled = False
        Me.HoloKoteRotationCombo.FormattingEnabled = True
        Me.HoloKoteRotationCombo.Location = New System.Drawing.Point(84, 39)
        Me.HoloKoteRotationCombo.Name = "HoloKoteRotationCombo"
        Me.HoloKoteRotationCombo.Size = New System.Drawing.Size(101, 21)
        Me.HoloKoteRotationCombo.TabIndex = 61
        '
        'label50
        '
        Me.label50.AutoSize = True
        Me.label50.Location = New System.Drawing.Point(6, 43)
        Me.label50.Name = "label50"
        Me.label50.Size = New System.Drawing.Size(47, 13)
        Me.label50.TabIndex = 60
        Me.label50.Text = "Rotation"
        '
        'HoloKoteButton
        '
        Me.HoloKoteButton.Location = New System.Drawing.Point(8, 66)
        Me.HoloKoteButton.Name = "HoloKoteButton"
        Me.HoloKoteButton.Size = New System.Drawing.Size(67, 24)
        Me.HoloKoteButton.TabIndex = 50
        Me.HoloKoteButton.Text = "HoloKote"
        Me.HoloKoteButton.UseVisualStyleBackColor = True
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_WhiteRef)
        Me.GroupBox18.Controls.Add(Me.Label58)
        Me.GroupBox18.Controls.Add(Me.Label59)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_BlackRef)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Illuminant)
        Me.GroupBox18.Controls.Add(Me.Label60)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Negative)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_DarkPic)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Blue)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Green)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Red)
        Me.GroupBox18.Controls.Add(Me.Label61)
        Me.GroupBox18.Controls.Add(Me.Label62)
        Me.GroupBox18.Controls.Add(Me.Label63)
        Me.GroupBox18.Controls.Add(Me.Label64)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Tint)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Colour)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Brightness)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Contrast)
        Me.GroupBox18.Controls.Add(Me.Label65)
        Me.GroupBox18.Controls.Add(Me.Label66)
        Me.GroupBox18.Controls.Add(Me.Label67)
        Me.GroupBox18.Controls.Add(Me.ColourAdjustBtn)
        Me.GroupBox18.Location = New System.Drawing.Point(202, 0)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(255, 196)
        Me.GroupBox18.TabIndex = 78
        Me.GroupBox18.TabStop = False
        '
        'ColourAdjust_WhiteRef
        '
        Me.ColourAdjust_WhiteRef.Enabled = False
        Me.ColourAdjust_WhiteRef.Location = New System.Drawing.Point(181, 135)
        Me.ColourAdjust_WhiteRef.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.ColourAdjust_WhiteRef.Minimum = New Decimal(New Integer() {6000, 0, 0, 0})
        Me.ColourAdjust_WhiteRef.Name = "ColourAdjust_WhiteRef"
        Me.ColourAdjust_WhiteRef.Size = New System.Drawing.Size(61, 20)
        Me.ColourAdjust_WhiteRef.TabIndex = 81
        Me.ColourAdjust_WhiteRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_WhiteRef.Value = New Decimal(New Integer() {6000, 0, 0, 0})
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(125, 139)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(55, 13)
        Me.Label58.TabIndex = 80
        Me.Label58.Text = "White Ref"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(4, 139)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(54, 13)
        Me.Label59.TabIndex = 79
        Me.Label59.Text = "Black Ref"
        '
        'ColourAdjust_BlackRef
        '
        Me.ColourAdjust_BlackRef.Enabled = False
        Me.ColourAdjust_BlackRef.Location = New System.Drawing.Point(59, 135)
        Me.ColourAdjust_BlackRef.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.ColourAdjust_BlackRef.Name = "ColourAdjust_BlackRef"
        Me.ColourAdjust_BlackRef.Size = New System.Drawing.Size(61, 20)
        Me.ColourAdjust_BlackRef.TabIndex = 78
        Me.ColourAdjust_BlackRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Illuminant
        '
        Me.ColourAdjust_Illuminant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAdjust_Illuminant.Enabled = False
        Me.ColourAdjust_Illuminant.FormattingEnabled = True
        Me.ColourAdjust_Illuminant.Location = New System.Drawing.Point(74, 103)
        Me.ColourAdjust_Illuminant.Name = "ColourAdjust_Illuminant"
        Me.ColourAdjust_Illuminant.Size = New System.Drawing.Size(156, 21)
        Me.ColourAdjust_Illuminant.TabIndex = 77
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(5, 111)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(51, 13)
        Me.Label60.TabIndex = 76
        Me.Label60.Text = "Illuminant"
        '
        'ColourAdjust_Negative
        '
        Me.ColourAdjust_Negative.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ColourAdjust_Negative.Enabled = False
        Me.ColourAdjust_Negative.Location = New System.Drawing.Point(105, 84)
        Me.ColourAdjust_Negative.Name = "ColourAdjust_Negative"
        Me.ColourAdjust_Negative.Size = New System.Drawing.Size(80, 17)
        Me.ColourAdjust_Negative.TabIndex = 75
        Me.ColourAdjust_Negative.Text = "Negative"
        Me.ColourAdjust_Negative.UseVisualStyleBackColor = True
        '
        'ColourAdjust_DarkPic
        '
        Me.ColourAdjust_DarkPic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ColourAdjust_DarkPic.Enabled = False
        Me.ColourAdjust_DarkPic.Location = New System.Drawing.Point(5, 84)
        Me.ColourAdjust_DarkPic.Name = "ColourAdjust_DarkPic"
        Me.ColourAdjust_DarkPic.Size = New System.Drawing.Size(85, 17)
        Me.ColourAdjust_DarkPic.TabIndex = 74
        Me.ColourAdjust_DarkPic.Text = "Dark Picture"
        Me.ColourAdjust_DarkPic.UseVisualStyleBackColor = True
        '
        'ColourAdjust_Blue
        '
        Me.ColourAdjust_Blue.Enabled = False
        Me.ColourAdjust_Blue.Location = New System.Drawing.Point(128, 58)
        Me.ColourAdjust_Blue.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Blue.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Blue.Name = "ColourAdjust_Blue"
        Me.ColourAdjust_Blue.Size = New System.Drawing.Size(61, 20)
        Me.ColourAdjust_Blue.TabIndex = 73
        Me.ColourAdjust_Blue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Blue.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'ColourAdjust_Green
        '
        Me.ColourAdjust_Green.Enabled = False
        Me.ColourAdjust_Green.Location = New System.Drawing.Point(67, 58)
        Me.ColourAdjust_Green.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Green.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Green.Name = "ColourAdjust_Green"
        Me.ColourAdjust_Green.Size = New System.Drawing.Size(61, 20)
        Me.ColourAdjust_Green.TabIndex = 72
        Me.ColourAdjust_Green.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Green.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'ColourAdjust_Red
        '
        Me.ColourAdjust_Red.Enabled = False
        Me.ColourAdjust_Red.Location = New System.Drawing.Point(6, 58)
        Me.ColourAdjust_Red.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Red.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Red.Name = "ColourAdjust_Red"
        Me.ColourAdjust_Red.Size = New System.Drawing.Size(61, 20)
        Me.ColourAdjust_Red.TabIndex = 69
        Me.ColourAdjust_Red.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Red.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(144, 44)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(14, 13)
        Me.Label61.TabIndex = 71
        Me.Label61.Text = "B"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(85, 44)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(15, 13)
        Me.Label62.TabIndex = 70
        Me.Label62.Text = "G"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(21, 44)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(15, 13)
        Me.Label63.TabIndex = 68
        Me.Label63.Text = "R"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(204, 10)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(25, 13)
        Me.Label64.TabIndex = 67
        Me.Label64.Text = "Tint"
        '
        'ColourAdjust_Tint
        '
        Me.ColourAdjust_Tint.Enabled = False
        Me.ColourAdjust_Tint.Location = New System.Drawing.Point(186, 24)
        Me.ColourAdjust_Tint.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Tint.Name = "ColourAdjust_Tint"
        Me.ColourAdjust_Tint.Size = New System.Drawing.Size(60, 20)
        Me.ColourAdjust_Tint.TabIndex = 66
        Me.ColourAdjust_Tint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Colour
        '
        Me.ColourAdjust_Colour.Enabled = False
        Me.ColourAdjust_Colour.Location = New System.Drawing.Point(126, 24)
        Me.ColourAdjust_Colour.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Colour.Name = "ColourAdjust_Colour"
        Me.ColourAdjust_Colour.Size = New System.Drawing.Size(60, 20)
        Me.ColourAdjust_Colour.TabIndex = 65
        Me.ColourAdjust_Colour.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Brightness
        '
        Me.ColourAdjust_Brightness.Enabled = False
        Me.ColourAdjust_Brightness.Location = New System.Drawing.Point(66, 24)
        Me.ColourAdjust_Brightness.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Brightness.Name = "ColourAdjust_Brightness"
        Me.ColourAdjust_Brightness.Size = New System.Drawing.Size(60, 20)
        Me.ColourAdjust_Brightness.TabIndex = 64
        Me.ColourAdjust_Brightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Contrast
        '
        Me.ColourAdjust_Contrast.Enabled = False
        Me.ColourAdjust_Contrast.Location = New System.Drawing.Point(6, 24)
        Me.ColourAdjust_Contrast.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Contrast.Name = "ColourAdjust_Contrast"
        Me.ColourAdjust_Contrast.Size = New System.Drawing.Size(60, 20)
        Me.ColourAdjust_Contrast.TabIndex = 60
        Me.ColourAdjust_Contrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(138, 10)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(37, 13)
        Me.Label65.TabIndex = 63
        Me.Label65.Text = "Colour"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(79, 10)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(34, 13)
        Me.Label66.TabIndex = 62
        Me.Label66.Text = "Bright"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(13, 10)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(46, 13)
        Me.Label67.TabIndex = 61
        Me.Label67.Text = "Contrast"
        '
        'ColourAdjustBtn
        '
        Me.ColourAdjustBtn.Location = New System.Drawing.Point(85, 166)
        Me.ColourAdjustBtn.Name = "ColourAdjustBtn"
        Me.ColourAdjustBtn.Size = New System.Drawing.Size(90, 24)
        Me.ColourAdjustBtn.TabIndex = 50
        Me.ColourAdjustBtn.Text = "Colour Adjust"
        Me.ColourAdjustBtn.UseVisualStyleBackColor = True
        '
        'groupBox15
        '
        Me.groupBox15.Controls.Add(Me.Rotate)
        Me.groupBox15.Controls.Add(Me.Overcoat)
        Me.groupBox15.Controls.Add(Me.CardSettingsSideCombo)
        Me.groupBox15.Controls.Add(Me.label47)
        Me.groupBox15.Controls.Add(Me.OrientationCombo)
        Me.groupBox15.Controls.Add(Me.label44)
        Me.groupBox15.Controls.Add(Me.ColourFormatCombo)
        Me.groupBox15.Controls.Add(Me.label48)
        Me.groupBox15.Controls.Add(Me.CardSettingsButton)
        Me.groupBox15.Location = New System.Drawing.Point(8, 109)
        Me.groupBox15.Name = "groupBox15"
        Me.groupBox15.Size = New System.Drawing.Size(191, 112)
        Me.groupBox15.TabIndex = 74
        Me.groupBox15.TabStop = False
        '
        'Rotate
        '
        Me.Rotate.AutoSize = True
        Me.Rotate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Rotate.Enabled = False
        Me.Rotate.Location = New System.Drawing.Point(114, 14)
        Me.Rotate.Name = "Rotate"
        Me.Rotate.Size = New System.Drawing.Size(58, 17)
        Me.Rotate.TabIndex = 65
        Me.Rotate.Text = "Rotate"
        Me.Rotate.UseVisualStyleBackColor = True
        '
        'Overcoat
        '
        Me.Overcoat.AutoSize = True
        Me.Overcoat.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Overcoat.Enabled = False
        Me.Overcoat.Location = New System.Drawing.Point(6, 86)
        Me.Overcoat.Name = "Overcoat"
        Me.Overcoat.Size = New System.Drawing.Size(70, 17)
        Me.Overcoat.TabIndex = 64
        Me.Overcoat.Text = "Overcoat"
        Me.Overcoat.UseVisualStyleBackColor = True
        '
        'CardSettingsSideCombo
        '
        Me.CardSettingsSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CardSettingsSideCombo.FormattingEnabled = True
        Me.CardSettingsSideCombo.Location = New System.Drawing.Point(37, 12)
        Me.CardSettingsSideCombo.Name = "CardSettingsSideCombo"
        Me.CardSettingsSideCombo.Size = New System.Drawing.Size(61, 21)
        Me.CardSettingsSideCombo.TabIndex = 63
        '
        'label47
        '
        Me.label47.AutoSize = True
        Me.label47.Location = New System.Drawing.Point(6, 16)
        Me.label47.Name = "label47"
        Me.label47.Size = New System.Drawing.Size(28, 13)
        Me.label47.TabIndex = 62
        Me.label47.Text = "Side"
        '
        'OrientationCombo
        '
        Me.OrientationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OrientationCombo.Enabled = False
        Me.OrientationCombo.FormattingEnabled = True
        Me.OrientationCombo.Location = New System.Drawing.Point(84, 59)
        Me.OrientationCombo.Name = "OrientationCombo"
        Me.OrientationCombo.Size = New System.Drawing.Size(101, 21)
        Me.OrientationCombo.TabIndex = 61
        '
        'label44
        '
        Me.label44.AutoSize = True
        Me.label44.Location = New System.Drawing.Point(6, 63)
        Me.label44.Name = "label44"
        Me.label44.Size = New System.Drawing.Size(58, 13)
        Me.label44.TabIndex = 60
        Me.label44.Text = "Orientation"
        '
        'ColourFormatCombo
        '
        Me.ColourFormatCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourFormatCombo.Enabled = False
        Me.ColourFormatCombo.FormattingEnabled = True
        Me.ColourFormatCombo.Location = New System.Drawing.Point(84, 37)
        Me.ColourFormatCombo.Name = "ColourFormatCombo"
        Me.ColourFormatCombo.Size = New System.Drawing.Size(101, 21)
        Me.ColourFormatCombo.TabIndex = 56
        '
        'label48
        '
        Me.label48.AutoSize = True
        Me.label48.Location = New System.Drawing.Point(6, 41)
        Me.label48.Name = "label48"
        Me.label48.Size = New System.Drawing.Size(72, 13)
        Me.label48.TabIndex = 56
        Me.label48.Text = "Colour Format"
        '
        'CardSettingsButton
        '
        Me.CardSettingsButton.Location = New System.Drawing.Point(95, 82)
        Me.CardSettingsButton.Name = "CardSettingsButton"
        Me.CardSettingsButton.Size = New System.Drawing.Size(90, 24)
        Me.CardSettingsButton.TabIndex = 50
        Me.CardSettingsButton.Text = "Card Settings"
        Me.CardSettingsButton.UseVisualStyleBackColor = True
        '
        'groupBox14
        '
        Me.groupBox14.Controls.Add(Me.CardSizeCombo)
        Me.groupBox14.Controls.Add(Me.label43)
        Me.groupBox14.Controls.Add(Me.CopyCountUpDown)
        Me.groupBox14.Controls.Add(Me.label45)
        Me.groupBox14.Controls.Add(Me.DuplexCombo)
        Me.groupBox14.Controls.Add(Me.label46)
        Me.groupBox14.Controls.Add(Me.PrintSettingsButton)
        Me.groupBox14.Location = New System.Drawing.Point(8, 22)
        Me.groupBox14.Name = "groupBox14"
        Me.groupBox14.Size = New System.Drawing.Size(191, 87)
        Me.groupBox14.TabIndex = 73
        Me.groupBox14.TabStop = False
        '
        'CardSizeCombo
        '
        Me.CardSizeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CardSizeCombo.Enabled = False
        Me.CardSizeCombo.FormattingEnabled = True
        Me.CardSizeCombo.Location = New System.Drawing.Point(72, 31)
        Me.CardSizeCombo.Name = "CardSizeCombo"
        Me.CardSizeCombo.Size = New System.Drawing.Size(113, 21)
        Me.CardSizeCombo.TabIndex = 61
        '
        'label43
        '
        Me.label43.AutoSize = True
        Me.label43.Location = New System.Drawing.Point(6, 35)
        Me.label43.Name = "label43"
        Me.label43.Size = New System.Drawing.Size(52, 13)
        Me.label43.TabIndex = 60
        Me.label43.Text = "Card Size"
        '
        'CopyCountUpDown
        '
        Me.CopyCountUpDown.Enabled = False
        Me.CopyCountUpDown.Location = New System.Drawing.Point(32, 59)
        Me.CopyCountUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.CopyCountUpDown.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.CopyCountUpDown.Name = "CopyCountUpDown"
        Me.CopyCountUpDown.Size = New System.Drawing.Size(49, 20)
        Me.CopyCountUpDown.TabIndex = 56
        Me.CopyCountUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.CopyCountUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label45
        '
        Me.label45.AutoSize = True
        Me.label45.Location = New System.Drawing.Point(6, 63)
        Me.label45.Name = "label45"
        Me.label45.Size = New System.Drawing.Size(24, 13)
        Me.label45.TabIndex = 57
        Me.label45.Text = "No:"
        '
        'DuplexCombo
        '
        Me.DuplexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DuplexCombo.Enabled = False
        Me.DuplexCombo.FormattingEnabled = True
        Me.DuplexCombo.Location = New System.Drawing.Point(72, 9)
        Me.DuplexCombo.Name = "DuplexCombo"
        Me.DuplexCombo.Size = New System.Drawing.Size(113, 21)
        Me.DuplexCombo.TabIndex = 56
        '
        'label46
        '
        Me.label46.AutoSize = True
        Me.label46.Location = New System.Drawing.Point(6, 13)
        Me.label46.Name = "label46"
        Me.label46.Size = New System.Drawing.Size(69, 13)
        Me.label46.TabIndex = 56
        Me.label46.Text = "Sides to Print"
        '
        'PrintSettingsButton
        '
        Me.PrintSettingsButton.Location = New System.Drawing.Point(95, 57)
        Me.PrintSettingsButton.Name = "PrintSettingsButton"
        Me.PrintSettingsButton.Size = New System.Drawing.Size(90, 24)
        Me.PrintSettingsButton.TabIndex = 50
        Me.PrintSettingsButton.Text = "Print Settings"
        Me.PrintSettingsButton.UseVisualStyleBackColor = True
        '
        'ClearDriver2MsgBoxButton
        '
        Me.ClearDriver2MsgBoxButton.Location = New System.Drawing.Point(294, 539)
        Me.ClearDriver2MsgBoxButton.Name = "ClearDriver2MsgBoxButton"
        Me.ClearDriver2MsgBoxButton.Size = New System.Drawing.Size(90, 24)
        Me.ClearDriver2MsgBoxButton.TabIndex = 72
        Me.ClearDriver2MsgBoxButton.Text = "Clear"
        Me.ClearDriver2MsgBoxButton.UseVisualStyleBackColor = True
        '
        'Driver2MsgBox
        '
        Me.Driver2MsgBox.Location = New System.Drawing.Point(202, 202)
        Me.Driver2MsgBox.Multiline = True
        Me.Driver2MsgBox.Name = "Driver2MsgBox"
        Me.Driver2MsgBox.ReadOnly = True
        Me.Driver2MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Driver2MsgBox.Size = New System.Drawing.Size(256, 331)
        Me.Driver2MsgBox.TabIndex = 71
        Me.Driver2MsgBox.WordWrap = False
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Location = New System.Drawing.Point(28, 6)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(40, 13)
        Me.label17.TabIndex = 70
        Me.label17.Text = "Action:"
        '
        'Driver2SetRadio
        '
        Me.Driver2SetRadio.AutoSize = True
        Me.Driver2SetRadio.Location = New System.Drawing.Point(110, 4)
        Me.Driver2SetRadio.Name = "Driver2SetRadio"
        Me.Driver2SetRadio.Size = New System.Drawing.Size(41, 17)
        Me.Driver2SetRadio.TabIndex = 69
        Me.Driver2SetRadio.Text = "Set"
        Me.Driver2SetRadio.UseVisualStyleBackColor = True
        '
        'Driver2GetRadio
        '
        Me.Driver2GetRadio.AutoSize = True
        Me.Driver2GetRadio.Checked = True
        Me.Driver2GetRadio.Location = New System.Drawing.Point(68, 4)
        Me.Driver2GetRadio.Name = "Driver2GetRadio"
        Me.Driver2GetRadio.Size = New System.Drawing.Size(42, 17)
        Me.Driver2GetRadio.TabIndex = 68
        Me.Driver2GetRadio.TabStop = True
        Me.Driver2GetRadio.Text = "Get"
        Me.Driver2GetRadio.UseVisualStyleBackColor = True
        '
        'PrintDemo
        '
        Me.PrintDemo.Controls.Add(Me.PrinterPrefs)
        Me.PrintDemo.Controls.Add(Me.nativePrint)
        Me.PrintDemo.Controls.Add(Me.CardSide)
        Me.PrintDemo.Controls.Add(Me.CardBack)
        Me.PrintDemo.Controls.Add(Me.CardFront)
        Me.PrintDemo.Controls.Add(Me.PrintButton)
        Me.PrintDemo.Location = New System.Drawing.Point(4, 22)
        Me.PrintDemo.Name = "PrintDemo"
        Me.PrintDemo.Padding = New System.Windows.Forms.Padding(3)
        Me.PrintDemo.Size = New System.Drawing.Size(464, 566)
        Me.PrintDemo.TabIndex = 6
        Me.PrintDemo.Text = "Print"
        Me.PrintDemo.UseVisualStyleBackColor = True
        '
        'nativePrint
        '
        Me.nativePrint.AutoSize = True
        Me.nativePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.nativePrint.Location = New System.Drawing.Point(171, 532)
        Me.nativePrint.Name = "nativePrint"
        Me.nativePrint.Size = New System.Drawing.Size(117, 17)
        Me.nativePrint.TabIndex = 90
        Me.nativePrint.Text = "Use Native Printing"
        Me.nativePrint.UseVisualStyleBackColor = True
        '
        'CardSide
        '
        Me.CardSide.Controls.Add(Me.Front)
        Me.CardSide.Controls.Add(Me.Back)
        Me.CardSide.Location = New System.Drawing.Point(7, 31)
        Me.CardSide.Name = "CardSide"
        Me.CardSide.SelectedIndex = 0
        Me.CardSide.Size = New System.Drawing.Size(451, 493)
        Me.CardSide.TabIndex = 72
        '
        'Front
        '
        Me.Front.Controls.Add(Me.GroupBox29)
        Me.Front.Controls.Add(Me.GroupBox30)
        Me.Front.Controls.Add(Me.GroupBox31)
        Me.Front.Controls.Add(Me.GroupBox32)
        Me.Front.Controls.Add(Me.groupBox33)
        Me.Front.Location = New System.Drawing.Point(4, 22)
        Me.Front.Name = "Front"
        Me.Front.Padding = New System.Windows.Forms.Padding(3)
        Me.Front.Size = New System.Drawing.Size(443, 467)
        Me.Front.TabIndex = 0
        Me.Front.Text = "Front"
        Me.Front.UseVisualStyleBackColor = True
        '
        'GroupBox29
        '
        Me.GroupBox29.Controls.Add(Me.Track3MagData)
        Me.GroupBox29.Controls.Add(Me.Track2MagData)
        Me.GroupBox29.Controls.Add(Me.Track1MagData)
        Me.GroupBox29.Controls.Add(Me.label11)
        Me.GroupBox29.Controls.Add(Me.label10)
        Me.GroupBox29.Controls.Add(Me.label6)
        Me.GroupBox29.Controls.Add(Me.MagDataEnabled)
        Me.GroupBox29.Location = New System.Drawing.Point(3, 354)
        Me.GroupBox29.Name = "GroupBox29"
        Me.GroupBox29.Size = New System.Drawing.Size(437, 107)
        Me.GroupBox29.TabIndex = 88
        Me.GroupBox29.TabStop = False
        Me.GroupBox29.Text = "Magnetic Encoding"
        '
        'Track3MagData
        '
        Me.Track3MagData.Location = New System.Drawing.Point(56, 78)
        Me.Track3MagData.Name = "Track3MagData"
        Me.Track3MagData.Size = New System.Drawing.Size(375, 20)
        Me.Track3MagData.TabIndex = 91
        '
        'Track2MagData
        '
        Me.Track2MagData.Location = New System.Drawing.Point(56, 54)
        Me.Track2MagData.Name = "Track2MagData"
        Me.Track2MagData.Size = New System.Drawing.Size(375, 20)
        Me.Track2MagData.TabIndex = 90
        '
        'Track1MagData
        '
        Me.Track1MagData.Location = New System.Drawing.Point(56, 30)
        Me.Track1MagData.Name = "Track1MagData"
        Me.Track1MagData.Size = New System.Drawing.Size(375, 20)
        Me.Track1MagData.TabIndex = 89
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(6, 82)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(44, 13)
        Me.label11.TabIndex = 88
        Me.label11.Text = "Track 3"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(6, 58)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(44, 13)
        Me.label10.TabIndex = 87
        Me.label10.Text = "Track 2"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(6, 34)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(44, 13)
        Me.label6.TabIndex = 86
        Me.label6.Text = "Track 1"
        '
        'MagDataEnabled
        '
        Me.MagDataEnabled.AutoSize = True
        Me.MagDataEnabled.Location = New System.Drawing.Point(6, 14)
        Me.MagDataEnabled.Name = "MagDataEnabled"
        Me.MagDataEnabled.Size = New System.Drawing.Size(65, 17)
        Me.MagDataEnabled.TabIndex = 85
        Me.MagDataEnabled.Text = "Enabled"
        Me.MagDataEnabled.UseVisualStyleBackColor = True
        '
        'GroupBox30
        '
        Me.GroupBox30.Controls.Add(Me.ImageFrontResin)
        Me.GroupBox30.Controls.Add(Me.ImageFrontEnabled)
        Me.GroupBox30.Controls.Add(Me.ImageFrontButton)
        Me.GroupBox30.Controls.Add(Me.ImageFrontFileBox)
        Me.GroupBox30.Controls.Add(Me.ImageFrontP2UpDown)
        Me.GroupBox30.Controls.Add(Me.Label8)
        Me.GroupBox30.Controls.Add(Me.Label12)
        Me.GroupBox30.Controls.Add(Me.ImageFrontP1UpDown)
        Me.GroupBox30.Controls.Add(Me.ImageFrontYUpDown)
        Me.GroupBox30.Controls.Add(Me.Label14)
        Me.GroupBox30.Controls.Add(Me.ImageFrontXUpDown)
        Me.GroupBox30.Controls.Add(Me.Label15)
        Me.GroupBox30.Controls.Add(Me.Label106)
        Me.GroupBox30.Controls.Add(Me.Label107)
        Me.GroupBox30.Location = New System.Drawing.Point(3, 273)
        Me.GroupBox30.Name = "GroupBox30"
        Me.GroupBox30.Size = New System.Drawing.Size(437, 75)
        Me.GroupBox30.TabIndex = 87
        Me.GroupBox30.TabStop = False
        Me.GroupBox30.Text = "Image"
        '
        'ImageFrontResin
        '
        Me.ImageFrontResin.AutoSize = True
        Me.ImageFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ImageFrontResin.Location = New System.Drawing.Point(356, 42)
        Me.ImageFrontResin.Name = "ImageFrontResin"
        Me.ImageFrontResin.Size = New System.Drawing.Size(75, 17)
        Me.ImageFrontResin.TabIndex = 87
        Me.ImageFrontResin.Text = "Use Resin"
        Me.ImageFrontResin.UseVisualStyleBackColor = True
        '
        'ImageFrontEnabled
        '
        Me.ImageFrontEnabled.AutoSize = True
        Me.ImageFrontEnabled.Location = New System.Drawing.Point(6, 14)
        Me.ImageFrontEnabled.Name = "ImageFrontEnabled"
        Me.ImageFrontEnabled.Size = New System.Drawing.Size(65, 17)
        Me.ImageFrontEnabled.TabIndex = 85
        Me.ImageFrontEnabled.Text = "Enabled"
        Me.ImageFrontEnabled.UseVisualStyleBackColor = True
        '
        'ImageFrontButton
        '
        Me.ImageFrontButton.Location = New System.Drawing.Point(400, 10)
        Me.ImageFrontButton.Name = "ImageFrontButton"
        Me.ImageFrontButton.Size = New System.Drawing.Size(28, 24)
        Me.ImageFrontButton.TabIndex = 70
        Me.ImageFrontButton.Text = "..."
        Me.ImageFrontButton.UseVisualStyleBackColor = True
        '
        'ImageFrontFileBox
        '
        Me.ImageFrontFileBox.Location = New System.Drawing.Point(127, 12)
        Me.ImageFrontFileBox.Name = "ImageFrontFileBox"
        Me.ImageFrontFileBox.Size = New System.Drawing.Size(273, 20)
        Me.ImageFrontFileBox.TabIndex = 83
        '
        'ImageFrontP2UpDown
        '
        Me.ImageFrontP2UpDown.Location = New System.Drawing.Point(258, 40)
        Me.ImageFrontP2UpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ImageFrontP2UpDown.Name = "ImageFrontP2UpDown"
        Me.ImageFrontP2UpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageFrontP2UpDown.TabIndex = 82
        Me.ImageFrontP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(238, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(20, 13)
        Me.Label8.TabIndex = 81
        Me.Label8.Text = "P2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(173, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(20, 13)
        Me.Label12.TabIndex = 80
        Me.Label12.Text = "P1"
        '
        'ImageFrontP1UpDown
        '
        Me.ImageFrontP1UpDown.Location = New System.Drawing.Point(193, 40)
        Me.ImageFrontP1UpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ImageFrontP1UpDown.Name = "ImageFrontP1UpDown"
        Me.ImageFrontP1UpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageFrontP1UpDown.TabIndex = 78
        Me.ImageFrontP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ImageFrontYUpDown
        '
        Me.ImageFrontYUpDown.Location = New System.Drawing.Point(128, 40)
        Me.ImageFrontYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ImageFrontYUpDown.Name = "ImageFrontYUpDown"
        Me.ImageFrontYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageFrontYUpDown.TabIndex = 76
        Me.ImageFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(114, 44)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(14, 13)
        Me.Label14.TabIndex = 75
        Me.Label14.Text = "Y"
        '
        'ImageFrontXUpDown
        '
        Me.ImageFrontXUpDown.Location = New System.Drawing.Point(69, 40)
        Me.ImageFrontXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ImageFrontXUpDown.Name = "ImageFrontXUpDown"
        Me.ImageFrontXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageFrontXUpDown.TabIndex = 74
        Me.ImageFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(56, 44)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(14, 13)
        Me.Label15.TabIndex = 73
        Me.Label15.Text = "X"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Location = New System.Drawing.Point(6, 44)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(47, 13)
        Me.Label106.TabIndex = 33
        Me.Label106.Text = "Position:"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(91, 16)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(23, 13)
        Me.Label107.TabIndex = 32
        Me.Label107.Text = "File"
        '
        'GroupBox31
        '
        Me.GroupBox31.Controls.Add(Me.LineFrontEnabled)
        Me.GroupBox31.Controls.Add(Me.Label108)
        Me.GroupBox31.Controls.Add(Me.LineFrontWidthUpDown)
        Me.GroupBox31.Controls.Add(Me.Label109)
        Me.GroupBox31.Controls.Add(Me.LineFrontStartYUpDown)
        Me.GroupBox31.Controls.Add(Me.LineFrontEndYUpDown)
        Me.GroupBox31.Controls.Add(Me.Label110)
        Me.GroupBox31.Controls.Add(Me.Label111)
        Me.GroupBox31.Controls.Add(Me.Label113)
        Me.GroupBox31.Controls.Add(Me.Label114)
        Me.GroupBox31.Controls.Add(Me.LineFrontResin)
        Me.GroupBox31.Controls.Add(Me.LineFrontEndXUpDown)
        Me.GroupBox31.Controls.Add(Me.LineFrontColourCombo)
        Me.GroupBox31.Controls.Add(Me.LineFrontStartXUpDown)
        Me.GroupBox31.Controls.Add(Me.Label115)
        Me.GroupBox31.Controls.Add(Me.Label116)
        Me.GroupBox31.Location = New System.Drawing.Point(3, 182)
        Me.GroupBox31.Name = "GroupBox31"
        Me.GroupBox31.Size = New System.Drawing.Size(437, 85)
        Me.GroupBox31.TabIndex = 86
        Me.GroupBox31.TabStop = False
        Me.GroupBox31.Text = "Line"
        '
        'LineFrontEnabled
        '
        Me.LineFrontEnabled.AutoSize = True
        Me.LineFrontEnabled.Checked = True
        Me.LineFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LineFrontEnabled.Location = New System.Drawing.Point(6, 14)
        Me.LineFrontEnabled.Name = "LineFrontEnabled"
        Me.LineFrontEnabled.Size = New System.Drawing.Size(65, 17)
        Me.LineFrontEnabled.TabIndex = 84
        Me.LineFrontEnabled.Text = "Enabled"
        Me.LineFrontEnabled.UseVisualStyleBackColor = True
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(188, 63)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(29, 13)
        Me.Label108.TabIndex = 82
        Me.Label108.Text = "End:"
        '
        'LineFrontWidthUpDown
        '
        Me.LineFrontWidthUpDown.Location = New System.Drawing.Point(234, 32)
        Me.LineFrontWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.LineFrontWidthUpDown.Name = "LineFrontWidthUpDown"
        Me.LineFrontWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineFrontWidthUpDown.TabIndex = 81
        Me.LineFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(201, 36)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(35, 13)
        Me.Label109.TabIndex = 80
        Me.Label109.Text = "Width"
        '
        'LineFrontStartYUpDown
        '
        Me.LineFrontStartYUpDown.Location = New System.Drawing.Point(115, 59)
        Me.LineFrontStartYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.LineFrontStartYUpDown.Name = "LineFrontStartYUpDown"
        Me.LineFrontStartYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineFrontStartYUpDown.TabIndex = 76
        Me.LineFrontStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineFrontEndYUpDown
        '
        Me.LineFrontEndYUpDown.Location = New System.Drawing.Point(295, 59)
        Me.LineFrontEndYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.LineFrontEndYUpDown.Name = "LineFrontEndYUpDown"
        Me.LineFrontEndYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineFrontEndYUpDown.TabIndex = 82
        Me.LineFrontEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(6, 62)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(32, 13)
        Me.Label110.TabIndex = 80
        Me.Label110.Text = "Start:"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(281, 63)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(14, 13)
        Me.Label111.TabIndex = 81
        Me.Label111.Text = "Y"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(42, 63)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(14, 13)
        Me.Label113.TabIndex = 73
        Me.Label113.Text = "X"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(220, 63)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(14, 13)
        Me.Label114.TabIndex = 80
        Me.Label114.Text = "X"
        '
        'LineFrontResin
        '
        Me.LineFrontResin.AutoSize = True
        Me.LineFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LineFrontResin.Location = New System.Drawing.Point(356, 14)
        Me.LineFrontResin.Name = "LineFrontResin"
        Me.LineFrontResin.Size = New System.Drawing.Size(75, 17)
        Me.LineFrontResin.TabIndex = 79
        Me.LineFrontResin.Text = "Use Resin"
        Me.LineFrontResin.UseVisualStyleBackColor = True
        '
        'LineFrontEndXUpDown
        '
        Me.LineFrontEndXUpDown.Location = New System.Drawing.Point(234, 59)
        Me.LineFrontEndXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.LineFrontEndXUpDown.Name = "LineFrontEndXUpDown"
        Me.LineFrontEndXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineFrontEndXUpDown.TabIndex = 78
        Me.LineFrontEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineFrontColourCombo
        '
        Me.LineFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LineFrontColourCombo.Location = New System.Drawing.Point(56, 32)
        Me.LineFrontColourCombo.Name = "LineFrontColourCombo"
        Me.LineFrontColourCombo.Size = New System.Drawing.Size(139, 21)
        Me.LineFrontColourCombo.TabIndex = 34
        '
        'LineFrontStartXUpDown
        '
        Me.LineFrontStartXUpDown.Location = New System.Drawing.Point(56, 59)
        Me.LineFrontStartXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.LineFrontStartXUpDown.Name = "LineFrontStartXUpDown"
        Me.LineFrontStartXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineFrontStartXUpDown.TabIndex = 74
        Me.LineFrontStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(6, 36)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(37, 13)
        Me.Label115.TabIndex = 32
        Me.Label115.Text = "Colour"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Location = New System.Drawing.Point(101, 63)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(14, 13)
        Me.Label116.TabIndex = 75
        Me.Label116.Text = "Y"
        '
        'GroupBox32
        '
        Me.GroupBox32.Controls.Add(Me.ShapeFrontEnabled)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontFillCombo)
        Me.GroupBox32.Controls.Add(Me.Label117)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontWidthUpDown)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontOutlineCombo)
        Me.GroupBox32.Controls.Add(Me.Label118)
        Me.GroupBox32.Controls.Add(Me.Label119)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontBUpDown)
        Me.GroupBox32.Controls.Add(Me.Label120)
        Me.GroupBox32.Controls.Add(Me.Label121)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontResin)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontRUpDown)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontTUpDown)
        Me.GroupBox32.Controls.Add(Me.Label122)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontLUpDown)
        Me.GroupBox32.Controls.Add(Me.Label123)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontCombo)
        Me.GroupBox32.Controls.Add(Me.Label124)
        Me.GroupBox32.Controls.Add(Me.Label125)
        Me.GroupBox32.Location = New System.Drawing.Point(3, 91)
        Me.GroupBox32.Name = "GroupBox32"
        Me.GroupBox32.Size = New System.Drawing.Size(437, 85)
        Me.GroupBox32.TabIndex = 85
        Me.GroupBox32.TabStop = False
        Me.GroupBox32.Text = "Shape"
        '
        'ShapeFrontEnabled
        '
        Me.ShapeFrontEnabled.AutoSize = True
        Me.ShapeFrontEnabled.Checked = True
        Me.ShapeFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShapeFrontEnabled.Location = New System.Drawing.Point(6, 14)
        Me.ShapeFrontEnabled.Name = "ShapeFrontEnabled"
        Me.ShapeFrontEnabled.Size = New System.Drawing.Size(65, 17)
        Me.ShapeFrontEnabled.TabIndex = 83
        Me.ShapeFrontEnabled.Text = "Enabled"
        Me.ShapeFrontEnabled.UseVisualStyleBackColor = True
        '
        'ShapeFrontFillCombo
        '
        Me.ShapeFrontFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontFillCombo.Items.AddRange(New Object() {"Red", "Green", "Blue", "Cyan", "Magenta", "Yellow", "White", "Black", "Transparent"})
        Me.ShapeFrontFillCombo.Location = New System.Drawing.Point(251, 60)
        Me.ShapeFrontFillCombo.Name = "ShapeFrontFillCombo"
        Me.ShapeFrontFillCombo.Size = New System.Drawing.Size(127, 21)
        Me.ShapeFrontFillCombo.TabIndex = 81
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(232, 64)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(19, 13)
        Me.Label117.TabIndex = 80
        Me.Label117.Text = "Fill"
        '
        'ShapeFrontWidthUpDown
        '
        Me.ShapeFrontWidthUpDown.Location = New System.Drawing.Point(176, 60)
        Me.ShapeFrontWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ShapeFrontWidthUpDown.Name = "ShapeFrontWidthUpDown"
        Me.ShapeFrontWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeFrontWidthUpDown.TabIndex = 81
        Me.ShapeFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeFrontOutlineCombo
        '
        Me.ShapeFrontOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontOutlineCombo.Location = New System.Drawing.Point(52, 60)
        Me.ShapeFrontOutlineCombo.Name = "ShapeFrontOutlineCombo"
        Me.ShapeFrontOutlineCombo.Size = New System.Drawing.Size(85, 21)
        Me.ShapeFrontOutlineCombo.TabIndex = 81
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(143, 64)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(35, 13)
        Me.Label118.TabIndex = 80
        Me.Label118.Text = "Width"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(6, 64)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(40, 13)
        Me.Label119.TabIndex = 80
        Me.Label119.Text = "Outline"
        '
        'ShapeFrontBUpDown
        '
        Me.ShapeFrontBUpDown.Location = New System.Drawing.Point(378, 37)
        Me.ShapeFrontBUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ShapeFrontBUpDown.Name = "ShapeFrontBUpDown"
        Me.ShapeFrontBUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeFrontBUpDown.TabIndex = 82
        Me.ShapeFrontBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(364, 41)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(14, 13)
        Me.Label120.TabIndex = 81
        Me.Label120.Text = "B"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Location = New System.Drawing.Point(304, 41)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(15, 13)
        Me.Label121.TabIndex = 80
        Me.Label121.Text = "R"
        '
        'ShapeFrontResin
        '
        Me.ShapeFrontResin.AutoSize = True
        Me.ShapeFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShapeFrontResin.Location = New System.Drawing.Point(356, 14)
        Me.ShapeFrontResin.Name = "ShapeFrontResin"
        Me.ShapeFrontResin.Size = New System.Drawing.Size(75, 17)
        Me.ShapeFrontResin.TabIndex = 79
        Me.ShapeFrontResin.Text = "Use Resin"
        Me.ShapeFrontResin.UseVisualStyleBackColor = True
        '
        'ShapeFrontRUpDown
        '
        Me.ShapeFrontRUpDown.Location = New System.Drawing.Point(319, 37)
        Me.ShapeFrontRUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ShapeFrontRUpDown.Name = "ShapeFrontRUpDown"
        Me.ShapeFrontRUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeFrontRUpDown.TabIndex = 78
        Me.ShapeFrontRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeFrontTUpDown
        '
        Me.ShapeFrontTUpDown.Location = New System.Drawing.Point(259, 37)
        Me.ShapeFrontTUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ShapeFrontTUpDown.Name = "ShapeFrontTUpDown"
        Me.ShapeFrontTUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeFrontTUpDown.TabIndex = 76
        Me.ShapeFrontTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Location = New System.Drawing.Point(245, 41)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(14, 13)
        Me.Label122.TabIndex = 75
        Me.Label122.Text = "T"
        '
        'ShapeFrontLUpDown
        '
        Me.ShapeFrontLUpDown.Location = New System.Drawing.Point(200, 37)
        Me.ShapeFrontLUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ShapeFrontLUpDown.Name = "ShapeFrontLUpDown"
        Me.ShapeFrontLUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeFrontLUpDown.TabIndex = 74
        Me.ShapeFrontLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(187, 41)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(13, 13)
        Me.Label123.TabIndex = 73
        Me.Label123.Text = "L"
        '
        'ShapeFrontCombo
        '
        Me.ShapeFrontCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontCombo.Location = New System.Drawing.Point(52, 37)
        Me.ShapeFrontCombo.Name = "ShapeFrontCombo"
        Me.ShapeFrontCombo.Size = New System.Drawing.Size(85, 21)
        Me.ShapeFrontCombo.TabIndex = 34
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(140, 41)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(47, 13)
        Me.Label124.TabIndex = 33
        Me.Label124.Text = "Position:"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(6, 41)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(38, 13)
        Me.Label125.TabIndex = 32
        Me.Label125.Text = "Shape"
        '
        'groupBox33
        '
        Me.groupBox33.Controls.Add(Me.TextFrontEnabled)
        Me.groupBox33.Controls.Add(Me.TextFrontResin)
        Me.groupBox33.Controls.Add(Me.TextFrontSizeUpDown)
        Me.groupBox33.Controls.Add(Me.Label126)
        Me.groupBox33.Controls.Add(Me.TextFrontYUpDown)
        Me.groupBox33.Controls.Add(Me.Label127)
        Me.groupBox33.Controls.Add(Me.TextFrontXUpDown)
        Me.groupBox33.Controls.Add(Me.Label128)
        Me.groupBox33.Controls.Add(Me.TextFrontStrikethrough)
        Me.groupBox33.Controls.Add(Me.TextFrontItalic)
        Me.groupBox33.Controls.Add(Me.TextFrontUnderline)
        Me.groupBox33.Controls.Add(Me.TextFrontBold)
        Me.groupBox33.Controls.Add(Me.TextFrontColourCombo)
        Me.groupBox33.Controls.Add(Me.Label129)
        Me.groupBox33.Controls.Add(Me.Label130)
        Me.groupBox33.Controls.Add(Me.Label131)
        Me.groupBox33.Controls.Add(Me.TextFrontBox)
        Me.groupBox33.Location = New System.Drawing.Point(3, 0)
        Me.groupBox33.Name = "groupBox33"
        Me.groupBox33.Size = New System.Drawing.Size(437, 85)
        Me.groupBox33.TabIndex = 1
        Me.groupBox33.TabStop = False
        Me.groupBox33.Text = "Text"
        '
        'TextFrontEnabled
        '
        Me.TextFrontEnabled.AutoSize = True
        Me.TextFrontEnabled.Checked = True
        Me.TextFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TextFrontEnabled.Location = New System.Drawing.Point(6, 14)
        Me.TextFrontEnabled.Name = "TextFrontEnabled"
        Me.TextFrontEnabled.Size = New System.Drawing.Size(65, 17)
        Me.TextFrontEnabled.TabIndex = 80
        Me.TextFrontEnabled.Text = "Enabled"
        Me.TextFrontEnabled.UseVisualStyleBackColor = True
        '
        'TextFrontResin
        '
        Me.TextFrontResin.AutoSize = True
        Me.TextFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontResin.Location = New System.Drawing.Point(356, 62)
        Me.TextFrontResin.Name = "TextFrontResin"
        Me.TextFrontResin.Size = New System.Drawing.Size(75, 17)
        Me.TextFrontResin.TabIndex = 79
        Me.TextFrontResin.Text = "Use Resin"
        Me.TextFrontResin.UseVisualStyleBackColor = True
        '
        'TextFrontSizeUpDown
        '
        Me.TextFrontSizeUpDown.Location = New System.Drawing.Point(241, 60)
        Me.TextFrontSizeUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.TextFrontSizeUpDown.Name = "TextFrontSizeUpDown"
        Me.TextFrontSizeUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextFrontSizeUpDown.TabIndex = 78
        Me.TextFrontSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Location = New System.Drawing.Point(214, 64)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(27, 13)
        Me.Label126.TabIndex = 77
        Me.Label126.Text = "Size"
        '
        'TextFrontYUpDown
        '
        Me.TextFrontYUpDown.Location = New System.Drawing.Point(144, 60)
        Me.TextFrontYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.TextFrontYUpDown.Name = "TextFrontYUpDown"
        Me.TextFrontYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextFrontYUpDown.TabIndex = 76
        Me.TextFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Location = New System.Drawing.Point(124, 64)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(14, 13)
        Me.Label127.TabIndex = 75
        Me.Label127.Text = "Y"
        '
        'TextFrontXUpDown
        '
        Me.TextFrontXUpDown.Location = New System.Drawing.Point(73, 60)
        Me.TextFrontXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.TextFrontXUpDown.Name = "TextFrontXUpDown"
        Me.TextFrontXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextFrontXUpDown.TabIndex = 74
        Me.TextFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Location = New System.Drawing.Point(53, 64)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(14, 13)
        Me.Label128.TabIndex = 73
        Me.Label128.Text = "X"
        '
        'TextFrontStrikethrough
        '
        Me.TextFrontStrikethrough.AutoSize = True
        Me.TextFrontStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontStrikethrough.Location = New System.Drawing.Point(342, 39)
        Me.TextFrontStrikethrough.Name = "TextFrontStrikethrough"
        Me.TextFrontStrikethrough.Size = New System.Drawing.Size(89, 17)
        Me.TextFrontStrikethrough.TabIndex = 72
        Me.TextFrontStrikethrough.Text = "Strikethrough"
        Me.TextFrontStrikethrough.UseVisualStyleBackColor = True
        '
        'TextFrontItalic
        '
        Me.TextFrontItalic.AutoSize = True
        Me.TextFrontItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontItalic.Location = New System.Drawing.Point(282, 39)
        Me.TextFrontItalic.Name = "TextFrontItalic"
        Me.TextFrontItalic.Size = New System.Drawing.Size(48, 17)
        Me.TextFrontItalic.TabIndex = 71
        Me.TextFrontItalic.Text = "Italic"
        Me.TextFrontItalic.UseVisualStyleBackColor = True
        '
        'TextFrontUnderline
        '
        Me.TextFrontUnderline.AutoSize = True
        Me.TextFrontUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontUnderline.Location = New System.Drawing.Point(201, 39)
        Me.TextFrontUnderline.Name = "TextFrontUnderline"
        Me.TextFrontUnderline.Size = New System.Drawing.Size(71, 17)
        Me.TextFrontUnderline.TabIndex = 70
        Me.TextFrontUnderline.Text = "Underline"
        Me.TextFrontUnderline.UseVisualStyleBackColor = True
        '
        'TextFrontBold
        '
        Me.TextFrontBold.AutoSize = True
        Me.TextFrontBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontBold.Location = New System.Drawing.Point(144, 39)
        Me.TextFrontBold.Name = "TextFrontBold"
        Me.TextFrontBold.Size = New System.Drawing.Size(47, 17)
        Me.TextFrontBold.TabIndex = 69
        Me.TextFrontBold.Text = "Bold"
        Me.TextFrontBold.UseVisualStyleBackColor = True
        '
        'TextFrontColourCombo
        '
        Me.TextFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TextFrontColourCombo.Location = New System.Drawing.Point(53, 37)
        Me.TextFrontColourCombo.Name = "TextFrontColourCombo"
        Me.TextFrontColourCombo.Size = New System.Drawing.Size(85, 21)
        Me.TextFrontColourCombo.TabIndex = 34
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(6, 64)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(47, 13)
        Me.Label129.TabIndex = 33
        Me.Label129.Text = "Position:"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(6, 41)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(37, 13)
        Me.Label130.TabIndex = 32
        Me.Label130.Text = "Colour"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(110, 16)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(28, 13)
        Me.Label131.TabIndex = 31
        Me.Label131.Text = "Text"
        '
        'TextFrontBox
        '
        Me.TextFrontBox.Location = New System.Drawing.Point(144, 12)
        Me.TextFrontBox.Name = "TextFrontBox"
        Me.TextFrontBox.Size = New System.Drawing.Size(287, 20)
        Me.TextFrontBox.TabIndex = 14
        Me.TextFrontBox.Text = "Front - First Line of VB Text"
        '
        'Back
        '
        Me.Back.Controls.Add(Me.GroupBox34)
        Me.Back.Controls.Add(Me.GroupBox35)
        Me.Back.Controls.Add(Me.GroupBox36)
        Me.Back.Controls.Add(Me.GroupBox37)
        Me.Back.Location = New System.Drawing.Point(4, 22)
        Me.Back.Name = "Back"
        Me.Back.Padding = New System.Windows.Forms.Padding(3)
        Me.Back.Size = New System.Drawing.Size(443, 467)
        Me.Back.TabIndex = 1
        Me.Back.Text = "Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'GroupBox34
        '
        Me.GroupBox34.Controls.Add(Me.ImageBackResin)
        Me.GroupBox34.Controls.Add(Me.ImageBackEnabled)
        Me.GroupBox34.Controls.Add(ImageBackButton)
        Me.GroupBox34.Controls.Add(Me.ImageBackFileBox)
        Me.GroupBox34.Controls.Add(Me.ImageBackP2UpDown)
        Me.GroupBox34.Controls.Add(Me.Label132)
        Me.GroupBox34.Controls.Add(Me.Label133)
        Me.GroupBox34.Controls.Add(Me.ImageBackP1UpDown)
        Me.GroupBox34.Controls.Add(Me.ImageBackYUpDown)
        Me.GroupBox34.Controls.Add(Me.Label134)
        Me.GroupBox34.Controls.Add(Me.ImageBackXUpDown)
        Me.GroupBox34.Controls.Add(Me.Label135)
        Me.GroupBox34.Controls.Add(Me.Label136)
        Me.GroupBox34.Controls.Add(Me.Label137)
        Me.GroupBox34.Location = New System.Drawing.Point(3, 273)
        Me.GroupBox34.Name = "GroupBox34"
        Me.GroupBox34.Size = New System.Drawing.Size(437, 75)
        Me.GroupBox34.TabIndex = 91
        Me.GroupBox34.TabStop = False
        Me.GroupBox34.Text = "Image"
        '
        'ImageBackResin
        '
        Me.ImageBackResin.AutoSize = True
        Me.ImageBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ImageBackResin.Enabled = False
        Me.ImageBackResin.Location = New System.Drawing.Point(356, 42)
        Me.ImageBackResin.Name = "ImageBackResin"
        Me.ImageBackResin.Size = New System.Drawing.Size(75, 17)
        Me.ImageBackResin.TabIndex = 86
        Me.ImageBackResin.Text = "Use Resin"
        Me.ImageBackResin.UseVisualStyleBackColor = True
        '
        'ImageBackEnabled
        '
        Me.ImageBackEnabled.AutoSize = True
        Me.ImageBackEnabled.Enabled = False
        Me.ImageBackEnabled.Location = New System.Drawing.Point(6, 14)
        Me.ImageBackEnabled.Name = "ImageBackEnabled"
        Me.ImageBackEnabled.Size = New System.Drawing.Size(65, 17)
        Me.ImageBackEnabled.TabIndex = 85
        Me.ImageBackEnabled.Text = "Enabled"
        Me.ImageBackEnabled.UseVisualStyleBackColor = True
        '
        'ImageBackFileBox
        '
        Me.ImageBackFileBox.Enabled = False
        Me.ImageBackFileBox.Location = New System.Drawing.Point(127, 12)
        Me.ImageBackFileBox.Name = "ImageBackFileBox"
        Me.ImageBackFileBox.Size = New System.Drawing.Size(273, 20)
        Me.ImageBackFileBox.TabIndex = 83
        '
        'ImageBackP2UpDown
        '
        Me.ImageBackP2UpDown.Enabled = False
        Me.ImageBackP2UpDown.Location = New System.Drawing.Point(258, 40)
        Me.ImageBackP2UpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ImageBackP2UpDown.Name = "ImageBackP2UpDown"
        Me.ImageBackP2UpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageBackP2UpDown.TabIndex = 82
        Me.ImageBackP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Location = New System.Drawing.Point(238, 44)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(20, 13)
        Me.Label132.TabIndex = 81
        Me.Label132.Text = "P2"
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(173, 44)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(20, 13)
        Me.Label133.TabIndex = 80
        Me.Label133.Text = "P1"
        '
        'ImageBackP1UpDown
        '
        Me.ImageBackP1UpDown.Enabled = False
        Me.ImageBackP1UpDown.Location = New System.Drawing.Point(193, 40)
        Me.ImageBackP1UpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ImageBackP1UpDown.Name = "ImageBackP1UpDown"
        Me.ImageBackP1UpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageBackP1UpDown.TabIndex = 78
        Me.ImageBackP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ImageBackYUpDown
        '
        Me.ImageBackYUpDown.Enabled = False
        Me.ImageBackYUpDown.Location = New System.Drawing.Point(128, 40)
        Me.ImageBackYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ImageBackYUpDown.Name = "ImageBackYUpDown"
        Me.ImageBackYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageBackYUpDown.TabIndex = 76
        Me.ImageBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Location = New System.Drawing.Point(114, 44)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(14, 13)
        Me.Label134.TabIndex = 75
        Me.Label134.Text = "Y"
        '
        'ImageBackXUpDown
        '
        Me.ImageBackXUpDown.Enabled = False
        Me.ImageBackXUpDown.Location = New System.Drawing.Point(69, 40)
        Me.ImageBackXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ImageBackXUpDown.Name = "ImageBackXUpDown"
        Me.ImageBackXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ImageBackXUpDown.TabIndex = 74
        Me.ImageBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Location = New System.Drawing.Point(56, 44)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(14, 13)
        Me.Label135.TabIndex = 73
        Me.Label135.Text = "X"
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Location = New System.Drawing.Point(6, 44)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(47, 13)
        Me.Label136.TabIndex = 33
        Me.Label136.Text = "Position:"
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Location = New System.Drawing.Point(91, 16)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(23, 13)
        Me.Label137.TabIndex = 32
        Me.Label137.Text = "File"
        '
        'GroupBox35
        '
        Me.GroupBox35.Controls.Add(Me.LineBackEnabled)
        Me.GroupBox35.Controls.Add(Me.Label138)
        Me.GroupBox35.Controls.Add(Me.LineBackWidthUpDown)
        Me.GroupBox35.Controls.Add(Me.Label139)
        Me.GroupBox35.Controls.Add(Me.LineBackStartYUpDown)
        Me.GroupBox35.Controls.Add(Me.LineBackEndYUpDown)
        Me.GroupBox35.Controls.Add(Me.Label140)
        Me.GroupBox35.Controls.Add(Me.Label141)
        Me.GroupBox35.Controls.Add(Me.Label142)
        Me.GroupBox35.Controls.Add(Me.Label143)
        Me.GroupBox35.Controls.Add(Me.LineBackResin)
        Me.GroupBox35.Controls.Add(Me.LineBackEndXUpDown)
        Me.GroupBox35.Controls.Add(Me.LineBackColourCombo)
        Me.GroupBox35.Controls.Add(Me.LineBackStartXUpDown)
        Me.GroupBox35.Controls.Add(Me.Label144)
        Me.GroupBox35.Controls.Add(Me.Label145)
        Me.GroupBox35.Location = New System.Drawing.Point(3, 182)
        Me.GroupBox35.Name = "GroupBox35"
        Me.GroupBox35.Size = New System.Drawing.Size(437, 85)
        Me.GroupBox35.TabIndex = 90
        Me.GroupBox35.TabStop = False
        Me.GroupBox35.Text = "Line"
        '
        'LineBackEnabled
        '
        Me.LineBackEnabled.AutoSize = True
        Me.LineBackEnabled.Enabled = False
        Me.LineBackEnabled.Location = New System.Drawing.Point(6, 14)
        Me.LineBackEnabled.Name = "LineBackEnabled"
        Me.LineBackEnabled.Size = New System.Drawing.Size(65, 17)
        Me.LineBackEnabled.TabIndex = 84
        Me.LineBackEnabled.Text = "Enabled"
        Me.LineBackEnabled.UseVisualStyleBackColor = True
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Location = New System.Drawing.Point(188, 63)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(29, 13)
        Me.Label138.TabIndex = 82
        Me.Label138.Text = "End:"
        '
        'LineBackWidthUpDown
        '
        Me.LineBackWidthUpDown.Enabled = False
        Me.LineBackWidthUpDown.Location = New System.Drawing.Point(234, 32)
        Me.LineBackWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.LineBackWidthUpDown.Name = "LineBackWidthUpDown"
        Me.LineBackWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineBackWidthUpDown.TabIndex = 81
        Me.LineBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Location = New System.Drawing.Point(201, 36)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(35, 13)
        Me.Label139.TabIndex = 80
        Me.Label139.Text = "Width"
        '
        'LineBackStartYUpDown
        '
        Me.LineBackStartYUpDown.Enabled = False
        Me.LineBackStartYUpDown.Location = New System.Drawing.Point(115, 59)
        Me.LineBackStartYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.LineBackStartYUpDown.Name = "LineBackStartYUpDown"
        Me.LineBackStartYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineBackStartYUpDown.TabIndex = 76
        Me.LineBackStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineBackEndYUpDown
        '
        Me.LineBackEndYUpDown.Enabled = False
        Me.LineBackEndYUpDown.Location = New System.Drawing.Point(295, 59)
        Me.LineBackEndYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.LineBackEndYUpDown.Name = "LineBackEndYUpDown"
        Me.LineBackEndYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineBackEndYUpDown.TabIndex = 82
        Me.LineBackEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(6, 62)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(32, 13)
        Me.Label140.TabIndex = 80
        Me.Label140.Text = "Start:"
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Location = New System.Drawing.Point(281, 63)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(14, 13)
        Me.Label141.TabIndex = 81
        Me.Label141.Text = "Y"
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Location = New System.Drawing.Point(42, 63)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(14, 13)
        Me.Label142.TabIndex = 73
        Me.Label142.Text = "X"
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Location = New System.Drawing.Point(220, 63)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(14, 13)
        Me.Label143.TabIndex = 80
        Me.Label143.Text = "X"
        '
        'LineBackResin
        '
        Me.LineBackResin.AutoSize = True
        Me.LineBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LineBackResin.Enabled = False
        Me.LineBackResin.Location = New System.Drawing.Point(356, 14)
        Me.LineBackResin.Name = "LineBackResin"
        Me.LineBackResin.Size = New System.Drawing.Size(75, 17)
        Me.LineBackResin.TabIndex = 79
        Me.LineBackResin.Text = "Use Resin"
        Me.LineBackResin.UseVisualStyleBackColor = True
        '
        'LineBackEndXUpDown
        '
        Me.LineBackEndXUpDown.Enabled = False
        Me.LineBackEndXUpDown.Location = New System.Drawing.Point(234, 59)
        Me.LineBackEndXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.LineBackEndXUpDown.Name = "LineBackEndXUpDown"
        Me.LineBackEndXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineBackEndXUpDown.TabIndex = 78
        Me.LineBackEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineBackColourCombo
        '
        Me.LineBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LineBackColourCombo.Enabled = False
        Me.LineBackColourCombo.Location = New System.Drawing.Point(56, 32)
        Me.LineBackColourCombo.Name = "LineBackColourCombo"
        Me.LineBackColourCombo.Size = New System.Drawing.Size(139, 21)
        Me.LineBackColourCombo.TabIndex = 34
        '
        'LineBackStartXUpDown
        '
        Me.LineBackStartXUpDown.Enabled = False
        Me.LineBackStartXUpDown.Location = New System.Drawing.Point(56, 59)
        Me.LineBackStartXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.LineBackStartXUpDown.Name = "LineBackStartXUpDown"
        Me.LineBackStartXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.LineBackStartXUpDown.TabIndex = 74
        Me.LineBackStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Location = New System.Drawing.Point(6, 36)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(37, 13)
        Me.Label144.TabIndex = 32
        Me.Label144.Text = "Colour"
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Location = New System.Drawing.Point(101, 63)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(14, 13)
        Me.Label145.TabIndex = 75
        Me.Label145.Text = "Y"
        '
        'GroupBox36
        '
        Me.GroupBox36.Controls.Add(Me.ShapeBackEnabled)
        Me.GroupBox36.Controls.Add(Me.ShapeBackFillCombo)
        Me.GroupBox36.Controls.Add(Me.Label146)
        Me.GroupBox36.Controls.Add(Me.ShapeBackWidthUpDown)
        Me.GroupBox36.Controls.Add(Me.ShapeBackOutlineCombo)
        Me.GroupBox36.Controls.Add(Me.Label147)
        Me.GroupBox36.Controls.Add(Me.Label148)
        Me.GroupBox36.Controls.Add(Me.ShapeBackBUpDown)
        Me.GroupBox36.Controls.Add(Me.Label149)
        Me.GroupBox36.Controls.Add(Me.Label150)
        Me.GroupBox36.Controls.Add(Me.ShapeBackResin)
        Me.GroupBox36.Controls.Add(Me.ShapeBackRUpDown)
        Me.GroupBox36.Controls.Add(Me.ShapeBackTUpDown)
        Me.GroupBox36.Controls.Add(Me.Label151)
        Me.GroupBox36.Controls.Add(Me.ShapeBackLUpDown)
        Me.GroupBox36.Controls.Add(Me.Label152)
        Me.GroupBox36.Controls.Add(Me.ShapeBackCombo)
        Me.GroupBox36.Controls.Add(Me.Label153)
        Me.GroupBox36.Controls.Add(Me.Label154)
        Me.GroupBox36.Location = New System.Drawing.Point(3, 91)
        Me.GroupBox36.Name = "GroupBox36"
        Me.GroupBox36.Size = New System.Drawing.Size(437, 85)
        Me.GroupBox36.TabIndex = 89
        Me.GroupBox36.TabStop = False
        Me.GroupBox36.Text = "Shape"
        '
        'ShapeBackEnabled
        '
        Me.ShapeBackEnabled.AutoSize = True
        Me.ShapeBackEnabled.Enabled = False
        Me.ShapeBackEnabled.Location = New System.Drawing.Point(6, 14)
        Me.ShapeBackEnabled.Name = "ShapeBackEnabled"
        Me.ShapeBackEnabled.Size = New System.Drawing.Size(65, 17)
        Me.ShapeBackEnabled.TabIndex = 83
        Me.ShapeBackEnabled.Text = "Enabled"
        Me.ShapeBackEnabled.UseVisualStyleBackColor = True
        '
        'ShapeBackFillCombo
        '
        Me.ShapeBackFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackFillCombo.Enabled = False
        Me.ShapeBackFillCombo.Items.AddRange(New Object() {"Red", "Green", "Blue", "Cyan", "Magenta", "Yellow", "White", "Black", "Transparent"})
        Me.ShapeBackFillCombo.Location = New System.Drawing.Point(251, 60)
        Me.ShapeBackFillCombo.Name = "ShapeBackFillCombo"
        Me.ShapeBackFillCombo.Size = New System.Drawing.Size(127, 21)
        Me.ShapeBackFillCombo.TabIndex = 81
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Location = New System.Drawing.Point(232, 64)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(19, 13)
        Me.Label146.TabIndex = 80
        Me.Label146.Text = "Fill"
        '
        'ShapeBackWidthUpDown
        '
        Me.ShapeBackWidthUpDown.Enabled = False
        Me.ShapeBackWidthUpDown.Location = New System.Drawing.Point(176, 60)
        Me.ShapeBackWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ShapeBackWidthUpDown.Name = "ShapeBackWidthUpDown"
        Me.ShapeBackWidthUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeBackWidthUpDown.TabIndex = 81
        Me.ShapeBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeBackOutlineCombo
        '
        Me.ShapeBackOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackOutlineCombo.Enabled = False
        Me.ShapeBackOutlineCombo.Location = New System.Drawing.Point(52, 60)
        Me.ShapeBackOutlineCombo.Name = "ShapeBackOutlineCombo"
        Me.ShapeBackOutlineCombo.Size = New System.Drawing.Size(85, 21)
        Me.ShapeBackOutlineCombo.TabIndex = 81
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Location = New System.Drawing.Point(143, 64)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(35, 13)
        Me.Label147.TabIndex = 80
        Me.Label147.Text = "Width"
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Location = New System.Drawing.Point(6, 64)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(40, 13)
        Me.Label148.TabIndex = 80
        Me.Label148.Text = "Outline"
        '
        'ShapeBackBUpDown
        '
        Me.ShapeBackBUpDown.Enabled = False
        Me.ShapeBackBUpDown.Location = New System.Drawing.Point(378, 37)
        Me.ShapeBackBUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ShapeBackBUpDown.Name = "ShapeBackBUpDown"
        Me.ShapeBackBUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeBackBUpDown.TabIndex = 82
        Me.ShapeBackBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(364, 41)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(14, 13)
        Me.Label149.TabIndex = 81
        Me.Label149.Text = "B"
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Location = New System.Drawing.Point(304, 41)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(15, 13)
        Me.Label150.TabIndex = 80
        Me.Label150.Text = "R"
        '
        'ShapeBackResin
        '
        Me.ShapeBackResin.AutoSize = True
        Me.ShapeBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShapeBackResin.Enabled = False
        Me.ShapeBackResin.Location = New System.Drawing.Point(356, 14)
        Me.ShapeBackResin.Name = "ShapeBackResin"
        Me.ShapeBackResin.Size = New System.Drawing.Size(75, 17)
        Me.ShapeBackResin.TabIndex = 79
        Me.ShapeBackResin.Text = "Use Resin"
        Me.ShapeBackResin.UseVisualStyleBackColor = True
        '
        'ShapeBackRUpDown
        '
        Me.ShapeBackRUpDown.Enabled = False
        Me.ShapeBackRUpDown.Location = New System.Drawing.Point(319, 37)
        Me.ShapeBackRUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ShapeBackRUpDown.Name = "ShapeBackRUpDown"
        Me.ShapeBackRUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeBackRUpDown.TabIndex = 78
        Me.ShapeBackRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeBackTUpDown
        '
        Me.ShapeBackTUpDown.Enabled = False
        Me.ShapeBackTUpDown.Location = New System.Drawing.Point(259, 37)
        Me.ShapeBackTUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.ShapeBackTUpDown.Name = "ShapeBackTUpDown"
        Me.ShapeBackTUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeBackTUpDown.TabIndex = 76
        Me.ShapeBackTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(245, 41)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(14, 13)
        Me.Label151.TabIndex = 75
        Me.Label151.Text = "T"
        '
        'ShapeBackLUpDown
        '
        Me.ShapeBackLUpDown.Enabled = False
        Me.ShapeBackLUpDown.Location = New System.Drawing.Point(200, 37)
        Me.ShapeBackLUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.ShapeBackLUpDown.Name = "ShapeBackLUpDown"
        Me.ShapeBackLUpDown.Size = New System.Drawing.Size(45, 20)
        Me.ShapeBackLUpDown.TabIndex = 74
        Me.ShapeBackLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Location = New System.Drawing.Point(187, 41)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(13, 13)
        Me.Label152.TabIndex = 73
        Me.Label152.Text = "L"
        '
        'ShapeBackCombo
        '
        Me.ShapeBackCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackCombo.Enabled = False
        Me.ShapeBackCombo.Location = New System.Drawing.Point(52, 37)
        Me.ShapeBackCombo.Name = "ShapeBackCombo"
        Me.ShapeBackCombo.Size = New System.Drawing.Size(85, 21)
        Me.ShapeBackCombo.TabIndex = 34
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(140, 41)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(47, 13)
        Me.Label153.TabIndex = 33
        Me.Label153.Text = "Position:"
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Location = New System.Drawing.Point(6, 41)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(38, 13)
        Me.Label154.TabIndex = 32
        Me.Label154.Text = "Shape"
        '
        'GroupBox37
        '
        Me.GroupBox37.Controls.Add(Me.TextBackEnabled)
        Me.GroupBox37.Controls.Add(Me.TextBackResin)
        Me.GroupBox37.Controls.Add(Me.TextBackSizeUpDown)
        Me.GroupBox37.Controls.Add(Me.Label155)
        Me.GroupBox37.Controls.Add(Me.TextBackYUpDown)
        Me.GroupBox37.Controls.Add(Me.Label156)
        Me.GroupBox37.Controls.Add(Me.TextBackXUpDown)
        Me.GroupBox37.Controls.Add(Me.Label157)
        Me.GroupBox37.Controls.Add(Me.TextBackStrikethrough)
        Me.GroupBox37.Controls.Add(Me.TextBackItalic)
        Me.GroupBox37.Controls.Add(Me.TextBackUnderline)
        Me.GroupBox37.Controls.Add(Me.TextBackBold)
        Me.GroupBox37.Controls.Add(Me.TextBackColourCombo)
        Me.GroupBox37.Controls.Add(Me.Label158)
        Me.GroupBox37.Controls.Add(Me.Label159)
        Me.GroupBox37.Controls.Add(Me.Label160)
        Me.GroupBox37.Controls.Add(Me.TextBackBox)
        Me.GroupBox37.Location = New System.Drawing.Point(3, 0)
        Me.GroupBox37.Name = "GroupBox37"
        Me.GroupBox37.Size = New System.Drawing.Size(437, 85)
        Me.GroupBox37.TabIndex = 88
        Me.GroupBox37.TabStop = False
        Me.GroupBox37.Text = "Text"
        '
        'TextBackEnabled
        '
        Me.TextBackEnabled.AutoSize = True
        Me.TextBackEnabled.Enabled = False
        Me.TextBackEnabled.Location = New System.Drawing.Point(6, 14)
        Me.TextBackEnabled.Name = "TextBackEnabled"
        Me.TextBackEnabled.Size = New System.Drawing.Size(65, 17)
        Me.TextBackEnabled.TabIndex = 80
        Me.TextBackEnabled.Text = "Enabled"
        Me.TextBackEnabled.UseVisualStyleBackColor = True
        '
        'TextBackResin
        '
        Me.TextBackResin.AutoSize = True
        Me.TextBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackResin.Enabled = False
        Me.TextBackResin.Location = New System.Drawing.Point(356, 62)
        Me.TextBackResin.Name = "TextBackResin"
        Me.TextBackResin.Size = New System.Drawing.Size(75, 17)
        Me.TextBackResin.TabIndex = 79
        Me.TextBackResin.Text = "Use Resin"
        Me.TextBackResin.UseVisualStyleBackColor = True
        '
        'TextBackSizeUpDown
        '
        Me.TextBackSizeUpDown.Enabled = False
        Me.TextBackSizeUpDown.Location = New System.Drawing.Point(241, 60)
        Me.TextBackSizeUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.TextBackSizeUpDown.Name = "TextBackSizeUpDown"
        Me.TextBackSizeUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextBackSizeUpDown.TabIndex = 78
        Me.TextBackSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(214, 64)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(27, 13)
        Me.Label155.TabIndex = 77
        Me.Label155.Text = "Size"
        '
        'TextBackYUpDown
        '
        Me.TextBackYUpDown.Enabled = False
        Me.TextBackYUpDown.Location = New System.Drawing.Point(144, 60)
        Me.TextBackYUpDown.Maximum = New Decimal(New Integer() {664, 0, 0, 0})
        Me.TextBackYUpDown.Name = "TextBackYUpDown"
        Me.TextBackYUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextBackYUpDown.TabIndex = 76
        Me.TextBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Location = New System.Drawing.Point(124, 64)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(14, 13)
        Me.Label156.TabIndex = 75
        Me.Label156.Text = "Y"
        '
        'TextBackXUpDown
        '
        Me.TextBackXUpDown.Enabled = False
        Me.TextBackXUpDown.Location = New System.Drawing.Point(73, 60)
        Me.TextBackXUpDown.Maximum = New Decimal(New Integer() {1036, 0, 0, 0})
        Me.TextBackXUpDown.Name = "TextBackXUpDown"
        Me.TextBackXUpDown.Size = New System.Drawing.Size(45, 20)
        Me.TextBackXUpDown.TabIndex = 74
        Me.TextBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(53, 64)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(14, 13)
        Me.Label157.TabIndex = 73
        Me.Label157.Text = "X"
        '
        'TextBackStrikethrough
        '
        Me.TextBackStrikethrough.AutoSize = True
        Me.TextBackStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackStrikethrough.Enabled = False
        Me.TextBackStrikethrough.Location = New System.Drawing.Point(342, 39)
        Me.TextBackStrikethrough.Name = "TextBackStrikethrough"
        Me.TextBackStrikethrough.Size = New System.Drawing.Size(89, 17)
        Me.TextBackStrikethrough.TabIndex = 72
        Me.TextBackStrikethrough.Text = "Strikethrough"
        Me.TextBackStrikethrough.UseVisualStyleBackColor = True
        '
        'TextBackItalic
        '
        Me.TextBackItalic.AutoSize = True
        Me.TextBackItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackItalic.Enabled = False
        Me.TextBackItalic.Location = New System.Drawing.Point(282, 39)
        Me.TextBackItalic.Name = "TextBackItalic"
        Me.TextBackItalic.Size = New System.Drawing.Size(48, 17)
        Me.TextBackItalic.TabIndex = 71
        Me.TextBackItalic.Text = "Italic"
        Me.TextBackItalic.UseVisualStyleBackColor = True
        '
        'TextBackUnderline
        '
        Me.TextBackUnderline.AutoSize = True
        Me.TextBackUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackUnderline.Enabled = False
        Me.TextBackUnderline.Location = New System.Drawing.Point(201, 39)
        Me.TextBackUnderline.Name = "TextBackUnderline"
        Me.TextBackUnderline.Size = New System.Drawing.Size(71, 17)
        Me.TextBackUnderline.TabIndex = 70
        Me.TextBackUnderline.Text = "Underline"
        Me.TextBackUnderline.UseVisualStyleBackColor = True
        '
        'TextBackBold
        '
        Me.TextBackBold.AutoSize = True
        Me.TextBackBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackBold.Enabled = False
        Me.TextBackBold.Location = New System.Drawing.Point(144, 39)
        Me.TextBackBold.Name = "TextBackBold"
        Me.TextBackBold.Size = New System.Drawing.Size(47, 17)
        Me.TextBackBold.TabIndex = 69
        Me.TextBackBold.Text = "Bold"
        Me.TextBackBold.UseVisualStyleBackColor = True
        '
        'TextBackColourCombo
        '
        Me.TextBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TextBackColourCombo.Enabled = False
        Me.TextBackColourCombo.Location = New System.Drawing.Point(53, 37)
        Me.TextBackColourCombo.Name = "TextBackColourCombo"
        Me.TextBackColourCombo.Size = New System.Drawing.Size(85, 21)
        Me.TextBackColourCombo.TabIndex = 34
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(6, 64)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(47, 13)
        Me.Label158.TabIndex = 33
        Me.Label158.Text = "Position:"
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(6, 41)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(37, 13)
        Me.Label159.TabIndex = 32
        Me.Label159.Text = "Colour"
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Location = New System.Drawing.Point(110, 16)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(28, 13)
        Me.Label160.TabIndex = 31
        Me.Label160.Text = "Text"
        '
        'TextBackBox
        '
        Me.TextBackBox.Enabled = False
        Me.TextBackBox.Location = New System.Drawing.Point(144, 12)
        Me.TextBackBox.Name = "TextBackBox"
        Me.TextBackBox.Size = New System.Drawing.Size(287, 20)
        Me.TextBackBox.TabIndex = 14
        Me.TextBackBox.Text = "Back - First Line of VB Text"
        '
        'CardBack
        '
        Me.CardBack.AutoSize = True
        Me.CardBack.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CardBack.Location = New System.Drawing.Point(251, 11)
        Me.CardBack.Name = "CardBack"
        Me.CardBack.Size = New System.Drawing.Size(76, 17)
        Me.CardBack.TabIndex = 71
        Me.CardBack.Text = "Card Back"
        Me.CardBack.UseVisualStyleBackColor = True
        '
        'CardFront
        '
        Me.CardFront.AutoSize = True
        Me.CardFront.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CardFront.Checked = True
        Me.CardFront.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CardFront.Location = New System.Drawing.Point(143, 11)
        Me.CardFront.Name = "CardFront"
        Me.CardFront.Size = New System.Drawing.Size(75, 17)
        Me.CardFront.TabIndex = 70
        Me.CardFront.Text = "Card Front"
        Me.CardFront.UseVisualStyleBackColor = True
        '
        'PrintButton
        '
        Me.PrintButton.Location = New System.Drawing.Point(361, 528)
        Me.PrintButton.Name = "PrintButton"
        Me.PrintButton.Size = New System.Drawing.Size(90, 24)
        Me.PrintButton.TabIndex = 69
        Me.PrintButton.Text = "Print"
        Me.PrintButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(390, 598)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(74, 24)
        Me.ExitButton.TabIndex = 13
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'PrinterID
        '
        Me.PrinterID.AutoSize = True
        Me.PrinterID.Location = New System.Drawing.Point(9, 604)
        Me.PrinterID.Name = "PrinterID"
        Me.PrinterID.Size = New System.Drawing.Size(40, 13)
        Me.PrinterID.TabIndex = 15
        Me.PrinterID.Text = "Printer:"
        Me.PrinterID.Visible = False
        '
        'PrinterPrefs
        '
        Me.PrinterPrefs.Location = New System.Drawing.Point(7, 528)
        Me.PrinterPrefs.Name = "PrinterPrefs"
        Me.PrinterPrefs.Size = New System.Drawing.Size(108, 24)
        Me.PrinterPrefs.TabIndex = 38
        Me.PrinterPrefs.Text = "Printer Preferences"
        Me.PrinterPrefs.UseVisualStyleBackColor = True
        Me.PrinterPrefs.Visible = False
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 634)
        Me.Controls.Add(Me.PrinterID)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.TabControl)
        Me.Name = "Main"
        Me.Text = "Ultima SDK VB Demo (64)"
        Me.TabControl.ResumeLayout(False)
        Me.Printer.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.groupBox7.ResumeLayout(False)
        Me.groupBox7.PerformLayout()
        Me.Information.ResumeLayout(False)
        Me.GroupBox27.ResumeLayout(False)
        Me.GroupBox27.PerformLayout()
        Me.Encoding.ResumeLayout(False)
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox5.PerformLayout()
        CType(Me.MagStartPosition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox9.ResumeLayout(False)
        Me.groupBox9.PerformLayout()
        Me.groupBox8.ResumeLayout(False)
        Me.groupBox8.PerformLayout()
        Me.Driver1.ResumeLayout(False)
        Me.Driver1.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.ColourAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaNo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox11.ResumeLayout(False)
        Me.groupBox11.PerformLayout()
        CType(Me.ResinAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaNoUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox10.ResumeLayout(False)
        Me.groupBox10.PerformLayout()
        CType(Me.OvercoatPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YMCPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SharpnessUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Driver2.ResumeLayout(False)
        Me.Driver2.PerformLayout()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.groupBox16.ResumeLayout(False)
        Me.groupBox16.PerformLayout()
        CType(Me.HoloKoteImageUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        CType(Me.ColourAdjust_WhiteRef, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_BlackRef, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Blue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Green, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Red, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Tint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Colour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Brightness, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Contrast, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox15.ResumeLayout(False)
        Me.groupBox15.PerformLayout()
        Me.groupBox14.ResumeLayout(False)
        Me.groupBox14.PerformLayout()
        CType(Me.CopyCountUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PrintDemo.ResumeLayout(False)
        Me.PrintDemo.PerformLayout()
        Me.CardSide.ResumeLayout(False)
        Me.Front.ResumeLayout(False)
        Me.GroupBox29.ResumeLayout(False)
        Me.GroupBox29.PerformLayout()
        Me.GroupBox30.ResumeLayout(False)
        Me.GroupBox30.PerformLayout()
        CType(Me.ImageFrontP2UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontP1UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox31.ResumeLayout(False)
        Me.GroupBox31.PerformLayout()
        CType(Me.LineFrontWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontStartYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontEndYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontEndXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontStartXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox32.ResumeLayout(False)
        Me.GroupBox32.PerformLayout()
        CType(Me.ShapeFrontWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontBUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontRUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontTUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontLUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox33.ResumeLayout(False)
        Me.groupBox33.PerformLayout()
        CType(Me.TextFrontSizeUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextFrontYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextFrontXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Back.ResumeLayout(False)
        Me.GroupBox34.ResumeLayout(False)
        Me.GroupBox34.PerformLayout()
        CType(Me.ImageBackP2UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackP1UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox35.ResumeLayout(False)
        Me.GroupBox35.PerformLayout()
        CType(Me.LineBackWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackStartYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackEndYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackEndXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackStartXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox36.ResumeLayout(False)
        Me.GroupBox36.PerformLayout()
        CType(Me.ShapeBackWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackBUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackRUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackTUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackLUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox37.ResumeLayout(False)
        Me.GroupBox37.PerformLayout()
        CType(Me.TextBackSizeUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBackYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBackXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl As System.Windows.Forms.TabControl
    Friend WithEvents Printer As System.Windows.Forms.TabPage
    Friend WithEvents Information As System.Windows.Forms.TabPage
    Friend WithEvents Encoding As System.Windows.Forms.TabPage
    Private WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Private WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents OpenSessionButton As System.Windows.Forms.Button
    Private WithEvents CloseSessionButton As System.Windows.Forms.Button
    Private WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents EjectModeButton As System.Windows.Forms.Button
    Private WithEvents EjectModeCombo As System.Windows.Forms.ComboBox
    Private WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents RestartButton As System.Windows.Forms.Button
    Private WithEvents CleanPrinterButton As System.Windows.Forms.Button
    Private WithEvents PrintTestCardButton As System.Windows.Forms.Button
    Private WithEvents PrinterStatusButton As System.Windows.Forms.Button
    Private WithEvents InfoMsgBox As System.Windows.Forms.TextBox
    Private WithEvents ReadMagButton As System.Windows.Forms.Button
    Private WithEvents EncodeMagButton As System.Windows.Forms.Button
    Private WithEvents EncodingBox As System.Windows.Forms.TextBox
    'Friend WithEvents pd As System.Windows.Forms.PrintDialog
    Private WithEvents ClearMsgBoxButton As System.Windows.Forms.Button
    Private WithEvents ClearEncodingBoxButton As System.Windows.Forms.Button
    Private WithEvents Track2Data As System.Windows.Forms.TextBox
    Private WithEvents ErrorResponseButton As System.Windows.Forms.Button
    Private WithEvents ErrorResponseCombo As System.Windows.Forms.ComboBox
    Private WithEvents MoveCardCombo As System.Windows.Forms.ComboBox
    Private WithEvents SDKVersionButton As System.Windows.Forms.Button
    Friend WithEvents Driver1 As System.Windows.Forms.TabPage
    Friend WithEvents Driver2 As System.Windows.Forms.TabPage
    Private WithEvents PrinterMsgBox As System.Windows.Forms.TextBox
    Private WithEvents groupBox7 As System.Windows.Forms.GroupBox
    Private WithEvents IPGatewayLabel As System.Windows.Forms.Label
    Private WithEvents IPSubnetLabel As System.Windows.Forms.Label
    Private WithEvents IPAddrLabel As System.Windows.Forms.Label
    Private WithEvents IPGatewayBox As System.Windows.Forms.TextBox
    Private WithEvents IPSubnetBox As System.Windows.Forms.TextBox
    Private WithEvents IPAddressBox As System.Windows.Forms.TextBox
    Private WithEvents IPSettingsButton As System.Windows.Forms.Button
    Private WithEvents IPModeLabel As System.Windows.Forms.Label
    Private WithEvents IPModeCombo As System.Windows.Forms.ComboBox
    Private WithEvents ClearPrinterMsgButton As System.Windows.Forms.Button
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents PrinterSetRadio As System.Windows.Forms.RadioButton
    Private WithEvents PrinterGetRadio As System.Windows.Forms.RadioButton
    Private WithEvents ConnectionTypeButton As System.Windows.Forms.Button
    Private WithEvents ExitButton As System.Windows.Forms.Button
    Private WithEvents groupBox9 As System.Windows.Forms.GroupBox
    Private WithEvents label112 As System.Windows.Forms.Label
    Private WithEvents BitsPerInchLabel As System.Windows.Forms.Label
    Private WithEvents BitsPerCharLabel As System.Windows.Forms.Label
    Private WithEvents Track3SettingsLabel As System.Windows.Forms.Label
    Private WithEvents Track2SettingsLabel As System.Windows.Forms.Label
    Private WithEvents Track1SettingsLabel As System.Windows.Forms.Label
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents Track3Label As System.Windows.Forms.Label
    Private WithEvents Track2Label As System.Windows.Forms.Label
    Private WithEvents Track1Data As System.Windows.Forms.TextBox
    Private WithEvents Track3Data As System.Windows.Forms.TextBox
    Private WithEvents Track1 As System.Windows.Forms.CheckBox
    Private WithEvents Track2 As System.Windows.Forms.CheckBox
    Private WithEvents Track3 As System.Windows.Forms.CheckBox
    Private WithEvents EncodingTypeCombo As System.Windows.Forms.ComboBox
    Private WithEvents CoercivityCombo As System.Windows.Forms.ComboBox
    Private WithEvents Verify As System.Windows.Forms.CheckBox
    Private WithEvents T1_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T1_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents Track1Label As System.Windows.Forms.Label
    Private WithEvents groupBox8 As System.Windows.Forms.GroupBox
    Private WithEvents groupBox11 As System.Windows.Forms.GroupBox
    Private WithEvents label26 As System.Windows.Forms.Label
    Private WithEvents ResinAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaNoUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label25 As System.Windows.Forms.Label
    Private WithEvents ResinAreaSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label24 As System.Windows.Forms.Label
    Private WithEvents ResinAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label21 As System.Windows.Forms.Label
    Private WithEvents label22 As System.Windows.Forms.Label
    Private WithEvents label23 As System.Windows.Forms.Label
    Private WithEvents ResinAreaButton As System.Windows.Forms.Button
    Private WithEvents groupBox10 As System.Windows.Forms.GroupBox
    Private WithEvents OvercoatPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents YMCPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label20 As System.Windows.Forms.Label
    Private WithEvents label19 As System.Windows.Forms.Label
    Private WithEvents label18 As System.Windows.Forms.Label
    Private WithEvents PowerLevelButton As System.Windows.Forms.Button
    Private WithEvents ColourCorrectionButton As System.Windows.Forms.Button
    Private WithEvents CorrectionCombo As System.Windows.Forms.ComboBox
    Private WithEvents SharpnessUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents GUIControlButton As System.Windows.Forms.Button
    Private WithEvents SharpnessButton As System.Windows.Forms.Button
    Private WithEvents label16 As System.Windows.Forms.Label
    Private WithEvents Driver1SetRadio As System.Windows.Forms.RadioButton
    Private WithEvents Driver1GetRadio As System.Windows.Forms.RadioButton
    Private WithEvents ClearDriver1MsgBoxButton As System.Windows.Forms.Button
    Private WithEvents Driver1MsgBox As System.Windows.Forms.TextBox
    Private WithEvents groupBox16 As System.Windows.Forms.GroupBox
    Private WithEvents HoloKoteImageUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label52 As System.Windows.Forms.Label
    Private WithEvents HoloKoteSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label49 As System.Windows.Forms.Label
    Private WithEvents HoloKoteRotationCombo As System.Windows.Forms.ComboBox
    Private WithEvents label50 As System.Windows.Forms.Label
    Private WithEvents HoloKoteButton As System.Windows.Forms.Button
    Private WithEvents groupBox15 As System.Windows.Forms.GroupBox
    Private WithEvents Rotate As System.Windows.Forms.CheckBox
    Private WithEvents Overcoat As System.Windows.Forms.CheckBox
    Private WithEvents CardSettingsSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label47 As System.Windows.Forms.Label
    Private WithEvents OrientationCombo As System.Windows.Forms.ComboBox
    Private WithEvents label44 As System.Windows.Forms.Label
    Private WithEvents ColourFormatCombo As System.Windows.Forms.ComboBox
    Private WithEvents label48 As System.Windows.Forms.Label
    Private WithEvents CardSettingsButton As System.Windows.Forms.Button
    Private WithEvents groupBox14 As System.Windows.Forms.GroupBox
    Private WithEvents CardSizeCombo As System.Windows.Forms.ComboBox
    Private WithEvents label43 As System.Windows.Forms.Label
    Private WithEvents CopyCountUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label45 As System.Windows.Forms.Label
    Private WithEvents DuplexCombo As System.Windows.Forms.ComboBox
    Private WithEvents label46 As System.Windows.Forms.Label
    Private WithEvents PrintSettingsButton As System.Windows.Forms.Button
    Private WithEvents ClearDriver2MsgBoxButton As System.Windows.Forms.Button
    Private WithEvents Driver2MsgBox As System.Windows.Forms.TextBox
    Private WithEvents label17 As System.Windows.Forms.Label
    Private WithEvents Driver2SetRadio As System.Windows.Forms.RadioButton
    Private WithEvents Driver2GetRadio As System.Windows.Forms.RadioButton
    Private WithEvents JIS2Label As System.Windows.Forms.Label
    Private WithEvents GUIPrinterCheck As System.Windows.Forms.CheckBox
    Private WithEvents GUIUserCheck As System.Windows.Forms.CheckBox
    Private WithEvents SessionConfigCombo As System.Windows.Forms.ComboBox
    Private WithEvents PrinterModelButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox27 As System.Windows.Forms.GroupBox
    Friend WithEvents PrintDemo As System.Windows.Forms.TabPage
    Private WithEvents CardSide As System.Windows.Forms.TabControl
    Private WithEvents Front As System.Windows.Forms.TabPage
    Private WithEvents GroupBox29 As System.Windows.Forms.GroupBox
    Private WithEvents Track3MagData As System.Windows.Forms.TextBox
    Private WithEvents Track2MagData As System.Windows.Forms.TextBox
    Private WithEvents Track1MagData As System.Windows.Forms.TextBox
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents MagDataEnabled As System.Windows.Forms.CheckBox
    Private WithEvents GroupBox30 As System.Windows.Forms.GroupBox
    Private WithEvents ImageFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents ImageFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ImageFrontButton As System.Windows.Forms.Button
    Private WithEvents ImageFrontFileBox As System.Windows.Forms.TextBox
    Private WithEvents ImageFrontP2UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents ImageFrontP1UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ImageFrontYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label14 As System.Windows.Forms.Label
    Private WithEvents ImageFrontXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label106 As System.Windows.Forms.Label
    Private WithEvents Label107 As System.Windows.Forms.Label
    Private WithEvents GroupBox31 As System.Windows.Forms.GroupBox
    Private WithEvents LineFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents Label108 As System.Windows.Forms.Label
    Private WithEvents LineFrontWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label109 As System.Windows.Forms.Label
    Private WithEvents LineFrontStartYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineFrontEndYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label110 As System.Windows.Forms.Label
    Private WithEvents Label111 As System.Windows.Forms.Label
    Private WithEvents Label113 As System.Windows.Forms.Label
    Private WithEvents Label114 As System.Windows.Forms.Label
    Private WithEvents LineFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents LineFrontEndXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineFrontColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents LineFrontStartXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label115 As System.Windows.Forms.Label
    Private WithEvents Label116 As System.Windows.Forms.Label
    Private WithEvents GroupBox32 As System.Windows.Forms.GroupBox
    Private WithEvents ShapeFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ShapeFrontFillCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label117 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeFrontOutlineCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label118 As System.Windows.Forms.Label
    Private WithEvents Label119 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontBUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label120 As System.Windows.Forms.Label
    Private WithEvents Label121 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents ShapeFrontRUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeFrontTUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label122 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontLUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label123 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label124 As System.Windows.Forms.Label
    Private WithEvents Label125 As System.Windows.Forms.Label
    Private WithEvents groupBox33 As System.Windows.Forms.GroupBox
    Private WithEvents TextFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontSizeUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label126 As System.Windows.Forms.Label
    Private WithEvents TextFrontYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label127 As System.Windows.Forms.Label
    Private WithEvents TextFrontXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label128 As System.Windows.Forms.Label
    Private WithEvents TextFrontStrikethrough As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontItalic As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontUnderline As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontBold As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label129 As System.Windows.Forms.Label
    Private WithEvents Label130 As System.Windows.Forms.Label
    Private WithEvents Label131 As System.Windows.Forms.Label
    Private WithEvents TextFrontBox As System.Windows.Forms.TextBox
    Private WithEvents Back As System.Windows.Forms.TabPage
    Private WithEvents GroupBox34 As System.Windows.Forms.GroupBox
    Private WithEvents ImageBackResin As System.Windows.Forms.CheckBox
    Private WithEvents ImageBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ImageBackFileBox As System.Windows.Forms.TextBox
    Private WithEvents ImageBackP2UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label132 As System.Windows.Forms.Label
    Private WithEvents Label133 As System.Windows.Forms.Label
    Private WithEvents ImageBackP1UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ImageBackYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label134 As System.Windows.Forms.Label
    Private WithEvents ImageBackXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label135 As System.Windows.Forms.Label
    Private WithEvents Label136 As System.Windows.Forms.Label
    Private WithEvents Label137 As System.Windows.Forms.Label
    Private WithEvents GroupBox35 As System.Windows.Forms.GroupBox
    Private WithEvents LineBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents Label138 As System.Windows.Forms.Label
    Private WithEvents LineBackWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label139 As System.Windows.Forms.Label
    Private WithEvents LineBackStartYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineBackEndYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label140 As System.Windows.Forms.Label
    Private WithEvents Label141 As System.Windows.Forms.Label
    Private WithEvents Label142 As System.Windows.Forms.Label
    Private WithEvents Label143 As System.Windows.Forms.Label
    Private WithEvents LineBackResin As System.Windows.Forms.CheckBox
    Private WithEvents LineBackEndXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineBackColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents LineBackStartXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label144 As System.Windows.Forms.Label
    Private WithEvents Label145 As System.Windows.Forms.Label
    Private WithEvents GroupBox36 As System.Windows.Forms.GroupBox
    Private WithEvents ShapeBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ShapeBackFillCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label146 As System.Windows.Forms.Label
    Private WithEvents ShapeBackWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeBackOutlineCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label147 As System.Windows.Forms.Label
    Private WithEvents Label148 As System.Windows.Forms.Label
    Private WithEvents ShapeBackBUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label149 As System.Windows.Forms.Label
    Private WithEvents Label150 As System.Windows.Forms.Label
    Private WithEvents ShapeBackResin As System.Windows.Forms.CheckBox
    Private WithEvents ShapeBackRUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeBackTUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label151 As System.Windows.Forms.Label
    Private WithEvents ShapeBackLUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label152 As System.Windows.Forms.Label
    Private WithEvents ShapeBackCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label153 As System.Windows.Forms.Label
    Private WithEvents Label154 As System.Windows.Forms.Label
    Private WithEvents GroupBox37 As System.Windows.Forms.GroupBox
    Private WithEvents TextBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents TextBackResin As System.Windows.Forms.CheckBox
    Private WithEvents TextBackSizeUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label155 As System.Windows.Forms.Label
    Private WithEvents TextBackYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label156 As System.Windows.Forms.Label
    Private WithEvents TextBackXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label157 As System.Windows.Forms.Label
    Private WithEvents TextBackStrikethrough As System.Windows.Forms.CheckBox
    Private WithEvents TextBackItalic As System.Windows.Forms.CheckBox
    Private WithEvents TextBackUnderline As System.Windows.Forms.CheckBox
    Private WithEvents TextBackBold As System.Windows.Forms.CheckBox
    Private WithEvents TextBackColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label158 As System.Windows.Forms.Label
    Private WithEvents Label159 As System.Windows.Forms.Label
    Private WithEvents Label160 As System.Windows.Forms.Label
    Private WithEvents TextBackBox As System.Windows.Forms.TextBox
    Private WithEvents CardBack As System.Windows.Forms.CheckBox
    Private WithEvents CardFront As System.Windows.Forms.CheckBox
    Private WithEvents PrintButton As System.Windows.Forms.Button
    Private WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Private WithEvents ColourAdjust_WhiteRef As System.Windows.Forms.NumericUpDown
    Private WithEvents Label58 As System.Windows.Forms.Label
    Private WithEvents Label59 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_BlackRef As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Illuminant As System.Windows.Forms.ComboBox
    Private WithEvents Label60 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_Negative As System.Windows.Forms.CheckBox
    Private WithEvents ColourAdjust_DarkPic As System.Windows.Forms.CheckBox
    Private WithEvents ColourAdjust_Blue As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Green As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Red As System.Windows.Forms.NumericUpDown
    Private WithEvents Label61 As System.Windows.Forms.Label
    Private WithEvents Label62 As System.Windows.Forms.Label
    Private WithEvents Label63 As System.Windows.Forms.Label
    Private WithEvents Label64 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_Tint As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Colour As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Brightness As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Contrast As System.Windows.Forms.NumericUpDown
    Private WithEvents Label65 As System.Windows.Forms.Label
    Private WithEvents Label66 As System.Windows.Forms.Label
    Private WithEvents Label67 As System.Windows.Forms.Label
    Private WithEvents ColourAdjustBtn As System.Windows.Forms.Button
    Private WithEvents groupBox5 As System.Windows.Forms.GroupBox
    Private WithEvents MagStartPosition As System.Windows.Forms.NumericUpDown
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents EncodingSetRadio As System.Windows.Forms.RadioButton
    Private WithEvents EncodingGetRadio As System.Windows.Forms.RadioButton
    Private WithEvents MagStartButton As System.Windows.Forms.Button
    Private WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents ColourAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents ColourAreaNo As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents ColourAreaCorrectionCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label27 As System.Windows.Forms.Label
    Private WithEvents ColourAreaButton As System.Windows.Forms.Button
    Private WithEvents MoveCardButton As System.Windows.Forms.Button
    Private WithEvents Track3Read As System.Windows.Forms.CheckBox
    Private WithEvents Track2Read As System.Windows.Forms.CheckBox
    Private WithEvents Track1Read As System.Windows.Forms.CheckBox
    Private WithEvents ReadMagTracks As System.Windows.Forms.Button
    Private WithEvents TemperatureButton As System.Windows.Forms.Button
    Private WithEvents PrinterInfoButton As System.Windows.Forms.Button
    Private WithEvents LastMessageButton As System.Windows.Forms.Button
    Private WithEvents SDKBitsButton As System.Windows.Forms.Button
    Private WithEvents PrinterID As System.Windows.Forms.Label
    Private WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Private WithEvents HoloKoteIDSlot As System.Windows.Forms.ComboBox
    Private WithEvents Label28 As System.Windows.Forms.Label
    Private WithEvents HoloKoteIDButton As System.Windows.Forms.Button
    Private WithEvents HoloKotePreviewButton As System.Windows.Forms.Button
    Private WithEvents PrinterPrefs As System.Windows.Forms.Button
    Private WithEvents PrinterTypeButton As System.Windows.Forms.Button
    Private WithEvents nativePrint As System.Windows.Forms.CheckBox

End Class

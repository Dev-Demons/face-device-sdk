Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

#If x86 Then
<Assembly: AssemblyTitle("Ultima SDK VB Demo (32 bit)")> 
#Else
<Assembly: AssemblyTitle("Ultima SDK VB Demo (64 bit)")> 
#End If
<Assembly: AssemblyDescription("Ultima VB Demo for Magicard SDK")> 
<Assembly: AssemblyCompany("Magicard Ltd.")> 
<Assembly: AssemblyProduct("Ultima SDK VB Demo")> 
<Assembly: AssemblyCopyright("Copyright ©2022 Magicard Ltd.")> 

<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c9c442f8-4492-48bc-ba1a-2adb9cd28ccd")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.5.1")> 
<Assembly: AssemblyFileVersion("1.0.5.1")> 

<Assembly: NeutralResourcesLanguageAttribute("en-GB")> 
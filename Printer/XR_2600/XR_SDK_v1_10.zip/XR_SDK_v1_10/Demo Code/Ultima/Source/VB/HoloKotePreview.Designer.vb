﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HKPreview
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pictureBox = New System.Windows.Forms.PictureBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.slotNumber = New System.Windows.Forms.NumericUpDown()
        CType(Me.pictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.slotNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pictureBox
        '
        Me.pictureBox.Location = New System.Drawing.Point(7, 0)
        Me.pictureBox.Name = "pictureBox"
        Me.pictureBox.Size = New System.Drawing.Size(259, 166)
        Me.pictureBox.TabIndex = 5
        Me.pictureBox.TabStop = False
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(6, 176)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(45, 13)
        Me.label1.TabIndex = 6
        Me.label1.Text = "Slot No."
        '
        'slotNumber
        '
        Me.slotNumber.Location = New System.Drawing.Point(57, 172)
        Me.slotNumber.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.slotNumber.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.slotNumber.Name = "slotNumber"
        Me.slotNumber.Size = New System.Drawing.Size(48, 20)
        Me.slotNumber.TabIndex = 37
        Me.slotNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.slotNumber.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'HKPreview
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(272, 203)
        Me.Controls.Add(Me.slotNumber)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.pictureBox)
        Me.Name = "HKPreview"
        Me.Text = "HoloKote Preview"
        CType(Me.pictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.slotNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents pictureBox As System.Windows.Forms.PictureBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents slotNumber As System.Windows.Forms.NumericUpDown
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ImageBackButton As System.Windows.Forms.Button
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.Printer = New System.Windows.Forms.TabPage()
        Me.GenCmdGroupBox = New System.Windows.Forms.GroupBox()
        Me.GenCommandButton = New System.Windows.Forms.Button()
        Me.GenCommandBox = New System.Windows.Forms.TextBox()
        Me.groupBox5 = New System.Windows.Forms.GroupBox()
        Me.EraseCount = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.EraseArea_TopRYBox = New System.Windows.Forms.NumericUpDown()
        Me.EraseArea_TopRXBox = New System.Windows.Forms.NumericUpDown()
        Me.EraseArea_BotLYBox = New System.Windows.Forms.NumericUpDown()
        Me.EraseArea_BotLXBox = New System.Windows.Forms.NumericUpDown()
        Me.label4 = New System.Windows.Forms.Label()
        Me.EraseCardButton = New System.Windows.Forms.Button()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MoveFilmButton = New System.Windows.Forms.Button()
        Me.FeedMoveButton = New System.Windows.Forms.Button()
        Me.MoveFilmCombo = New System.Windows.Forms.ComboBox()
        Me.CardLocationButton = New System.Windows.Forms.Button()
        Me.FeedMoveCombo = New System.Windows.Forms.ComboBox()
        Me.RestartButton = New System.Windows.Forms.Button()
        Me.EjectCardButton = New System.Windows.Forms.Button()
        Me.FlipCardButton = New System.Windows.Forms.Button()
        Me.CleanPrinterButton = New System.Windows.Forms.Button()
        Me.PrintTestCardButton = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SessionConfigCombo = New System.Windows.Forms.ComboBox()
        Me.OpenSessionButton = New System.Windows.Forms.Button()
        Me.CloseSessionButton = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ErrorResponseCombo = New System.Windows.Forms.ComboBox()
        Me.ErrorResponseButton = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.IPGroupBox = New System.Windows.Forms.GroupBox()
        Me.IPGatewayLabel = New System.Windows.Forms.Label()
        Me.IPSubnetLabel = New System.Windows.Forms.Label()
        Me.IPAddressLabel = New System.Windows.Forms.Label()
        Me.IPGatewayBox = New System.Windows.Forms.TextBox()
        Me.IPSubnetBox = New System.Windows.Forms.TextBox()
        Me.IPAddressBox = New System.Windows.Forms.TextBox()
        Me.IPSettingsButton = New System.Windows.Forms.Button()
        Me.IPModeLabel = New System.Windows.Forms.Label()
        Me.IPModeCombo = New System.Windows.Forms.ComboBox()
        Me.ClearPrinterMsgButton = New System.Windows.Forms.Button()
        Me.label7 = New System.Windows.Forms.Label()
        Me.PrinterSetRadio = New System.Windows.Forms.RadioButton()
        Me.PrinterGetRadio = New System.Windows.Forms.RadioButton()
        Me.HandFeedCombo = New System.Windows.Forms.ComboBox()
        Me.HorzEjectCombo = New System.Windows.Forms.ComboBox()
        Me.HorzEjectButton = New System.Windows.Forms.Button()
        Me.HandFeedButton = New System.Windows.Forms.Button()
        Me.SmartOffsetButton = New System.Windows.Forms.Button()
        Me.SmartModeCombo = New System.Windows.Forms.ComboBox()
        Me.EjectModeCombo = New System.Windows.Forms.ComboBox()
        Me.EjectModeButton = New System.Windows.Forms.Button()
        Me.EraseSpeedCombo = New System.Windows.Forms.ComboBox()
        Me.EraseSpeedButton = New System.Windows.Forms.Button()
        Me.SmartModeButton = New System.Windows.Forms.Button()
        Me.SmartOffsetBox = New System.Windows.Forms.NumericUpDown()
        Me.PrinterMsgBox = New System.Windows.Forms.TextBox()
        Me.Information = New System.Windows.Forms.TabPage()
        Me.groupBox28 = New System.Windows.Forms.GroupBox()
        Me.Pwd2Label = New System.Windows.Forms.Label()
        Me.Pwd1Label = New System.Windows.Forms.Label()
        Me.PasswordButton = New System.Windows.Forms.Button()
        Me.Password2 = New System.Windows.Forms.TextBox()
        Me.Password1 = New System.Windows.Forms.TextBox()
        Me.PasswordCommand = New System.Windows.Forms.ComboBox()
        Me.ClearMsgBoxButton = New System.Windows.Forms.Button()
        Me.GroupBox27 = New System.Windows.Forms.GroupBox()
        Me.SensorsButton = New System.Windows.Forms.Button()
        Me.PrinterTypeButton = New System.Windows.Forms.Button()
        Me.Generation2GroupBox = New System.Windows.Forms.GroupBox()
        Me.AllParamsButton = New System.Windows.Forms.Button()
        Me.ReadParamButton = New System.Windows.Forms.Button()
        Me.ParamCombo = New System.Windows.Forms.ComboBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.SDKBitsButton = New System.Windows.Forms.Button()
        Me.PrinterModelButton = New System.Windows.Forms.Button()
        Me.PrinterInfoButton = New System.Windows.Forms.Button()
        Me.InfoMsgBox = New System.Windows.Forms.TextBox()
        Me.ConnectionTypeButton = New System.Windows.Forms.Button()
        Me.LastMessageButton = New System.Windows.Forms.Button()
        Me.PrinterStatusButton = New System.Windows.Forms.Button()
        Me.SDKVersionButton = New System.Windows.Forms.Button()
        Me.Encoding = New System.Windows.Forms.TabPage()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.MagStartButton = New System.Windows.Forms.Button()
        Me.MagStartPosition = New System.Windows.Forms.NumericUpDown()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.EncodingSetRadio = New System.Windows.Forms.RadioButton()
        Me.EncodingGetRadio = New System.Windows.Forms.RadioButton()
        Me.groupBox9 = New System.Windows.Forms.GroupBox()
        Me.JIS2Label = New System.Windows.Forms.Label()
        Me.label112 = New System.Windows.Forms.Label()
        Me.LRCLabel = New System.Windows.Forms.Label()
        Me.Track2Data = New System.Windows.Forms.TextBox()
        Me.ParityLabel = New System.Windows.Forms.Label()
        Me.BitsPerInchLabel = New System.Windows.Forms.Label()
        Me.EncodeMagButton = New System.Windows.Forms.Button()
        Me.BitsPerCharLabel = New System.Windows.Forms.Label()
        Me.Track3SettingsLabel = New System.Windows.Forms.Label()
        Me.Track2SettingsLabel = New System.Windows.Forms.Label()
        Me.Track1SettingsLabel = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.Track3Label = New System.Windows.Forms.Label()
        Me.Track2Label = New System.Windows.Forms.Label()
        Me.Track1Data = New System.Windows.Forms.TextBox()
        Me.Track3Data = New System.Windows.Forms.TextBox()
        Me.Track1 = New System.Windows.Forms.CheckBox()
        Me.Track2 = New System.Windows.Forms.CheckBox()
        Me.Track3 = New System.Windows.Forms.CheckBox()
        Me.EncodingTypeCombo = New System.Windows.Forms.ComboBox()
        Me.CoercivityCombo = New System.Windows.Forms.ComboBox()
        Me.Verify = New System.Windows.Forms.CheckBox()
        Me.T1_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T1_BPICombo = New System.Windows.Forms.ComboBox()
        Me.T1_ParityCombo = New System.Windows.Forms.ComboBox()
        Me.T1_LRCCombo = New System.Windows.Forms.ComboBox()
        Me.T2_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T2_BPICombo = New System.Windows.Forms.ComboBox()
        Me.T2_ParityCombo = New System.Windows.Forms.ComboBox()
        Me.T2_LRCCombo = New System.Windows.Forms.ComboBox()
        Me.T3_BPCCombo = New System.Windows.Forms.ComboBox()
        Me.T3_BPICombo = New System.Windows.Forms.ComboBox()
        Me.T3_ParityCombo = New System.Windows.Forms.ComboBox()
        Me.T3_LRCCombo = New System.Windows.Forms.ComboBox()
        Me.Track1Label = New System.Windows.Forms.Label()
        Me.groupBox8 = New System.Windows.Forms.GroupBox()
        Me.ReadMagTracks = New System.Windows.Forms.Button()
        Me.Track2Read = New System.Windows.Forms.CheckBox()
        Me.Track3Read = New System.Windows.Forms.CheckBox()
        Me.Track1Read = New System.Windows.Forms.CheckBox()
        Me.ReadMagButton = New System.Windows.Forms.Button()
        Me.ClearEncodingBoxButton = New System.Windows.Forms.Button()
        Me.EncodingBox = New System.Windows.Forms.TextBox()
        Me.Driver1 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Radio600DPI = New System.Windows.Forms.RadioButton()
        Me.ResolutionButton = New System.Windows.Forms.Button()
        Me.Radio300DPI = New System.Windows.Forms.RadioButton()
        Me.groupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PrintableAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.PrintableAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.PrintableAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.PrintableAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.PrintableAreaButton = New System.Windows.Forms.Button()
        Me.GUIPrinterCheck = New System.Windows.Forms.CheckBox()
        Me.GUIUserCheck = New System.Windows.Forms.CheckBox()
        Me.groupBox13 = New System.Windows.Forms.GroupBox()
        Me.EraseBeforePrint = New System.Windows.Forms.CheckBox()
        Me.EraseEndPowerLabel = New System.Windows.Forms.Label()
        Me.ErasePowerEndUpDown = New System.Windows.Forms.NumericUpDown()
        Me.WritePowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.WritePowerLabel = New System.Windows.Forms.Label()
        Me.label40 = New System.Windows.Forms.Label()
        Me.label34 = New System.Windows.Forms.Label()
        Me.label35 = New System.Windows.Forms.Label()
        Me.EraseAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ErasePowerStartUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label36 = New System.Windows.Forms.Label()
        Me.label37 = New System.Windows.Forms.Label()
        Me.EraseAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.EraseAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.EraseAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label38 = New System.Windows.Forms.Label()
        Me.label39 = New System.Windows.Forms.Label()
        Me.RewritableButton = New System.Windows.Forms.Button()
        Me.groupBox12 = New System.Windows.Forms.GroupBox()
        Me.AreaHoleTypeCombo = New System.Windows.Forms.ComboBox()
        Me.label33 = New System.Windows.Forms.Label()
        Me.label27 = New System.Windows.Forms.Label()
        Me.AreaHoleHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.AreaHoleNoUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label28 = New System.Windows.Forms.Label()
        Me.AreaHoleSideCombo = New System.Windows.Forms.ComboBox()
        Me.label29 = New System.Windows.Forms.Label()
        Me.AreaHoleBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.AreaHoleWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.AreaHoleLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label30 = New System.Windows.Forms.Label()
        Me.label31 = New System.Windows.Forms.Label()
        Me.label32 = New System.Windows.Forms.Label()
        Me.AreaHoleButton = New System.Windows.Forms.Button()
        Me.groupBox11 = New System.Windows.Forms.GroupBox()
        Me.label26 = New System.Windows.Forms.Label()
        Me.ResinAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaNoUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label25 = New System.Windows.Forms.Label()
        Me.ResinAreaSideCombo = New System.Windows.Forms.ComboBox()
        Me.label24 = New System.Windows.Forms.Label()
        Me.ResinAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label21 = New System.Windows.Forms.Label()
        Me.label22 = New System.Windows.Forms.Label()
        Me.label23 = New System.Windows.Forms.Label()
        Me.ResinAreaButton = New System.Windows.Forms.Button()
        Me.groupBox10 = New System.Windows.Forms.GroupBox()
        Me.OvercoatPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ResinPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.YMCPowerUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label20 = New System.Windows.Forms.Label()
        Me.label19 = New System.Windows.Forms.Label()
        Me.label18 = New System.Windows.Forms.Label()
        Me.PowerLevelButton = New System.Windows.Forms.Button()
        Me.PrintSpeedButton = New System.Windows.Forms.Button()
        Me.PrintSpeedCombo = New System.Windows.Forms.ComboBox()
        Me.ColourCorrectionButton = New System.Windows.Forms.Button()
        Me.CorrectionCombo = New System.Windows.Forms.ComboBox()
        Me.SharpnessUpDown = New System.Windows.Forms.NumericUpDown()
        Me.GUIControlButton = New System.Windows.Forms.Button()
        Me.SharpnessButton = New System.Windows.Forms.Button()
        Me.label16 = New System.Windows.Forms.Label()
        Me.Driver1SetRadio = New System.Windows.Forms.RadioButton()
        Me.Driver1GetRadio = New System.Windows.Forms.RadioButton()
        Me.ClearDriver1MsgBoxButton = New System.Windows.Forms.Button()
        Me.Driver1MsgBox = New System.Windows.Forms.TextBox()
        Me.Driver2 = New System.Windows.Forms.TabPage()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.ColourAdjust_WhiteRef = New System.Windows.Forms.NumericUpDown()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.ColourAdjust_BlackRef = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Illuminant = New System.Windows.Forms.ComboBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.ColourAdjust_Negative = New System.Windows.Forms.CheckBox()
        Me.ColourAdjust_DarkPic = New System.Windows.Forms.CheckBox()
        Me.ColourAdjust_Blue = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Green = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Red = New System.Windows.Forms.NumericUpDown()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.ColourAdjust_Tint = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Colour = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Brightness = New System.Windows.Forms.NumericUpDown()
        Me.ColourAdjust_Contrast = New System.Windows.Forms.NumericUpDown()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.ColourAdjustBtn = New System.Windows.Forms.Button()
        Me.groupBox23 = New System.Windows.Forms.GroupBox()
        Me.label86 = New System.Windows.Forms.Label()
        Me.ColourAreaHeightUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaBottomUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaLeftUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.ColourAreaNo = New System.Windows.Forms.NumericUpDown()
        Me.ColourAreaSideCombo = New System.Windows.Forms.ComboBox()
        Me.label85 = New System.Windows.Forms.Label()
        Me.ColourAreaCorrectionCombo = New System.Windows.Forms.ComboBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.ColourAreaButton = New System.Windows.Forms.Button()
        Me.groupBox17 = New System.Windows.Forms.GroupBox()
        Me.HoloPatchPositionUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label53 = New System.Windows.Forms.Label()
        Me.ColourHole = New System.Windows.Forms.CheckBox()
        Me.HoloPatchButton = New System.Windows.Forms.Button()
        Me.groupBox16 = New System.Windows.Forms.GroupBox()
        Me.HoloKotePreviewButton = New System.Windows.Forms.Button()
        Me.HoloKoteMapUpDown = New System.Windows.Forms.NumericUpDown()
        Me.HoloKoteImageUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label52 = New System.Windows.Forms.Label()
        Me.HoloKoteSideCombo = New System.Windows.Forms.ComboBox()
        Me.NoCustomKey = New System.Windows.Forms.CheckBox()
        Me.label49 = New System.Windows.Forms.Label()
        Me.HoloKoteRotationCombo = New System.Windows.Forms.ComboBox()
        Me.UseLaminate = New System.Windows.Forms.CheckBox()
        Me.label50 = New System.Windows.Forms.Label()
        Me.label51 = New System.Windows.Forms.Label()
        Me.HoloKoteButton = New System.Windows.Forms.Button()
        Me.groupBox15 = New System.Windows.Forms.GroupBox()
        Me.Rotate = New System.Windows.Forms.CheckBox()
        Me.Overcoat = New System.Windows.Forms.CheckBox()
        Me.CardSettingsSideCombo = New System.Windows.Forms.ComboBox()
        Me.label47 = New System.Windows.Forms.Label()
        Me.OrientationCombo = New System.Windows.Forms.ComboBox()
        Me.label44 = New System.Windows.Forms.Label()
        Me.ColourFormatCombo = New System.Windows.Forms.ComboBox()
        Me.label48 = New System.Windows.Forms.Label()
        Me.CardSettingsButton = New System.Windows.Forms.Button()
        Me.groupBox14 = New System.Windows.Forms.GroupBox()
        Me.CardSizeCombo = New System.Windows.Forms.ComboBox()
        Me.label43 = New System.Windows.Forms.Label()
        Me.CopyCountUpDown = New System.Windows.Forms.NumericUpDown()
        Me.label45 = New System.Windows.Forms.Label()
        Me.DuplexCombo = New System.Windows.Forms.ComboBox()
        Me.label46 = New System.Windows.Forms.Label()
        Me.PrintSettingsButton = New System.Windows.Forms.Button()
        Me.ClearDriver2MsgBoxButton = New System.Windows.Forms.Button()
        Me.Driver2MsgBox = New System.Windows.Forms.TextBox()
        Me.label17 = New System.Windows.Forms.Label()
        Me.Driver2SetRadio = New System.Windows.Forms.RadioButton()
        Me.Driver2GetRadio = New System.Windows.Forms.RadioButton()
        Me.PrintDemo = New System.Windows.Forms.TabPage()
        Me.Functions600DPI = New System.Windows.Forms.CheckBox()
        Me.PrinterPrefs = New System.Windows.Forms.Button()
        Me.nativePrint = New System.Windows.Forms.CheckBox()
        Me.CardSide = New System.Windows.Forms.TabControl()
        Me.Front = New System.Windows.Forms.TabPage()
        Me.GroupBox29 = New System.Windows.Forms.GroupBox()
        Me.Track3MagData = New System.Windows.Forms.TextBox()
        Me.Track2MagData = New System.Windows.Forms.TextBox()
        Me.Track1MagData = New System.Windows.Forms.TextBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.MagDataEnabled = New System.Windows.Forms.CheckBox()
        Me.GroupBox30 = New System.Windows.Forms.GroupBox()
        Me.ImageFrontResin = New System.Windows.Forms.CheckBox()
        Me.ImageFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.ImageFrontButton = New System.Windows.Forms.Button()
        Me.ImageFrontFileBox = New System.Windows.Forms.TextBox()
        Me.ImageFrontP2UpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ImageFrontP1UpDown = New System.Windows.Forms.NumericUpDown()
        Me.ImageFrontYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ImageFrontXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.GroupBox31 = New System.Windows.Forms.GroupBox()
        Me.LineFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.LineFrontWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.LineFrontStartYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineFrontEndYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.LineFrontResin = New System.Windows.Forms.CheckBox()
        Me.LineFrontEndXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineFrontColourCombo = New System.Windows.Forms.ComboBox()
        Me.LineFrontStartXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.GroupBox32 = New System.Windows.Forms.GroupBox()
        Me.ShapeFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.ShapeFrontFillCombo = New System.Windows.Forms.ComboBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.ShapeFrontWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeFrontOutlineCombo = New System.Windows.Forms.ComboBox()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.ShapeFrontBUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.ShapeFrontResin = New System.Windows.Forms.CheckBox()
        Me.ShapeFrontRUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeFrontTUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.ShapeFrontLUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.ShapeFrontCombo = New System.Windows.Forms.ComboBox()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.groupBox33 = New System.Windows.Forms.GroupBox()
        Me.TextFrontEnabled = New System.Windows.Forms.CheckBox()
        Me.TextFrontResin = New System.Windows.Forms.CheckBox()
        Me.TextFrontSizeUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.TextFrontYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.TextFrontXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.TextFrontStrikethrough = New System.Windows.Forms.CheckBox()
        Me.TextFrontItalic = New System.Windows.Forms.CheckBox()
        Me.TextFrontUnderline = New System.Windows.Forms.CheckBox()
        Me.TextFrontBold = New System.Windows.Forms.CheckBox()
        Me.TextFrontColourCombo = New System.Windows.Forms.ComboBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.TextFrontBox = New System.Windows.Forms.TextBox()
        Me.Back = New System.Windows.Forms.TabPage()
        Me.GroupBox34 = New System.Windows.Forms.GroupBox()
        Me.ImageBackResin = New System.Windows.Forms.CheckBox()
        Me.ImageBackEnabled = New System.Windows.Forms.CheckBox()
        Me.ImageBackFileBox = New System.Windows.Forms.TextBox()
        Me.ImageBackP2UpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.ImageBackP1UpDown = New System.Windows.Forms.NumericUpDown()
        Me.ImageBackYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.ImageBackXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.GroupBox35 = New System.Windows.Forms.GroupBox()
        Me.LineBackEnabled = New System.Windows.Forms.CheckBox()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.LineBackWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.LineBackStartYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineBackEndYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.LineBackResin = New System.Windows.Forms.CheckBox()
        Me.LineBackEndXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.LineBackColourCombo = New System.Windows.Forms.ComboBox()
        Me.LineBackStartXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.GroupBox36 = New System.Windows.Forms.GroupBox()
        Me.ShapeBackEnabled = New System.Windows.Forms.CheckBox()
        Me.ShapeBackFillCombo = New System.Windows.Forms.ComboBox()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.ShapeBackWidthUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeBackOutlineCombo = New System.Windows.Forms.ComboBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.ShapeBackBUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.ShapeBackResin = New System.Windows.Forms.CheckBox()
        Me.ShapeBackRUpDown = New System.Windows.Forms.NumericUpDown()
        Me.ShapeBackTUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.ShapeBackLUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.ShapeBackCombo = New System.Windows.Forms.ComboBox()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.GroupBox37 = New System.Windows.Forms.GroupBox()
        Me.TextBackEnabled = New System.Windows.Forms.CheckBox()
        Me.TextBackResin = New System.Windows.Forms.CheckBox()
        Me.TextBackSizeUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.TextBackYUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.TextBackXUpDown = New System.Windows.Forms.NumericUpDown()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.TextBackStrikethrough = New System.Windows.Forms.CheckBox()
        Me.TextBackItalic = New System.Windows.Forms.CheckBox()
        Me.TextBackUnderline = New System.Windows.Forms.CheckBox()
        Me.TextBackBold = New System.Windows.Forms.CheckBox()
        Me.TextBackColourCombo = New System.Windows.Forms.ComboBox()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.TextBackBox = New System.Windows.Forms.TextBox()
        Me.CardBack = New System.Windows.Forms.CheckBox()
        Me.CardFront = New System.Windows.Forms.CheckBox()
        Me.PrintButton = New System.Windows.Forms.Button()
        Me.Utils = New System.Windows.Forms.TabPage()
        Me.SendAPDUButton = New System.Windows.Forms.Button()
        Me.SendAPDUBox = New System.Windows.Forms.TextBox()
        Me.ClearUtilsMsgBoxButton = New System.Windows.Forms.Button()
        Me.UtilsMsgBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.PrinterID = New System.Windows.Forms.Label()
        ImageBackButton = New System.Windows.Forms.Button()
        Me.TabControl.SuspendLayout()
        Me.Printer.SuspendLayout()
        Me.GenCmdGroupBox.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        CType(Me.EraseCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseArea_TopRYBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseArea_TopRXBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseArea_BotLYBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseArea_BotLXBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.IPGroupBox.SuspendLayout()
        CType(Me.SmartOffsetBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Information.SuspendLayout()
        Me.groupBox28.SuspendLayout()
        Me.GroupBox27.SuspendLayout()
        Me.Generation2GroupBox.SuspendLayout()
        Me.Encoding.SuspendLayout()
        Me.GroupBox19.SuspendLayout()
        CType(Me.MagStartPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox9.SuspendLayout()
        Me.groupBox8.SuspendLayout()
        Me.Driver1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.groupBox7.SuspendLayout()
        CType(Me.PrintableAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrintableAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrintableAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PrintableAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox13.SuspendLayout()
        CType(Me.ErasePowerEndUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WritePowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErasePowerStartUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EraseAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox12.SuspendLayout()
        CType(Me.AreaHoleHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AreaHoleNoUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AreaHoleBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AreaHoleWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AreaHoleLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox11.SuspendLayout()
        CType(Me.ResinAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaNoUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox10.SuspendLayout()
        CType(Me.OvercoatPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResinPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YMCPowerUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SharpnessUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Driver2.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        CType(Me.ColourAdjust_WhiteRef, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_BlackRef, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Blue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Green, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Red, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Tint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Colour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Brightness, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAdjust_Contrast, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox23.SuspendLayout()
        CType(Me.ColourAreaHeightUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaBottomUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaLeftUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ColourAreaNo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox17.SuspendLayout()
        CType(Me.HoloPatchPositionUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox16.SuspendLayout()
        CType(Me.HoloKoteMapUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HoloKoteImageUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox15.SuspendLayout()
        Me.groupBox14.SuspendLayout()
        CType(Me.CopyCountUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PrintDemo.SuspendLayout()
        Me.CardSide.SuspendLayout()
        Me.Front.SuspendLayout()
        Me.GroupBox29.SuspendLayout()
        Me.GroupBox30.SuspendLayout()
        CType(Me.ImageFrontP2UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontP1UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageFrontXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox31.SuspendLayout()
        CType(Me.LineFrontWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontStartYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontEndYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontEndXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineFrontStartXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox32.SuspendLayout()
        CType(Me.ShapeFrontWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontBUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontRUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontTUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeFrontLUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox33.SuspendLayout()
        CType(Me.TextFrontSizeUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextFrontYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextFrontXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Back.SuspendLayout()
        Me.GroupBox34.SuspendLayout()
        CType(Me.ImageBackP2UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackP1UpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImageBackXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox35.SuspendLayout()
        CType(Me.LineBackWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackStartYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackEndYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackEndXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LineBackStartXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox36.SuspendLayout()
        CType(Me.ShapeBackWidthUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackBUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackRUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackTUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShapeBackLUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox37.SuspendLayout()
        CType(Me.TextBackSizeUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBackYUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TextBackXUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Utils.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageBackButton
        '
        ImageBackButton.Enabled = False
        ImageBackButton.Location = New System.Drawing.Point(533, 12)
        ImageBackButton.Margin = New System.Windows.Forms.Padding(4)
        ImageBackButton.Name = "ImageBackButton"
        ImageBackButton.Size = New System.Drawing.Size(37, 30)
        ImageBackButton.TabIndex = 70
        ImageBackButton.Text = "..."
        ImageBackButton.UseVisualStyleBackColor = True
        AddHandler ImageBackButton.Click, AddressOf Me.ImageBackButton_Click
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.Printer)
        Me.TabControl.Controls.Add(Me.Information)
        Me.TabControl.Controls.Add(Me.Encoding)
        Me.TabControl.Controls.Add(Me.Driver1)
        Me.TabControl.Controls.Add(Me.Driver2)
        Me.TabControl.Controls.Add(Me.PrintDemo)
        Me.TabControl.Controls.Add(Me.Utils)
        Me.TabControl.Location = New System.Drawing.Point(4, 0)
        Me.TabControl.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(629, 729)
        Me.TabControl.TabIndex = 1
        '
        'Printer
        '
        Me.Printer.Controls.Add(Me.GenCmdGroupBox)
        Me.Printer.Controls.Add(Me.groupBox5)
        Me.Printer.Controls.Add(Me.GroupBox2)
        Me.Printer.Controls.Add(Me.GroupBox1)
        Me.Printer.Controls.Add(Me.GroupBox4)
        Me.Printer.Controls.Add(Me.GroupBox3)
        Me.Printer.Location = New System.Drawing.Point(4, 25)
        Me.Printer.Margin = New System.Windows.Forms.Padding(4)
        Me.Printer.Name = "Printer"
        Me.Printer.Padding = New System.Windows.Forms.Padding(4)
        Me.Printer.Size = New System.Drawing.Size(621, 700)
        Me.Printer.TabIndex = 0
        Me.Printer.Text = "Printer"
        Me.Printer.UseVisualStyleBackColor = True
        '
        'GenCmdGroupBox
        '
        Me.GenCmdGroupBox.Controls.Add(Me.GenCommandButton)
        Me.GenCmdGroupBox.Controls.Add(Me.GenCommandBox)
        Me.GenCmdGroupBox.Location = New System.Drawing.Point(7, 60)
        Me.GenCmdGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.GenCmdGroupBox.Name = "GenCmdGroupBox"
        Me.GenCmdGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.GenCmdGroupBox.Size = New System.Drawing.Size(361, 53)
        Me.GenCmdGroupBox.TabIndex = 29
        Me.GenCmdGroupBox.TabStop = False
        Me.GenCmdGroupBox.Text = "General Command"
        '
        'GenCommandButton
        '
        Me.GenCommandButton.Enabled = False
        Me.GenCommandButton.Location = New System.Drawing.Point(285, 17)
        Me.GenCommandButton.Margin = New System.Windows.Forms.Padding(4)
        Me.GenCommandButton.Name = "GenCommandButton"
        Me.GenCommandButton.Size = New System.Drawing.Size(65, 30)
        Me.GenCommandButton.TabIndex = 25
        Me.GenCommandButton.Text = "Send"
        Me.GenCommandButton.UseVisualStyleBackColor = True
        '
        'GenCommandBox
        '
        Me.GenCommandBox.Enabled = False
        Me.GenCommandBox.Location = New System.Drawing.Point(4, 20)
        Me.GenCommandBox.Margin = New System.Windows.Forms.Padding(4)
        Me.GenCommandBox.Name = "GenCommandBox"
        Me.GenCommandBox.Size = New System.Drawing.Size(272, 22)
        Me.GenCommandBox.TabIndex = 18
        '
        'groupBox5
        '
        Me.groupBox5.Controls.Add(Me.EraseCount)
        Me.groupBox5.Controls.Add(Me.Label5)
        Me.groupBox5.Controls.Add(Me.EraseArea_TopRYBox)
        Me.groupBox5.Controls.Add(Me.EraseArea_TopRXBox)
        Me.groupBox5.Controls.Add(Me.EraseArea_BotLYBox)
        Me.groupBox5.Controls.Add(Me.EraseArea_BotLXBox)
        Me.groupBox5.Controls.Add(Me.label4)
        Me.groupBox5.Controls.Add(Me.EraseCardButton)
        Me.groupBox5.Controls.Add(Me.label3)
        Me.groupBox5.Controls.Add(Me.label2)
        Me.groupBox5.Controls.Add(Me.label1)
        Me.groupBox5.Location = New System.Drawing.Point(376, 114)
        Me.groupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox5.Size = New System.Drawing.Size(233, 149)
        Me.groupBox5.TabIndex = 32
        Me.groupBox5.TabStop = False
        '
        'EraseCount
        '
        Me.EraseCount.Enabled = False
        Me.EraseCount.Location = New System.Drawing.Point(69, 82)
        Me.EraseCount.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseCount.Maximum = New Decimal(New Integer() {499, 0, 0, 0})
        Me.EraseCount.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.EraseCount.Name = "EraseCount"
        Me.EraseCount.Size = New System.Drawing.Size(131, 22)
        Me.EraseCount.TabIndex = 40
        Me.EraseCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.EraseCount.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 90)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 39
        Me.Label5.Text = "Count"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EraseArea_TopRYBox
        '
        Me.EraseArea_TopRYBox.Enabled = False
        Me.EraseArea_TopRYBox.Location = New System.Drawing.Point(136, 55)
        Me.EraseArea_TopRYBox.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseArea_TopRYBox.Maximum = New Decimal(New Integer() {641, 0, 0, 0})
        Me.EraseArea_TopRYBox.Name = "EraseArea_TopRYBox"
        Me.EraseArea_TopRYBox.Size = New System.Drawing.Size(64, 22)
        Me.EraseArea_TopRYBox.TabIndex = 38
        Me.EraseArea_TopRYBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.EraseArea_TopRYBox.Value = New Decimal(New Integer() {641, 0, 0, 0})
        '
        'EraseArea_TopRXBox
        '
        Me.EraseArea_TopRXBox.Enabled = False
        Me.EraseArea_TopRXBox.Location = New System.Drawing.Point(69, 55)
        Me.EraseArea_TopRXBox.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseArea_TopRXBox.Maximum = New Decimal(New Integer() {1015, 0, 0, 0})
        Me.EraseArea_TopRXBox.Name = "EraseArea_TopRXBox"
        Me.EraseArea_TopRXBox.Size = New System.Drawing.Size(64, 22)
        Me.EraseArea_TopRXBox.TabIndex = 37
        Me.EraseArea_TopRXBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.EraseArea_TopRXBox.Value = New Decimal(New Integer() {1015, 0, 0, 0})
        '
        'EraseArea_BotLYBox
        '
        Me.EraseArea_BotLYBox.Enabled = False
        Me.EraseArea_BotLYBox.Location = New System.Drawing.Point(136, 26)
        Me.EraseArea_BotLYBox.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseArea_BotLYBox.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.EraseArea_BotLYBox.Name = "EraseArea_BotLYBox"
        Me.EraseArea_BotLYBox.Size = New System.Drawing.Size(64, 22)
        Me.EraseArea_BotLYBox.TabIndex = 36
        Me.EraseArea_BotLYBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EraseArea_BotLXBox
        '
        Me.EraseArea_BotLXBox.Enabled = False
        Me.EraseArea_BotLXBox.Location = New System.Drawing.Point(69, 26)
        Me.EraseArea_BotLXBox.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseArea_BotLXBox.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.EraseArea_BotLXBox.Name = "EraseArea_BotLXBox"
        Me.EraseArea_BotLXBox.Size = New System.Drawing.Size(64, 22)
        Me.EraseArea_BotLXBox.TabIndex = 35
        Me.EraseArea_BotLXBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(4, 60)
        Me.label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(47, 17)
        Me.label4.TabIndex = 34
        Me.label4.Text = "Top R"
        Me.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EraseCardButton
        '
        Me.EraseCardButton.Enabled = False
        Me.EraseCardButton.Location = New System.Drawing.Point(69, 112)
        Me.EraseCardButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseCardButton.Name = "EraseCardButton"
        Me.EraseCardButton.Size = New System.Drawing.Size(120, 30)
        Me.EraseCardButton.TabIndex = 30
        Me.EraseCardButton.Text = "EraseCard"
        Me.EraseCardButton.UseVisualStyleBackColor = True
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(4, 31)
        Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(64, 17)
        Me.label3.TabIndex = 33
        Me.label3.Text = "Bottom L"
        Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(159, 9)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(17, 17)
        Me.label2.TabIndex = 32
        Me.label2.Text = "Y"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(92, 9)
        Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(17, 17)
        Me.label1.TabIndex = 31
        Me.label1.Text = "X"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MoveFilmButton)
        Me.GroupBox2.Controls.Add(Me.FeedMoveButton)
        Me.GroupBox2.Controls.Add(Me.MoveFilmCombo)
        Me.GroupBox2.Controls.Add(Me.CardLocationButton)
        Me.GroupBox2.Controls.Add(Me.FeedMoveCombo)
        Me.GroupBox2.Controls.Add(Me.RestartButton)
        Me.GroupBox2.Controls.Add(Me.EjectCardButton)
        Me.GroupBox2.Controls.Add(Me.FlipCardButton)
        Me.GroupBox2.Controls.Add(Me.CleanPrinterButton)
        Me.GroupBox2.Controls.Add(Me.PrintTestCardButton)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 114)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(361, 149)
        Me.GroupBox2.TabIndex = 30
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Printer Control"
        '
        'MoveFilmButton
        '
        Me.MoveFilmButton.Enabled = False
        Me.MoveFilmButton.Location = New System.Drawing.Point(4, 53)
        Me.MoveFilmButton.Margin = New System.Windows.Forms.Padding(4)
        Me.MoveFilmButton.Name = "MoveFilmButton"
        Me.MoveFilmButton.Size = New System.Drawing.Size(108, 30)
        Me.MoveFilmButton.TabIndex = 32
        Me.MoveFilmButton.Text = "MoveFilm"
        Me.MoveFilmButton.UseVisualStyleBackColor = True
        '
        'FeedMoveButton
        '
        Me.FeedMoveButton.Enabled = False
        Me.FeedMoveButton.Location = New System.Drawing.Point(4, 23)
        Me.FeedMoveButton.Margin = New System.Windows.Forms.Padding(4)
        Me.FeedMoveButton.Name = "FeedMoveButton"
        Me.FeedMoveButton.Size = New System.Drawing.Size(108, 30)
        Me.FeedMoveButton.TabIndex = 31
        Me.FeedMoveButton.Text = "FeedCard"
        Me.FeedMoveButton.UseVisualStyleBackColor = True
        '
        'MoveFilmCombo
        '
        Me.MoveFilmCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MoveFilmCombo.Enabled = False
        Me.MoveFilmCombo.Location = New System.Drawing.Point(124, 55)
        Me.MoveFilmCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.MoveFilmCombo.Name = "MoveFilmCombo"
        Me.MoveFilmCombo.Size = New System.Drawing.Size(225, 24)
        Me.MoveFilmCombo.TabIndex = 29
        '
        'CardLocationButton
        '
        Me.CardLocationButton.Enabled = False
        Me.CardLocationButton.Location = New System.Drawing.Point(4, 112)
        Me.CardLocationButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CardLocationButton.Name = "CardLocationButton"
        Me.CardLocationButton.Size = New System.Drawing.Size(108, 30)
        Me.CardLocationButton.TabIndex = 28
        Me.CardLocationButton.Text = "CardLocation"
        Me.CardLocationButton.UseVisualStyleBackColor = True
        '
        'FeedMoveCombo
        '
        Me.FeedMoveCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FeedMoveCombo.Enabled = False
        Me.FeedMoveCombo.FormattingEnabled = True
        Me.FeedMoveCombo.Location = New System.Drawing.Point(124, 26)
        Me.FeedMoveCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.FeedMoveCombo.Name = "FeedMoveCombo"
        Me.FeedMoveCombo.Size = New System.Drawing.Size(225, 24)
        Me.FeedMoveCombo.TabIndex = 26
        '
        'RestartButton
        '
        Me.RestartButton.Enabled = False
        Me.RestartButton.Location = New System.Drawing.Point(124, 112)
        Me.RestartButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RestartButton.Name = "RestartButton"
        Me.RestartButton.Size = New System.Drawing.Size(108, 30)
        Me.RestartButton.TabIndex = 24
        Me.RestartButton.Text = "RestartPrinter"
        Me.RestartButton.UseVisualStyleBackColor = True
        '
        'EjectCardButton
        '
        Me.EjectCardButton.Enabled = False
        Me.EjectCardButton.Location = New System.Drawing.Point(4, 82)
        Me.EjectCardButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EjectCardButton.Name = "EjectCardButton"
        Me.EjectCardButton.Size = New System.Drawing.Size(108, 30)
        Me.EjectCardButton.TabIndex = 19
        Me.EjectCardButton.Text = "EjectCard"
        Me.EjectCardButton.UseVisualStyleBackColor = True
        '
        'FlipCardButton
        '
        Me.FlipCardButton.Enabled = False
        Me.FlipCardButton.Location = New System.Drawing.Point(124, 82)
        Me.FlipCardButton.Margin = New System.Windows.Forms.Padding(4)
        Me.FlipCardButton.Name = "FlipCardButton"
        Me.FlipCardButton.Size = New System.Drawing.Size(108, 30)
        Me.FlipCardButton.TabIndex = 22
        Me.FlipCardButton.Text = "FlipCard"
        Me.FlipCardButton.UseVisualStyleBackColor = True
        '
        'CleanPrinterButton
        '
        Me.CleanPrinterButton.Enabled = False
        Me.CleanPrinterButton.Location = New System.Drawing.Point(244, 112)
        Me.CleanPrinterButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CleanPrinterButton.Name = "CleanPrinterButton"
        Me.CleanPrinterButton.Size = New System.Drawing.Size(108, 30)
        Me.CleanPrinterButton.TabIndex = 20
        Me.CleanPrinterButton.Text = "CleanPrinter"
        Me.CleanPrinterButton.UseVisualStyleBackColor = True
        '
        'PrintTestCardButton
        '
        Me.PrintTestCardButton.Enabled = False
        Me.PrintTestCardButton.Location = New System.Drawing.Point(244, 82)
        Me.PrintTestCardButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintTestCardButton.Name = "PrintTestCardButton"
        Me.PrintTestCardButton.Size = New System.Drawing.Size(108, 30)
        Me.PrintTestCardButton.TabIndex = 23
        Me.PrintTestCardButton.Text = "PrintTestCard"
        Me.PrintTestCardButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SessionConfigCombo)
        Me.GroupBox1.Controls.Add(Me.OpenSessionButton)
        Me.GroupBox1.Controls.Add(Me.CloseSessionButton)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(361, 53)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        '
        'SessionConfigCombo
        '
        Me.SessionConfigCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SessionConfigCombo.FormattingEnabled = True
        Me.SessionConfigCombo.Location = New System.Drawing.Point(128, 18)
        Me.SessionConfigCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.SessionConfigCombo.Name = "SessionConfigCombo"
        Me.SessionConfigCombo.Size = New System.Drawing.Size(205, 24)
        Me.SessionConfigCombo.TabIndex = 39
        '
        'OpenSessionButton
        '
        Me.OpenSessionButton.Location = New System.Drawing.Point(4, 16)
        Me.OpenSessionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.OpenSessionButton.Name = "OpenSessionButton"
        Me.OpenSessionButton.Size = New System.Drawing.Size(120, 30)
        Me.OpenSessionButton.TabIndex = 2
        Me.OpenSessionButton.Text = "OpenSession"
        Me.OpenSessionButton.UseVisualStyleBackColor = True
        '
        'CloseSessionButton
        '
        Me.CloseSessionButton.Location = New System.Drawing.Point(127, 16)
        Me.CloseSessionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CloseSessionButton.Name = "CloseSessionButton"
        Me.CloseSessionButton.Size = New System.Drawing.Size(120, 30)
        Me.CloseSessionButton.TabIndex = 3
        Me.CloseSessionButton.Text = "CloseSession"
        Me.CloseSessionButton.UseVisualStyleBackColor = True
        Me.CloseSessionButton.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ErrorResponseCombo)
        Me.GroupBox4.Controls.Add(Me.ErrorResponseButton)
        Me.GroupBox4.Location = New System.Drawing.Point(376, 4)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(233, 110)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Error Handling"
        '
        'ErrorResponseCombo
        '
        Me.ErrorResponseCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ErrorResponseCombo.Enabled = False
        Me.ErrorResponseCombo.FormattingEnabled = True
        Me.ErrorResponseCombo.Location = New System.Drawing.Point(47, 23)
        Me.ErrorResponseCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ErrorResponseCombo.Name = "ErrorResponseCombo"
        Me.ErrorResponseCombo.Size = New System.Drawing.Size(152, 24)
        Me.ErrorResponseCombo.TabIndex = 19
        '
        'ErrorResponseButton
        '
        Me.ErrorResponseButton.Enabled = False
        Me.ErrorResponseButton.Location = New System.Drawing.Point(63, 57)
        Me.ErrorResponseButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ErrorResponseButton.Name = "ErrorResponseButton"
        Me.ErrorResponseButton.Size = New System.Drawing.Size(120, 30)
        Me.ErrorResponseButton.TabIndex = 23
        Me.ErrorResponseButton.Text = "ErrorResponse"
        Me.ErrorResponseButton.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.IPGroupBox)
        Me.GroupBox3.Controls.Add(Me.ClearPrinterMsgButton)
        Me.GroupBox3.Controls.Add(Me.label7)
        Me.GroupBox3.Controls.Add(Me.PrinterSetRadio)
        Me.GroupBox3.Controls.Add(Me.PrinterGetRadio)
        Me.GroupBox3.Controls.Add(Me.HandFeedCombo)
        Me.GroupBox3.Controls.Add(Me.HorzEjectCombo)
        Me.GroupBox3.Controls.Add(Me.HorzEjectButton)
        Me.GroupBox3.Controls.Add(Me.HandFeedButton)
        Me.GroupBox3.Controls.Add(Me.SmartOffsetButton)
        Me.GroupBox3.Controls.Add(Me.SmartModeCombo)
        Me.GroupBox3.Controls.Add(Me.EjectModeCombo)
        Me.GroupBox3.Controls.Add(Me.EjectModeButton)
        Me.GroupBox3.Controls.Add(Me.EraseSpeedCombo)
        Me.GroupBox3.Controls.Add(Me.EraseSpeedButton)
        Me.GroupBox3.Controls.Add(Me.SmartModeButton)
        Me.GroupBox3.Controls.Add(Me.SmartOffsetBox)
        Me.GroupBox3.Controls.Add(Me.PrinterMsgBox)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 263)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(603, 433)
        Me.GroupBox3.TabIndex = 31
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Printer Config"
        '
        'IPGroupBox
        '
        Me.IPGroupBox.Controls.Add(Me.IPGatewayLabel)
        Me.IPGroupBox.Controls.Add(Me.IPSubnetLabel)
        Me.IPGroupBox.Controls.Add(Me.IPAddressLabel)
        Me.IPGroupBox.Controls.Add(Me.IPGatewayBox)
        Me.IPGroupBox.Controls.Add(Me.IPSubnetBox)
        Me.IPGroupBox.Controls.Add(Me.IPAddressBox)
        Me.IPGroupBox.Controls.Add(Me.IPSettingsButton)
        Me.IPGroupBox.Controls.Add(Me.IPModeLabel)
        Me.IPGroupBox.Controls.Add(Me.IPModeCombo)
        Me.IPGroupBox.Location = New System.Drawing.Point(4, 228)
        Me.IPGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.IPGroupBox.Name = "IPGroupBox"
        Me.IPGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.IPGroupBox.Size = New System.Drawing.Size(280, 192)
        Me.IPGroupBox.TabIndex = 42
        Me.IPGroupBox.TabStop = False
        Me.IPGroupBox.Text = "Network Settings"
        '
        'IPGatewayLabel
        '
        Me.IPGatewayLabel.AutoSize = True
        Me.IPGatewayLabel.Location = New System.Drawing.Point(8, 118)
        Me.IPGatewayLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.IPGatewayLabel.Name = "IPGatewayLabel"
        Me.IPGatewayLabel.Size = New System.Drawing.Size(63, 17)
        Me.IPGatewayLabel.TabIndex = 44
        Me.IPGatewayLabel.Text = "Gateway"
        '
        'IPSubnetLabel
        '
        Me.IPSubnetLabel.AutoSize = True
        Me.IPSubnetLabel.Location = New System.Drawing.Point(8, 89)
        Me.IPSubnetLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.IPSubnetLabel.Name = "IPSubnetLabel"
        Me.IPSubnetLabel.Size = New System.Drawing.Size(53, 17)
        Me.IPSubnetLabel.TabIndex = 43
        Me.IPSubnetLabel.Text = "Subnet"
        '
        'IPAddressLabel
        '
        Me.IPAddressLabel.AutoSize = True
        Me.IPAddressLabel.Location = New System.Drawing.Point(8, 59)
        Me.IPAddressLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.IPAddressLabel.Name = "IPAddressLabel"
        Me.IPAddressLabel.Size = New System.Drawing.Size(76, 17)
        Me.IPAddressLabel.TabIndex = 42
        Me.IPAddressLabel.Text = "IP Address"
        '
        'IPGatewayBox
        '
        Me.IPGatewayBox.Enabled = False
        Me.IPGatewayBox.Location = New System.Drawing.Point(91, 113)
        Me.IPGatewayBox.Margin = New System.Windows.Forms.Padding(4)
        Me.IPGatewayBox.Name = "IPGatewayBox"
        Me.IPGatewayBox.Size = New System.Drawing.Size(173, 22)
        Me.IPGatewayBox.TabIndex = 41
        Me.IPGatewayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPSubnetBox
        '
        Me.IPSubnetBox.Enabled = False
        Me.IPSubnetBox.Location = New System.Drawing.Point(91, 84)
        Me.IPSubnetBox.Margin = New System.Windows.Forms.Padding(4)
        Me.IPSubnetBox.Name = "IPSubnetBox"
        Me.IPSubnetBox.Size = New System.Drawing.Size(173, 22)
        Me.IPSubnetBox.TabIndex = 40
        Me.IPSubnetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPAddressBox
        '
        Me.IPAddressBox.Enabled = False
        Me.IPAddressBox.Location = New System.Drawing.Point(91, 54)
        Me.IPAddressBox.Margin = New System.Windows.Forms.Padding(4)
        Me.IPAddressBox.Name = "IPAddressBox"
        Me.IPAddressBox.Size = New System.Drawing.Size(173, 22)
        Me.IPAddressBox.TabIndex = 26
        Me.IPAddressBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'IPSettingsButton
        '
        Me.IPSettingsButton.Enabled = False
        Me.IPSettingsButton.Location = New System.Drawing.Point(84, 145)
        Me.IPSettingsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IPSettingsButton.Name = "IPSettingsButton"
        Me.IPSettingsButton.Size = New System.Drawing.Size(120, 30)
        Me.IPSettingsButton.TabIndex = 39
        Me.IPSettingsButton.Text = "IP Settings"
        Me.IPSettingsButton.UseVisualStyleBackColor = True
        '
        'IPModeLabel
        '
        Me.IPModeLabel.AutoSize = True
        Me.IPModeLabel.Location = New System.Drawing.Point(8, 28)
        Me.IPModeLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.IPModeLabel.Name = "IPModeLabel"
        Me.IPModeLabel.Size = New System.Drawing.Size(43, 17)
        Me.IPModeLabel.TabIndex = 37
        Me.IPModeLabel.Text = "Mode"
        '
        'IPModeCombo
        '
        Me.IPModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IPModeCombo.Enabled = False
        Me.IPModeCombo.FormattingEnabled = True
        Me.IPModeCombo.Location = New System.Drawing.Point(91, 23)
        Me.IPModeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.IPModeCombo.Name = "IPModeCombo"
        Me.IPModeCombo.Size = New System.Drawing.Size(173, 24)
        Me.IPModeCombo.TabIndex = 38
        '
        'ClearPrinterMsgButton
        '
        Me.ClearPrinterMsgButton.Location = New System.Drawing.Point(383, 396)
        Me.ClearPrinterMsgButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearPrinterMsgButton.Name = "ClearPrinterMsgButton"
        Me.ClearPrinterMsgButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearPrinterMsgButton.TabIndex = 44
        Me.ClearPrinterMsgButton.Text = "Clear"
        Me.ClearPrinterMsgButton.UseVisualStyleBackColor = True
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(8, 28)
        Me.label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(51, 17)
        Me.label7.TabIndex = 41
        Me.label7.Text = "Action:"
        '
        'PrinterSetRadio
        '
        Me.PrinterSetRadio.AutoSize = True
        Me.PrinterSetRadio.Enabled = False
        Me.PrinterSetRadio.Location = New System.Drawing.Point(117, 26)
        Me.PrinterSetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterSetRadio.Name = "PrinterSetRadio"
        Me.PrinterSetRadio.Size = New System.Drawing.Size(50, 21)
        Me.PrinterSetRadio.TabIndex = 40
        Me.PrinterSetRadio.Text = "Set"
        Me.PrinterSetRadio.UseVisualStyleBackColor = True
        '
        'PrinterGetRadio
        '
        Me.PrinterGetRadio.AutoSize = True
        Me.PrinterGetRadio.Checked = True
        Me.PrinterGetRadio.Enabled = False
        Me.PrinterGetRadio.Location = New System.Drawing.Point(61, 26)
        Me.PrinterGetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterGetRadio.Name = "PrinterGetRadio"
        Me.PrinterGetRadio.Size = New System.Drawing.Size(52, 21)
        Me.PrinterGetRadio.TabIndex = 39
        Me.PrinterGetRadio.TabStop = True
        Me.PrinterGetRadio.Text = "Get"
        Me.PrinterGetRadio.UseVisualStyleBackColor = True
        '
        'HandFeedCombo
        '
        Me.HandFeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HandFeedCombo.Enabled = False
        Me.HandFeedCombo.FormattingEnabled = True
        Me.HandFeedCombo.Location = New System.Drawing.Point(128, 53)
        Me.HandFeedCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.HandFeedCombo.Name = "HandFeedCombo"
        Me.HandFeedCombo.Size = New System.Drawing.Size(140, 24)
        Me.HandFeedCombo.TabIndex = 38
        '
        'HorzEjectCombo
        '
        Me.HorzEjectCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HorzEjectCombo.Enabled = False
        Me.HorzEjectCombo.FormattingEnabled = True
        Me.HorzEjectCombo.Location = New System.Drawing.Point(128, 171)
        Me.HorzEjectCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.HorzEjectCombo.Name = "HorzEjectCombo"
        Me.HorzEjectCombo.Size = New System.Drawing.Size(140, 24)
        Me.HorzEjectCombo.TabIndex = 37
        '
        'HorzEjectButton
        '
        Me.HorzEjectButton.Enabled = False
        Me.HorzEjectButton.Location = New System.Drawing.Point(4, 169)
        Me.HorzEjectButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HorzEjectButton.Name = "HorzEjectButton"
        Me.HorzEjectButton.Size = New System.Drawing.Size(120, 30)
        Me.HorzEjectButton.TabIndex = 36
        Me.HorzEjectButton.Text = "HorzEject"
        Me.HorzEjectButton.UseVisualStyleBackColor = True
        '
        'HandFeedButton
        '
        Me.HandFeedButton.Enabled = False
        Me.HandFeedButton.Location = New System.Drawing.Point(4, 50)
        Me.HandFeedButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HandFeedButton.Name = "HandFeedButton"
        Me.HandFeedButton.Size = New System.Drawing.Size(120, 30)
        Me.HandFeedButton.TabIndex = 35
        Me.HandFeedButton.Text = "HandFeed"
        Me.HandFeedButton.UseVisualStyleBackColor = True
        '
        'SmartOffsetButton
        '
        Me.SmartOffsetButton.Enabled = False
        Me.SmartOffsetButton.Location = New System.Drawing.Point(4, 110)
        Me.SmartOffsetButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SmartOffsetButton.Name = "SmartOffsetButton"
        Me.SmartOffsetButton.Size = New System.Drawing.Size(120, 30)
        Me.SmartOffsetButton.TabIndex = 25
        Me.SmartOffsetButton.Text = "SmartOffset"
        Me.SmartOffsetButton.UseVisualStyleBackColor = True
        '
        'SmartModeCombo
        '
        Me.SmartModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SmartModeCombo.Enabled = False
        Me.SmartModeCombo.FormattingEnabled = True
        Me.SmartModeCombo.Location = New System.Drawing.Point(128, 142)
        Me.SmartModeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.SmartModeCombo.Name = "SmartModeCombo"
        Me.SmartModeCombo.Size = New System.Drawing.Size(140, 24)
        Me.SmartModeCombo.TabIndex = 22
        '
        'EjectModeCombo
        '
        Me.EjectModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EjectModeCombo.Enabled = False
        Me.EjectModeCombo.FormattingEnabled = True
        Me.EjectModeCombo.Location = New System.Drawing.Point(128, 82)
        Me.EjectModeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.EjectModeCombo.Name = "EjectModeCombo"
        Me.EjectModeCombo.Size = New System.Drawing.Size(140, 24)
        Me.EjectModeCombo.TabIndex = 15
        '
        'EjectModeButton
        '
        Me.EjectModeButton.Enabled = False
        Me.EjectModeButton.Location = New System.Drawing.Point(4, 80)
        Me.EjectModeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EjectModeButton.Name = "EjectModeButton"
        Me.EjectModeButton.Size = New System.Drawing.Size(120, 30)
        Me.EjectModeButton.TabIndex = 21
        Me.EjectModeButton.Text = "EjectMode"
        Me.EjectModeButton.UseVisualStyleBackColor = True
        '
        'EraseSpeedCombo
        '
        Me.EraseSpeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EraseSpeedCombo.Enabled = False
        Me.EraseSpeedCombo.FormattingEnabled = True
        Me.EraseSpeedCombo.Location = New System.Drawing.Point(128, 201)
        Me.EraseSpeedCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseSpeedCombo.Name = "EraseSpeedCombo"
        Me.EraseSpeedCombo.Size = New System.Drawing.Size(140, 24)
        Me.EraseSpeedCombo.TabIndex = 26
        '
        'EraseSpeedButton
        '
        Me.EraseSpeedButton.Enabled = False
        Me.EraseSpeedButton.Location = New System.Drawing.Point(4, 198)
        Me.EraseSpeedButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseSpeedButton.Name = "EraseSpeedButton"
        Me.EraseSpeedButton.Size = New System.Drawing.Size(120, 30)
        Me.EraseSpeedButton.TabIndex = 26
        Me.EraseSpeedButton.Text = "EraseSpeed"
        Me.EraseSpeedButton.UseVisualStyleBackColor = True
        '
        'SmartModeButton
        '
        Me.SmartModeButton.Enabled = False
        Me.SmartModeButton.Location = New System.Drawing.Point(4, 139)
        Me.SmartModeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SmartModeButton.Name = "SmartModeButton"
        Me.SmartModeButton.Size = New System.Drawing.Size(120, 30)
        Me.SmartModeButton.TabIndex = 23
        Me.SmartModeButton.Text = "SmartMode"
        Me.SmartModeButton.UseVisualStyleBackColor = True
        '
        'SmartOffsetBox
        '
        Me.SmartOffsetBox.Enabled = False
        Me.SmartOffsetBox.Location = New System.Drawing.Point(128, 112)
        Me.SmartOffsetBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SmartOffsetBox.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.SmartOffsetBox.Name = "SmartOffsetBox"
        Me.SmartOffsetBox.Size = New System.Drawing.Size(141, 22)
        Me.SmartOffsetBox.TabIndex = 17
        Me.SmartOffsetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PrinterMsgBox
        '
        Me.PrinterMsgBox.Location = New System.Drawing.Point(292, 14)
        Me.PrinterMsgBox.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterMsgBox.Multiline = True
        Me.PrinterMsgBox.Name = "PrinterMsgBox"
        Me.PrinterMsgBox.ReadOnly = True
        Me.PrinterMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.PrinterMsgBox.Size = New System.Drawing.Size(301, 374)
        Me.PrinterMsgBox.TabIndex = 43
        Me.PrinterMsgBox.WordWrap = False
        '
        'Information
        '
        Me.Information.Controls.Add(Me.groupBox28)
        Me.Information.Controls.Add(Me.ClearMsgBoxButton)
        Me.Information.Controls.Add(Me.GroupBox27)
        Me.Information.Location = New System.Drawing.Point(4, 25)
        Me.Information.Margin = New System.Windows.Forms.Padding(4)
        Me.Information.Name = "Information"
        Me.Information.Padding = New System.Windows.Forms.Padding(4)
        Me.Information.Size = New System.Drawing.Size(621, 700)
        Me.Information.TabIndex = 1
        Me.Information.Text = "Information"
        Me.Information.UseVisualStyleBackColor = True
        '
        'groupBox28
        '
        Me.groupBox28.Controls.Add(Me.Pwd2Label)
        Me.groupBox28.Controls.Add(Me.Pwd1Label)
        Me.groupBox28.Controls.Add(Me.PasswordButton)
        Me.groupBox28.Controls.Add(Me.Password2)
        Me.groupBox28.Controls.Add(Me.Password1)
        Me.groupBox28.Controls.Add(Me.PasswordCommand)
        Me.groupBox28.Location = New System.Drawing.Point(1, 7)
        Me.groupBox28.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox28.Name = "groupBox28"
        Me.groupBox28.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox28.Size = New System.Drawing.Size(613, 70)
        Me.groupBox28.TabIndex = 105
        Me.groupBox28.TabStop = False
        Me.groupBox28.Text = "Password"
        '
        'Pwd2Label
        '
        Me.Pwd2Label.AutoSize = True
        Me.Pwd2Label.Location = New System.Drawing.Point(323, 28)
        Me.Pwd2Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Pwd2Label.Name = "Pwd2Label"
        Me.Pwd2Label.Size = New System.Drawing.Size(25, 17)
        Me.Pwd2Label.TabIndex = 39
        Me.Pwd2Label.Text = "P2"
        '
        'Pwd1Label
        '
        Me.Pwd1Label.AutoSize = True
        Me.Pwd1Label.Location = New System.Drawing.Point(167, 28)
        Me.Pwd1Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Pwd1Label.Name = "Pwd1Label"
        Me.Pwd1Label.Size = New System.Drawing.Size(25, 17)
        Me.Pwd1Label.TabIndex = 38
        Me.Pwd1Label.Text = "P1"
        '
        'PasswordButton
        '
        Me.PasswordButton.Location = New System.Drawing.Point(492, 21)
        Me.PasswordButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PasswordButton.Name = "PasswordButton"
        Me.PasswordButton.Size = New System.Drawing.Size(101, 30)
        Me.PasswordButton.TabIndex = 21
        Me.PasswordButton.Text = "Send"
        Me.PasswordButton.UseVisualStyleBackColor = True
        '
        'Password2
        '
        Me.Password2.Location = New System.Drawing.Point(357, 23)
        Me.Password2.Margin = New System.Windows.Forms.Padding(4)
        Me.Password2.Name = "Password2"
        Me.Password2.Size = New System.Drawing.Size(112, 22)
        Me.Password2.TabIndex = 20
        '
        'Password1
        '
        Me.Password1.Location = New System.Drawing.Point(201, 23)
        Me.Password1.Margin = New System.Windows.Forms.Padding(4)
        Me.Password1.Name = "Password1"
        Me.Password1.Size = New System.Drawing.Size(112, 22)
        Me.Password1.TabIndex = 19
        '
        'PasswordCommand
        '
        Me.PasswordCommand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PasswordCommand.FormattingEnabled = True
        Me.PasswordCommand.Location = New System.Drawing.Point(16, 23)
        Me.PasswordCommand.Margin = New System.Windows.Forms.Padding(4)
        Me.PasswordCommand.Name = "PasswordCommand"
        Me.PasswordCommand.Size = New System.Drawing.Size(141, 24)
        Me.PasswordCommand.TabIndex = 18
        '
        'ClearMsgBoxButton
        '
        Me.ClearMsgBoxButton.Location = New System.Drawing.Point(353, 660)
        Me.ClearMsgBoxButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearMsgBoxButton.Name = "ClearMsgBoxButton"
        Me.ClearMsgBoxButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearMsgBoxButton.TabIndex = 14
        Me.ClearMsgBoxButton.Text = "Clear"
        Me.ClearMsgBoxButton.UseVisualStyleBackColor = True
        '
        'GroupBox27
        '
        Me.GroupBox27.Controls.Add(Me.SensorsButton)
        Me.GroupBox27.Controls.Add(Me.PrinterTypeButton)
        Me.GroupBox27.Controls.Add(Me.Generation2GroupBox)
        Me.GroupBox27.Controls.Add(Me.SDKBitsButton)
        Me.GroupBox27.Controls.Add(Me.PrinterModelButton)
        Me.GroupBox27.Controls.Add(Me.PrinterInfoButton)
        Me.GroupBox27.Controls.Add(Me.InfoMsgBox)
        Me.GroupBox27.Controls.Add(Me.ConnectionTypeButton)
        Me.GroupBox27.Controls.Add(Me.LastMessageButton)
        Me.GroupBox27.Controls.Add(Me.PrinterStatusButton)
        Me.GroupBox27.Controls.Add(Me.SDKVersionButton)
        Me.GroupBox27.Location = New System.Drawing.Point(1, 80)
        Me.GroupBox27.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox27.Name = "GroupBox27"
        Me.GroupBox27.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox27.Size = New System.Drawing.Size(619, 694)
        Me.GroupBox27.TabIndex = 104
        Me.GroupBox27.TabStop = False
        '
        'SensorsButton
        '
        Me.SensorsButton.Location = New System.Drawing.Point(19, 313)
        Me.SensorsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SensorsButton.Name = "SensorsButton"
        Me.SensorsButton.Size = New System.Drawing.Size(189, 30)
        Me.SensorsButton.TabIndex = 107
        Me.SensorsButton.Text = "Sensors"
        Me.SensorsButton.UseVisualStyleBackColor = True
        '
        'PrinterTypeButton
        '
        Me.PrinterTypeButton.Location = New System.Drawing.Point(19, 128)
        Me.PrinterTypeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterTypeButton.Name = "PrinterTypeButton"
        Me.PrinterTypeButton.Size = New System.Drawing.Size(189, 30)
        Me.PrinterTypeButton.TabIndex = 106
        Me.PrinterTypeButton.Text = "PrinterType"
        Me.PrinterTypeButton.UseVisualStyleBackColor = True
        '
        'Generation2GroupBox
        '
        Me.Generation2GroupBox.Controls.Add(Me.AllParamsButton)
        Me.Generation2GroupBox.Controls.Add(Me.ReadParamButton)
        Me.Generation2GroupBox.Controls.Add(Me.ParamCombo)
        Me.Generation2GroupBox.Controls.Add(Me.Label68)
        Me.Generation2GroupBox.Location = New System.Drawing.Point(8, 432)
        Me.Generation2GroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.Generation2GroupBox.Name = "Generation2GroupBox"
        Me.Generation2GroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.Generation2GroupBox.Size = New System.Drawing.Size(203, 170)
        Me.Generation2GroupBox.TabIndex = 105
        Me.Generation2GroupBox.TabStop = False
        Me.Generation2GroupBox.Text = "Generation 2 Settings"
        '
        'AllParamsButton
        '
        Me.AllParamsButton.Location = New System.Drawing.Point(16, 126)
        Me.AllParamsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AllParamsButton.Name = "AllParamsButton"
        Me.AllParamsButton.Size = New System.Drawing.Size(169, 30)
        Me.AllParamsButton.TabIndex = 43
        Me.AllParamsButton.Text = "All Params"
        Me.AllParamsButton.UseVisualStyleBackColor = True
        '
        'ReadParamButton
        '
        Me.ReadParamButton.Location = New System.Drawing.Point(16, 89)
        Me.ReadParamButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReadParamButton.Name = "ReadParamButton"
        Me.ReadParamButton.Size = New System.Drawing.Size(169, 30)
        Me.ReadParamButton.TabIndex = 22
        Me.ReadParamButton.Text = "Read"
        Me.ReadParamButton.UseVisualStyleBackColor = True
        '
        'ParamCombo
        '
        Me.ParamCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ParamCombo.FormattingEnabled = True
        Me.ParamCombo.Location = New System.Drawing.Point(16, 55)
        Me.ParamCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ParamCombo.Name = "ParamCombo"
        Me.ParamCombo.Size = New System.Drawing.Size(168, 24)
        Me.ParamCombo.TabIndex = 41
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(64, 31)
        Me.Label68.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(74, 17)
        Me.Label68.TabIndex = 40
        Me.Label68.Text = "Parameter"
        '
        'SDKBitsButton
        '
        Me.SDKBitsButton.Location = New System.Drawing.Point(19, 54)
        Me.SDKBitsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SDKBitsButton.Name = "SDKBitsButton"
        Me.SDKBitsButton.Size = New System.Drawing.Size(189, 30)
        Me.SDKBitsButton.TabIndex = 104
        Me.SDKBitsButton.Text = "SDKBits"
        Me.SDKBitsButton.UseVisualStyleBackColor = True
        '
        'PrinterModelButton
        '
        Me.PrinterModelButton.Location = New System.Drawing.Point(19, 165)
        Me.PrinterModelButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterModelButton.Name = "PrinterModelButton"
        Me.PrinterModelButton.Size = New System.Drawing.Size(189, 30)
        Me.PrinterModelButton.TabIndex = 103
        Me.PrinterModelButton.Text = "PrinterModel"
        Me.PrinterModelButton.UseVisualStyleBackColor = True
        '
        'PrinterInfoButton
        '
        Me.PrinterInfoButton.Location = New System.Drawing.Point(19, 239)
        Me.PrinterInfoButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterInfoButton.Name = "PrinterInfoButton"
        Me.PrinterInfoButton.Size = New System.Drawing.Size(189, 30)
        Me.PrinterInfoButton.TabIndex = 12
        Me.PrinterInfoButton.Text = "PrinterInfo"
        Me.PrinterInfoButton.UseVisualStyleBackColor = True
        '
        'InfoMsgBox
        '
        Me.InfoMsgBox.Location = New System.Drawing.Point(219, 17)
        Me.InfoMsgBox.Margin = New System.Windows.Forms.Padding(4)
        Me.InfoMsgBox.Multiline = True
        Me.InfoMsgBox.Name = "InfoMsgBox"
        Me.InfoMsgBox.ReadOnly = True
        Me.InfoMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.InfoMsgBox.Size = New System.Drawing.Size(388, 554)
        Me.InfoMsgBox.TabIndex = 8
        '
        'ConnectionTypeButton
        '
        Me.ConnectionTypeButton.Location = New System.Drawing.Point(19, 91)
        Me.ConnectionTypeButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ConnectionTypeButton.Name = "ConnectionTypeButton"
        Me.ConnectionTypeButton.Size = New System.Drawing.Size(189, 30)
        Me.ConnectionTypeButton.TabIndex = 102
        Me.ConnectionTypeButton.Text = "Connection Type"
        Me.ConnectionTypeButton.UseVisualStyleBackColor = True
        '
        'LastMessageButton
        '
        Me.LastMessageButton.Location = New System.Drawing.Point(19, 276)
        Me.LastMessageButton.Margin = New System.Windows.Forms.Padding(4)
        Me.LastMessageButton.Name = "LastMessageButton"
        Me.LastMessageButton.Size = New System.Drawing.Size(189, 30)
        Me.LastMessageButton.TabIndex = 13
        Me.LastMessageButton.Text = "LastMessage"
        Me.LastMessageButton.UseVisualStyleBackColor = True
        '
        'PrinterStatusButton
        '
        Me.PrinterStatusButton.Location = New System.Drawing.Point(19, 202)
        Me.PrinterStatusButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterStatusButton.Name = "PrinterStatusButton"
        Me.PrinterStatusButton.Size = New System.Drawing.Size(189, 30)
        Me.PrinterStatusButton.TabIndex = 11
        Me.PrinterStatusButton.Text = "PrinterStatus"
        Me.PrinterStatusButton.UseVisualStyleBackColor = True
        '
        'SDKVersionButton
        '
        Me.SDKVersionButton.Location = New System.Drawing.Point(19, 17)
        Me.SDKVersionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SDKVersionButton.Name = "SDKVersionButton"
        Me.SDKVersionButton.Size = New System.Drawing.Size(189, 30)
        Me.SDKVersionButton.TabIndex = 100
        Me.SDKVersionButton.Text = "SDKVersion"
        Me.SDKVersionButton.UseVisualStyleBackColor = True
        '
        'Encoding
        '
        Me.Encoding.Controls.Add(Me.GroupBox19)
        Me.Encoding.Controls.Add(Me.groupBox9)
        Me.Encoding.Controls.Add(Me.groupBox8)
        Me.Encoding.Location = New System.Drawing.Point(4, 25)
        Me.Encoding.Margin = New System.Windows.Forms.Padding(4)
        Me.Encoding.Name = "Encoding"
        Me.Encoding.Padding = New System.Windows.Forms.Padding(4)
        Me.Encoding.Size = New System.Drawing.Size(621, 700)
        Me.Encoding.TabIndex = 2
        Me.Encoding.Text = "Encoding"
        Me.Encoding.UseVisualStyleBackColor = True
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.MagStartButton)
        Me.GroupBox19.Controls.Add(Me.MagStartPosition)
        Me.GroupBox19.Controls.Add(Me.Label69)
        Me.GroupBox19.Controls.Add(Me.EncodingSetRadio)
        Me.GroupBox19.Controls.Add(Me.EncodingGetRadio)
        Me.GroupBox19.Location = New System.Drawing.Point(4, 9)
        Me.GroupBox19.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox19.Size = New System.Drawing.Size(608, 62)
        Me.GroupBox19.TabIndex = 18
        Me.GroupBox19.TabStop = False
        '
        'MagStartButton
        '
        Me.MagStartButton.Location = New System.Drawing.Point(432, 25)
        Me.MagStartButton.Margin = New System.Windows.Forms.Padding(4)
        Me.MagStartButton.Name = "MagStartButton"
        Me.MagStartButton.Size = New System.Drawing.Size(151, 30)
        Me.MagStartButton.TabIndex = 32
        Me.MagStartButton.Text = "Mag Start"
        Me.MagStartButton.UseVisualStyleBackColor = True
        '
        'MagStartPosition
        '
        Me.MagStartPosition.Enabled = False
        Me.MagStartPosition.Location = New System.Drawing.Point(259, 27)
        Me.MagStartPosition.Margin = New System.Windows.Forms.Padding(4)
        Me.MagStartPosition.Maximum = New Decimal(New Integer() {85000, 0, 0, 0})
        Me.MagStartPosition.Name = "MagStartPosition"
        Me.MagStartPosition.Size = New System.Drawing.Size(141, 22)
        Me.MagStartPosition.TabIndex = 63
        Me.MagStartPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(155, 32)
        Me.Label69.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(92, 17)
        Me.Label69.TabIndex = 62
        Me.Label69.Text = "Start Position"
        '
        'EncodingSetRadio
        '
        Me.EncodingSetRadio.AutoSize = True
        Me.EncodingSetRadio.Location = New System.Drawing.Point(87, 30)
        Me.EncodingSetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.EncodingSetRadio.Name = "EncodingSetRadio"
        Me.EncodingSetRadio.Size = New System.Drawing.Size(50, 21)
        Me.EncodingSetRadio.TabIndex = 41
        Me.EncodingSetRadio.TabStop = True
        Me.EncodingSetRadio.Text = "Set"
        Me.EncodingSetRadio.UseVisualStyleBackColor = True
        '
        'EncodingGetRadio
        '
        Me.EncodingGetRadio.AutoSize = True
        Me.EncodingGetRadio.Checked = True
        Me.EncodingGetRadio.Location = New System.Drawing.Point(31, 30)
        Me.EncodingGetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.EncodingGetRadio.Name = "EncodingGetRadio"
        Me.EncodingGetRadio.Size = New System.Drawing.Size(52, 21)
        Me.EncodingGetRadio.TabIndex = 40
        Me.EncodingGetRadio.TabStop = True
        Me.EncodingGetRadio.Text = "Get"
        Me.EncodingGetRadio.UseVisualStyleBackColor = True
        '
        'groupBox9
        '
        Me.groupBox9.Controls.Add(Me.JIS2Label)
        Me.groupBox9.Controls.Add(Me.label112)
        Me.groupBox9.Controls.Add(Me.LRCLabel)
        Me.groupBox9.Controls.Add(Me.Track2Data)
        Me.groupBox9.Controls.Add(Me.ParityLabel)
        Me.groupBox9.Controls.Add(Me.BitsPerInchLabel)
        Me.groupBox9.Controls.Add(Me.EncodeMagButton)
        Me.groupBox9.Controls.Add(Me.BitsPerCharLabel)
        Me.groupBox9.Controls.Add(Me.Track3SettingsLabel)
        Me.groupBox9.Controls.Add(Me.Track2SettingsLabel)
        Me.groupBox9.Controls.Add(Me.Track1SettingsLabel)
        Me.groupBox9.Controls.Add(Me.label13)
        Me.groupBox9.Controls.Add(Me.Track3Label)
        Me.groupBox9.Controls.Add(Me.Track2Label)
        Me.groupBox9.Controls.Add(Me.Track1Data)
        Me.groupBox9.Controls.Add(Me.Track3Data)
        Me.groupBox9.Controls.Add(Me.Track1)
        Me.groupBox9.Controls.Add(Me.Track2)
        Me.groupBox9.Controls.Add(Me.Track3)
        Me.groupBox9.Controls.Add(Me.EncodingTypeCombo)
        Me.groupBox9.Controls.Add(Me.CoercivityCombo)
        Me.groupBox9.Controls.Add(Me.Verify)
        Me.groupBox9.Controls.Add(Me.T1_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T1_BPICombo)
        Me.groupBox9.Controls.Add(Me.T1_ParityCombo)
        Me.groupBox9.Controls.Add(Me.T1_LRCCombo)
        Me.groupBox9.Controls.Add(Me.T2_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T2_BPICombo)
        Me.groupBox9.Controls.Add(Me.T2_ParityCombo)
        Me.groupBox9.Controls.Add(Me.T2_LRCCombo)
        Me.groupBox9.Controls.Add(Me.T3_BPCCombo)
        Me.groupBox9.Controls.Add(Me.T3_BPICombo)
        Me.groupBox9.Controls.Add(Me.T3_ParityCombo)
        Me.groupBox9.Controls.Add(Me.T3_LRCCombo)
        Me.groupBox9.Controls.Add(Me.Track1Label)
        Me.groupBox9.Location = New System.Drawing.Point(4, 70)
        Me.groupBox9.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox9.Name = "groupBox9"
        Me.groupBox9.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox9.Size = New System.Drawing.Size(608, 287)
        Me.groupBox9.TabIndex = 17
        Me.groupBox9.TabStop = False
        '
        'JIS2Label
        '
        Me.JIS2Label.AutoSize = True
        Me.JIS2Label.Location = New System.Drawing.Point(11, 54)
        Me.JIS2Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.JIS2Label.Name = "JIS2Label"
        Me.JIS2Label.Size = New System.Drawing.Size(38, 17)
        Me.JIS2Label.TabIndex = 62
        Me.JIS2Label.Text = "Data"
        Me.JIS2Label.Visible = False
        '
        'label112
        '
        Me.label112.AutoSize = True
        Me.label112.Location = New System.Drawing.Point(177, 25)
        Me.label112.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label112.Name = "label112"
        Me.label112.Size = New System.Drawing.Size(69, 17)
        Me.label112.TabIndex = 60
        Me.label112.Text = "Coercivity"
        '
        'LRCLabel
        '
        Me.LRCLabel.AutoSize = True
        Me.LRCLabel.Location = New System.Drawing.Point(527, 135)
        Me.LRCLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LRCLabel.Name = "LRCLabel"
        Me.LRCLabel.Size = New System.Drawing.Size(35, 17)
        Me.LRCLabel.TabIndex = 59
        Me.LRCLabel.Text = "LRC"
        '
        'Track2Data
        '
        Me.Track2Data.Enabled = False
        Me.Track2Data.Location = New System.Drawing.Point(105, 79)
        Me.Track2Data.Margin = New System.Windows.Forms.Padding(4)
        Me.Track2Data.Name = "Track2Data"
        Me.Track2Data.Size = New System.Drawing.Size(493, 22)
        Me.Track2Data.TabIndex = 14
        '
        'ParityLabel
        '
        Me.ParityLabel.AutoSize = True
        Me.ParityLabel.Location = New System.Drawing.Point(395, 135)
        Me.ParityLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ParityLabel.Name = "ParityLabel"
        Me.ParityLabel.Size = New System.Drawing.Size(44, 17)
        Me.ParityLabel.TabIndex = 58
        Me.ParityLabel.Text = "Parity"
        '
        'BitsPerInchLabel
        '
        Me.BitsPerInchLabel.AutoSize = True
        Me.BitsPerInchLabel.Location = New System.Drawing.Point(243, 135)
        Me.BitsPerInchLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.BitsPerInchLabel.Name = "BitsPerInchLabel"
        Me.BitsPerInchLabel.Size = New System.Drawing.Size(87, 17)
        Me.BitsPerInchLabel.TabIndex = 57
        Me.BitsPerInchLabel.Text = "Bits Per Inch"
        '
        'EncodeMagButton
        '
        Me.EncodeMagButton.Location = New System.Drawing.Point(181, 250)
        Me.EncodeMagButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EncodeMagButton.Name = "EncodeMagButton"
        Me.EncodeMagButton.Size = New System.Drawing.Size(245, 30)
        Me.EncodeMagButton.TabIndex = 11
        Me.EncodeMagButton.Text = "EncodeMag"
        Me.EncodeMagButton.UseVisualStyleBackColor = True
        '
        'BitsPerCharLabel
        '
        Me.BitsPerCharLabel.AutoSize = True
        Me.BitsPerCharLabel.Location = New System.Drawing.Point(112, 135)
        Me.BitsPerCharLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.BitsPerCharLabel.Name = "BitsPerCharLabel"
        Me.BitsPerCharLabel.Size = New System.Drawing.Size(91, 17)
        Me.BitsPerCharLabel.TabIndex = 56
        Me.BitsPerCharLabel.Text = "Bits Per Char"
        '
        'Track3SettingsLabel
        '
        Me.Track3SettingsLabel.AutoSize = True
        Me.Track3SettingsLabel.Enabled = False
        Me.Track3SettingsLabel.Location = New System.Drawing.Point(11, 226)
        Me.Track3SettingsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track3SettingsLabel.Name = "Track3SettingsLabel"
        Me.Track3SettingsLabel.Size = New System.Drawing.Size(56, 17)
        Me.Track3SettingsLabel.TabIndex = 55
        Me.Track3SettingsLabel.Text = "Track 3"
        '
        'Track2SettingsLabel
        '
        Me.Track2SettingsLabel.AutoSize = True
        Me.Track2SettingsLabel.Enabled = False
        Me.Track2SettingsLabel.Location = New System.Drawing.Point(11, 193)
        Me.Track2SettingsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track2SettingsLabel.Name = "Track2SettingsLabel"
        Me.Track2SettingsLabel.Size = New System.Drawing.Size(56, 17)
        Me.Track2SettingsLabel.TabIndex = 54
        Me.Track2SettingsLabel.Text = "Track 2"
        '
        'Track1SettingsLabel
        '
        Me.Track1SettingsLabel.AutoSize = True
        Me.Track1SettingsLabel.Location = New System.Drawing.Point(11, 160)
        Me.Track1SettingsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track1SettingsLabel.Name = "Track1SettingsLabel"
        Me.Track1SettingsLabel.Size = New System.Drawing.Size(56, 17)
        Me.Track1SettingsLabel.TabIndex = 53
        Me.Track1SettingsLabel.Text = "Track 1"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(11, 25)
        Me.label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(40, 17)
        Me.label13.TabIndex = 52
        Me.label13.Text = "Type"
        '
        'Track3Label
        '
        Me.Track3Label.AutoSize = True
        Me.Track3Label.Enabled = False
        Me.Track3Label.Location = New System.Drawing.Point(11, 111)
        Me.Track3Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track3Label.Name = "Track3Label"
        Me.Track3Label.Size = New System.Drawing.Size(56, 17)
        Me.Track3Label.TabIndex = 50
        Me.Track3Label.Text = "Track 3"
        '
        'Track2Label
        '
        Me.Track2Label.AutoSize = True
        Me.Track2Label.Enabled = False
        Me.Track2Label.Location = New System.Drawing.Point(11, 82)
        Me.Track2Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track2Label.Name = "Track2Label"
        Me.Track2Label.Size = New System.Drawing.Size(56, 17)
        Me.Track2Label.TabIndex = 48
        Me.Track2Label.Text = "Track 2"
        '
        'Track1Data
        '
        Me.Track1Data.Location = New System.Drawing.Point(105, 50)
        Me.Track1Data.Margin = New System.Windows.Forms.Padding(4)
        Me.Track1Data.Name = "Track1Data"
        Me.Track1Data.Size = New System.Drawing.Size(493, 22)
        Me.Track1Data.TabIndex = 18
        Me.Track1Data.Text = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"
        '
        'Track3Data
        '
        Me.Track3Data.Enabled = False
        Me.Track3Data.Location = New System.Drawing.Point(105, 107)
        Me.Track3Data.Margin = New System.Windows.Forms.Padding(4)
        Me.Track3Data.Name = "Track3Data"
        Me.Track3Data.Size = New System.Drawing.Size(493, 22)
        Me.Track3Data.TabIndex = 19
        '
        'Track1
        '
        Me.Track1.AutoSize = True
        Me.Track1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track1.Checked = True
        Me.Track1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Track1.Location = New System.Drawing.Point(75, 53)
        Me.Track1.Margin = New System.Windows.Forms.Padding(4)
        Me.Track1.Name = "Track1"
        Me.Track1.Size = New System.Drawing.Size(18, 17)
        Me.Track1.TabIndex = 14
        Me.Track1.UseVisualStyleBackColor = True
        '
        'Track2
        '
        Me.Track2.AutoSize = True
        Me.Track2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track2.Location = New System.Drawing.Point(75, 81)
        Me.Track2.Margin = New System.Windows.Forms.Padding(4)
        Me.Track2.Name = "Track2"
        Me.Track2.Size = New System.Drawing.Size(18, 17)
        Me.Track2.TabIndex = 16
        Me.Track2.UseVisualStyleBackColor = True
        '
        'Track3
        '
        Me.Track3.AutoSize = True
        Me.Track3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track3.Location = New System.Drawing.Point(75, 110)
        Me.Track3.Margin = New System.Windows.Forms.Padding(4)
        Me.Track3.Name = "Track3"
        Me.Track3.Size = New System.Drawing.Size(18, 17)
        Me.Track3.TabIndex = 17
        Me.Track3.UseVisualStyleBackColor = True
        '
        'EncodingTypeCombo
        '
        Me.EncodingTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EncodingTypeCombo.Location = New System.Drawing.Point(63, 20)
        Me.EncodingTypeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.EncodingTypeCombo.Name = "EncodingTypeCombo"
        Me.EncodingTypeCombo.Size = New System.Drawing.Size(77, 24)
        Me.EncodingTypeCombo.TabIndex = 24
        '
        'CoercivityCombo
        '
        Me.CoercivityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CoercivityCombo.Location = New System.Drawing.Point(259, 20)
        Me.CoercivityCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.CoercivityCombo.Name = "CoercivityCombo"
        Me.CoercivityCombo.Size = New System.Drawing.Size(153, 24)
        Me.CoercivityCombo.TabIndex = 26
        '
        'Verify
        '
        Me.Verify.AutoSize = True
        Me.Verify.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Verify.Checked = True
        Me.Verify.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Verify.Location = New System.Drawing.Point(465, 22)
        Me.Verify.Margin = New System.Windows.Forms.Padding(4)
        Me.Verify.Name = "Verify"
        Me.Verify.Size = New System.Drawing.Size(66, 21)
        Me.Verify.TabIndex = 27
        Me.Verify.Text = "Verify"
        Me.Verify.UseVisualStyleBackColor = True
        '
        'T1_BPCCombo
        '
        Me.T1_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_BPCCombo.Location = New System.Drawing.Point(105, 155)
        Me.T1_BPCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_BPCCombo.Name = "T1_BPCCombo"
        Me.T1_BPCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T1_BPCCombo.TabIndex = 28
        '
        'T1_BPICombo
        '
        Me.T1_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_BPICombo.Location = New System.Drawing.Point(235, 155)
        Me.T1_BPICombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_BPICombo.Name = "T1_BPICombo"
        Me.T1_BPICombo.Size = New System.Drawing.Size(103, 24)
        Me.T1_BPICombo.TabIndex = 33
        '
        'T1_ParityCombo
        '
        Me.T1_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_ParityCombo.Location = New System.Drawing.Point(364, 155)
        Me.T1_ParityCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_ParityCombo.Name = "T1_ParityCombo"
        Me.T1_ParityCombo.Size = New System.Drawing.Size(103, 24)
        Me.T1_ParityCombo.TabIndex = 34
        '
        'T1_LRCCombo
        '
        Me.T1_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T1_LRCCombo.Location = New System.Drawing.Point(493, 155)
        Me.T1_LRCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_LRCCombo.Name = "T1_LRCCombo"
        Me.T1_LRCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T1_LRCCombo.TabIndex = 35
        '
        'T2_BPCCombo
        '
        Me.T2_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_BPCCombo.Enabled = False
        Me.T2_BPCCombo.Location = New System.Drawing.Point(105, 188)
        Me.T2_BPCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_BPCCombo.Name = "T2_BPCCombo"
        Me.T2_BPCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T2_BPCCombo.TabIndex = 36
        '
        'T2_BPICombo
        '
        Me.T2_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_BPICombo.Enabled = False
        Me.T2_BPICombo.Location = New System.Drawing.Point(235, 188)
        Me.T2_BPICombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_BPICombo.Name = "T2_BPICombo"
        Me.T2_BPICombo.Size = New System.Drawing.Size(103, 24)
        Me.T2_BPICombo.TabIndex = 38
        '
        'T2_ParityCombo
        '
        Me.T2_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_ParityCombo.Enabled = False
        Me.T2_ParityCombo.Location = New System.Drawing.Point(364, 188)
        Me.T2_ParityCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_ParityCombo.Name = "T2_ParityCombo"
        Me.T2_ParityCombo.Size = New System.Drawing.Size(103, 24)
        Me.T2_ParityCombo.TabIndex = 40
        '
        'T2_LRCCombo
        '
        Me.T2_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T2_LRCCombo.Enabled = False
        Me.T2_LRCCombo.Location = New System.Drawing.Point(493, 188)
        Me.T2_LRCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_LRCCombo.Name = "T2_LRCCombo"
        Me.T2_LRCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T2_LRCCombo.TabIndex = 42
        '
        'T3_BPCCombo
        '
        Me.T3_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_BPCCombo.Enabled = False
        Me.T3_BPCCombo.Location = New System.Drawing.Point(105, 222)
        Me.T3_BPCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T3_BPCCombo.Name = "T3_BPCCombo"
        Me.T3_BPCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T3_BPCCombo.TabIndex = 37
        '
        'T3_BPICombo
        '
        Me.T3_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_BPICombo.Enabled = False
        Me.T3_BPICombo.Location = New System.Drawing.Point(235, 222)
        Me.T3_BPICombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T3_BPICombo.Name = "T3_BPICombo"
        Me.T3_BPICombo.Size = New System.Drawing.Size(103, 24)
        Me.T3_BPICombo.TabIndex = 39
        '
        'T3_ParityCombo
        '
        Me.T3_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_ParityCombo.Enabled = False
        Me.T3_ParityCombo.Location = New System.Drawing.Point(364, 222)
        Me.T3_ParityCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T3_ParityCombo.Name = "T3_ParityCombo"
        Me.T3_ParityCombo.Size = New System.Drawing.Size(103, 24)
        Me.T3_ParityCombo.TabIndex = 41
        '
        'T3_LRCCombo
        '
        Me.T3_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.T3_LRCCombo.Enabled = False
        Me.T3_LRCCombo.Location = New System.Drawing.Point(493, 222)
        Me.T3_LRCCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.T3_LRCCombo.Name = "T3_LRCCombo"
        Me.T3_LRCCombo.Size = New System.Drawing.Size(103, 24)
        Me.T3_LRCCombo.TabIndex = 43
        '
        'Track1Label
        '
        Me.Track1Label.AutoSize = True
        Me.Track1Label.Location = New System.Drawing.Point(11, 54)
        Me.Track1Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Track1Label.Name = "Track1Label"
        Me.Track1Label.Size = New System.Drawing.Size(56, 17)
        Me.Track1Label.TabIndex = 61
        Me.Track1Label.Text = "Track 1"
        '
        'groupBox8
        '
        Me.groupBox8.Controls.Add(Me.ReadMagTracks)
        Me.groupBox8.Controls.Add(Me.Track2Read)
        Me.groupBox8.Controls.Add(Me.Track3Read)
        Me.groupBox8.Controls.Add(Me.Track1Read)
        Me.groupBox8.Controls.Add(Me.ReadMagButton)
        Me.groupBox8.Controls.Add(Me.ClearEncodingBoxButton)
        Me.groupBox8.Controls.Add(Me.EncodingBox)
        Me.groupBox8.Location = New System.Drawing.Point(4, 357)
        Me.groupBox8.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox8.Name = "groupBox8"
        Me.groupBox8.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox8.Size = New System.Drawing.Size(603, 340)
        Me.groupBox8.TabIndex = 16
        Me.groupBox8.TabStop = False
        '
        'ReadMagTracks
        '
        Me.ReadMagTracks.Location = New System.Drawing.Point(265, 16)
        Me.ReadMagTracks.Margin = New System.Windows.Forms.Padding(4)
        Me.ReadMagTracks.Name = "ReadMagTracks"
        Me.ReadMagTracks.Size = New System.Drawing.Size(151, 30)
        Me.ReadMagTracks.TabIndex = 35
        Me.ReadMagTracks.Text = "ReadMagTracks"
        Me.ReadMagTracks.UseVisualStyleBackColor = True
        '
        'Track2Read
        '
        Me.Track2Read.AutoSize = True
        Me.Track2Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track2Read.Location = New System.Drawing.Point(93, 21)
        Me.Track2Read.Margin = New System.Windows.Forms.Padding(4)
        Me.Track2Read.Name = "Track2Read"
        Me.Track2Read.Size = New System.Drawing.Size(78, 21)
        Me.Track2Read.TabIndex = 34
        Me.Track2Read.Text = "Track 2"
        Me.Track2Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Track2Read.UseVisualStyleBackColor = True
        '
        'Track3Read
        '
        Me.Track3Read.AutoSize = True
        Me.Track3Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track3Read.Location = New System.Drawing.Point(173, 21)
        Me.Track3Read.Margin = New System.Windows.Forms.Padding(4)
        Me.Track3Read.Name = "Track3Read"
        Me.Track3Read.Size = New System.Drawing.Size(78, 21)
        Me.Track3Read.TabIndex = 33
        Me.Track3Read.Text = "Track 3"
        Me.Track3Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Track3Read.UseVisualStyleBackColor = True
        '
        'Track1Read
        '
        Me.Track1Read.AutoSize = True
        Me.Track1Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Track1Read.Location = New System.Drawing.Point(11, 21)
        Me.Track1Read.Margin = New System.Windows.Forms.Padding(4)
        Me.Track1Read.Name = "Track1Read"
        Me.Track1Read.Size = New System.Drawing.Size(78, 21)
        Me.Track1Read.TabIndex = 32
        Me.Track1Read.Text = "Track 1"
        Me.Track1Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Track1Read.UseVisualStyleBackColor = True
        '
        'ReadMagButton
        '
        Me.ReadMagButton.Location = New System.Drawing.Point(449, 16)
        Me.ReadMagButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReadMagButton.Name = "ReadMagButton"
        Me.ReadMagButton.Size = New System.Drawing.Size(151, 30)
        Me.ReadMagButton.TabIndex = 12
        Me.ReadMagButton.Text = "ReadMag"
        Me.ReadMagButton.UseVisualStyleBackColor = True
        '
        'ClearEncodingBoxButton
        '
        Me.ClearEncodingBoxButton.Location = New System.Drawing.Point(239, 304)
        Me.ClearEncodingBoxButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearEncodingBoxButton.Name = "ClearEncodingBoxButton"
        Me.ClearEncodingBoxButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearEncodingBoxButton.TabIndex = 13
        Me.ClearEncodingBoxButton.Text = "Clear"
        Me.ClearEncodingBoxButton.UseVisualStyleBackColor = True
        '
        'EncodingBox
        '
        Me.EncodingBox.Location = New System.Drawing.Point(8, 53)
        Me.EncodingBox.Margin = New System.Windows.Forms.Padding(4)
        Me.EncodingBox.Multiline = True
        Me.EncodingBox.Name = "EncodingBox"
        Me.EncodingBox.ReadOnly = True
        Me.EncodingBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.EncodingBox.Size = New System.Drawing.Size(591, 244)
        Me.EncodingBox.TabIndex = 9
        Me.EncodingBox.WordWrap = False
        '
        'Driver1
        '
        Me.Driver1.Controls.Add(Me.GroupBox6)
        Me.Driver1.Controls.Add(Me.groupBox7)
        Me.Driver1.Controls.Add(Me.GUIPrinterCheck)
        Me.Driver1.Controls.Add(Me.GUIUserCheck)
        Me.Driver1.Controls.Add(Me.groupBox13)
        Me.Driver1.Controls.Add(Me.groupBox12)
        Me.Driver1.Controls.Add(Me.groupBox11)
        Me.Driver1.Controls.Add(Me.groupBox10)
        Me.Driver1.Controls.Add(Me.PrintSpeedButton)
        Me.Driver1.Controls.Add(Me.PrintSpeedCombo)
        Me.Driver1.Controls.Add(Me.ColourCorrectionButton)
        Me.Driver1.Controls.Add(Me.CorrectionCombo)
        Me.Driver1.Controls.Add(Me.SharpnessUpDown)
        Me.Driver1.Controls.Add(Me.GUIControlButton)
        Me.Driver1.Controls.Add(Me.SharpnessButton)
        Me.Driver1.Controls.Add(Me.label16)
        Me.Driver1.Controls.Add(Me.Driver1SetRadio)
        Me.Driver1.Controls.Add(Me.Driver1GetRadio)
        Me.Driver1.Controls.Add(Me.ClearDriver1MsgBoxButton)
        Me.Driver1.Controls.Add(Me.Driver1MsgBox)
        Me.Driver1.Location = New System.Drawing.Point(4, 25)
        Me.Driver1.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver1.Name = "Driver1"
        Me.Driver1.Size = New System.Drawing.Size(621, 700)
        Me.Driver1.TabIndex = 3
        Me.Driver1.Text = "Driver 1"
        Me.Driver1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Radio600DPI)
        Me.GroupBox6.Controls.Add(Me.ResolutionButton)
        Me.GroupBox6.Controls.Add(Me.Radio300DPI)
        Me.GroupBox6.Location = New System.Drawing.Point(277, 4)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Size = New System.Drawing.Size(333, 76)
        Me.GroupBox6.TabIndex = 83
        Me.GroupBox6.TabStop = False
        '
        'Radio600DPI
        '
        Me.Radio600DPI.AutoSize = True
        Me.Radio600DPI.Enabled = False
        Me.Radio600DPI.Location = New System.Drawing.Point(21, 43)
        Me.Radio600DPI.Margin = New System.Windows.Forms.Padding(4)
        Me.Radio600DPI.Name = "Radio600DPI"
        Me.Radio600DPI.Size = New System.Drawing.Size(117, 21)
        Me.Radio600DPI.TabIndex = 70
        Me.Radio600DPI.TabStop = True
        Me.Radio600DPI.Text = "600 x 300 DPI"
        Me.Radio600DPI.UseVisualStyleBackColor = True
        '
        'ResolutionButton
        '
        Me.ResolutionButton.Enabled = False
        Me.ResolutionButton.Location = New System.Drawing.Point(193, 27)
        Me.ResolutionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ResolutionButton.Name = "ResolutionButton"
        Me.ResolutionButton.Size = New System.Drawing.Size(101, 30)
        Me.ResolutionButton.TabIndex = 50
        Me.ResolutionButton.Text = "Resolution"
        Me.ResolutionButton.UseVisualStyleBackColor = True
        '
        'Radio300DPI
        '
        Me.Radio300DPI.AutoSize = True
        Me.Radio300DPI.Checked = True
        Me.Radio300DPI.Enabled = False
        Me.Radio300DPI.Location = New System.Drawing.Point(21, 20)
        Me.Radio300DPI.Margin = New System.Windows.Forms.Padding(4)
        Me.Radio300DPI.Name = "Radio300DPI"
        Me.Radio300DPI.Size = New System.Drawing.Size(117, 21)
        Me.Radio300DPI.TabIndex = 69
        Me.Radio300DPI.TabStop = True
        Me.Radio300DPI.Text = "300 x 300 DPI"
        Me.Radio300DPI.UseVisualStyleBackColor = True
        '
        'groupBox7
        '
        Me.groupBox7.Controls.Add(Me.Label9)
        Me.groupBox7.Controls.Add(Me.PrintableAreaHeightUpDown)
        Me.groupBox7.Controls.Add(Me.PrintableAreaBottomUpDown)
        Me.groupBox7.Controls.Add(Me.PrintableAreaWidthUpDown)
        Me.groupBox7.Controls.Add(Me.PrintableAreaLeftUpDown)
        Me.groupBox7.Controls.Add(Me.Label70)
        Me.groupBox7.Controls.Add(Me.Label71)
        Me.groupBox7.Controls.Add(Me.Label72)
        Me.groupBox7.Controls.Add(Me.PrintableAreaButton)
        Me.groupBox7.Location = New System.Drawing.Point(277, 78)
        Me.groupBox7.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox7.Name = "groupBox7"
        Me.groupBox7.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox7.Size = New System.Drawing.Size(333, 103)
        Me.groupBox7.TabIndex = 82
        Me.groupBox7.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(255, 15)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(18, 17)
        Me.Label9.TabIndex = 59
        Me.Label9.Text = "H"
        '
        'PrintableAreaHeightUpDown
        '
        Me.PrintableAreaHeightUpDown.Enabled = False
        Me.PrintableAreaHeightUpDown.Location = New System.Drawing.Point(235, 34)
        Me.PrintableAreaHeightUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintableAreaHeightUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.PrintableAreaHeightUpDown.Name = "PrintableAreaHeightUpDown"
        Me.PrintableAreaHeightUpDown.Size = New System.Drawing.Size(60, 22)
        Me.PrintableAreaHeightUpDown.TabIndex = 58
        Me.PrintableAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PrintableAreaBottomUpDown
        '
        Me.PrintableAreaBottomUpDown.Enabled = False
        Me.PrintableAreaBottomUpDown.Location = New System.Drawing.Point(175, 34)
        Me.PrintableAreaBottomUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintableAreaBottomUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.PrintableAreaBottomUpDown.Name = "PrintableAreaBottomUpDown"
        Me.PrintableAreaBottomUpDown.Size = New System.Drawing.Size(60, 22)
        Me.PrintableAreaBottomUpDown.TabIndex = 54
        Me.PrintableAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PrintableAreaWidthUpDown
        '
        Me.PrintableAreaWidthUpDown.Enabled = False
        Me.PrintableAreaWidthUpDown.Location = New System.Drawing.Point(115, 34)
        Me.PrintableAreaWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintableAreaWidthUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.PrintableAreaWidthUpDown.Name = "PrintableAreaWidthUpDown"
        Me.PrintableAreaWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.PrintableAreaWidthUpDown.TabIndex = 53
        Me.PrintableAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PrintableAreaLeftUpDown
        '
        Me.PrintableAreaLeftUpDown.Enabled = False
        Me.PrintableAreaLeftUpDown.Location = New System.Drawing.Point(55, 34)
        Me.PrintableAreaLeftUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintableAreaLeftUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.PrintableAreaLeftUpDown.Name = "PrintableAreaLeftUpDown"
        Me.PrintableAreaLeftUpDown.Size = New System.Drawing.Size(60, 22)
        Me.PrintableAreaLeftUpDown.TabIndex = 50
        Me.PrintableAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(195, 15)
        Me.Label70.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(17, 17)
        Me.Label70.TabIndex = 52
        Me.Label70.Text = "B"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(132, 15)
        Me.Label71.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(21, 17)
        Me.Label71.TabIndex = 51
        Me.Label71.Text = "W"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(76, 15)
        Me.Label72.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(16, 17)
        Me.Label72.TabIndex = 50
        Me.Label72.Text = "L"
        '
        'PrintableAreaButton
        '
        Me.PrintableAreaButton.Location = New System.Drawing.Point(117, 66)
        Me.PrintableAreaButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintableAreaButton.Name = "PrintableAreaButton"
        Me.PrintableAreaButton.Size = New System.Drawing.Size(120, 30)
        Me.PrintableAreaButton.TabIndex = 50
        Me.PrintableAreaButton.Text = "PrintableArea"
        Me.PrintableAreaButton.UseVisualStyleBackColor = True
        '
        'GUIPrinterCheck
        '
        Me.GUIPrinterCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.GUIPrinterCheck.Location = New System.Drawing.Point(192, 27)
        Me.GUIPrinterCheck.Margin = New System.Windows.Forms.Padding(4)
        Me.GUIPrinterCheck.Name = "GUIPrinterCheck"
        Me.GUIPrinterCheck.Size = New System.Drawing.Size(76, 30)
        Me.GUIPrinterCheck.TabIndex = 81
        Me.GUIPrinterCheck.Text = "Printer"
        Me.GUIPrinterCheck.UseVisualStyleBackColor = True
        '
        'GUIUserCheck
        '
        Me.GUIUserCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.GUIUserCheck.Location = New System.Drawing.Point(128, 27)
        Me.GUIUserCheck.Margin = New System.Windows.Forms.Padding(4)
        Me.GUIUserCheck.Name = "GUIUserCheck"
        Me.GUIUserCheck.Size = New System.Drawing.Size(64, 30)
        Me.GUIUserCheck.TabIndex = 80
        Me.GUIUserCheck.Text = "User"
        Me.GUIUserCheck.UseVisualStyleBackColor = True
        '
        'groupBox13
        '
        Me.groupBox13.Controls.Add(Me.EraseBeforePrint)
        Me.groupBox13.Controls.Add(Me.EraseEndPowerLabel)
        Me.groupBox13.Controls.Add(Me.ErasePowerEndUpDown)
        Me.groupBox13.Controls.Add(Me.WritePowerUpDown)
        Me.groupBox13.Controls.Add(Me.WritePowerLabel)
        Me.groupBox13.Controls.Add(Me.label40)
        Me.groupBox13.Controls.Add(Me.label34)
        Me.groupBox13.Controls.Add(Me.label35)
        Me.groupBox13.Controls.Add(Me.EraseAreaHeightUpDown)
        Me.groupBox13.Controls.Add(Me.ErasePowerStartUpDown)
        Me.groupBox13.Controls.Add(Me.label36)
        Me.groupBox13.Controls.Add(Me.label37)
        Me.groupBox13.Controls.Add(Me.EraseAreaWidthUpDown)
        Me.groupBox13.Controls.Add(Me.EraseAreaBottomUpDown)
        Me.groupBox13.Controls.Add(Me.EraseAreaLeftUpDown)
        Me.groupBox13.Controls.Add(Me.label38)
        Me.groupBox13.Controls.Add(Me.label39)
        Me.groupBox13.Controls.Add(Me.RewritableButton)
        Me.groupBox13.Location = New System.Drawing.Point(8, 505)
        Me.groupBox13.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox13.Name = "groupBox13"
        Me.groupBox13.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox13.Size = New System.Drawing.Size(255, 186)
        Me.groupBox13.TabIndex = 79
        Me.groupBox13.TabStop = False
        '
        'EraseBeforePrint
        '
        Me.EraseBeforePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.EraseBeforePrint.Location = New System.Drawing.Point(8, 117)
        Me.EraseBeforePrint.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseBeforePrint.Name = "EraseBeforePrint"
        Me.EraseBeforePrint.Size = New System.Drawing.Size(116, 37)
        Me.EraseBeforePrint.TabIndex = 66
        Me.EraseBeforePrint.Text = "Erase Before Print"
        Me.EraseBeforePrint.UseVisualStyleBackColor = True
        '
        'EraseEndPowerLabel
        '
        Me.EraseEndPowerLabel.AutoSize = True
        Me.EraseEndPowerLabel.Location = New System.Drawing.Point(128, 97)
        Me.EraseEndPowerLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EraseEndPowerLabel.Name = "EraseEndPowerLabel"
        Me.EraseEndPowerLabel.Size = New System.Drawing.Size(33, 17)
        Me.EraseEndPowerLabel.TabIndex = 65
        Me.EraseEndPowerLabel.Text = "End"
        '
        'ErasePowerEndUpDown
        '
        Me.ErasePowerEndUpDown.Enabled = False
        Me.ErasePowerEndUpDown.Location = New System.Drawing.Point(179, 92)
        Me.ErasePowerEndUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ErasePowerEndUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ErasePowerEndUpDown.Name = "ErasePowerEndUpDown"
        Me.ErasePowerEndUpDown.Size = New System.Drawing.Size(65, 22)
        Me.ErasePowerEndUpDown.TabIndex = 64
        Me.ErasePowerEndUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'WritePowerUpDown
        '
        Me.WritePowerUpDown.Enabled = False
        Me.WritePowerUpDown.Location = New System.Drawing.Point(179, 118)
        Me.WritePowerUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.WritePowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.WritePowerUpDown.Name = "WritePowerUpDown"
        Me.WritePowerUpDown.Size = New System.Drawing.Size(65, 22)
        Me.WritePowerUpDown.TabIndex = 63
        Me.WritePowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'WritePowerLabel
        '
        Me.WritePowerLabel.AutoSize = True
        Me.WritePowerLabel.Location = New System.Drawing.Point(128, 123)
        Me.WritePowerLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.WritePowerLabel.Name = "WritePowerLabel"
        Me.WritePowerLabel.Size = New System.Drawing.Size(41, 17)
        Me.WritePowerLabel.TabIndex = 62
        Me.WritePowerLabel.Text = "Write"
        '
        'label40
        '
        Me.label40.AutoSize = True
        Me.label40.Location = New System.Drawing.Point(8, 76)
        Me.label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label40.Name = "label40"
        Me.label40.Size = New System.Drawing.Size(51, 17)
        Me.label40.TabIndex = 61
        Me.label40.Text = "Power:"
        '
        'label34
        '
        Me.label34.AutoSize = True
        Me.label34.Location = New System.Drawing.Point(25, 27)
        Me.label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label34.Name = "label34"
        Me.label34.Size = New System.Drawing.Size(16, 17)
        Me.label34.TabIndex = 60
        Me.label34.Text = "L"
        '
        'label35
        '
        Me.label35.AutoSize = True
        Me.label35.Location = New System.Drawing.Point(204, 27)
        Me.label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label35.Name = "label35"
        Me.label35.Size = New System.Drawing.Size(18, 17)
        Me.label35.TabIndex = 59
        Me.label35.Text = "H"
        '
        'EraseAreaHeightUpDown
        '
        Me.EraseAreaHeightUpDown.Enabled = False
        Me.EraseAreaHeightUpDown.Location = New System.Drawing.Point(184, 48)
        Me.EraseAreaHeightUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseAreaHeightUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.EraseAreaHeightUpDown.Name = "EraseAreaHeightUpDown"
        Me.EraseAreaHeightUpDown.Size = New System.Drawing.Size(60, 22)
        Me.EraseAreaHeightUpDown.TabIndex = 58
        Me.EraseAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ErasePowerStartUpDown
        '
        Me.ErasePowerStartUpDown.Enabled = False
        Me.ErasePowerStartUpDown.Location = New System.Drawing.Point(60, 92)
        Me.ErasePowerStartUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ErasePowerStartUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ErasePowerStartUpDown.Name = "ErasePowerStartUpDown"
        Me.ErasePowerStartUpDown.Size = New System.Drawing.Size(65, 22)
        Me.ErasePowerStartUpDown.TabIndex = 56
        Me.ErasePowerStartUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label36
        '
        Me.label36.AutoSize = True
        Me.label36.Location = New System.Drawing.Point(8, 97)
        Me.label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label36.Name = "label36"
        Me.label36.Size = New System.Drawing.Size(38, 17)
        Me.label36.TabIndex = 57
        Me.label36.Text = "Start"
        '
        'label37
        '
        Me.label37.AutoSize = True
        Me.label37.Location = New System.Drawing.Point(8, 6)
        Me.label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label37.Name = "label37"
        Me.label37.Size = New System.Drawing.Size(79, 17)
        Me.label37.TabIndex = 56
        Me.label37.Text = "Erase Area"
        '
        'EraseAreaWidthUpDown
        '
        Me.EraseAreaWidthUpDown.Enabled = False
        Me.EraseAreaWidthUpDown.Location = New System.Drawing.Point(64, 48)
        Me.EraseAreaWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseAreaWidthUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.EraseAreaWidthUpDown.Name = "EraseAreaWidthUpDown"
        Me.EraseAreaWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.EraseAreaWidthUpDown.TabIndex = 54
        Me.EraseAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EraseAreaBottomUpDown
        '
        Me.EraseAreaBottomUpDown.Enabled = False
        Me.EraseAreaBottomUpDown.Location = New System.Drawing.Point(124, 48)
        Me.EraseAreaBottomUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseAreaBottomUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.EraseAreaBottomUpDown.Name = "EraseAreaBottomUpDown"
        Me.EraseAreaBottomUpDown.Size = New System.Drawing.Size(60, 22)
        Me.EraseAreaBottomUpDown.TabIndex = 53
        Me.EraseAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'EraseAreaLeftUpDown
        '
        Me.EraseAreaLeftUpDown.Enabled = False
        Me.EraseAreaLeftUpDown.Location = New System.Drawing.Point(4, 48)
        Me.EraseAreaLeftUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.EraseAreaLeftUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.EraseAreaLeftUpDown.Name = "EraseAreaLeftUpDown"
        Me.EraseAreaLeftUpDown.Size = New System.Drawing.Size(60, 22)
        Me.EraseAreaLeftUpDown.TabIndex = 50
        Me.EraseAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label38
        '
        Me.label38.AutoSize = True
        Me.label38.Location = New System.Drawing.Point(144, 27)
        Me.label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label38.Name = "label38"
        Me.label38.Size = New System.Drawing.Size(17, 17)
        Me.label38.TabIndex = 52
        Me.label38.Text = "B"
        '
        'label39
        '
        Me.label39.AutoSize = True
        Me.label39.Location = New System.Drawing.Point(81, 27)
        Me.label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label39.Name = "label39"
        Me.label39.Size = New System.Drawing.Size(21, 17)
        Me.label39.TabIndex = 51
        Me.label39.Text = "W"
        '
        'RewritableButton
        '
        Me.RewritableButton.Location = New System.Drawing.Point(76, 153)
        Me.RewritableButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RewritableButton.Name = "RewritableButton"
        Me.RewritableButton.Size = New System.Drawing.Size(120, 30)
        Me.RewritableButton.TabIndex = 50
        Me.RewritableButton.Text = "Rewritable"
        Me.RewritableButton.UseVisualStyleBackColor = True
        '
        'groupBox12
        '
        Me.groupBox12.Controls.Add(Me.AreaHoleTypeCombo)
        Me.groupBox12.Controls.Add(Me.label33)
        Me.groupBox12.Controls.Add(Me.label27)
        Me.groupBox12.Controls.Add(Me.AreaHoleHeightUpDown)
        Me.groupBox12.Controls.Add(Me.AreaHoleNoUpDown)
        Me.groupBox12.Controls.Add(Me.label28)
        Me.groupBox12.Controls.Add(Me.AreaHoleSideCombo)
        Me.groupBox12.Controls.Add(Me.label29)
        Me.groupBox12.Controls.Add(Me.AreaHoleBottomUpDown)
        Me.groupBox12.Controls.Add(Me.AreaHoleWidthUpDown)
        Me.groupBox12.Controls.Add(Me.AreaHoleLeftUpDown)
        Me.groupBox12.Controls.Add(Me.label30)
        Me.groupBox12.Controls.Add(Me.label31)
        Me.groupBox12.Controls.Add(Me.label32)
        Me.groupBox12.Controls.Add(Me.AreaHoleButton)
        Me.groupBox12.Location = New System.Drawing.Point(8, 358)
        Me.groupBox12.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox12.Name = "groupBox12"
        Me.groupBox12.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox12.Size = New System.Drawing.Size(255, 146)
        Me.groupBox12.TabIndex = 78
        Me.groupBox12.TabStop = False
        '
        'AreaHoleTypeCombo
        '
        Me.AreaHoleTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AreaHoleTypeCombo.FormattingEnabled = True
        Me.AreaHoleTypeCombo.Location = New System.Drawing.Point(49, 37)
        Me.AreaHoleTypeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleTypeCombo.Name = "AreaHoleTypeCombo"
        Me.AreaHoleTypeCombo.Size = New System.Drawing.Size(80, 24)
        Me.AreaHoleTypeCombo.TabIndex = 61
        '
        'label33
        '
        Me.label33.AutoSize = True
        Me.label33.Location = New System.Drawing.Point(8, 42)
        Me.label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label33.Name = "label33"
        Me.label33.Size = New System.Drawing.Size(40, 17)
        Me.label33.TabIndex = 60
        Me.label33.Text = "Type"
        '
        'label27
        '
        Me.label27.AutoSize = True
        Me.label27.Location = New System.Drawing.Point(204, 66)
        Me.label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label27.Name = "label27"
        Me.label27.Size = New System.Drawing.Size(18, 17)
        Me.label27.TabIndex = 59
        Me.label27.Text = "H"
        '
        'AreaHoleHeightUpDown
        '
        Me.AreaHoleHeightUpDown.Enabled = False
        Me.AreaHoleHeightUpDown.Location = New System.Drawing.Point(184, 85)
        Me.AreaHoleHeightUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleHeightUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.AreaHoleHeightUpDown.Name = "AreaHoleHeightUpDown"
        Me.AreaHoleHeightUpDown.Size = New System.Drawing.Size(60, 22)
        Me.AreaHoleHeightUpDown.TabIndex = 58
        Me.AreaHoleHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AreaHoleNoUpDown
        '
        Me.AreaHoleNoUpDown.Location = New System.Drawing.Point(179, 37)
        Me.AreaHoleNoUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleNoUpDown.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.AreaHoleNoUpDown.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.AreaHoleNoUpDown.Name = "AreaHoleNoUpDown"
        Me.AreaHoleNoUpDown.Size = New System.Drawing.Size(65, 22)
        Me.AreaHoleNoUpDown.TabIndex = 56
        Me.AreaHoleNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.AreaHoleNoUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label28
        '
        Me.label28.AutoSize = True
        Me.label28.Location = New System.Drawing.Point(139, 42)
        Me.label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label28.Name = "label28"
        Me.label28.Size = New System.Drawing.Size(30, 17)
        Me.label28.TabIndex = 57
        Me.label28.Text = "No."
        '
        'AreaHoleSideCombo
        '
        Me.AreaHoleSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.AreaHoleSideCombo.FormattingEnabled = True
        Me.AreaHoleSideCombo.Location = New System.Drawing.Point(49, 11)
        Me.AreaHoleSideCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleSideCombo.Name = "AreaHoleSideCombo"
        Me.AreaHoleSideCombo.Size = New System.Drawing.Size(80, 24)
        Me.AreaHoleSideCombo.TabIndex = 56
        '
        'label29
        '
        Me.label29.AutoSize = True
        Me.label29.Location = New System.Drawing.Point(8, 16)
        Me.label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label29.Name = "label29"
        Me.label29.Size = New System.Drawing.Size(36, 17)
        Me.label29.TabIndex = 56
        Me.label29.Text = "Side"
        '
        'AreaHoleBottomUpDown
        '
        Me.AreaHoleBottomUpDown.Enabled = False
        Me.AreaHoleBottomUpDown.Location = New System.Drawing.Point(124, 85)
        Me.AreaHoleBottomUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleBottomUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.AreaHoleBottomUpDown.Name = "AreaHoleBottomUpDown"
        Me.AreaHoleBottomUpDown.Size = New System.Drawing.Size(60, 22)
        Me.AreaHoleBottomUpDown.TabIndex = 54
        Me.AreaHoleBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AreaHoleWidthUpDown
        '
        Me.AreaHoleWidthUpDown.Enabled = False
        Me.AreaHoleWidthUpDown.Location = New System.Drawing.Point(64, 85)
        Me.AreaHoleWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleWidthUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.AreaHoleWidthUpDown.Name = "AreaHoleWidthUpDown"
        Me.AreaHoleWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.AreaHoleWidthUpDown.TabIndex = 53
        Me.AreaHoleWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'AreaHoleLeftUpDown
        '
        Me.AreaHoleLeftUpDown.Enabled = False
        Me.AreaHoleLeftUpDown.Location = New System.Drawing.Point(4, 85)
        Me.AreaHoleLeftUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleLeftUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.AreaHoleLeftUpDown.Name = "AreaHoleLeftUpDown"
        Me.AreaHoleLeftUpDown.Size = New System.Drawing.Size(60, 22)
        Me.AreaHoleLeftUpDown.TabIndex = 50
        Me.AreaHoleLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label30
        '
        Me.label30.AutoSize = True
        Me.label30.Location = New System.Drawing.Point(144, 66)
        Me.label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(17, 17)
        Me.label30.TabIndex = 52
        Me.label30.Text = "B"
        '
        'label31
        '
        Me.label31.AutoSize = True
        Me.label31.Location = New System.Drawing.Point(81, 66)
        Me.label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(21, 17)
        Me.label31.TabIndex = 51
        Me.label31.Text = "W"
        '
        'label32
        '
        Me.label32.AutoSize = True
        Me.label32.Location = New System.Drawing.Point(25, 66)
        Me.label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label32.Name = "label32"
        Me.label32.Size = New System.Drawing.Size(16, 17)
        Me.label32.TabIndex = 50
        Me.label32.Text = "L"
        '
        'AreaHoleButton
        '
        Me.AreaHoleButton.Location = New System.Drawing.Point(76, 112)
        Me.AreaHoleButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AreaHoleButton.Name = "AreaHoleButton"
        Me.AreaHoleButton.Size = New System.Drawing.Size(120, 30)
        Me.AreaHoleButton.TabIndex = 50
        Me.AreaHoleButton.Text = "Area/Hole"
        Me.AreaHoleButton.UseVisualStyleBackColor = True
        '
        'groupBox11
        '
        Me.groupBox11.Controls.Add(Me.label26)
        Me.groupBox11.Controls.Add(Me.ResinAreaHeightUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaNoUpDown)
        Me.groupBox11.Controls.Add(Me.label25)
        Me.groupBox11.Controls.Add(Me.ResinAreaSideCombo)
        Me.groupBox11.Controls.Add(Me.label24)
        Me.groupBox11.Controls.Add(Me.ResinAreaBottomUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaWidthUpDown)
        Me.groupBox11.Controls.Add(Me.ResinAreaLeftUpDown)
        Me.groupBox11.Controls.Add(Me.label21)
        Me.groupBox11.Controls.Add(Me.label22)
        Me.groupBox11.Controls.Add(Me.label23)
        Me.groupBox11.Controls.Add(Me.ResinAreaButton)
        Me.groupBox11.Location = New System.Drawing.Point(8, 238)
        Me.groupBox11.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox11.Name = "groupBox11"
        Me.groupBox11.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox11.Size = New System.Drawing.Size(255, 121)
        Me.groupBox11.TabIndex = 77
        Me.groupBox11.TabStop = False
        '
        'label26
        '
        Me.label26.AutoSize = True
        Me.label26.Location = New System.Drawing.Point(204, 41)
        Me.label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label26.Name = "label26"
        Me.label26.Size = New System.Drawing.Size(18, 17)
        Me.label26.TabIndex = 59
        Me.label26.Text = "H"
        '
        'ResinAreaHeightUpDown
        '
        Me.ResinAreaHeightUpDown.Enabled = False
        Me.ResinAreaHeightUpDown.Location = New System.Drawing.Point(184, 59)
        Me.ResinAreaHeightUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaHeightUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ResinAreaHeightUpDown.Name = "ResinAreaHeightUpDown"
        Me.ResinAreaHeightUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ResinAreaHeightUpDown.TabIndex = 58
        Me.ResinAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaNoUpDown
        '
        Me.ResinAreaNoUpDown.Location = New System.Drawing.Point(179, 11)
        Me.ResinAreaNoUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaNoUpDown.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.ResinAreaNoUpDown.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ResinAreaNoUpDown.Name = "ResinAreaNoUpDown"
        Me.ResinAreaNoUpDown.Size = New System.Drawing.Size(65, 22)
        Me.ResinAreaNoUpDown.TabIndex = 56
        Me.ResinAreaNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ResinAreaNoUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Location = New System.Drawing.Point(139, 16)
        Me.label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(30, 17)
        Me.label25.TabIndex = 57
        Me.label25.Text = "No."
        '
        'ResinAreaSideCombo
        '
        Me.ResinAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ResinAreaSideCombo.FormattingEnabled = True
        Me.ResinAreaSideCombo.Location = New System.Drawing.Point(49, 11)
        Me.ResinAreaSideCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaSideCombo.Name = "ResinAreaSideCombo"
        Me.ResinAreaSideCombo.Size = New System.Drawing.Size(80, 24)
        Me.ResinAreaSideCombo.TabIndex = 56
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Location = New System.Drawing.Point(8, 16)
        Me.label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(36, 17)
        Me.label24.TabIndex = 56
        Me.label24.Text = "Side"
        '
        'ResinAreaBottomUpDown
        '
        Me.ResinAreaBottomUpDown.Enabled = False
        Me.ResinAreaBottomUpDown.Location = New System.Drawing.Point(124, 59)
        Me.ResinAreaBottomUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaBottomUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ResinAreaBottomUpDown.Name = "ResinAreaBottomUpDown"
        Me.ResinAreaBottomUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ResinAreaBottomUpDown.TabIndex = 54
        Me.ResinAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaWidthUpDown
        '
        Me.ResinAreaWidthUpDown.Enabled = False
        Me.ResinAreaWidthUpDown.Location = New System.Drawing.Point(64, 59)
        Me.ResinAreaWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaWidthUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ResinAreaWidthUpDown.Name = "ResinAreaWidthUpDown"
        Me.ResinAreaWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ResinAreaWidthUpDown.TabIndex = 53
        Me.ResinAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinAreaLeftUpDown
        '
        Me.ResinAreaLeftUpDown.Enabled = False
        Me.ResinAreaLeftUpDown.Location = New System.Drawing.Point(4, 59)
        Me.ResinAreaLeftUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaLeftUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ResinAreaLeftUpDown.Name = "ResinAreaLeftUpDown"
        Me.ResinAreaLeftUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ResinAreaLeftUpDown.TabIndex = 50
        Me.ResinAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(144, 41)
        Me.label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(17, 17)
        Me.label21.TabIndex = 52
        Me.label21.Text = "B"
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Location = New System.Drawing.Point(81, 41)
        Me.label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(21, 17)
        Me.label22.TabIndex = 51
        Me.label22.Text = "W"
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Location = New System.Drawing.Point(25, 41)
        Me.label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(16, 17)
        Me.label23.TabIndex = 50
        Me.label23.Text = "L"
        '
        'ResinAreaButton
        '
        Me.ResinAreaButton.Location = New System.Drawing.Point(76, 86)
        Me.ResinAreaButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinAreaButton.Name = "ResinAreaButton"
        Me.ResinAreaButton.Size = New System.Drawing.Size(120, 30)
        Me.ResinAreaButton.TabIndex = 50
        Me.ResinAreaButton.Text = "ResinArea"
        Me.ResinAreaButton.UseVisualStyleBackColor = True
        '
        'groupBox10
        '
        Me.groupBox10.Controls.Add(Me.OvercoatPowerUpDown)
        Me.groupBox10.Controls.Add(Me.ResinPowerUpDown)
        Me.groupBox10.Controls.Add(Me.YMCPowerUpDown)
        Me.groupBox10.Controls.Add(Me.label20)
        Me.groupBox10.Controls.Add(Me.label19)
        Me.groupBox10.Controls.Add(Me.label18)
        Me.groupBox10.Controls.Add(Me.PowerLevelButton)
        Me.groupBox10.Location = New System.Drawing.Point(8, 145)
        Me.groupBox10.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox10.Name = "groupBox10"
        Me.groupBox10.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox10.Size = New System.Drawing.Size(255, 94)
        Me.groupBox10.TabIndex = 76
        Me.groupBox10.TabStop = False
        '
        'OvercoatPowerUpDown
        '
        Me.OvercoatPowerUpDown.Enabled = False
        Me.OvercoatPowerUpDown.Location = New System.Drawing.Point(167, 32)
        Me.OvercoatPowerUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.OvercoatPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.OvercoatPowerUpDown.Name = "OvercoatPowerUpDown"
        Me.OvercoatPowerUpDown.Size = New System.Drawing.Size(81, 22)
        Me.OvercoatPowerUpDown.TabIndex = 54
        Me.OvercoatPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ResinPowerUpDown
        '
        Me.ResinPowerUpDown.Enabled = False
        Me.ResinPowerUpDown.Location = New System.Drawing.Point(85, 32)
        Me.ResinPowerUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ResinPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ResinPowerUpDown.Name = "ResinPowerUpDown"
        Me.ResinPowerUpDown.Size = New System.Drawing.Size(81, 22)
        Me.ResinPowerUpDown.TabIndex = 53
        Me.ResinPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'YMCPowerUpDown
        '
        Me.YMCPowerUpDown.Enabled = False
        Me.YMCPowerUpDown.Location = New System.Drawing.Point(4, 32)
        Me.YMCPowerUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.YMCPowerUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.YMCPowerUpDown.Name = "YMCPowerUpDown"
        Me.YMCPowerUpDown.Size = New System.Drawing.Size(81, 22)
        Me.YMCPowerUpDown.TabIndex = 50
        Me.YMCPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Location = New System.Drawing.Point(187, 14)
        Me.label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(66, 17)
        Me.label20.TabIndex = 52
        Me.label20.Text = "Overcoat"
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Location = New System.Drawing.Point(105, 14)
        Me.label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(44, 17)
        Me.label19.TabIndex = 51
        Me.label19.Text = "Resin"
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Location = New System.Drawing.Point(24, 14)
        Me.label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(37, 17)
        Me.label18.TabIndex = 50
        Me.label18.Text = "YMC"
        '
        'PowerLevelButton
        '
        Me.PowerLevelButton.Location = New System.Drawing.Point(76, 59)
        Me.PowerLevelButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PowerLevelButton.Name = "PowerLevelButton"
        Me.PowerLevelButton.Size = New System.Drawing.Size(120, 30)
        Me.PowerLevelButton.TabIndex = 50
        Me.PowerLevelButton.Text = "Power Level"
        Me.PowerLevelButton.UseVisualStyleBackColor = True
        '
        'PrintSpeedButton
        '
        Me.PrintSpeedButton.Location = New System.Drawing.Point(8, 116)
        Me.PrintSpeedButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintSpeedButton.Name = "PrintSpeedButton"
        Me.PrintSpeedButton.Size = New System.Drawing.Size(120, 30)
        Me.PrintSpeedButton.TabIndex = 74
        Me.PrintSpeedButton.Text = "Print Speed"
        Me.PrintSpeedButton.UseVisualStyleBackColor = True
        '
        'PrintSpeedCombo
        '
        Me.PrintSpeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PrintSpeedCombo.Enabled = False
        Me.PrintSpeedCombo.FormattingEnabled = True
        Me.PrintSpeedCombo.Location = New System.Drawing.Point(136, 118)
        Me.PrintSpeedCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintSpeedCombo.Name = "PrintSpeedCombo"
        Me.PrintSpeedCombo.Size = New System.Drawing.Size(125, 24)
        Me.PrintSpeedCombo.TabIndex = 75
        '
        'ColourCorrectionButton
        '
        Me.ColourCorrectionButton.Location = New System.Drawing.Point(8, 86)
        Me.ColourCorrectionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourCorrectionButton.Name = "ColourCorrectionButton"
        Me.ColourCorrectionButton.Size = New System.Drawing.Size(120, 30)
        Me.ColourCorrectionButton.TabIndex = 72
        Me.ColourCorrectionButton.Text = "Colour Corr."
        Me.ColourCorrectionButton.UseVisualStyleBackColor = True
        '
        'CorrectionCombo
        '
        Me.CorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CorrectionCombo.Enabled = False
        Me.CorrectionCombo.FormattingEnabled = True
        Me.CorrectionCombo.Location = New System.Drawing.Point(136, 89)
        Me.CorrectionCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.CorrectionCombo.Name = "CorrectionCombo"
        Me.CorrectionCombo.Size = New System.Drawing.Size(125, 24)
        Me.CorrectionCombo.TabIndex = 73
        '
        'SharpnessUpDown
        '
        Me.SharpnessUpDown.Enabled = False
        Me.SharpnessUpDown.Location = New System.Drawing.Point(136, 59)
        Me.SharpnessUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.SharpnessUpDown.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.SharpnessUpDown.Minimum = New Decimal(New Integer() {2, 0, 0, -2147483648})
        Me.SharpnessUpDown.Name = "SharpnessUpDown"
        Me.SharpnessUpDown.Size = New System.Drawing.Size(127, 22)
        Me.SharpnessUpDown.TabIndex = 68
        Me.SharpnessUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GUIControlButton
        '
        Me.GUIControlButton.Location = New System.Drawing.Point(8, 27)
        Me.GUIControlButton.Margin = New System.Windows.Forms.Padding(4)
        Me.GUIControlButton.Name = "GUIControlButton"
        Me.GUIControlButton.Size = New System.Drawing.Size(120, 30)
        Me.GUIControlButton.TabIndex = 69
        Me.GUIControlButton.Text = "GUI Control"
        Me.GUIControlButton.UseVisualStyleBackColor = True
        '
        'SharpnessButton
        '
        Me.SharpnessButton.Location = New System.Drawing.Point(8, 57)
        Me.SharpnessButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SharpnessButton.Name = "SharpnessButton"
        Me.SharpnessButton.Size = New System.Drawing.Size(120, 30)
        Me.SharpnessButton.TabIndex = 71
        Me.SharpnessButton.Text = "Sharpness"
        Me.SharpnessButton.UseVisualStyleBackColor = True
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Location = New System.Drawing.Point(40, 7)
        Me.label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(51, 17)
        Me.label16.TabIndex = 67
        Me.label16.Text = "Action:"
        '
        'Driver1SetRadio
        '
        Me.Driver1SetRadio.AutoSize = True
        Me.Driver1SetRadio.Location = New System.Drawing.Point(149, 5)
        Me.Driver1SetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver1SetRadio.Name = "Driver1SetRadio"
        Me.Driver1SetRadio.Size = New System.Drawing.Size(50, 21)
        Me.Driver1SetRadio.TabIndex = 66
        Me.Driver1SetRadio.TabStop = True
        Me.Driver1SetRadio.Text = "Set"
        Me.Driver1SetRadio.UseVisualStyleBackColor = True
        '
        'Driver1GetRadio
        '
        Me.Driver1GetRadio.AutoSize = True
        Me.Driver1GetRadio.Checked = True
        Me.Driver1GetRadio.Location = New System.Drawing.Point(93, 5)
        Me.Driver1GetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver1GetRadio.Name = "Driver1GetRadio"
        Me.Driver1GetRadio.Size = New System.Drawing.Size(52, 21)
        Me.Driver1GetRadio.TabIndex = 65
        Me.Driver1GetRadio.TabStop = True
        Me.Driver1GetRadio.Text = "Get"
        Me.Driver1GetRadio.UseVisualStyleBackColor = True
        '
        'ClearDriver1MsgBoxButton
        '
        Me.ClearDriver1MsgBoxButton.Location = New System.Drawing.Point(395, 663)
        Me.ClearDriver1MsgBoxButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearDriver1MsgBoxButton.Name = "ClearDriver1MsgBoxButton"
        Me.ClearDriver1MsgBoxButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearDriver1MsgBoxButton.TabIndex = 64
        Me.ClearDriver1MsgBoxButton.Text = "Clear"
        Me.ClearDriver1MsgBoxButton.UseVisualStyleBackColor = True
        '
        'Driver1MsgBox
        '
        Me.Driver1MsgBox.Location = New System.Drawing.Point(276, 188)
        Me.Driver1MsgBox.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver1MsgBox.Multiline = True
        Me.Driver1MsgBox.Name = "Driver1MsgBox"
        Me.Driver1MsgBox.ReadOnly = True
        Me.Driver1MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Driver1MsgBox.Size = New System.Drawing.Size(333, 467)
        Me.Driver1MsgBox.TabIndex = 63
        Me.Driver1MsgBox.WordWrap = False
        '
        'Driver2
        '
        Me.Driver2.Controls.Add(Me.GroupBox18)
        Me.Driver2.Controls.Add(Me.groupBox23)
        Me.Driver2.Controls.Add(Me.groupBox17)
        Me.Driver2.Controls.Add(Me.groupBox16)
        Me.Driver2.Controls.Add(Me.groupBox15)
        Me.Driver2.Controls.Add(Me.groupBox14)
        Me.Driver2.Controls.Add(Me.ClearDriver2MsgBoxButton)
        Me.Driver2.Controls.Add(Me.Driver2MsgBox)
        Me.Driver2.Controls.Add(Me.label17)
        Me.Driver2.Controls.Add(Me.Driver2SetRadio)
        Me.Driver2.Controls.Add(Me.Driver2GetRadio)
        Me.Driver2.Location = New System.Drawing.Point(4, 25)
        Me.Driver2.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver2.Name = "Driver2"
        Me.Driver2.Size = New System.Drawing.Size(621, 700)
        Me.Driver2.TabIndex = 4
        Me.Driver2.Text = "Driver 2"
        Me.Driver2.UseVisualStyleBackColor = True
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_WhiteRef)
        Me.GroupBox18.Controls.Add(Me.Label58)
        Me.GroupBox18.Controls.Add(Me.Label59)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_BlackRef)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Illuminant)
        Me.GroupBox18.Controls.Add(Me.Label60)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Negative)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_DarkPic)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Blue)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Green)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Red)
        Me.GroupBox18.Controls.Add(Me.Label61)
        Me.GroupBox18.Controls.Add(Me.Label62)
        Me.GroupBox18.Controls.Add(Me.Label63)
        Me.GroupBox18.Controls.Add(Me.Label64)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Tint)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Colour)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Brightness)
        Me.GroupBox18.Controls.Add(Me.ColourAdjust_Contrast)
        Me.GroupBox18.Controls.Add(Me.Label65)
        Me.GroupBox18.Controls.Add(Me.Label66)
        Me.GroupBox18.Controls.Add(Me.Label67)
        Me.GroupBox18.Controls.Add(Me.ColourAdjustBtn)
        Me.GroupBox18.Location = New System.Drawing.Point(269, 7)
        Me.GroupBox18.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox18.Size = New System.Drawing.Size(341, 220)
        Me.GroupBox18.TabIndex = 78
        Me.GroupBox18.TabStop = False
        '
        'ColourAdjust_WhiteRef
        '
        Me.ColourAdjust_WhiteRef.Enabled = False
        Me.ColourAdjust_WhiteRef.Location = New System.Drawing.Point(241, 158)
        Me.ColourAdjust_WhiteRef.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_WhiteRef.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.ColourAdjust_WhiteRef.Minimum = New Decimal(New Integer() {6000, 0, 0, 0})
        Me.ColourAdjust_WhiteRef.Name = "ColourAdjust_WhiteRef"
        Me.ColourAdjust_WhiteRef.Size = New System.Drawing.Size(81, 22)
        Me.ColourAdjust_WhiteRef.TabIndex = 81
        Me.ColourAdjust_WhiteRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_WhiteRef.Value = New Decimal(New Integer() {6000, 0, 0, 0})
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(171, 162)
        Me.Label58.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(70, 17)
        Me.Label58.TabIndex = 80
        Me.Label58.Text = "White Ref"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(5, 162)
        Me.Label59.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(68, 17)
        Me.Label59.TabIndex = 79
        Me.Label59.Text = "Black Ref"
        '
        'ColourAdjust_BlackRef
        '
        Me.ColourAdjust_BlackRef.Enabled = False
        Me.ColourAdjust_BlackRef.Location = New System.Drawing.Point(81, 158)
        Me.ColourAdjust_BlackRef.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_BlackRef.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.ColourAdjust_BlackRef.Name = "ColourAdjust_BlackRef"
        Me.ColourAdjust_BlackRef.Size = New System.Drawing.Size(81, 22)
        Me.ColourAdjust_BlackRef.TabIndex = 78
        Me.ColourAdjust_BlackRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Illuminant
        '
        Me.ColourAdjust_Illuminant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAdjust_Illuminant.Enabled = False
        Me.ColourAdjust_Illuminant.FormattingEnabled = True
        Me.ColourAdjust_Illuminant.Location = New System.Drawing.Point(99, 127)
        Me.ColourAdjust_Illuminant.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Illuminant.Name = "ColourAdjust_Illuminant"
        Me.ColourAdjust_Illuminant.Size = New System.Drawing.Size(207, 24)
        Me.ColourAdjust_Illuminant.TabIndex = 77
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(21, 130)
        Me.Label60.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(67, 17)
        Me.Label60.TabIndex = 76
        Me.Label60.Text = "Illuminant"
        '
        'ColourAdjust_Negative
        '
        Me.ColourAdjust_Negative.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ColourAdjust_Negative.Enabled = False
        Me.ColourAdjust_Negative.Location = New System.Drawing.Point(191, 103)
        Me.ColourAdjust_Negative.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Negative.Name = "ColourAdjust_Negative"
        Me.ColourAdjust_Negative.Size = New System.Drawing.Size(107, 23)
        Me.ColourAdjust_Negative.TabIndex = 75
        Me.ColourAdjust_Negative.Text = "Negative"
        Me.ColourAdjust_Negative.UseVisualStyleBackColor = True
        '
        'ColourAdjust_DarkPic
        '
        Me.ColourAdjust_DarkPic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ColourAdjust_DarkPic.Enabled = False
        Me.ColourAdjust_DarkPic.Location = New System.Drawing.Point(27, 103)
        Me.ColourAdjust_DarkPic.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_DarkPic.Name = "ColourAdjust_DarkPic"
        Me.ColourAdjust_DarkPic.Size = New System.Drawing.Size(113, 21)
        Me.ColourAdjust_DarkPic.TabIndex = 74
        Me.ColourAdjust_DarkPic.Text = "Dark Picture"
        Me.ColourAdjust_DarkPic.UseVisualStyleBackColor = True
        '
        'ColourAdjust_Blue
        '
        Me.ColourAdjust_Blue.Enabled = False
        Me.ColourAdjust_Blue.Location = New System.Drawing.Point(216, 74)
        Me.ColourAdjust_Blue.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Blue.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Blue.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Blue.Name = "ColourAdjust_Blue"
        Me.ColourAdjust_Blue.Size = New System.Drawing.Size(81, 22)
        Me.ColourAdjust_Blue.TabIndex = 73
        Me.ColourAdjust_Blue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Blue.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'ColourAdjust_Green
        '
        Me.ColourAdjust_Green.Enabled = False
        Me.ColourAdjust_Green.Location = New System.Drawing.Point(135, 74)
        Me.ColourAdjust_Green.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Green.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Green.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Green.Name = "ColourAdjust_Green"
        Me.ColourAdjust_Green.Size = New System.Drawing.Size(81, 22)
        Me.ColourAdjust_Green.TabIndex = 72
        Me.ColourAdjust_Green.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Green.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'ColourAdjust_Red
        '
        Me.ColourAdjust_Red.Enabled = False
        Me.ColourAdjust_Red.Location = New System.Drawing.Point(53, 74)
        Me.ColourAdjust_Red.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Red.Maximum = New Decimal(New Integer() {65000, 0, 0, 0})
        Me.ColourAdjust_Red.Minimum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.ColourAdjust_Red.Name = "ColourAdjust_Red"
        Me.ColourAdjust_Red.Size = New System.Drawing.Size(81, 22)
        Me.ColourAdjust_Red.TabIndex = 69
        Me.ColourAdjust_Red.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAdjust_Red.Value = New Decimal(New Integer() {2500, 0, 0, 0})
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(237, 57)
        Me.Label61.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(17, 17)
        Me.Label61.TabIndex = 71
        Me.Label61.Text = "B"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(159, 57)
        Me.Label62.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(19, 17)
        Me.Label62.TabIndex = 70
        Me.Label62.Text = "G"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(73, 57)
        Me.Label63.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(18, 17)
        Me.Label63.TabIndex = 68
        Me.Label63.Text = "R"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(247, 11)
        Me.Label64.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(32, 17)
        Me.Label64.TabIndex = 67
        Me.Label64.Text = "Tint"
        '
        'ColourAdjust_Tint
        '
        Me.ColourAdjust_Tint.Enabled = False
        Me.ColourAdjust_Tint.Location = New System.Drawing.Point(233, 27)
        Me.ColourAdjust_Tint.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Tint.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Tint.Name = "ColourAdjust_Tint"
        Me.ColourAdjust_Tint.Size = New System.Drawing.Size(60, 22)
        Me.ColourAdjust_Tint.TabIndex = 66
        Me.ColourAdjust_Tint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Colour
        '
        Me.ColourAdjust_Colour.Enabled = False
        Me.ColourAdjust_Colour.Location = New System.Drawing.Point(173, 27)
        Me.ColourAdjust_Colour.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Colour.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Colour.Name = "ColourAdjust_Colour"
        Me.ColourAdjust_Colour.Size = New System.Drawing.Size(60, 22)
        Me.ColourAdjust_Colour.TabIndex = 65
        Me.ColourAdjust_Colour.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Brightness
        '
        Me.ColourAdjust_Brightness.Enabled = False
        Me.ColourAdjust_Brightness.Location = New System.Drawing.Point(113, 27)
        Me.ColourAdjust_Brightness.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Brightness.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Brightness.Name = "ColourAdjust_Brightness"
        Me.ColourAdjust_Brightness.Size = New System.Drawing.Size(60, 22)
        Me.ColourAdjust_Brightness.TabIndex = 64
        Me.ColourAdjust_Brightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAdjust_Contrast
        '
        Me.ColourAdjust_Contrast.Enabled = False
        Me.ColourAdjust_Contrast.Location = New System.Drawing.Point(53, 27)
        Me.ColourAdjust_Contrast.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjust_Contrast.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.ColourAdjust_Contrast.Name = "ColourAdjust_Contrast"
        Me.ColourAdjust_Contrast.Size = New System.Drawing.Size(60, 22)
        Me.ColourAdjust_Contrast.TabIndex = 60
        Me.ColourAdjust_Contrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(179, 11)
        Me.Label65.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(49, 17)
        Me.Label65.TabIndex = 63
        Me.Label65.Text = "Colour"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(120, 11)
        Me.Label66.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(45, 17)
        Me.Label66.TabIndex = 62
        Me.Label66.Text = "Bright"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(52, 11)
        Me.Label67.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(61, 17)
        Me.Label67.TabIndex = 61
        Me.Label67.Text = "Contrast"
        '
        'ColourAdjustBtn
        '
        Me.ColourAdjustBtn.Location = New System.Drawing.Point(113, 183)
        Me.ColourAdjustBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAdjustBtn.Name = "ColourAdjustBtn"
        Me.ColourAdjustBtn.Size = New System.Drawing.Size(120, 30)
        Me.ColourAdjustBtn.TabIndex = 50
        Me.ColourAdjustBtn.Text = "Colour Adjust"
        Me.ColourAdjustBtn.UseVisualStyleBackColor = True
        '
        'groupBox23
        '
        Me.groupBox23.Controls.Add(Me.label86)
        Me.groupBox23.Controls.Add(Me.ColourAreaHeightUpDown)
        Me.groupBox23.Controls.Add(Me.ColourAreaBottomUpDown)
        Me.groupBox23.Controls.Add(Me.ColourAreaWidthUpDown)
        Me.groupBox23.Controls.Add(Me.ColourAreaLeftUpDown)
        Me.groupBox23.Controls.Add(Me.Label55)
        Me.groupBox23.Controls.Add(Me.Label56)
        Me.groupBox23.Controls.Add(Me.Label57)
        Me.groupBox23.Controls.Add(Me.ColourAreaNo)
        Me.groupBox23.Controls.Add(Me.ColourAreaSideCombo)
        Me.groupBox23.Controls.Add(Me.label85)
        Me.groupBox23.Controls.Add(Me.ColourAreaCorrectionCombo)
        Me.groupBox23.Controls.Add(Me.Label54)
        Me.groupBox23.Controls.Add(Me.ColourAreaButton)
        Me.groupBox23.Location = New System.Drawing.Point(11, 542)
        Me.groupBox23.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox23.Name = "groupBox23"
        Me.groupBox23.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox23.Size = New System.Drawing.Size(255, 151)
        Me.groupBox23.TabIndex = 77
        Me.groupBox23.TabStop = False
        '
        'label86
        '
        Me.label86.AutoSize = True
        Me.label86.Location = New System.Drawing.Point(204, 71)
        Me.label86.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label86.Name = "label86"
        Me.label86.Size = New System.Drawing.Size(18, 17)
        Me.label86.TabIndex = 78
        Me.label86.Text = "H"
        '
        'ColourAreaHeightUpDown
        '
        Me.ColourAreaHeightUpDown.Enabled = False
        Me.ColourAreaHeightUpDown.Location = New System.Drawing.Point(184, 90)
        Me.ColourAreaHeightUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaHeightUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ColourAreaHeightUpDown.Name = "ColourAreaHeightUpDown"
        Me.ColourAreaHeightUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ColourAreaHeightUpDown.TabIndex = 77
        Me.ColourAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaBottomUpDown
        '
        Me.ColourAreaBottomUpDown.Enabled = False
        Me.ColourAreaBottomUpDown.Location = New System.Drawing.Point(124, 90)
        Me.ColourAreaBottomUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaBottomUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ColourAreaBottomUpDown.Name = "ColourAreaBottomUpDown"
        Me.ColourAreaBottomUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ColourAreaBottomUpDown.TabIndex = 76
        Me.ColourAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaWidthUpDown
        '
        Me.ColourAreaWidthUpDown.Enabled = False
        Me.ColourAreaWidthUpDown.Location = New System.Drawing.Point(64, 90)
        Me.ColourAreaWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaWidthUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ColourAreaWidthUpDown.Name = "ColourAreaWidthUpDown"
        Me.ColourAreaWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ColourAreaWidthUpDown.TabIndex = 75
        Me.ColourAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ColourAreaLeftUpDown
        '
        Me.ColourAreaLeftUpDown.Enabled = False
        Me.ColourAreaLeftUpDown.Location = New System.Drawing.Point(4, 90)
        Me.ColourAreaLeftUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaLeftUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ColourAreaLeftUpDown.Name = "ColourAreaLeftUpDown"
        Me.ColourAreaLeftUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ColourAreaLeftUpDown.TabIndex = 71
        Me.ColourAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(144, 71)
        Me.Label55.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(17, 17)
        Me.Label55.TabIndex = 74
        Me.Label55.Text = "B"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(81, 71)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(21, 17)
        Me.Label56.TabIndex = 73
        Me.Label56.Text = "W"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(25, 71)
        Me.Label57.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(16, 17)
        Me.Label57.TabIndex = 72
        Me.Label57.Text = "L"
        '
        'ColourAreaNo
        '
        Me.ColourAreaNo.Location = New System.Drawing.Point(181, 15)
        Me.ColourAreaNo.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaNo.Maximum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.ColourAreaNo.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ColourAreaNo.Name = "ColourAreaNo"
        Me.ColourAreaNo.Size = New System.Drawing.Size(65, 22)
        Me.ColourAreaNo.TabIndex = 70
        Me.ColourAreaNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColourAreaNo.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ColourAreaSideCombo
        '
        Me.ColourAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAreaSideCombo.FormattingEnabled = True
        Me.ColourAreaSideCombo.Location = New System.Drawing.Point(49, 15)
        Me.ColourAreaSideCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaSideCombo.Name = "ColourAreaSideCombo"
        Me.ColourAreaSideCombo.Size = New System.Drawing.Size(111, 24)
        Me.ColourAreaSideCombo.TabIndex = 63
        '
        'label85
        '
        Me.label85.AutoSize = True
        Me.label85.Location = New System.Drawing.Point(8, 20)
        Me.label85.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label85.Name = "label85"
        Me.label85.Size = New System.Drawing.Size(36, 17)
        Me.label85.TabIndex = 62
        Me.label85.Text = "Side"
        '
        'ColourAreaCorrectionCombo
        '
        Me.ColourAreaCorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourAreaCorrectionCombo.Enabled = False
        Me.ColourAreaCorrectionCombo.FormattingEnabled = True
        Me.ColourAreaCorrectionCombo.Location = New System.Drawing.Point(112, 46)
        Me.ColourAreaCorrectionCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaCorrectionCombo.Name = "ColourAreaCorrectionCombo"
        Me.ColourAreaCorrectionCombo.Size = New System.Drawing.Size(133, 24)
        Me.ColourAreaCorrectionCombo.TabIndex = 56
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(8, 50)
        Me.Label54.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(73, 17)
        Me.Label54.TabIndex = 56
        Me.Label54.Text = "Correction"
        '
        'ColourAreaButton
        '
        Me.ColourAreaButton.Location = New System.Drawing.Point(72, 119)
        Me.ColourAreaButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourAreaButton.Name = "ColourAreaButton"
        Me.ColourAreaButton.Size = New System.Drawing.Size(120, 30)
        Me.ColourAreaButton.TabIndex = 50
        Me.ColourAreaButton.Text = "Colour Area"
        Me.ColourAreaButton.UseVisualStyleBackColor = True
        '
        'groupBox17
        '
        Me.groupBox17.Controls.Add(Me.HoloPatchPositionUpDown)
        Me.groupBox17.Controls.Add(Me.label53)
        Me.groupBox17.Controls.Add(Me.ColourHole)
        Me.groupBox17.Controls.Add(Me.HoloPatchButton)
        Me.groupBox17.Location = New System.Drawing.Point(11, 458)
        Me.groupBox17.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox17.Name = "groupBox17"
        Me.groupBox17.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox17.Size = New System.Drawing.Size(255, 82)
        Me.groupBox17.TabIndex = 76
        Me.groupBox17.TabStop = False
        '
        'HoloPatchPositionUpDown
        '
        Me.HoloPatchPositionUpDown.Enabled = False
        Me.HoloPatchPositionUpDown.Location = New System.Drawing.Point(67, 15)
        Me.HoloPatchPositionUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloPatchPositionUpDown.Maximum = New Decimal(New Integer() {24, 0, 0, 0})
        Me.HoloPatchPositionUpDown.Name = "HoloPatchPositionUpDown"
        Me.HoloPatchPositionUpDown.Size = New System.Drawing.Size(65, 22)
        Me.HoloPatchPositionUpDown.TabIndex = 62
        Me.HoloPatchPositionUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.HoloPatchPositionUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label53
        '
        Me.label53.AutoSize = True
        Me.label53.Location = New System.Drawing.Point(8, 20)
        Me.label53.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label53.Name = "label53"
        Me.label53.Size = New System.Drawing.Size(58, 17)
        Me.label53.TabIndex = 68
        Me.label53.Text = "Position"
        '
        'ColourHole
        '
        Me.ColourHole.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ColourHole.Enabled = False
        Me.ColourHole.Location = New System.Drawing.Point(137, 16)
        Me.ColourHole.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourHole.Name = "ColourHole"
        Me.ColourHole.Size = New System.Drawing.Size(109, 21)
        Me.ColourHole.TabIndex = 66
        Me.ColourHole.Text = "Colour Hole"
        Me.ColourHole.UseVisualStyleBackColor = True
        '
        'HoloPatchButton
        '
        Me.HoloPatchButton.Location = New System.Drawing.Point(77, 47)
        Me.HoloPatchButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloPatchButton.Name = "HoloPatchButton"
        Me.HoloPatchButton.Size = New System.Drawing.Size(120, 30)
        Me.HoloPatchButton.TabIndex = 50
        Me.HoloPatchButton.Text = "HoloPatch"
        Me.HoloPatchButton.UseVisualStyleBackColor = True
        '
        'groupBox16
        '
        Me.groupBox16.Controls.Add(Me.HoloKotePreviewButton)
        Me.groupBox16.Controls.Add(Me.HoloKoteMapUpDown)
        Me.groupBox16.Controls.Add(Me.HoloKoteImageUpDown)
        Me.groupBox16.Controls.Add(Me.label52)
        Me.groupBox16.Controls.Add(Me.HoloKoteSideCombo)
        Me.groupBox16.Controls.Add(Me.NoCustomKey)
        Me.groupBox16.Controls.Add(Me.label49)
        Me.groupBox16.Controls.Add(Me.HoloKoteRotationCombo)
        Me.groupBox16.Controls.Add(Me.UseLaminate)
        Me.groupBox16.Controls.Add(Me.label50)
        Me.groupBox16.Controls.Add(Me.label51)
        Me.groupBox16.Controls.Add(Me.HoloKoteButton)
        Me.groupBox16.Location = New System.Drawing.Point(11, 272)
        Me.groupBox16.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox16.Name = "groupBox16"
        Me.groupBox16.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox16.Size = New System.Drawing.Size(255, 185)
        Me.groupBox16.TabIndex = 75
        Me.groupBox16.TabStop = False
        '
        'HoloKotePreviewButton
        '
        Me.HoloKotePreviewButton.Location = New System.Drawing.Point(108, 146)
        Me.HoloKotePreviewButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKotePreviewButton.Name = "HoloKotePreviewButton"
        Me.HoloKotePreviewButton.Size = New System.Drawing.Size(136, 30)
        Me.HoloKotePreviewButton.TabIndex = 83
        Me.HoloKotePreviewButton.Text = "HoloKote Preview"
        Me.HoloKotePreviewButton.UseVisualStyleBackColor = True
        '
        'HoloKoteMapUpDown
        '
        Me.HoloKoteMapUpDown.Enabled = False
        Me.HoloKoteMapUpDown.Hexadecimal = True
        Me.HoloKoteMapUpDown.Location = New System.Drawing.Point(112, 48)
        Me.HoloKoteMapUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKoteMapUpDown.Maximum = New Decimal(New Integer() {16777215, 0, 0, 0})
        Me.HoloKoteMapUpDown.Name = "HoloKoteMapUpDown"
        Me.HoloKoteMapUpDown.Size = New System.Drawing.Size(135, 22)
        Me.HoloKoteMapUpDown.TabIndex = 69
        Me.HoloKoteMapUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'HoloKoteImageUpDown
        '
        Me.HoloKoteImageUpDown.Enabled = False
        Me.HoloKoteImageUpDown.Location = New System.Drawing.Point(193, 15)
        Me.HoloKoteImageUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKoteImageUpDown.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.HoloKoteImageUpDown.Name = "HoloKoteImageUpDown"
        Me.HoloKoteImageUpDown.Size = New System.Drawing.Size(53, 22)
        Me.HoloKoteImageUpDown.TabIndex = 62
        Me.HoloKoteImageUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.HoloKoteImageUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label52
        '
        Me.label52.AutoSize = True
        Me.label52.Location = New System.Drawing.Point(137, 20)
        Me.label52.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label52.Name = "label52"
        Me.label52.Size = New System.Drawing.Size(46, 17)
        Me.label52.TabIndex = 68
        Me.label52.Text = "Image"
        '
        'HoloKoteSideCombo
        '
        Me.HoloKoteSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HoloKoteSideCombo.FormattingEnabled = True
        Me.HoloKoteSideCombo.Location = New System.Drawing.Point(49, 15)
        Me.HoloKoteSideCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKoteSideCombo.Name = "HoloKoteSideCombo"
        Me.HoloKoteSideCombo.Size = New System.Drawing.Size(80, 24)
        Me.HoloKoteSideCombo.TabIndex = 63
        '
        'NoCustomKey
        '
        Me.NoCustomKey.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.NoCustomKey.Enabled = False
        Me.NoCustomKey.Location = New System.Drawing.Point(8, 123)
        Me.NoCustomKey.Margin = New System.Windows.Forms.Padding(4)
        Me.NoCustomKey.Name = "NoCustomKey"
        Me.NoCustomKey.Size = New System.Drawing.Size(133, 21)
        Me.NoCustomKey.TabIndex = 67
        Me.NoCustomKey.Text = "No Custom Key"
        Me.NoCustomKey.UseVisualStyleBackColor = True
        '
        'label49
        '
        Me.label49.AutoSize = True
        Me.label49.Location = New System.Drawing.Point(8, 20)
        Me.label49.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label49.Name = "label49"
        Me.label49.Size = New System.Drawing.Size(36, 17)
        Me.label49.TabIndex = 62
        Me.label49.Text = "Side"
        '
        'HoloKoteRotationCombo
        '
        Me.HoloKoteRotationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.HoloKoteRotationCombo.Enabled = False
        Me.HoloKoteRotationCombo.FormattingEnabled = True
        Me.HoloKoteRotationCombo.Location = New System.Drawing.Point(112, 74)
        Me.HoloKoteRotationCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKoteRotationCombo.Name = "HoloKoteRotationCombo"
        Me.HoloKoteRotationCombo.Size = New System.Drawing.Size(133, 24)
        Me.HoloKoteRotationCombo.TabIndex = 61
        '
        'UseLaminate
        '
        Me.UseLaminate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.UseLaminate.Enabled = False
        Me.UseLaminate.Location = New System.Drawing.Point(8, 102)
        Me.UseLaminate.Margin = New System.Windows.Forms.Padding(4)
        Me.UseLaminate.Name = "UseLaminate"
        Me.UseLaminate.Size = New System.Drawing.Size(133, 21)
        Me.UseLaminate.TabIndex = 66
        Me.UseLaminate.Text = "Use Laminate"
        Me.UseLaminate.UseVisualStyleBackColor = True
        '
        'label50
        '
        Me.label50.AutoSize = True
        Me.label50.Location = New System.Drawing.Point(8, 79)
        Me.label50.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label50.Name = "label50"
        Me.label50.Size = New System.Drawing.Size(61, 17)
        Me.label50.TabIndex = 60
        Me.label50.Text = "Rotation"
        '
        'label51
        '
        Me.label51.AutoSize = True
        Me.label51.Location = New System.Drawing.Point(8, 53)
        Me.label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label51.Name = "label51"
        Me.label51.Size = New System.Drawing.Size(97, 17)
        Me.label51.TabIndex = 56
        Me.label51.Text = "HoloKote Map"
        '
        'HoloKoteButton
        '
        Me.HoloKoteButton.Location = New System.Drawing.Point(11, 146)
        Me.HoloKoteButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HoloKoteButton.Name = "HoloKoteButton"
        Me.HoloKoteButton.Size = New System.Drawing.Size(89, 30)
        Me.HoloKoteButton.TabIndex = 50
        Me.HoloKoteButton.Text = "HoloKote"
        Me.HoloKoteButton.UseVisualStyleBackColor = True
        '
        'groupBox15
        '
        Me.groupBox15.Controls.Add(Me.Rotate)
        Me.groupBox15.Controls.Add(Me.Overcoat)
        Me.groupBox15.Controls.Add(Me.CardSettingsSideCombo)
        Me.groupBox15.Controls.Add(Me.label47)
        Me.groupBox15.Controls.Add(Me.OrientationCombo)
        Me.groupBox15.Controls.Add(Me.label44)
        Me.groupBox15.Controls.Add(Me.ColourFormatCombo)
        Me.groupBox15.Controls.Add(Me.label48)
        Me.groupBox15.Controls.Add(Me.CardSettingsButton)
        Me.groupBox15.Location = New System.Drawing.Point(11, 134)
        Me.groupBox15.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox15.Name = "groupBox15"
        Me.groupBox15.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox15.Size = New System.Drawing.Size(255, 138)
        Me.groupBox15.TabIndex = 74
        Me.groupBox15.TabStop = False
        '
        'Rotate
        '
        Me.Rotate.AutoSize = True
        Me.Rotate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Rotate.Enabled = False
        Me.Rotate.Location = New System.Drawing.Point(152, 17)
        Me.Rotate.Margin = New System.Windows.Forms.Padding(4)
        Me.Rotate.Name = "Rotate"
        Me.Rotate.Size = New System.Drawing.Size(72, 21)
        Me.Rotate.TabIndex = 65
        Me.Rotate.Text = "Rotate"
        Me.Rotate.UseVisualStyleBackColor = True
        '
        'Overcoat
        '
        Me.Overcoat.AutoSize = True
        Me.Overcoat.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Overcoat.Enabled = False
        Me.Overcoat.Location = New System.Drawing.Point(8, 106)
        Me.Overcoat.Margin = New System.Windows.Forms.Padding(4)
        Me.Overcoat.Name = "Overcoat"
        Me.Overcoat.Size = New System.Drawing.Size(88, 21)
        Me.Overcoat.TabIndex = 64
        Me.Overcoat.Text = "Overcoat"
        Me.Overcoat.UseVisualStyleBackColor = True
        '
        'CardSettingsSideCombo
        '
        Me.CardSettingsSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CardSettingsSideCombo.FormattingEnabled = True
        Me.CardSettingsSideCombo.Location = New System.Drawing.Point(49, 15)
        Me.CardSettingsSideCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.CardSettingsSideCombo.Name = "CardSettingsSideCombo"
        Me.CardSettingsSideCombo.Size = New System.Drawing.Size(80, 24)
        Me.CardSettingsSideCombo.TabIndex = 63
        '
        'label47
        '
        Me.label47.AutoSize = True
        Me.label47.Location = New System.Drawing.Point(8, 20)
        Me.label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label47.Name = "label47"
        Me.label47.Size = New System.Drawing.Size(36, 17)
        Me.label47.TabIndex = 62
        Me.label47.Text = "Side"
        '
        'OrientationCombo
        '
        Me.OrientationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OrientationCombo.Enabled = False
        Me.OrientationCombo.FormattingEnabled = True
        Me.OrientationCombo.Location = New System.Drawing.Point(112, 73)
        Me.OrientationCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.OrientationCombo.Name = "OrientationCombo"
        Me.OrientationCombo.Size = New System.Drawing.Size(133, 24)
        Me.OrientationCombo.TabIndex = 61
        '
        'label44
        '
        Me.label44.AutoSize = True
        Me.label44.Location = New System.Drawing.Point(8, 78)
        Me.label44.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label44.Name = "label44"
        Me.label44.Size = New System.Drawing.Size(78, 17)
        Me.label44.TabIndex = 60
        Me.label44.Text = "Orientation"
        '
        'ColourFormatCombo
        '
        Me.ColourFormatCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ColourFormatCombo.Enabled = False
        Me.ColourFormatCombo.FormattingEnabled = True
        Me.ColourFormatCombo.Location = New System.Drawing.Point(112, 46)
        Me.ColourFormatCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ColourFormatCombo.Name = "ColourFormatCombo"
        Me.ColourFormatCombo.Size = New System.Drawing.Size(133, 24)
        Me.ColourFormatCombo.TabIndex = 56
        '
        'label48
        '
        Me.label48.AutoSize = True
        Me.label48.Location = New System.Drawing.Point(8, 50)
        Me.label48.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label48.Name = "label48"
        Me.label48.Size = New System.Drawing.Size(97, 17)
        Me.label48.TabIndex = 56
        Me.label48.Text = "Colour Format"
        '
        'CardSettingsButton
        '
        Me.CardSettingsButton.Location = New System.Drawing.Point(127, 101)
        Me.CardSettingsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CardSettingsButton.Name = "CardSettingsButton"
        Me.CardSettingsButton.Size = New System.Drawing.Size(120, 30)
        Me.CardSettingsButton.TabIndex = 50
        Me.CardSettingsButton.Text = "Card Settings"
        Me.CardSettingsButton.UseVisualStyleBackColor = True
        '
        'groupBox14
        '
        Me.groupBox14.Controls.Add(Me.CardSizeCombo)
        Me.groupBox14.Controls.Add(Me.label43)
        Me.groupBox14.Controls.Add(Me.CopyCountUpDown)
        Me.groupBox14.Controls.Add(Me.label45)
        Me.groupBox14.Controls.Add(Me.DuplexCombo)
        Me.groupBox14.Controls.Add(Me.label46)
        Me.groupBox14.Controls.Add(Me.PrintSettingsButton)
        Me.groupBox14.Location = New System.Drawing.Point(11, 27)
        Me.groupBox14.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox14.Name = "groupBox14"
        Me.groupBox14.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox14.Size = New System.Drawing.Size(255, 107)
        Me.groupBox14.TabIndex = 73
        Me.groupBox14.TabStop = False
        '
        'CardSizeCombo
        '
        Me.CardSizeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CardSizeCombo.Enabled = False
        Me.CardSizeCombo.FormattingEnabled = True
        Me.CardSizeCombo.Location = New System.Drawing.Point(96, 38)
        Me.CardSizeCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.CardSizeCombo.Name = "CardSizeCombo"
        Me.CardSizeCombo.Size = New System.Drawing.Size(149, 24)
        Me.CardSizeCombo.TabIndex = 61
        '
        'label43
        '
        Me.label43.AutoSize = True
        Me.label43.Location = New System.Drawing.Point(8, 43)
        Me.label43.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label43.Name = "label43"
        Me.label43.Size = New System.Drawing.Size(69, 17)
        Me.label43.TabIndex = 60
        Me.label43.Text = "Card Size"
        '
        'CopyCountUpDown
        '
        Me.CopyCountUpDown.Enabled = False
        Me.CopyCountUpDown.Location = New System.Drawing.Point(43, 73)
        Me.CopyCountUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.CopyCountUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.CopyCountUpDown.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.CopyCountUpDown.Name = "CopyCountUpDown"
        Me.CopyCountUpDown.Size = New System.Drawing.Size(65, 22)
        Me.CopyCountUpDown.TabIndex = 56
        Me.CopyCountUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.CopyCountUpDown.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'label45
        '
        Me.label45.AutoSize = True
        Me.label45.Location = New System.Drawing.Point(8, 78)
        Me.label45.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label45.Name = "label45"
        Me.label45.Size = New System.Drawing.Size(30, 17)
        Me.label45.TabIndex = 57
        Me.label45.Text = "No:"
        '
        'DuplexCombo
        '
        Me.DuplexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DuplexCombo.Enabled = False
        Me.DuplexCombo.FormattingEnabled = True
        Me.DuplexCombo.Location = New System.Drawing.Point(96, 11)
        Me.DuplexCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.DuplexCombo.Name = "DuplexCombo"
        Me.DuplexCombo.Size = New System.Drawing.Size(149, 24)
        Me.DuplexCombo.TabIndex = 56
        '
        'label46
        '
        Me.label46.AutoSize = True
        Me.label46.Location = New System.Drawing.Point(8, 16)
        Me.label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label46.Name = "label46"
        Me.label46.Size = New System.Drawing.Size(92, 17)
        Me.label46.TabIndex = 56
        Me.label46.Text = "Sides to Print"
        '
        'PrintSettingsButton
        '
        Me.PrintSettingsButton.Location = New System.Drawing.Point(127, 70)
        Me.PrintSettingsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintSettingsButton.Name = "PrintSettingsButton"
        Me.PrintSettingsButton.Size = New System.Drawing.Size(120, 30)
        Me.PrintSettingsButton.TabIndex = 50
        Me.PrintSettingsButton.Text = "Print Settings"
        Me.PrintSettingsButton.UseVisualStyleBackColor = True
        '
        'ClearDriver2MsgBoxButton
        '
        Me.ClearDriver2MsgBoxButton.Location = New System.Drawing.Point(392, 663)
        Me.ClearDriver2MsgBoxButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearDriver2MsgBoxButton.Name = "ClearDriver2MsgBoxButton"
        Me.ClearDriver2MsgBoxButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearDriver2MsgBoxButton.TabIndex = 72
        Me.ClearDriver2MsgBoxButton.Text = "Clear"
        Me.ClearDriver2MsgBoxButton.UseVisualStyleBackColor = True
        '
        'Driver2MsgBox
        '
        Me.Driver2MsgBox.Location = New System.Drawing.Point(269, 235)
        Me.Driver2MsgBox.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver2MsgBox.Multiline = True
        Me.Driver2MsgBox.Name = "Driver2MsgBox"
        Me.Driver2MsgBox.ReadOnly = True
        Me.Driver2MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Driver2MsgBox.Size = New System.Drawing.Size(340, 472)
        Me.Driver2MsgBox.TabIndex = 71
        Me.Driver2MsgBox.WordWrap = False
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Location = New System.Drawing.Point(37, 7)
        Me.label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(51, 17)
        Me.label17.TabIndex = 70
        Me.label17.Text = "Action:"
        '
        'Driver2SetRadio
        '
        Me.Driver2SetRadio.AutoSize = True
        Me.Driver2SetRadio.Location = New System.Drawing.Point(147, 5)
        Me.Driver2SetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver2SetRadio.Name = "Driver2SetRadio"
        Me.Driver2SetRadio.Size = New System.Drawing.Size(50, 21)
        Me.Driver2SetRadio.TabIndex = 69
        Me.Driver2SetRadio.Text = "Set"
        Me.Driver2SetRadio.UseVisualStyleBackColor = True
        '
        'Driver2GetRadio
        '
        Me.Driver2GetRadio.AutoSize = True
        Me.Driver2GetRadio.Checked = True
        Me.Driver2GetRadio.Location = New System.Drawing.Point(91, 5)
        Me.Driver2GetRadio.Margin = New System.Windows.Forms.Padding(4)
        Me.Driver2GetRadio.Name = "Driver2GetRadio"
        Me.Driver2GetRadio.Size = New System.Drawing.Size(52, 21)
        Me.Driver2GetRadio.TabIndex = 68
        Me.Driver2GetRadio.TabStop = True
        Me.Driver2GetRadio.Text = "Get"
        Me.Driver2GetRadio.UseVisualStyleBackColor = True
        '
        'PrintDemo
        '
        Me.PrintDemo.Controls.Add(Me.Functions600DPI)
        Me.PrintDemo.Controls.Add(Me.PrinterPrefs)
        Me.PrintDemo.Controls.Add(Me.nativePrint)
        Me.PrintDemo.Controls.Add(Me.CardSide)
        Me.PrintDemo.Controls.Add(Me.CardBack)
        Me.PrintDemo.Controls.Add(Me.CardFront)
        Me.PrintDemo.Controls.Add(Me.PrintButton)
        Me.PrintDemo.Location = New System.Drawing.Point(4, 25)
        Me.PrintDemo.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintDemo.Name = "PrintDemo"
        Me.PrintDemo.Padding = New System.Windows.Forms.Padding(4)
        Me.PrintDemo.Size = New System.Drawing.Size(621, 700)
        Me.PrintDemo.TabIndex = 6
        Me.PrintDemo.Text = "Print Demo"
        Me.PrintDemo.UseVisualStyleBackColor = True
        '
        'Functions600DPI
        '
        Me.Functions600DPI.AutoSize = True
        Me.Functions600DPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Functions600DPI.Location = New System.Drawing.Point(416, 33)
        Me.Functions600DPI.Margin = New System.Windows.Forms.Padding(4)
        Me.Functions600DPI.Name = "Functions600DPI"
        Me.Functions600DPI.Size = New System.Drawing.Size(161, 21)
        Me.Functions600DPI.TabIndex = 90
        Me.Functions600DPI.Text = "Use 600 DPI Printing"
        Me.Functions600DPI.UseVisualStyleBackColor = True
        '
        'PrinterPrefs
        '
        Me.PrinterPrefs.Location = New System.Drawing.Point(9, 650)
        Me.PrinterPrefs.Margin = New System.Windows.Forms.Padding(4)
        Me.PrinterPrefs.Name = "PrinterPrefs"
        Me.PrinterPrefs.Size = New System.Drawing.Size(144, 30)
        Me.PrinterPrefs.TabIndex = 38
        Me.PrinterPrefs.Text = "Printer Preferences"
        Me.PrinterPrefs.UseVisualStyleBackColor = True
        Me.PrinterPrefs.Visible = False
        '
        'nativePrint
        '
        Me.nativePrint.AutoSize = True
        Me.nativePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.nativePrint.Location = New System.Drawing.Point(228, 655)
        Me.nativePrint.Margin = New System.Windows.Forms.Padding(4)
        Me.nativePrint.Name = "nativePrint"
        Me.nativePrint.Size = New System.Drawing.Size(151, 21)
        Me.nativePrint.TabIndex = 89
        Me.nativePrint.Text = "Use Native Printing"
        Me.nativePrint.UseVisualStyleBackColor = True
        '
        'CardSide
        '
        Me.CardSide.Controls.Add(Me.Front)
        Me.CardSide.Controls.Add(Me.Back)
        Me.CardSide.Location = New System.Drawing.Point(9, 38)
        Me.CardSide.Margin = New System.Windows.Forms.Padding(4)
        Me.CardSide.Name = "CardSide"
        Me.CardSide.SelectedIndex = 0
        Me.CardSide.Size = New System.Drawing.Size(601, 607)
        Me.CardSide.TabIndex = 72
        '
        'Front
        '
        Me.Front.Controls.Add(Me.GroupBox29)
        Me.Front.Controls.Add(Me.GroupBox30)
        Me.Front.Controls.Add(Me.GroupBox31)
        Me.Front.Controls.Add(Me.GroupBox32)
        Me.Front.Controls.Add(Me.groupBox33)
        Me.Front.Location = New System.Drawing.Point(4, 25)
        Me.Front.Margin = New System.Windows.Forms.Padding(4)
        Me.Front.Name = "Front"
        Me.Front.Padding = New System.Windows.Forms.Padding(4)
        Me.Front.Size = New System.Drawing.Size(593, 578)
        Me.Front.TabIndex = 0
        Me.Front.Text = "Front"
        Me.Front.UseVisualStyleBackColor = True
        '
        'GroupBox29
        '
        Me.GroupBox29.Controls.Add(Me.Track3MagData)
        Me.GroupBox29.Controls.Add(Me.Track2MagData)
        Me.GroupBox29.Controls.Add(Me.Track1MagData)
        Me.GroupBox29.Controls.Add(Me.label11)
        Me.GroupBox29.Controls.Add(Me.label10)
        Me.GroupBox29.Controls.Add(Me.label6)
        Me.GroupBox29.Controls.Add(Me.MagDataEnabled)
        Me.GroupBox29.Location = New System.Drawing.Point(4, 436)
        Me.GroupBox29.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox29.Name = "GroupBox29"
        Me.GroupBox29.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox29.Size = New System.Drawing.Size(583, 132)
        Me.GroupBox29.TabIndex = 88
        Me.GroupBox29.TabStop = False
        Me.GroupBox29.Text = "Magnetic Encoding"
        '
        'Track3MagData
        '
        Me.Track3MagData.Location = New System.Drawing.Point(75, 96)
        Me.Track3MagData.Margin = New System.Windows.Forms.Padding(4)
        Me.Track3MagData.Name = "Track3MagData"
        Me.Track3MagData.Size = New System.Drawing.Size(499, 22)
        Me.Track3MagData.TabIndex = 91
        '
        'Track2MagData
        '
        Me.Track2MagData.Location = New System.Drawing.Point(75, 66)
        Me.Track2MagData.Margin = New System.Windows.Forms.Padding(4)
        Me.Track2MagData.Name = "Track2MagData"
        Me.Track2MagData.Size = New System.Drawing.Size(499, 22)
        Me.Track2MagData.TabIndex = 90
        '
        'Track1MagData
        '
        Me.Track1MagData.Location = New System.Drawing.Point(75, 37)
        Me.Track1MagData.Margin = New System.Windows.Forms.Padding(4)
        Me.Track1MagData.Name = "Track1MagData"
        Me.Track1MagData.Size = New System.Drawing.Size(499, 22)
        Me.Track1MagData.TabIndex = 89
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(8, 101)
        Me.label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(56, 17)
        Me.label11.TabIndex = 88
        Me.label11.Text = "Track 3"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(8, 71)
        Me.label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(56, 17)
        Me.label10.TabIndex = 87
        Me.label10.Text = "Track 2"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(8, 42)
        Me.label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(56, 17)
        Me.label6.TabIndex = 86
        Me.label6.Text = "Track 1"
        '
        'MagDataEnabled
        '
        Me.MagDataEnabled.AutoSize = True
        Me.MagDataEnabled.Location = New System.Drawing.Point(8, 17)
        Me.MagDataEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.MagDataEnabled.Name = "MagDataEnabled"
        Me.MagDataEnabled.Size = New System.Drawing.Size(82, 21)
        Me.MagDataEnabled.TabIndex = 85
        Me.MagDataEnabled.Text = "Enabled"
        Me.MagDataEnabled.UseVisualStyleBackColor = True
        '
        'GroupBox30
        '
        Me.GroupBox30.Controls.Add(Me.ImageFrontResin)
        Me.GroupBox30.Controls.Add(Me.ImageFrontEnabled)
        Me.GroupBox30.Controls.Add(Me.ImageFrontButton)
        Me.GroupBox30.Controls.Add(Me.ImageFrontFileBox)
        Me.GroupBox30.Controls.Add(Me.ImageFrontP2UpDown)
        Me.GroupBox30.Controls.Add(Me.Label8)
        Me.GroupBox30.Controls.Add(Me.Label12)
        Me.GroupBox30.Controls.Add(Me.ImageFrontP1UpDown)
        Me.GroupBox30.Controls.Add(Me.ImageFrontYUpDown)
        Me.GroupBox30.Controls.Add(Me.Label14)
        Me.GroupBox30.Controls.Add(Me.ImageFrontXUpDown)
        Me.GroupBox30.Controls.Add(Me.Label15)
        Me.GroupBox30.Controls.Add(Me.Label106)
        Me.GroupBox30.Controls.Add(Me.Label107)
        Me.GroupBox30.Location = New System.Drawing.Point(4, 336)
        Me.GroupBox30.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox30.Name = "GroupBox30"
        Me.GroupBox30.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox30.Size = New System.Drawing.Size(583, 92)
        Me.GroupBox30.TabIndex = 87
        Me.GroupBox30.TabStop = False
        Me.GroupBox30.Text = "Image"
        '
        'ImageFrontResin
        '
        Me.ImageFrontResin.AutoSize = True
        Me.ImageFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ImageFrontResin.Location = New System.Drawing.Point(475, 52)
        Me.ImageFrontResin.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontResin.Name = "ImageFrontResin"
        Me.ImageFrontResin.Size = New System.Drawing.Size(95, 21)
        Me.ImageFrontResin.TabIndex = 87
        Me.ImageFrontResin.Text = "Use Resin"
        Me.ImageFrontResin.UseVisualStyleBackColor = True
        '
        'ImageFrontEnabled
        '
        Me.ImageFrontEnabled.AutoSize = True
        Me.ImageFrontEnabled.Location = New System.Drawing.Point(8, 17)
        Me.ImageFrontEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontEnabled.Name = "ImageFrontEnabled"
        Me.ImageFrontEnabled.Size = New System.Drawing.Size(82, 21)
        Me.ImageFrontEnabled.TabIndex = 85
        Me.ImageFrontEnabled.Text = "Enabled"
        Me.ImageFrontEnabled.UseVisualStyleBackColor = True
        '
        'ImageFrontButton
        '
        Me.ImageFrontButton.Location = New System.Drawing.Point(533, 12)
        Me.ImageFrontButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontButton.Name = "ImageFrontButton"
        Me.ImageFrontButton.Size = New System.Drawing.Size(37, 30)
        Me.ImageFrontButton.TabIndex = 70
        Me.ImageFrontButton.Text = "..."
        Me.ImageFrontButton.UseVisualStyleBackColor = True
        '
        'ImageFrontFileBox
        '
        Me.ImageFrontFileBox.Location = New System.Drawing.Point(169, 15)
        Me.ImageFrontFileBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontFileBox.Name = "ImageFrontFileBox"
        Me.ImageFrontFileBox.Size = New System.Drawing.Size(363, 22)
        Me.ImageFrontFileBox.TabIndex = 83
        '
        'ImageFrontP2UpDown
        '
        Me.ImageFrontP2UpDown.Location = New System.Drawing.Point(344, 49)
        Me.ImageFrontP2UpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontP2UpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ImageFrontP2UpDown.Name = "ImageFrontP2UpDown"
        Me.ImageFrontP2UpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageFrontP2UpDown.TabIndex = 82
        Me.ImageFrontP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(317, 54)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(25, 17)
        Me.Label8.TabIndex = 81
        Me.Label8.Text = "P2"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(231, 54)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(25, 17)
        Me.Label12.TabIndex = 80
        Me.Label12.Text = "P1"
        '
        'ImageFrontP1UpDown
        '
        Me.ImageFrontP1UpDown.Location = New System.Drawing.Point(257, 49)
        Me.ImageFrontP1UpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontP1UpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ImageFrontP1UpDown.Name = "ImageFrontP1UpDown"
        Me.ImageFrontP1UpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageFrontP1UpDown.TabIndex = 78
        Me.ImageFrontP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ImageFrontYUpDown
        '
        Me.ImageFrontYUpDown.Location = New System.Drawing.Point(171, 49)
        Me.ImageFrontYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ImageFrontYUpDown.Name = "ImageFrontYUpDown"
        Me.ImageFrontYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageFrontYUpDown.TabIndex = 76
        Me.ImageFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(152, 54)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(17, 17)
        Me.Label14.TabIndex = 75
        Me.Label14.Text = "Y"
        '
        'ImageFrontXUpDown
        '
        Me.ImageFrontXUpDown.Location = New System.Drawing.Point(92, 49)
        Me.ImageFrontXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageFrontXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ImageFrontXUpDown.Name = "ImageFrontXUpDown"
        Me.ImageFrontXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageFrontXUpDown.TabIndex = 74
        Me.ImageFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(75, 54)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(17, 17)
        Me.Label15.TabIndex = 73
        Me.Label15.Text = "X"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Location = New System.Drawing.Point(8, 54)
        Me.Label106.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(62, 17)
        Me.Label106.TabIndex = 33
        Me.Label106.Text = "Position:"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Location = New System.Drawing.Point(121, 20)
        Me.Label107.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(30, 17)
        Me.Label107.TabIndex = 32
        Me.Label107.Text = "File"
        '
        'GroupBox31
        '
        Me.GroupBox31.Controls.Add(Me.LineFrontEnabled)
        Me.GroupBox31.Controls.Add(Me.Label108)
        Me.GroupBox31.Controls.Add(Me.LineFrontWidthUpDown)
        Me.GroupBox31.Controls.Add(Me.Label109)
        Me.GroupBox31.Controls.Add(Me.LineFrontStartYUpDown)
        Me.GroupBox31.Controls.Add(Me.LineFrontEndYUpDown)
        Me.GroupBox31.Controls.Add(Me.Label110)
        Me.GroupBox31.Controls.Add(Me.Label111)
        Me.GroupBox31.Controls.Add(Me.Label113)
        Me.GroupBox31.Controls.Add(Me.Label114)
        Me.GroupBox31.Controls.Add(Me.LineFrontResin)
        Me.GroupBox31.Controls.Add(Me.LineFrontEndXUpDown)
        Me.GroupBox31.Controls.Add(Me.LineFrontColourCombo)
        Me.GroupBox31.Controls.Add(Me.LineFrontStartXUpDown)
        Me.GroupBox31.Controls.Add(Me.Label115)
        Me.GroupBox31.Controls.Add(Me.Label116)
        Me.GroupBox31.Location = New System.Drawing.Point(4, 224)
        Me.GroupBox31.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox31.Name = "GroupBox31"
        Me.GroupBox31.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox31.Size = New System.Drawing.Size(583, 105)
        Me.GroupBox31.TabIndex = 86
        Me.GroupBox31.TabStop = False
        Me.GroupBox31.Text = "Line"
        '
        'LineFrontEnabled
        '
        Me.LineFrontEnabled.AutoSize = True
        Me.LineFrontEnabled.Checked = True
        Me.LineFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.LineFrontEnabled.Location = New System.Drawing.Point(8, 17)
        Me.LineFrontEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontEnabled.Name = "LineFrontEnabled"
        Me.LineFrontEnabled.Size = New System.Drawing.Size(82, 21)
        Me.LineFrontEnabled.TabIndex = 84
        Me.LineFrontEnabled.Text = "Enabled"
        Me.LineFrontEnabled.UseVisualStyleBackColor = True
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Location = New System.Drawing.Point(251, 78)
        Me.Label108.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(37, 17)
        Me.Label108.TabIndex = 82
        Me.Label108.Text = "End:"
        '
        'LineFrontWidthUpDown
        '
        Me.LineFrontWidthUpDown.Location = New System.Drawing.Point(312, 39)
        Me.LineFrontWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.LineFrontWidthUpDown.Name = "LineFrontWidthUpDown"
        Me.LineFrontWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineFrontWidthUpDown.TabIndex = 81
        Me.LineFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(268, 44)
        Me.Label109.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(44, 17)
        Me.Label109.TabIndex = 80
        Me.Label109.Text = "Width"
        '
        'LineFrontStartYUpDown
        '
        Me.LineFrontStartYUpDown.Location = New System.Drawing.Point(153, 73)
        Me.LineFrontStartYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontStartYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.LineFrontStartYUpDown.Name = "LineFrontStartYUpDown"
        Me.LineFrontStartYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineFrontStartYUpDown.TabIndex = 76
        Me.LineFrontStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineFrontEndYUpDown
        '
        Me.LineFrontEndYUpDown.Location = New System.Drawing.Point(393, 73)
        Me.LineFrontEndYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontEndYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.LineFrontEndYUpDown.Name = "LineFrontEndYUpDown"
        Me.LineFrontEndYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineFrontEndYUpDown.TabIndex = 82
        Me.LineFrontEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(8, 76)
        Me.Label110.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(42, 17)
        Me.Label110.TabIndex = 80
        Me.Label110.Text = "Start:"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(375, 78)
        Me.Label111.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(17, 17)
        Me.Label111.TabIndex = 81
        Me.Label111.Text = "Y"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(56, 78)
        Me.Label113.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(17, 17)
        Me.Label113.TabIndex = 73
        Me.Label113.Text = "X"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Location = New System.Drawing.Point(293, 78)
        Me.Label114.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(17, 17)
        Me.Label114.TabIndex = 80
        Me.Label114.Text = "X"
        '
        'LineFrontResin
        '
        Me.LineFrontResin.AutoSize = True
        Me.LineFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LineFrontResin.Location = New System.Drawing.Point(475, 17)
        Me.LineFrontResin.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontResin.Name = "LineFrontResin"
        Me.LineFrontResin.Size = New System.Drawing.Size(95, 21)
        Me.LineFrontResin.TabIndex = 79
        Me.LineFrontResin.Text = "Use Resin"
        Me.LineFrontResin.UseVisualStyleBackColor = True
        '
        'LineFrontEndXUpDown
        '
        Me.LineFrontEndXUpDown.Location = New System.Drawing.Point(312, 73)
        Me.LineFrontEndXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontEndXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.LineFrontEndXUpDown.Name = "LineFrontEndXUpDown"
        Me.LineFrontEndXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineFrontEndXUpDown.TabIndex = 78
        Me.LineFrontEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineFrontColourCombo
        '
        Me.LineFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LineFrontColourCombo.Location = New System.Drawing.Point(75, 39)
        Me.LineFrontColourCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontColourCombo.Name = "LineFrontColourCombo"
        Me.LineFrontColourCombo.Size = New System.Drawing.Size(184, 24)
        Me.LineFrontColourCombo.TabIndex = 34
        '
        'LineFrontStartXUpDown
        '
        Me.LineFrontStartXUpDown.Location = New System.Drawing.Point(75, 73)
        Me.LineFrontStartXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineFrontStartXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.LineFrontStartXUpDown.Name = "LineFrontStartXUpDown"
        Me.LineFrontStartXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineFrontStartXUpDown.TabIndex = 74
        Me.LineFrontStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Location = New System.Drawing.Point(8, 44)
        Me.Label115.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(49, 17)
        Me.Label115.TabIndex = 32
        Me.Label115.Text = "Colour"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Location = New System.Drawing.Point(135, 78)
        Me.Label116.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(17, 17)
        Me.Label116.TabIndex = 75
        Me.Label116.Text = "Y"
        '
        'GroupBox32
        '
        Me.GroupBox32.Controls.Add(Me.ShapeFrontEnabled)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontFillCombo)
        Me.GroupBox32.Controls.Add(Me.Label117)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontWidthUpDown)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontOutlineCombo)
        Me.GroupBox32.Controls.Add(Me.Label118)
        Me.GroupBox32.Controls.Add(Me.Label119)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontBUpDown)
        Me.GroupBox32.Controls.Add(Me.Label120)
        Me.GroupBox32.Controls.Add(Me.Label121)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontResin)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontRUpDown)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontTUpDown)
        Me.GroupBox32.Controls.Add(Me.Label122)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontLUpDown)
        Me.GroupBox32.Controls.Add(Me.Label123)
        Me.GroupBox32.Controls.Add(Me.ShapeFrontCombo)
        Me.GroupBox32.Controls.Add(Me.Label124)
        Me.GroupBox32.Controls.Add(Me.Label125)
        Me.GroupBox32.Location = New System.Drawing.Point(4, 112)
        Me.GroupBox32.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox32.Name = "GroupBox32"
        Me.GroupBox32.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox32.Size = New System.Drawing.Size(583, 105)
        Me.GroupBox32.TabIndex = 85
        Me.GroupBox32.TabStop = False
        Me.GroupBox32.Text = "Shape"
        '
        'ShapeFrontEnabled
        '
        Me.ShapeFrontEnabled.AutoSize = True
        Me.ShapeFrontEnabled.Checked = True
        Me.ShapeFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ShapeFrontEnabled.Location = New System.Drawing.Point(8, 17)
        Me.ShapeFrontEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontEnabled.Name = "ShapeFrontEnabled"
        Me.ShapeFrontEnabled.Size = New System.Drawing.Size(82, 21)
        Me.ShapeFrontEnabled.TabIndex = 83
        Me.ShapeFrontEnabled.Text = "Enabled"
        Me.ShapeFrontEnabled.UseVisualStyleBackColor = True
        '
        'ShapeFrontFillCombo
        '
        Me.ShapeFrontFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontFillCombo.Items.AddRange(New Object() {"Red", "Green", "Blue", "Cyan", "Magenta", "Yellow", "White", "Black", "Transparent"})
        Me.ShapeFrontFillCombo.Location = New System.Drawing.Point(335, 74)
        Me.ShapeFrontFillCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontFillCombo.Name = "ShapeFrontFillCombo"
        Me.ShapeFrontFillCombo.Size = New System.Drawing.Size(168, 24)
        Me.ShapeFrontFillCombo.TabIndex = 81
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Location = New System.Drawing.Point(309, 79)
        Me.Label117.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(25, 17)
        Me.Label117.TabIndex = 80
        Me.Label117.Text = "Fill"
        '
        'ShapeFrontWidthUpDown
        '
        Me.ShapeFrontWidthUpDown.Location = New System.Drawing.Point(235, 74)
        Me.ShapeFrontWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ShapeFrontWidthUpDown.Name = "ShapeFrontWidthUpDown"
        Me.ShapeFrontWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeFrontWidthUpDown.TabIndex = 81
        Me.ShapeFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeFrontOutlineCombo
        '
        Me.ShapeFrontOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontOutlineCombo.Location = New System.Drawing.Point(69, 74)
        Me.ShapeFrontOutlineCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontOutlineCombo.Name = "ShapeFrontOutlineCombo"
        Me.ShapeFrontOutlineCombo.Size = New System.Drawing.Size(112, 24)
        Me.ShapeFrontOutlineCombo.TabIndex = 81
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Location = New System.Drawing.Point(191, 79)
        Me.Label118.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(44, 17)
        Me.Label118.TabIndex = 80
        Me.Label118.Text = "Width"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(8, 79)
        Me.Label119.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(53, 17)
        Me.Label119.TabIndex = 80
        Me.Label119.Text = "Outline"
        '
        'ShapeFrontBUpDown
        '
        Me.ShapeFrontBUpDown.Location = New System.Drawing.Point(504, 46)
        Me.ShapeFrontBUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontBUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ShapeFrontBUpDown.Name = "ShapeFrontBUpDown"
        Me.ShapeFrontBUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeFrontBUpDown.TabIndex = 82
        Me.ShapeFrontBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(485, 50)
        Me.Label120.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(17, 17)
        Me.Label120.TabIndex = 81
        Me.Label120.Text = "B"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Location = New System.Drawing.Point(405, 50)
        Me.Label121.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(18, 17)
        Me.Label121.TabIndex = 80
        Me.Label121.Text = "R"
        '
        'ShapeFrontResin
        '
        Me.ShapeFrontResin.AutoSize = True
        Me.ShapeFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShapeFrontResin.Location = New System.Drawing.Point(475, 17)
        Me.ShapeFrontResin.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontResin.Name = "ShapeFrontResin"
        Me.ShapeFrontResin.Size = New System.Drawing.Size(95, 21)
        Me.ShapeFrontResin.TabIndex = 79
        Me.ShapeFrontResin.Text = "Use Resin"
        Me.ShapeFrontResin.UseVisualStyleBackColor = True
        '
        'ShapeFrontRUpDown
        '
        Me.ShapeFrontRUpDown.Location = New System.Drawing.Point(425, 46)
        Me.ShapeFrontRUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontRUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ShapeFrontRUpDown.Name = "ShapeFrontRUpDown"
        Me.ShapeFrontRUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeFrontRUpDown.TabIndex = 78
        Me.ShapeFrontRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeFrontTUpDown
        '
        Me.ShapeFrontTUpDown.Location = New System.Drawing.Point(345, 46)
        Me.ShapeFrontTUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontTUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ShapeFrontTUpDown.Name = "ShapeFrontTUpDown"
        Me.ShapeFrontTUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeFrontTUpDown.TabIndex = 76
        Me.ShapeFrontTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Location = New System.Drawing.Point(327, 50)
        Me.Label122.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(17, 17)
        Me.Label122.TabIndex = 75
        Me.Label122.Text = "T"
        '
        'ShapeFrontLUpDown
        '
        Me.ShapeFrontLUpDown.Location = New System.Drawing.Point(267, 46)
        Me.ShapeFrontLUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontLUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ShapeFrontLUpDown.Name = "ShapeFrontLUpDown"
        Me.ShapeFrontLUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeFrontLUpDown.TabIndex = 74
        Me.ShapeFrontLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Location = New System.Drawing.Point(249, 50)
        Me.Label123.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(16, 17)
        Me.Label123.TabIndex = 73
        Me.Label123.Text = "L"
        '
        'ShapeFrontCombo
        '
        Me.ShapeFrontCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeFrontCombo.Location = New System.Drawing.Point(69, 46)
        Me.ShapeFrontCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeFrontCombo.Name = "ShapeFrontCombo"
        Me.ShapeFrontCombo.Size = New System.Drawing.Size(112, 24)
        Me.ShapeFrontCombo.TabIndex = 34
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Location = New System.Drawing.Point(187, 50)
        Me.Label124.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(62, 17)
        Me.Label124.TabIndex = 33
        Me.Label124.Text = "Position:"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Location = New System.Drawing.Point(8, 50)
        Me.Label125.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(49, 17)
        Me.Label125.TabIndex = 32
        Me.Label125.Text = "Shape"
        '
        'groupBox33
        '
        Me.groupBox33.Controls.Add(Me.TextFrontEnabled)
        Me.groupBox33.Controls.Add(Me.TextFrontResin)
        Me.groupBox33.Controls.Add(Me.TextFrontSizeUpDown)
        Me.groupBox33.Controls.Add(Me.Label126)
        Me.groupBox33.Controls.Add(Me.TextFrontYUpDown)
        Me.groupBox33.Controls.Add(Me.Label127)
        Me.groupBox33.Controls.Add(Me.TextFrontXUpDown)
        Me.groupBox33.Controls.Add(Me.Label128)
        Me.groupBox33.Controls.Add(Me.TextFrontStrikethrough)
        Me.groupBox33.Controls.Add(Me.TextFrontItalic)
        Me.groupBox33.Controls.Add(Me.TextFrontUnderline)
        Me.groupBox33.Controls.Add(Me.TextFrontBold)
        Me.groupBox33.Controls.Add(Me.TextFrontColourCombo)
        Me.groupBox33.Controls.Add(Me.Label129)
        Me.groupBox33.Controls.Add(Me.Label130)
        Me.groupBox33.Controls.Add(Me.Label131)
        Me.groupBox33.Controls.Add(Me.TextFrontBox)
        Me.groupBox33.Location = New System.Drawing.Point(4, 0)
        Me.groupBox33.Margin = New System.Windows.Forms.Padding(4)
        Me.groupBox33.Name = "groupBox33"
        Me.groupBox33.Padding = New System.Windows.Forms.Padding(4)
        Me.groupBox33.Size = New System.Drawing.Size(583, 105)
        Me.groupBox33.TabIndex = 1
        Me.groupBox33.TabStop = False
        Me.groupBox33.Text = "Text"
        '
        'TextFrontEnabled
        '
        Me.TextFrontEnabled.AutoSize = True
        Me.TextFrontEnabled.Checked = True
        Me.TextFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.TextFrontEnabled.Location = New System.Drawing.Point(8, 17)
        Me.TextFrontEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontEnabled.Name = "TextFrontEnabled"
        Me.TextFrontEnabled.Size = New System.Drawing.Size(82, 21)
        Me.TextFrontEnabled.TabIndex = 80
        Me.TextFrontEnabled.Text = "Enabled"
        Me.TextFrontEnabled.UseVisualStyleBackColor = True
        '
        'TextFrontResin
        '
        Me.TextFrontResin.AutoSize = True
        Me.TextFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextFrontResin.Location = New System.Drawing.Point(475, 76)
        Me.TextFrontResin.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontResin.Name = "TextFrontResin"
        Me.TextFrontResin.Size = New System.Drawing.Size(95, 21)
        Me.TextFrontResin.TabIndex = 79
        Me.TextFrontResin.Text = "Use Resin"
        Me.TextFrontResin.UseVisualStyleBackColor = True
        '
        'TextFrontSizeUpDown
        '
        Me.TextFrontSizeUpDown.Location = New System.Drawing.Point(321, 74)
        Me.TextFrontSizeUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontSizeUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.TextFrontSizeUpDown.Name = "TextFrontSizeUpDown"
        Me.TextFrontSizeUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextFrontSizeUpDown.TabIndex = 78
        Me.TextFrontSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Location = New System.Drawing.Point(285, 79)
        Me.Label126.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(35, 17)
        Me.Label126.TabIndex = 77
        Me.Label126.Text = "Size"
        '
        'TextFrontYUpDown
        '
        Me.TextFrontYUpDown.Location = New System.Drawing.Point(192, 74)
        Me.TextFrontYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.TextFrontYUpDown.Name = "TextFrontYUpDown"
        Me.TextFrontYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextFrontYUpDown.TabIndex = 76
        Me.TextFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Location = New System.Drawing.Point(165, 79)
        Me.Label127.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(17, 17)
        Me.Label127.TabIndex = 75
        Me.Label127.Text = "Y"
        '
        'TextFrontXUpDown
        '
        Me.TextFrontXUpDown.Location = New System.Drawing.Point(97, 74)
        Me.TextFrontXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.TextFrontXUpDown.Name = "TextFrontXUpDown"
        Me.TextFrontXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextFrontXUpDown.TabIndex = 74
        Me.TextFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Location = New System.Drawing.Point(71, 79)
        Me.Label128.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(17, 17)
        Me.Label128.TabIndex = 73
        Me.Label128.Text = "X"
        '
        'TextFrontStrikethrough
        '
        Me.TextFrontStrikethrough.AutoSize = True
        Me.TextFrontStrikethrough.Location = New System.Drawing.Point(456, 48)
        Me.TextFrontStrikethrough.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontStrikethrough.Name = "TextFrontStrikethrough"
        Me.TextFrontStrikethrough.Size = New System.Drawing.Size(115, 21)
        Me.TextFrontStrikethrough.TabIndex = 72
        Me.TextFrontStrikethrough.Text = "Strikethrough"
        Me.TextFrontStrikethrough.UseVisualStyleBackColor = True
        '
        'TextFrontItalic
        '
        Me.TextFrontItalic.AutoSize = True
        Me.TextFrontItalic.Location = New System.Drawing.Point(376, 48)
        Me.TextFrontItalic.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontItalic.Name = "TextFrontItalic"
        Me.TextFrontItalic.Size = New System.Drawing.Size(58, 21)
        Me.TextFrontItalic.TabIndex = 71
        Me.TextFrontItalic.Text = "Italic"
        Me.TextFrontItalic.UseVisualStyleBackColor = True
        '
        'TextFrontUnderline
        '
        Me.TextFrontUnderline.AutoSize = True
        Me.TextFrontUnderline.Location = New System.Drawing.Point(268, 48)
        Me.TextFrontUnderline.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontUnderline.Name = "TextFrontUnderline"
        Me.TextFrontUnderline.Size = New System.Drawing.Size(91, 21)
        Me.TextFrontUnderline.TabIndex = 70
        Me.TextFrontUnderline.Text = "Underline"
        Me.TextFrontUnderline.UseVisualStyleBackColor = True
        '
        'TextFrontBold
        '
        Me.TextFrontBold.AutoSize = True
        Me.TextFrontBold.Location = New System.Drawing.Point(192, 48)
        Me.TextFrontBold.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontBold.Name = "TextFrontBold"
        Me.TextFrontBold.Size = New System.Drawing.Size(58, 21)
        Me.TextFrontBold.TabIndex = 69
        Me.TextFrontBold.Text = "Bold"
        Me.TextFrontBold.UseVisualStyleBackColor = True
        '
        'TextFrontColourCombo
        '
        Me.TextFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TextFrontColourCombo.Location = New System.Drawing.Point(71, 46)
        Me.TextFrontColourCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontColourCombo.Name = "TextFrontColourCombo"
        Me.TextFrontColourCombo.Size = New System.Drawing.Size(112, 24)
        Me.TextFrontColourCombo.TabIndex = 34
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Location = New System.Drawing.Point(8, 79)
        Me.Label129.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(62, 17)
        Me.Label129.TabIndex = 33
        Me.Label129.Text = "Position:"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Location = New System.Drawing.Point(8, 50)
        Me.Label130.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(49, 17)
        Me.Label130.TabIndex = 32
        Me.Label130.Text = "Colour"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(147, 20)
        Me.Label131.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(35, 17)
        Me.Label131.TabIndex = 31
        Me.Label131.Text = "Text"
        '
        'TextFrontBox
        '
        Me.TextFrontBox.Location = New System.Drawing.Point(192, 15)
        Me.TextFrontBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TextFrontBox.Name = "TextFrontBox"
        Me.TextFrontBox.Size = New System.Drawing.Size(381, 22)
        Me.TextFrontBox.TabIndex = 14
        Me.TextFrontBox.Text = "Front - First Line of VB Text"
        '
        'Back
        '
        Me.Back.Controls.Add(Me.GroupBox34)
        Me.Back.Controls.Add(Me.GroupBox35)
        Me.Back.Controls.Add(Me.GroupBox36)
        Me.Back.Controls.Add(Me.GroupBox37)
        Me.Back.Location = New System.Drawing.Point(4, 25)
        Me.Back.Margin = New System.Windows.Forms.Padding(4)
        Me.Back.Name = "Back"
        Me.Back.Padding = New System.Windows.Forms.Padding(4)
        Me.Back.Size = New System.Drawing.Size(593, 578)
        Me.Back.TabIndex = 1
        Me.Back.Text = "Back"
        Me.Back.UseVisualStyleBackColor = True
        '
        'GroupBox34
        '
        Me.GroupBox34.Controls.Add(Me.ImageBackResin)
        Me.GroupBox34.Controls.Add(Me.ImageBackEnabled)
        Me.GroupBox34.Controls.Add(ImageBackButton)
        Me.GroupBox34.Controls.Add(Me.ImageBackFileBox)
        Me.GroupBox34.Controls.Add(Me.ImageBackP2UpDown)
        Me.GroupBox34.Controls.Add(Me.Label132)
        Me.GroupBox34.Controls.Add(Me.Label133)
        Me.GroupBox34.Controls.Add(Me.ImageBackP1UpDown)
        Me.GroupBox34.Controls.Add(Me.ImageBackYUpDown)
        Me.GroupBox34.Controls.Add(Me.Label134)
        Me.GroupBox34.Controls.Add(Me.ImageBackXUpDown)
        Me.GroupBox34.Controls.Add(Me.Label135)
        Me.GroupBox34.Controls.Add(Me.Label136)
        Me.GroupBox34.Controls.Add(Me.Label137)
        Me.GroupBox34.Location = New System.Drawing.Point(4, 336)
        Me.GroupBox34.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox34.Name = "GroupBox34"
        Me.GroupBox34.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox34.Size = New System.Drawing.Size(583, 92)
        Me.GroupBox34.TabIndex = 91
        Me.GroupBox34.TabStop = False
        Me.GroupBox34.Text = "Image"
        '
        'ImageBackResin
        '
        Me.ImageBackResin.AutoSize = True
        Me.ImageBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ImageBackResin.Enabled = False
        Me.ImageBackResin.Location = New System.Drawing.Point(475, 52)
        Me.ImageBackResin.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackResin.Name = "ImageBackResin"
        Me.ImageBackResin.Size = New System.Drawing.Size(95, 21)
        Me.ImageBackResin.TabIndex = 86
        Me.ImageBackResin.Text = "Use Resin"
        Me.ImageBackResin.UseVisualStyleBackColor = True
        '
        'ImageBackEnabled
        '
        Me.ImageBackEnabled.AutoSize = True
        Me.ImageBackEnabled.Enabled = False
        Me.ImageBackEnabled.Location = New System.Drawing.Point(8, 17)
        Me.ImageBackEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackEnabled.Name = "ImageBackEnabled"
        Me.ImageBackEnabled.Size = New System.Drawing.Size(82, 21)
        Me.ImageBackEnabled.TabIndex = 85
        Me.ImageBackEnabled.Text = "Enabled"
        Me.ImageBackEnabled.UseVisualStyleBackColor = True
        '
        'ImageBackFileBox
        '
        Me.ImageBackFileBox.Enabled = False
        Me.ImageBackFileBox.Location = New System.Drawing.Point(169, 15)
        Me.ImageBackFileBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackFileBox.Name = "ImageBackFileBox"
        Me.ImageBackFileBox.Size = New System.Drawing.Size(363, 22)
        Me.ImageBackFileBox.TabIndex = 83
        '
        'ImageBackP2UpDown
        '
        Me.ImageBackP2UpDown.Enabled = False
        Me.ImageBackP2UpDown.Location = New System.Drawing.Point(344, 49)
        Me.ImageBackP2UpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackP2UpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ImageBackP2UpDown.Name = "ImageBackP2UpDown"
        Me.ImageBackP2UpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageBackP2UpDown.TabIndex = 82
        Me.ImageBackP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Location = New System.Drawing.Point(317, 54)
        Me.Label132.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(25, 17)
        Me.Label132.TabIndex = 81
        Me.Label132.Text = "P2"
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(231, 54)
        Me.Label133.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(25, 17)
        Me.Label133.TabIndex = 80
        Me.Label133.Text = "P1"
        '
        'ImageBackP1UpDown
        '
        Me.ImageBackP1UpDown.Enabled = False
        Me.ImageBackP1UpDown.Location = New System.Drawing.Point(257, 49)
        Me.ImageBackP1UpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackP1UpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ImageBackP1UpDown.Name = "ImageBackP1UpDown"
        Me.ImageBackP1UpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageBackP1UpDown.TabIndex = 78
        Me.ImageBackP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ImageBackYUpDown
        '
        Me.ImageBackYUpDown.Enabled = False
        Me.ImageBackYUpDown.Location = New System.Drawing.Point(171, 49)
        Me.ImageBackYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ImageBackYUpDown.Name = "ImageBackYUpDown"
        Me.ImageBackYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageBackYUpDown.TabIndex = 76
        Me.ImageBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Location = New System.Drawing.Point(152, 54)
        Me.Label134.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(17, 17)
        Me.Label134.TabIndex = 75
        Me.Label134.Text = "Y"
        '
        'ImageBackXUpDown
        '
        Me.ImageBackXUpDown.Enabled = False
        Me.ImageBackXUpDown.Location = New System.Drawing.Point(92, 49)
        Me.ImageBackXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ImageBackXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ImageBackXUpDown.Name = "ImageBackXUpDown"
        Me.ImageBackXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ImageBackXUpDown.TabIndex = 74
        Me.ImageBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Location = New System.Drawing.Point(75, 54)
        Me.Label135.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(17, 17)
        Me.Label135.TabIndex = 73
        Me.Label135.Text = "X"
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Location = New System.Drawing.Point(8, 54)
        Me.Label136.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(62, 17)
        Me.Label136.TabIndex = 33
        Me.Label136.Text = "Position:"
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Location = New System.Drawing.Point(121, 20)
        Me.Label137.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(30, 17)
        Me.Label137.TabIndex = 32
        Me.Label137.Text = "File"
        '
        'GroupBox35
        '
        Me.GroupBox35.Controls.Add(Me.LineBackEnabled)
        Me.GroupBox35.Controls.Add(Me.Label138)
        Me.GroupBox35.Controls.Add(Me.LineBackWidthUpDown)
        Me.GroupBox35.Controls.Add(Me.Label139)
        Me.GroupBox35.Controls.Add(Me.LineBackStartYUpDown)
        Me.GroupBox35.Controls.Add(Me.LineBackEndYUpDown)
        Me.GroupBox35.Controls.Add(Me.Label140)
        Me.GroupBox35.Controls.Add(Me.Label141)
        Me.GroupBox35.Controls.Add(Me.Label142)
        Me.GroupBox35.Controls.Add(Me.Label143)
        Me.GroupBox35.Controls.Add(Me.LineBackResin)
        Me.GroupBox35.Controls.Add(Me.LineBackEndXUpDown)
        Me.GroupBox35.Controls.Add(Me.LineBackColourCombo)
        Me.GroupBox35.Controls.Add(Me.LineBackStartXUpDown)
        Me.GroupBox35.Controls.Add(Me.Label144)
        Me.GroupBox35.Controls.Add(Me.Label145)
        Me.GroupBox35.Location = New System.Drawing.Point(4, 224)
        Me.GroupBox35.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox35.Name = "GroupBox35"
        Me.GroupBox35.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox35.Size = New System.Drawing.Size(583, 105)
        Me.GroupBox35.TabIndex = 90
        Me.GroupBox35.TabStop = False
        Me.GroupBox35.Text = "Line"
        '
        'LineBackEnabled
        '
        Me.LineBackEnabled.AutoSize = True
        Me.LineBackEnabled.Enabled = False
        Me.LineBackEnabled.Location = New System.Drawing.Point(8, 17)
        Me.LineBackEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackEnabled.Name = "LineBackEnabled"
        Me.LineBackEnabled.Size = New System.Drawing.Size(82, 21)
        Me.LineBackEnabled.TabIndex = 84
        Me.LineBackEnabled.Text = "Enabled"
        Me.LineBackEnabled.UseVisualStyleBackColor = True
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Location = New System.Drawing.Point(251, 78)
        Me.Label138.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(37, 17)
        Me.Label138.TabIndex = 82
        Me.Label138.Text = "End:"
        '
        'LineBackWidthUpDown
        '
        Me.LineBackWidthUpDown.Enabled = False
        Me.LineBackWidthUpDown.Location = New System.Drawing.Point(312, 39)
        Me.LineBackWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.LineBackWidthUpDown.Name = "LineBackWidthUpDown"
        Me.LineBackWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineBackWidthUpDown.TabIndex = 81
        Me.LineBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Location = New System.Drawing.Point(268, 44)
        Me.Label139.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(44, 17)
        Me.Label139.TabIndex = 80
        Me.Label139.Text = "Width"
        '
        'LineBackStartYUpDown
        '
        Me.LineBackStartYUpDown.Enabled = False
        Me.LineBackStartYUpDown.Location = New System.Drawing.Point(153, 73)
        Me.LineBackStartYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackStartYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.LineBackStartYUpDown.Name = "LineBackStartYUpDown"
        Me.LineBackStartYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineBackStartYUpDown.TabIndex = 76
        Me.LineBackStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineBackEndYUpDown
        '
        Me.LineBackEndYUpDown.Enabled = False
        Me.LineBackEndYUpDown.Location = New System.Drawing.Point(393, 73)
        Me.LineBackEndYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackEndYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.LineBackEndYUpDown.Name = "LineBackEndYUpDown"
        Me.LineBackEndYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineBackEndYUpDown.TabIndex = 82
        Me.LineBackEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(8, 76)
        Me.Label140.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(42, 17)
        Me.Label140.TabIndex = 80
        Me.Label140.Text = "Start:"
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Location = New System.Drawing.Point(375, 78)
        Me.Label141.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(17, 17)
        Me.Label141.TabIndex = 81
        Me.Label141.Text = "Y"
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Location = New System.Drawing.Point(56, 78)
        Me.Label142.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(17, 17)
        Me.Label142.TabIndex = 73
        Me.Label142.Text = "X"
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Location = New System.Drawing.Point(293, 78)
        Me.Label143.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(17, 17)
        Me.Label143.TabIndex = 80
        Me.Label143.Text = "X"
        '
        'LineBackResin
        '
        Me.LineBackResin.AutoSize = True
        Me.LineBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.LineBackResin.Enabled = False
        Me.LineBackResin.Location = New System.Drawing.Point(475, 17)
        Me.LineBackResin.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackResin.Name = "LineBackResin"
        Me.LineBackResin.Size = New System.Drawing.Size(95, 21)
        Me.LineBackResin.TabIndex = 79
        Me.LineBackResin.Text = "Use Resin"
        Me.LineBackResin.UseVisualStyleBackColor = True
        '
        'LineBackEndXUpDown
        '
        Me.LineBackEndXUpDown.Enabled = False
        Me.LineBackEndXUpDown.Location = New System.Drawing.Point(312, 73)
        Me.LineBackEndXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackEndXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.LineBackEndXUpDown.Name = "LineBackEndXUpDown"
        Me.LineBackEndXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineBackEndXUpDown.TabIndex = 78
        Me.LineBackEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'LineBackColourCombo
        '
        Me.LineBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LineBackColourCombo.Enabled = False
        Me.LineBackColourCombo.Location = New System.Drawing.Point(75, 39)
        Me.LineBackColourCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackColourCombo.Name = "LineBackColourCombo"
        Me.LineBackColourCombo.Size = New System.Drawing.Size(184, 24)
        Me.LineBackColourCombo.TabIndex = 34
        '
        'LineBackStartXUpDown
        '
        Me.LineBackStartXUpDown.Enabled = False
        Me.LineBackStartXUpDown.Location = New System.Drawing.Point(75, 73)
        Me.LineBackStartXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.LineBackStartXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.LineBackStartXUpDown.Name = "LineBackStartXUpDown"
        Me.LineBackStartXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.LineBackStartXUpDown.TabIndex = 74
        Me.LineBackStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Location = New System.Drawing.Point(8, 44)
        Me.Label144.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(49, 17)
        Me.Label144.TabIndex = 32
        Me.Label144.Text = "Colour"
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Location = New System.Drawing.Point(135, 78)
        Me.Label145.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(17, 17)
        Me.Label145.TabIndex = 75
        Me.Label145.Text = "Y"
        '
        'GroupBox36
        '
        Me.GroupBox36.Controls.Add(Me.ShapeBackEnabled)
        Me.GroupBox36.Controls.Add(Me.ShapeBackFillCombo)
        Me.GroupBox36.Controls.Add(Me.Label146)
        Me.GroupBox36.Controls.Add(Me.ShapeBackWidthUpDown)
        Me.GroupBox36.Controls.Add(Me.ShapeBackOutlineCombo)
        Me.GroupBox36.Controls.Add(Me.Label147)
        Me.GroupBox36.Controls.Add(Me.Label148)
        Me.GroupBox36.Controls.Add(Me.ShapeBackBUpDown)
        Me.GroupBox36.Controls.Add(Me.Label149)
        Me.GroupBox36.Controls.Add(Me.Label150)
        Me.GroupBox36.Controls.Add(Me.ShapeBackResin)
        Me.GroupBox36.Controls.Add(Me.ShapeBackRUpDown)
        Me.GroupBox36.Controls.Add(Me.ShapeBackTUpDown)
        Me.GroupBox36.Controls.Add(Me.Label151)
        Me.GroupBox36.Controls.Add(Me.ShapeBackLUpDown)
        Me.GroupBox36.Controls.Add(Me.Label152)
        Me.GroupBox36.Controls.Add(Me.ShapeBackCombo)
        Me.GroupBox36.Controls.Add(Me.Label153)
        Me.GroupBox36.Controls.Add(Me.Label154)
        Me.GroupBox36.Location = New System.Drawing.Point(4, 112)
        Me.GroupBox36.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox36.Name = "GroupBox36"
        Me.GroupBox36.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox36.Size = New System.Drawing.Size(583, 105)
        Me.GroupBox36.TabIndex = 89
        Me.GroupBox36.TabStop = False
        Me.GroupBox36.Text = "Shape"
        '
        'ShapeBackEnabled
        '
        Me.ShapeBackEnabled.AutoSize = True
        Me.ShapeBackEnabled.Enabled = False
        Me.ShapeBackEnabled.Location = New System.Drawing.Point(8, 17)
        Me.ShapeBackEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackEnabled.Name = "ShapeBackEnabled"
        Me.ShapeBackEnabled.Size = New System.Drawing.Size(82, 21)
        Me.ShapeBackEnabled.TabIndex = 83
        Me.ShapeBackEnabled.Text = "Enabled"
        Me.ShapeBackEnabled.UseVisualStyleBackColor = True
        '
        'ShapeBackFillCombo
        '
        Me.ShapeBackFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackFillCombo.Enabled = False
        Me.ShapeBackFillCombo.Items.AddRange(New Object() {"Red", "Green", "Blue", "Cyan", "Magenta", "Yellow", "White", "Black", "Transparent"})
        Me.ShapeBackFillCombo.Location = New System.Drawing.Point(335, 74)
        Me.ShapeBackFillCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackFillCombo.Name = "ShapeBackFillCombo"
        Me.ShapeBackFillCombo.Size = New System.Drawing.Size(168, 24)
        Me.ShapeBackFillCombo.TabIndex = 81
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Location = New System.Drawing.Point(309, 79)
        Me.Label146.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(25, 17)
        Me.Label146.TabIndex = 80
        Me.Label146.Text = "Fill"
        '
        'ShapeBackWidthUpDown
        '
        Me.ShapeBackWidthUpDown.Enabled = False
        Me.ShapeBackWidthUpDown.Location = New System.Drawing.Point(235, 74)
        Me.ShapeBackWidthUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackWidthUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.ShapeBackWidthUpDown.Name = "ShapeBackWidthUpDown"
        Me.ShapeBackWidthUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeBackWidthUpDown.TabIndex = 81
        Me.ShapeBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeBackOutlineCombo
        '
        Me.ShapeBackOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackOutlineCombo.Enabled = False
        Me.ShapeBackOutlineCombo.Location = New System.Drawing.Point(69, 74)
        Me.ShapeBackOutlineCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackOutlineCombo.Name = "ShapeBackOutlineCombo"
        Me.ShapeBackOutlineCombo.Size = New System.Drawing.Size(112, 24)
        Me.ShapeBackOutlineCombo.TabIndex = 81
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Location = New System.Drawing.Point(191, 79)
        Me.Label147.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(44, 17)
        Me.Label147.TabIndex = 80
        Me.Label147.Text = "Width"
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Location = New System.Drawing.Point(8, 79)
        Me.Label148.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(53, 17)
        Me.Label148.TabIndex = 80
        Me.Label148.Text = "Outline"
        '
        'ShapeBackBUpDown
        '
        Me.ShapeBackBUpDown.Enabled = False
        Me.ShapeBackBUpDown.Location = New System.Drawing.Point(504, 46)
        Me.ShapeBackBUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackBUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ShapeBackBUpDown.Name = "ShapeBackBUpDown"
        Me.ShapeBackBUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeBackBUpDown.TabIndex = 82
        Me.ShapeBackBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label149
        '
        Me.Label149.AutoSize = True
        Me.Label149.Location = New System.Drawing.Point(485, 50)
        Me.Label149.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(17, 17)
        Me.Label149.TabIndex = 81
        Me.Label149.Text = "B"
        '
        'Label150
        '
        Me.Label150.AutoSize = True
        Me.Label150.Location = New System.Drawing.Point(405, 50)
        Me.Label150.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(18, 17)
        Me.Label150.TabIndex = 80
        Me.Label150.Text = "R"
        '
        'ShapeBackResin
        '
        Me.ShapeBackResin.AutoSize = True
        Me.ShapeBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ShapeBackResin.Enabled = False
        Me.ShapeBackResin.Location = New System.Drawing.Point(475, 17)
        Me.ShapeBackResin.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackResin.Name = "ShapeBackResin"
        Me.ShapeBackResin.Size = New System.Drawing.Size(95, 21)
        Me.ShapeBackResin.TabIndex = 79
        Me.ShapeBackResin.Text = "Use Resin"
        Me.ShapeBackResin.UseVisualStyleBackColor = True
        '
        'ShapeBackRUpDown
        '
        Me.ShapeBackRUpDown.Enabled = False
        Me.ShapeBackRUpDown.Location = New System.Drawing.Point(425, 46)
        Me.ShapeBackRUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackRUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ShapeBackRUpDown.Name = "ShapeBackRUpDown"
        Me.ShapeBackRUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeBackRUpDown.TabIndex = 78
        Me.ShapeBackRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ShapeBackTUpDown
        '
        Me.ShapeBackTUpDown.Enabled = False
        Me.ShapeBackTUpDown.Location = New System.Drawing.Point(345, 46)
        Me.ShapeBackTUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackTUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.ShapeBackTUpDown.Name = "ShapeBackTUpDown"
        Me.ShapeBackTUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeBackTUpDown.TabIndex = 76
        Me.ShapeBackTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label151
        '
        Me.Label151.AutoSize = True
        Me.Label151.Location = New System.Drawing.Point(327, 50)
        Me.Label151.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(17, 17)
        Me.Label151.TabIndex = 75
        Me.Label151.Text = "T"
        '
        'ShapeBackLUpDown
        '
        Me.ShapeBackLUpDown.Enabled = False
        Me.ShapeBackLUpDown.Location = New System.Drawing.Point(267, 46)
        Me.ShapeBackLUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackLUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.ShapeBackLUpDown.Name = "ShapeBackLUpDown"
        Me.ShapeBackLUpDown.Size = New System.Drawing.Size(60, 22)
        Me.ShapeBackLUpDown.TabIndex = 74
        Me.ShapeBackLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label152
        '
        Me.Label152.AutoSize = True
        Me.Label152.Location = New System.Drawing.Point(249, 50)
        Me.Label152.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(16, 17)
        Me.Label152.TabIndex = 73
        Me.Label152.Text = "L"
        '
        'ShapeBackCombo
        '
        Me.ShapeBackCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ShapeBackCombo.Enabled = False
        Me.ShapeBackCombo.Location = New System.Drawing.Point(69, 46)
        Me.ShapeBackCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.ShapeBackCombo.Name = "ShapeBackCombo"
        Me.ShapeBackCombo.Size = New System.Drawing.Size(112, 24)
        Me.ShapeBackCombo.TabIndex = 34
        '
        'Label153
        '
        Me.Label153.AutoSize = True
        Me.Label153.Location = New System.Drawing.Point(187, 50)
        Me.Label153.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(62, 17)
        Me.Label153.TabIndex = 33
        Me.Label153.Text = "Position:"
        '
        'Label154
        '
        Me.Label154.AutoSize = True
        Me.Label154.Location = New System.Drawing.Point(8, 50)
        Me.Label154.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(49, 17)
        Me.Label154.TabIndex = 32
        Me.Label154.Text = "Shape"
        '
        'GroupBox37
        '
        Me.GroupBox37.Controls.Add(Me.TextBackEnabled)
        Me.GroupBox37.Controls.Add(Me.TextBackResin)
        Me.GroupBox37.Controls.Add(Me.TextBackSizeUpDown)
        Me.GroupBox37.Controls.Add(Me.Label155)
        Me.GroupBox37.Controls.Add(Me.TextBackYUpDown)
        Me.GroupBox37.Controls.Add(Me.Label156)
        Me.GroupBox37.Controls.Add(Me.TextBackXUpDown)
        Me.GroupBox37.Controls.Add(Me.Label157)
        Me.GroupBox37.Controls.Add(Me.TextBackStrikethrough)
        Me.GroupBox37.Controls.Add(Me.TextBackItalic)
        Me.GroupBox37.Controls.Add(Me.TextBackUnderline)
        Me.GroupBox37.Controls.Add(Me.TextBackBold)
        Me.GroupBox37.Controls.Add(Me.TextBackColourCombo)
        Me.GroupBox37.Controls.Add(Me.Label158)
        Me.GroupBox37.Controls.Add(Me.Label159)
        Me.GroupBox37.Controls.Add(Me.Label160)
        Me.GroupBox37.Controls.Add(Me.TextBackBox)
        Me.GroupBox37.Location = New System.Drawing.Point(4, 0)
        Me.GroupBox37.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox37.Name = "GroupBox37"
        Me.GroupBox37.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox37.Size = New System.Drawing.Size(583, 105)
        Me.GroupBox37.TabIndex = 88
        Me.GroupBox37.TabStop = False
        Me.GroupBox37.Text = "Text"
        '
        'TextBackEnabled
        '
        Me.TextBackEnabled.AutoSize = True
        Me.TextBackEnabled.Enabled = False
        Me.TextBackEnabled.Location = New System.Drawing.Point(8, 17)
        Me.TextBackEnabled.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackEnabled.Name = "TextBackEnabled"
        Me.TextBackEnabled.Size = New System.Drawing.Size(82, 21)
        Me.TextBackEnabled.TabIndex = 80
        Me.TextBackEnabled.Text = "Enabled"
        Me.TextBackEnabled.UseVisualStyleBackColor = True
        '
        'TextBackResin
        '
        Me.TextBackResin.AutoSize = True
        Me.TextBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackResin.Enabled = False
        Me.TextBackResin.Location = New System.Drawing.Point(475, 76)
        Me.TextBackResin.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackResin.Name = "TextBackResin"
        Me.TextBackResin.Size = New System.Drawing.Size(95, 21)
        Me.TextBackResin.TabIndex = 79
        Me.TextBackResin.Text = "Use Resin"
        Me.TextBackResin.UseVisualStyleBackColor = True
        '
        'TextBackSizeUpDown
        '
        Me.TextBackSizeUpDown.Enabled = False
        Me.TextBackSizeUpDown.Location = New System.Drawing.Point(321, 74)
        Me.TextBackSizeUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackSizeUpDown.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.TextBackSizeUpDown.Name = "TextBackSizeUpDown"
        Me.TextBackSizeUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextBackSizeUpDown.TabIndex = 78
        Me.TextBackSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label155
        '
        Me.Label155.AutoSize = True
        Me.Label155.Location = New System.Drawing.Point(285, 79)
        Me.Label155.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(35, 17)
        Me.Label155.TabIndex = 77
        Me.Label155.Text = "Size"
        '
        'TextBackYUpDown
        '
        Me.TextBackYUpDown.Enabled = False
        Me.TextBackYUpDown.Location = New System.Drawing.Point(192, 74)
        Me.TextBackYUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackYUpDown.Maximum = New Decimal(New Integer() {642, 0, 0, 0})
        Me.TextBackYUpDown.Name = "TextBackYUpDown"
        Me.TextBackYUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextBackYUpDown.TabIndex = 76
        Me.TextBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label156
        '
        Me.Label156.AutoSize = True
        Me.Label156.Location = New System.Drawing.Point(165, 79)
        Me.Label156.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(17, 17)
        Me.Label156.TabIndex = 75
        Me.Label156.Text = "Y"
        '
        'TextBackXUpDown
        '
        Me.TextBackXUpDown.Enabled = False
        Me.TextBackXUpDown.Location = New System.Drawing.Point(97, 74)
        Me.TextBackXUpDown.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackXUpDown.Maximum = New Decimal(New Integer() {1016, 0, 0, 0})
        Me.TextBackXUpDown.Name = "TextBackXUpDown"
        Me.TextBackXUpDown.Size = New System.Drawing.Size(60, 22)
        Me.TextBackXUpDown.TabIndex = 74
        Me.TextBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label157
        '
        Me.Label157.AutoSize = True
        Me.Label157.Location = New System.Drawing.Point(71, 79)
        Me.Label157.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(17, 17)
        Me.Label157.TabIndex = 73
        Me.Label157.Text = "X"
        '
        'TextBackStrikethrough
        '
        Me.TextBackStrikethrough.AutoSize = True
        Me.TextBackStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackStrikethrough.Enabled = False
        Me.TextBackStrikethrough.Location = New System.Drawing.Point(456, 48)
        Me.TextBackStrikethrough.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackStrikethrough.Name = "TextBackStrikethrough"
        Me.TextBackStrikethrough.Size = New System.Drawing.Size(115, 21)
        Me.TextBackStrikethrough.TabIndex = 72
        Me.TextBackStrikethrough.Text = "Strikethrough"
        Me.TextBackStrikethrough.UseVisualStyleBackColor = True
        '
        'TextBackItalic
        '
        Me.TextBackItalic.AutoSize = True
        Me.TextBackItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackItalic.Enabled = False
        Me.TextBackItalic.Location = New System.Drawing.Point(376, 48)
        Me.TextBackItalic.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackItalic.Name = "TextBackItalic"
        Me.TextBackItalic.Size = New System.Drawing.Size(58, 21)
        Me.TextBackItalic.TabIndex = 71
        Me.TextBackItalic.Text = "Italic"
        Me.TextBackItalic.UseVisualStyleBackColor = True
        '
        'TextBackUnderline
        '
        Me.TextBackUnderline.AutoSize = True
        Me.TextBackUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackUnderline.Enabled = False
        Me.TextBackUnderline.Location = New System.Drawing.Point(268, 48)
        Me.TextBackUnderline.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackUnderline.Name = "TextBackUnderline"
        Me.TextBackUnderline.Size = New System.Drawing.Size(91, 21)
        Me.TextBackUnderline.TabIndex = 70
        Me.TextBackUnderline.Text = "Underline"
        Me.TextBackUnderline.UseVisualStyleBackColor = True
        '
        'TextBackBold
        '
        Me.TextBackBold.AutoSize = True
        Me.TextBackBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TextBackBold.Enabled = False
        Me.TextBackBold.Location = New System.Drawing.Point(192, 48)
        Me.TextBackBold.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackBold.Name = "TextBackBold"
        Me.TextBackBold.Size = New System.Drawing.Size(58, 21)
        Me.TextBackBold.TabIndex = 69
        Me.TextBackBold.Text = "Bold"
        Me.TextBackBold.UseVisualStyleBackColor = True
        '
        'TextBackColourCombo
        '
        Me.TextBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.TextBackColourCombo.Enabled = False
        Me.TextBackColourCombo.Location = New System.Drawing.Point(71, 46)
        Me.TextBackColourCombo.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackColourCombo.Name = "TextBackColourCombo"
        Me.TextBackColourCombo.Size = New System.Drawing.Size(112, 24)
        Me.TextBackColourCombo.TabIndex = 34
        '
        'Label158
        '
        Me.Label158.AutoSize = True
        Me.Label158.Location = New System.Drawing.Point(8, 79)
        Me.Label158.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(62, 17)
        Me.Label158.TabIndex = 33
        Me.Label158.Text = "Position:"
        '
        'Label159
        '
        Me.Label159.AutoSize = True
        Me.Label159.Location = New System.Drawing.Point(8, 50)
        Me.Label159.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(49, 17)
        Me.Label159.TabIndex = 32
        Me.Label159.Text = "Colour"
        '
        'Label160
        '
        Me.Label160.AutoSize = True
        Me.Label160.Location = New System.Drawing.Point(147, 20)
        Me.Label160.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(35, 17)
        Me.Label160.TabIndex = 31
        Me.Label160.Text = "Text"
        '
        'TextBackBox
        '
        Me.TextBackBox.Enabled = False
        Me.TextBackBox.Location = New System.Drawing.Point(192, 15)
        Me.TextBackBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBackBox.Name = "TextBackBox"
        Me.TextBackBox.Size = New System.Drawing.Size(381, 22)
        Me.TextBackBox.TabIndex = 14
        Me.TextBackBox.Text = "Back - First Line of VB Text"
        '
        'CardBack
        '
        Me.CardBack.AutoSize = True
        Me.CardBack.Location = New System.Drawing.Point(331, 10)
        Me.CardBack.Margin = New System.Windows.Forms.Padding(4)
        Me.CardBack.Name = "CardBack"
        Me.CardBack.Size = New System.Drawing.Size(95, 21)
        Me.CardBack.TabIndex = 71
        Me.CardBack.Text = "Card Back"
        Me.CardBack.UseVisualStyleBackColor = True
        '
        'CardFront
        '
        Me.CardFront.AutoSize = True
        Me.CardFront.Checked = True
        Me.CardFront.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CardFront.Location = New System.Drawing.Point(187, 10)
        Me.CardFront.Margin = New System.Windows.Forms.Padding(4)
        Me.CardFront.Name = "CardFront"
        Me.CardFront.Size = New System.Drawing.Size(97, 21)
        Me.CardFront.TabIndex = 70
        Me.CardFront.Text = "Card Front"
        Me.CardFront.UseVisualStyleBackColor = True
        '
        'PrintButton
        '
        Me.PrintButton.Location = New System.Drawing.Point(481, 650)
        Me.PrintButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintButton.Name = "PrintButton"
        Me.PrintButton.Size = New System.Drawing.Size(120, 30)
        Me.PrintButton.TabIndex = 69
        Me.PrintButton.Text = "Print"
        Me.PrintButton.UseVisualStyleBackColor = True
        '
        'Utils
        '
        Me.Utils.Controls.Add(Me.SendAPDUButton)
        Me.Utils.Controls.Add(Me.SendAPDUBox)
        Me.Utils.Controls.Add(Me.ClearUtilsMsgBoxButton)
        Me.Utils.Controls.Add(Me.UtilsMsgBox)
        Me.Utils.Location = New System.Drawing.Point(4, 25)
        Me.Utils.Margin = New System.Windows.Forms.Padding(4)
        Me.Utils.Name = "Utils"
        Me.Utils.Padding = New System.Windows.Forms.Padding(4)
        Me.Utils.Size = New System.Drawing.Size(621, 700)
        Me.Utils.TabIndex = 7
        Me.Utils.Text = "Utils"
        Me.Utils.UseVisualStyleBackColor = True
        '
        'SendAPDUButton
        '
        Me.SendAPDUButton.Location = New System.Drawing.Point(420, 95)
        Me.SendAPDUButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SendAPDUButton.Name = "SendAPDUButton"
        Me.SendAPDUButton.Size = New System.Drawing.Size(120, 30)
        Me.SendAPDUButton.TabIndex = 3
        Me.SendAPDUButton.Text = "Send APDU"
        Me.SendAPDUButton.UseVisualStyleBackColor = True
        '
        'SendAPDUBox
        '
        Me.SendAPDUBox.Location = New System.Drawing.Point(20, 78)
        Me.SendAPDUBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SendAPDUBox.Multiline = True
        Me.SendAPDUBox.Name = "SendAPDUBox"
        Me.SendAPDUBox.Size = New System.Drawing.Size(381, 66)
        Me.SendAPDUBox.TabIndex = 2
        '
        'ClearUtilsMsgBoxButton
        '
        Me.ClearUtilsMsgBoxButton.Location = New System.Drawing.Point(250, 500)
        Me.ClearUtilsMsgBoxButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearUtilsMsgBoxButton.Name = "ClearUtilsMsgBoxButton"
        Me.ClearUtilsMsgBoxButton.Size = New System.Drawing.Size(120, 30)
        Me.ClearUtilsMsgBoxButton.TabIndex = 16
        Me.ClearUtilsMsgBoxButton.Text = "Clear"
        Me.ClearUtilsMsgBoxButton.UseVisualStyleBackColor = True
        '
        'UtilsMsgBox
        '
        Me.UtilsMsgBox.Location = New System.Drawing.Point(140, 212)
        Me.UtilsMsgBox.Margin = New System.Windows.Forms.Padding(4)
        Me.UtilsMsgBox.Multiline = True
        Me.UtilsMsgBox.Name = "UtilsMsgBox"
        Me.UtilsMsgBox.ReadOnly = True
        Me.UtilsMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.UtilsMsgBox.Size = New System.Drawing.Size(340, 276)
        Me.UtilsMsgBox.TabIndex = 15
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(0, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(520, 736)
        Me.ExitButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(99, 30)
        Me.ExitButton.TabIndex = 13
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'PrinterID
        '
        Me.PrinterID.AutoSize = True
        Me.PrinterID.Location = New System.Drawing.Point(12, 743)
        Me.PrinterID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PrinterID.Name = "PrinterID"
        Me.PrinterID.Size = New System.Drawing.Size(54, 17)
        Me.PrinterID.TabIndex = 14
        Me.PrinterID.Text = "Printer:"
        Me.PrinterID.Visible = False
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(635, 780)
        Me.Controls.Add(Me.PrinterID)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.TabControl)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Main"
        Me.Text = "DTC SDK VB Demo (32 bit)"
        Me.TabControl.ResumeLayout(False)
        Me.Printer.ResumeLayout(False)
        Me.GenCmdGroupBox.ResumeLayout(False)
        Me.GenCmdGroupBox.PerformLayout()
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox5.PerformLayout()
        CType(Me.EraseCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseArea_TopRYBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseArea_TopRXBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseArea_BotLYBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseArea_BotLXBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.IPGroupBox.ResumeLayout(False)
        Me.IPGroupBox.PerformLayout()
        CType(Me.SmartOffsetBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Information.ResumeLayout(False)
        Me.groupBox28.ResumeLayout(False)
        Me.groupBox28.PerformLayout()
        Me.GroupBox27.ResumeLayout(False)
        Me.GroupBox27.PerformLayout()
        Me.Generation2GroupBox.ResumeLayout(False)
        Me.Generation2GroupBox.PerformLayout()
        Me.Encoding.ResumeLayout(False)
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox19.PerformLayout()
        CType(Me.MagStartPosition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox9.ResumeLayout(False)
        Me.groupBox9.PerformLayout()
        Me.groupBox8.ResumeLayout(False)
        Me.groupBox8.PerformLayout()
        Me.Driver1.ResumeLayout(False)
        Me.Driver1.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.groupBox7.ResumeLayout(False)
        Me.groupBox7.PerformLayout()
        CType(Me.PrintableAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrintableAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrintableAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PrintableAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox13.ResumeLayout(False)
        Me.groupBox13.PerformLayout()
        CType(Me.ErasePowerEndUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WritePowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErasePowerStartUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EraseAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox12.ResumeLayout(False)
        Me.groupBox12.PerformLayout()
        CType(Me.AreaHoleHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AreaHoleNoUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AreaHoleBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AreaHoleWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AreaHoleLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox11.ResumeLayout(False)
        Me.groupBox11.PerformLayout()
        CType(Me.ResinAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaNoUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox10.ResumeLayout(False)
        Me.groupBox10.PerformLayout()
        CType(Me.OvercoatPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResinPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YMCPowerUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SharpnessUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Driver2.ResumeLayout(False)
        Me.Driver2.PerformLayout()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox18.PerformLayout()
        CType(Me.ColourAdjust_WhiteRef, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_BlackRef, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Blue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Green, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Red, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Tint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Colour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Brightness, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAdjust_Contrast, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox23.ResumeLayout(False)
        Me.groupBox23.PerformLayout()
        CType(Me.ColourAreaHeightUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaBottomUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaLeftUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ColourAreaNo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox17.ResumeLayout(False)
        Me.groupBox17.PerformLayout()
        CType(Me.HoloPatchPositionUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox16.ResumeLayout(False)
        Me.groupBox16.PerformLayout()
        CType(Me.HoloKoteMapUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HoloKoteImageUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox15.ResumeLayout(False)
        Me.groupBox15.PerformLayout()
        Me.groupBox14.ResumeLayout(False)
        Me.groupBox14.PerformLayout()
        CType(Me.CopyCountUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PrintDemo.ResumeLayout(False)
        Me.PrintDemo.PerformLayout()
        Me.CardSide.ResumeLayout(False)
        Me.Front.ResumeLayout(False)
        Me.GroupBox29.ResumeLayout(False)
        Me.GroupBox29.PerformLayout()
        Me.GroupBox30.ResumeLayout(False)
        Me.GroupBox30.PerformLayout()
        CType(Me.ImageFrontP2UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontP1UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageFrontXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox31.ResumeLayout(False)
        Me.GroupBox31.PerformLayout()
        CType(Me.LineFrontWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontStartYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontEndYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontEndXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineFrontStartXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox32.ResumeLayout(False)
        Me.GroupBox32.PerformLayout()
        CType(Me.ShapeFrontWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontBUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontRUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontTUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeFrontLUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox33.ResumeLayout(False)
        Me.groupBox33.PerformLayout()
        CType(Me.TextFrontSizeUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextFrontYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextFrontXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Back.ResumeLayout(False)
        Me.GroupBox34.ResumeLayout(False)
        Me.GroupBox34.PerformLayout()
        CType(Me.ImageBackP2UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackP1UpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImageBackXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox35.ResumeLayout(False)
        Me.GroupBox35.PerformLayout()
        CType(Me.LineBackWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackStartYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackEndYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackEndXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LineBackStartXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox36.ResumeLayout(False)
        Me.GroupBox36.PerformLayout()
        CType(Me.ShapeBackWidthUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackBUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackRUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackTUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShapeBackLUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox37.ResumeLayout(False)
        Me.GroupBox37.PerformLayout()
        CType(Me.TextBackSizeUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBackYUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TextBackXUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Utils.ResumeLayout(False)
        Me.Utils.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl As System.Windows.Forms.TabControl
    Friend WithEvents Printer As System.Windows.Forms.TabPage
    Friend WithEvents Information As System.Windows.Forms.TabPage
    Friend WithEvents Encoding As System.Windows.Forms.TabPage
    Private WithEvents Button1 As System.Windows.Forms.Button
    Private WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Private WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents OpenSessionButton As System.Windows.Forms.Button
    Private WithEvents CloseSessionButton As System.Windows.Forms.Button
    Private WithEvents groupBox5 As System.Windows.Forms.GroupBox
    Private WithEvents EraseArea_TopRYBox As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseArea_TopRXBox As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseArea_BotLYBox As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseArea_BotLXBox As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseSpeedButton As System.Windows.Forms.Button
    Private WithEvents EraseSpeedCombo As System.Windows.Forms.ComboBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents EraseCardButton As System.Windows.Forms.Button
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents SmartOffsetBox As System.Windows.Forms.NumericUpDown
    Private WithEvents SmartOffsetButton As System.Windows.Forms.Button
    Private WithEvents SmartModeButton As System.Windows.Forms.Button
    Private WithEvents SmartModeCombo As System.Windows.Forms.ComboBox
    Private WithEvents EjectModeButton As System.Windows.Forms.Button
    Private WithEvents EjectModeCombo As System.Windows.Forms.ComboBox
    Private WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents GenCommandButton As System.Windows.Forms.Button
    Private WithEvents RestartButton As System.Windows.Forms.Button
    Private WithEvents GenCommandBox As System.Windows.Forms.TextBox
    Private WithEvents EjectCardButton As System.Windows.Forms.Button
    Private WithEvents FlipCardButton As System.Windows.Forms.Button
    Private WithEvents CleanPrinterButton As System.Windows.Forms.Button
    Private WithEvents PrintTestCardButton As System.Windows.Forms.Button
    Private WithEvents PrinterInfoButton As System.Windows.Forms.Button
    Private WithEvents PrinterStatusButton As System.Windows.Forms.Button
    Private WithEvents InfoMsgBox As System.Windows.Forms.TextBox
    Private WithEvents ReadMagButton As System.Windows.Forms.Button
    Private WithEvents EncodeMagButton As System.Windows.Forms.Button
    Private WithEvents EncodingBox As System.Windows.Forms.TextBox
    'Friend WithEvents pd As System.Windows.Forms.PrintDialog
    Private WithEvents LastMessageButton As System.Windows.Forms.Button
    Private WithEvents ClearMsgBoxButton As System.Windows.Forms.Button
    Private WithEvents ClearEncodingBoxButton As System.Windows.Forms.Button
    Private WithEvents Track2Data As System.Windows.Forms.TextBox
    Private WithEvents ErrorResponseButton As System.Windows.Forms.Button
    Private WithEvents ErrorResponseCombo As System.Windows.Forms.ComboBox
    Private WithEvents FeedMoveCombo As System.Windows.Forms.ComboBox
    Private WithEvents GenCmdGroupBox As System.Windows.Forms.GroupBox
    Private WithEvents SDKVersionButton As System.Windows.Forms.Button
    Friend WithEvents Driver1 As System.Windows.Forms.TabPage
    Friend WithEvents Driver2 As System.Windows.Forms.TabPage
    Private WithEvents PrinterMsgBox As System.Windows.Forms.TextBox
    Private WithEvents IPGroupBox As System.Windows.Forms.GroupBox
    Private WithEvents IPGatewayLabel As System.Windows.Forms.Label
    Private WithEvents IPSubnetLabel As System.Windows.Forms.Label
    Private WithEvents IPAddressLabel As System.Windows.Forms.Label
    Private WithEvents IPGatewayBox As System.Windows.Forms.TextBox
    Private WithEvents IPSubnetBox As System.Windows.Forms.TextBox
    Private WithEvents IPAddressBox As System.Windows.Forms.TextBox
    Private WithEvents IPSettingsButton As System.Windows.Forms.Button
    Private WithEvents IPModeLabel As System.Windows.Forms.Label
    Private WithEvents IPModeCombo As System.Windows.Forms.ComboBox
    Private WithEvents ClearPrinterMsgButton As System.Windows.Forms.Button
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents PrinterSetRadio As System.Windows.Forms.RadioButton
    Private WithEvents PrinterGetRadio As System.Windows.Forms.RadioButton
    Private WithEvents HandFeedCombo As System.Windows.Forms.ComboBox
    Private WithEvents HorzEjectCombo As System.Windows.Forms.ComboBox
    Private WithEvents HorzEjectButton As System.Windows.Forms.Button
    Private WithEvents HandFeedButton As System.Windows.Forms.Button
    Private WithEvents ConnectionTypeButton As System.Windows.Forms.Button
    Private WithEvents Version As System.Windows.Forms.Label
    Private WithEvents ExitButton As System.Windows.Forms.Button
    Private WithEvents groupBox9 As System.Windows.Forms.GroupBox
    Private WithEvents label112 As System.Windows.Forms.Label
    Private WithEvents LRCLabel As System.Windows.Forms.Label
    Private WithEvents ParityLabel As System.Windows.Forms.Label
    Private WithEvents BitsPerInchLabel As System.Windows.Forms.Label
    Private WithEvents BitsPerCharLabel As System.Windows.Forms.Label
    Private WithEvents Track3SettingsLabel As System.Windows.Forms.Label
    Private WithEvents Track2SettingsLabel As System.Windows.Forms.Label
    Private WithEvents Track1SettingsLabel As System.Windows.Forms.Label
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents Track3Label As System.Windows.Forms.Label
    Private WithEvents Track2Label As System.Windows.Forms.Label
    Private WithEvents Track1Data As System.Windows.Forms.TextBox
    Private WithEvents Track3Data As System.Windows.Forms.TextBox
    Private WithEvents Track1 As System.Windows.Forms.CheckBox
    Private WithEvents Track2 As System.Windows.Forms.CheckBox
    Private WithEvents Track3 As System.Windows.Forms.CheckBox
    Private WithEvents EncodingTypeCombo As System.Windows.Forms.ComboBox
    Private WithEvents CoercivityCombo As System.Windows.Forms.ComboBox
    Private WithEvents Verify As System.Windows.Forms.CheckBox
    Private WithEvents T1_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T1_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents T1_ParityCombo As System.Windows.Forms.ComboBox
    Private WithEvents T1_LRCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_ParityCombo As System.Windows.Forms.ComboBox
    Private WithEvents T2_LRCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_BPCCombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_BPICombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_ParityCombo As System.Windows.Forms.ComboBox
    Private WithEvents T3_LRCCombo As System.Windows.Forms.ComboBox
    Private WithEvents Track1Label As System.Windows.Forms.Label
    Private WithEvents groupBox8 As System.Windows.Forms.GroupBox
    Private WithEvents groupBox13 As System.Windows.Forms.GroupBox
    Private WithEvents EraseBeforePrint As System.Windows.Forms.CheckBox
    Private WithEvents EraseEndPowerLabel As System.Windows.Forms.Label
    Private WithEvents ErasePowerEndUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents WritePowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents WritePowerLabel As System.Windows.Forms.Label
    Private WithEvents label40 As System.Windows.Forms.Label
    Private WithEvents label34 As System.Windows.Forms.Label
    Private WithEvents label35 As System.Windows.Forms.Label
    Private WithEvents EraseAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ErasePowerStartUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label36 As System.Windows.Forms.Label
    Private WithEvents label37 As System.Windows.Forms.Label
    Private WithEvents EraseAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents EraseAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label38 As System.Windows.Forms.Label
    Private WithEvents label39 As System.Windows.Forms.Label
    Private WithEvents RewritableButton As System.Windows.Forms.Button
    Private WithEvents groupBox12 As System.Windows.Forms.GroupBox
    Private WithEvents AreaHoleTypeCombo As System.Windows.Forms.ComboBox
    Private WithEvents label33 As System.Windows.Forms.Label
    Private WithEvents label27 As System.Windows.Forms.Label
    Private WithEvents AreaHoleHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents AreaHoleNoUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label28 As System.Windows.Forms.Label
    Private WithEvents AreaHoleSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label29 As System.Windows.Forms.Label
    Private WithEvents AreaHoleBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents AreaHoleWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents AreaHoleLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label30 As System.Windows.Forms.Label
    Private WithEvents label31 As System.Windows.Forms.Label
    Private WithEvents label32 As System.Windows.Forms.Label
    Private WithEvents AreaHoleButton As System.Windows.Forms.Button
    Private WithEvents groupBox11 As System.Windows.Forms.GroupBox
    Private WithEvents label26 As System.Windows.Forms.Label
    Private WithEvents ResinAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaNoUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label25 As System.Windows.Forms.Label
    Private WithEvents ResinAreaSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label24 As System.Windows.Forms.Label
    Private WithEvents ResinAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label21 As System.Windows.Forms.Label
    Private WithEvents label22 As System.Windows.Forms.Label
    Private WithEvents label23 As System.Windows.Forms.Label
    Private WithEvents ResinAreaButton As System.Windows.Forms.Button
    Private WithEvents groupBox10 As System.Windows.Forms.GroupBox
    Private WithEvents OvercoatPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ResinPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents YMCPowerUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label20 As System.Windows.Forms.Label
    Private WithEvents label19 As System.Windows.Forms.Label
    Private WithEvents label18 As System.Windows.Forms.Label
    Private WithEvents PowerLevelButton As System.Windows.Forms.Button
    Private WithEvents PrintSpeedButton As System.Windows.Forms.Button
    Private WithEvents PrintSpeedCombo As System.Windows.Forms.ComboBox
    Private WithEvents ColourCorrectionButton As System.Windows.Forms.Button
    Private WithEvents CorrectionCombo As System.Windows.Forms.ComboBox
    Private WithEvents SharpnessUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents GUIControlButton As System.Windows.Forms.Button
    Private WithEvents SharpnessButton As System.Windows.Forms.Button
    Private WithEvents label16 As System.Windows.Forms.Label
    Private WithEvents Driver1SetRadio As System.Windows.Forms.RadioButton
    Private WithEvents Driver1GetRadio As System.Windows.Forms.RadioButton
    Private WithEvents ClearDriver1MsgBoxButton As System.Windows.Forms.Button
    Private WithEvents Driver1MsgBox As System.Windows.Forms.TextBox
    Private WithEvents groupBox17 As System.Windows.Forms.GroupBox
    Private WithEvents HoloPatchPositionUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label53 As System.Windows.Forms.Label
    Private WithEvents ColourHole As System.Windows.Forms.CheckBox
    Private WithEvents HoloPatchButton As System.Windows.Forms.Button
    Private WithEvents groupBox16 As System.Windows.Forms.GroupBox
    Private WithEvents HoloKoteMapUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents HoloKoteImageUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label52 As System.Windows.Forms.Label
    Private WithEvents HoloKoteSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents NoCustomKey As System.Windows.Forms.CheckBox
    Private WithEvents label49 As System.Windows.Forms.Label
    Private WithEvents HoloKoteRotationCombo As System.Windows.Forms.ComboBox
    Private WithEvents UseLaminate As System.Windows.Forms.CheckBox
    Private WithEvents label50 As System.Windows.Forms.Label
    Private WithEvents label51 As System.Windows.Forms.Label
    Private WithEvents HoloKoteButton As System.Windows.Forms.Button
    Private WithEvents groupBox15 As System.Windows.Forms.GroupBox
    Private WithEvents Rotate As System.Windows.Forms.CheckBox
    Private WithEvents Overcoat As System.Windows.Forms.CheckBox
    Private WithEvents CardSettingsSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label47 As System.Windows.Forms.Label
    Private WithEvents OrientationCombo As System.Windows.Forms.ComboBox
    Private WithEvents label44 As System.Windows.Forms.Label
    Private WithEvents ColourFormatCombo As System.Windows.Forms.ComboBox
    Private WithEvents label48 As System.Windows.Forms.Label
    Private WithEvents CardSettingsButton As System.Windows.Forms.Button
    Private WithEvents groupBox14 As System.Windows.Forms.GroupBox
    Private WithEvents CardSizeCombo As System.Windows.Forms.ComboBox
    Private WithEvents label43 As System.Windows.Forms.Label
    Private WithEvents CopyCountUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents label45 As System.Windows.Forms.Label
    Private WithEvents DuplexCombo As System.Windows.Forms.ComboBox
    Private WithEvents label46 As System.Windows.Forms.Label
    Private WithEvents PrintSettingsButton As System.Windows.Forms.Button
    Private WithEvents ClearDriver2MsgBoxButton As System.Windows.Forms.Button
    Private WithEvents Driver2MsgBox As System.Windows.Forms.TextBox
    Private WithEvents label17 As System.Windows.Forms.Label
    Private WithEvents Driver2SetRadio As System.Windows.Forms.RadioButton
    Private WithEvents Driver2GetRadio As System.Windows.Forms.RadioButton
    Private WithEvents JIS2Label As System.Windows.Forms.Label
    Private WithEvents GUIPrinterCheck As System.Windows.Forms.CheckBox
    Private WithEvents GUIUserCheck As System.Windows.Forms.CheckBox
    Private WithEvents SessionConfigCombo As System.Windows.Forms.ComboBox
    Private WithEvents EraseCount As System.Windows.Forms.NumericUpDown
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents PrinterModelButton As System.Windows.Forms.Button
    Private WithEvents groupBox28 As System.Windows.Forms.GroupBox
    Private WithEvents Pwd2Label As System.Windows.Forms.Label
    Private WithEvents Pwd1Label As System.Windows.Forms.Label
    Private WithEvents PasswordButton As System.Windows.Forms.Button
    Private WithEvents Password2 As System.Windows.Forms.TextBox
    Private WithEvents Password1 As System.Windows.Forms.TextBox
    Private WithEvents PasswordCommand As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox27 As System.Windows.Forms.GroupBox
    Friend WithEvents PrintDemo As System.Windows.Forms.TabPage
    Private WithEvents CardSide As System.Windows.Forms.TabControl
    Private WithEvents Front As System.Windows.Forms.TabPage
    Private WithEvents GroupBox29 As System.Windows.Forms.GroupBox
    Private WithEvents Track3MagData As System.Windows.Forms.TextBox
    Private WithEvents Track2MagData As System.Windows.Forms.TextBox
    Private WithEvents Track1MagData As System.Windows.Forms.TextBox
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents MagDataEnabled As System.Windows.Forms.CheckBox
    Private WithEvents GroupBox30 As System.Windows.Forms.GroupBox
    Private WithEvents ImageFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents ImageFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ImageFrontButton As System.Windows.Forms.Button
    Private WithEvents ImageFrontFileBox As System.Windows.Forms.TextBox
    Private WithEvents ImageFrontP2UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents ImageFrontP1UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ImageFrontYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label14 As System.Windows.Forms.Label
    Private WithEvents ImageFrontXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label106 As System.Windows.Forms.Label
    Private WithEvents Label107 As System.Windows.Forms.Label
    Private WithEvents GroupBox31 As System.Windows.Forms.GroupBox
    Private WithEvents LineFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents Label108 As System.Windows.Forms.Label
    Private WithEvents LineFrontWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label109 As System.Windows.Forms.Label
    Private WithEvents LineFrontStartYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineFrontEndYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label110 As System.Windows.Forms.Label
    Private WithEvents Label111 As System.Windows.Forms.Label
    Private WithEvents Label113 As System.Windows.Forms.Label
    Private WithEvents Label114 As System.Windows.Forms.Label
    Private WithEvents LineFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents LineFrontEndXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineFrontColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents LineFrontStartXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label115 As System.Windows.Forms.Label
    Private WithEvents Label116 As System.Windows.Forms.Label
    Private WithEvents GroupBox32 As System.Windows.Forms.GroupBox
    Private WithEvents ShapeFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ShapeFrontFillCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label117 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeFrontOutlineCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label118 As System.Windows.Forms.Label
    Private WithEvents Label119 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontBUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label120 As System.Windows.Forms.Label
    Private WithEvents Label121 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents ShapeFrontRUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeFrontTUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label122 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontLUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label123 As System.Windows.Forms.Label
    Private WithEvents ShapeFrontCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label124 As System.Windows.Forms.Label
    Private WithEvents Label125 As System.Windows.Forms.Label
    Private WithEvents groupBox33 As System.Windows.Forms.GroupBox
    Private WithEvents TextFrontEnabled As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontResin As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontSizeUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label126 As System.Windows.Forms.Label
    Private WithEvents TextFrontYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label127 As System.Windows.Forms.Label
    Private WithEvents TextFrontXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label128 As System.Windows.Forms.Label
    Private WithEvents TextFrontStrikethrough As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontItalic As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontUnderline As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontBold As System.Windows.Forms.CheckBox
    Private WithEvents TextFrontColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label129 As System.Windows.Forms.Label
    Private WithEvents Label130 As System.Windows.Forms.Label
    Private WithEvents Label131 As System.Windows.Forms.Label
    Private WithEvents TextFrontBox As System.Windows.Forms.TextBox
    Private WithEvents Back As System.Windows.Forms.TabPage
    Private WithEvents GroupBox34 As System.Windows.Forms.GroupBox
    Private WithEvents ImageBackResin As System.Windows.Forms.CheckBox
    Private WithEvents ImageBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ImageBackFileBox As System.Windows.Forms.TextBox
    Private WithEvents ImageBackP2UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label132 As System.Windows.Forms.Label
    Private WithEvents Label133 As System.Windows.Forms.Label
    Private WithEvents ImageBackP1UpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ImageBackYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label134 As System.Windows.Forms.Label
    Private WithEvents ImageBackXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label135 As System.Windows.Forms.Label
    Private WithEvents Label136 As System.Windows.Forms.Label
    Private WithEvents Label137 As System.Windows.Forms.Label
    Private WithEvents GroupBox35 As System.Windows.Forms.GroupBox
    Private WithEvents LineBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents Label138 As System.Windows.Forms.Label
    Private WithEvents LineBackWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label139 As System.Windows.Forms.Label
    Private WithEvents LineBackStartYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineBackEndYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label140 As System.Windows.Forms.Label
    Private WithEvents Label141 As System.Windows.Forms.Label
    Private WithEvents Label142 As System.Windows.Forms.Label
    Private WithEvents Label143 As System.Windows.Forms.Label
    Private WithEvents LineBackResin As System.Windows.Forms.CheckBox
    Private WithEvents LineBackEndXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents LineBackColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents LineBackStartXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label144 As System.Windows.Forms.Label
    Private WithEvents Label145 As System.Windows.Forms.Label
    Private WithEvents GroupBox36 As System.Windows.Forms.GroupBox
    Private WithEvents ShapeBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents ShapeBackFillCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label146 As System.Windows.Forms.Label
    Private WithEvents ShapeBackWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeBackOutlineCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label147 As System.Windows.Forms.Label
    Private WithEvents Label148 As System.Windows.Forms.Label
    Private WithEvents ShapeBackBUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label149 As System.Windows.Forms.Label
    Private WithEvents Label150 As System.Windows.Forms.Label
    Private WithEvents ShapeBackResin As System.Windows.Forms.CheckBox
    Private WithEvents ShapeBackRUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ShapeBackTUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label151 As System.Windows.Forms.Label
    Private WithEvents ShapeBackLUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label152 As System.Windows.Forms.Label
    Private WithEvents ShapeBackCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label153 As System.Windows.Forms.Label
    Private WithEvents Label154 As System.Windows.Forms.Label
    Private WithEvents GroupBox37 As System.Windows.Forms.GroupBox
    Private WithEvents TextBackEnabled As System.Windows.Forms.CheckBox
    Private WithEvents TextBackResin As System.Windows.Forms.CheckBox
    Private WithEvents TextBackSizeUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label155 As System.Windows.Forms.Label
    Private WithEvents TextBackYUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label156 As System.Windows.Forms.Label
    Private WithEvents TextBackXUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label157 As System.Windows.Forms.Label
    Private WithEvents TextBackStrikethrough As System.Windows.Forms.CheckBox
    Private WithEvents TextBackItalic As System.Windows.Forms.CheckBox
    Private WithEvents TextBackUnderline As System.Windows.Forms.CheckBox
    Private WithEvents TextBackBold As System.Windows.Forms.CheckBox
    Private WithEvents TextBackColourCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label158 As System.Windows.Forms.Label
    Private WithEvents Label159 As System.Windows.Forms.Label
    Private WithEvents Label160 As System.Windows.Forms.Label
    Private WithEvents TextBackBox As System.Windows.Forms.TextBox
    Private WithEvents CardBack As System.Windows.Forms.CheckBox
    Private WithEvents CardFront As System.Windows.Forms.CheckBox
    Private WithEvents PrintButton As System.Windows.Forms.Button
    Private WithEvents groupBox23 As System.Windows.Forms.GroupBox
    Private WithEvents label86 As System.Windows.Forms.Label
    Private WithEvents ColourAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label55 As System.Windows.Forms.Label
    Private WithEvents Label56 As System.Windows.Forms.Label
    Private WithEvents Label57 As System.Windows.Forms.Label
    Private WithEvents ColourAreaNo As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAreaSideCombo As System.Windows.Forms.ComboBox
    Private WithEvents label85 As System.Windows.Forms.Label
    Private WithEvents ColourAreaCorrectionCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label54 As System.Windows.Forms.Label
    Private WithEvents ColourAreaButton As System.Windows.Forms.Button
    Private WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Private WithEvents ColourAdjust_WhiteRef As System.Windows.Forms.NumericUpDown
    Private WithEvents Label58 As System.Windows.Forms.Label
    Private WithEvents Label59 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_BlackRef As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Illuminant As System.Windows.Forms.ComboBox
    Private WithEvents Label60 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_Negative As System.Windows.Forms.CheckBox
    Private WithEvents ColourAdjust_DarkPic As System.Windows.Forms.CheckBox
    Private WithEvents ColourAdjust_Blue As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Green As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Red As System.Windows.Forms.NumericUpDown
    Private WithEvents Label61 As System.Windows.Forms.Label
    Private WithEvents Label62 As System.Windows.Forms.Label
    Private WithEvents Label63 As System.Windows.Forms.Label
    Private WithEvents Label64 As System.Windows.Forms.Label
    Private WithEvents ColourAdjust_Tint As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Colour As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Brightness As System.Windows.Forms.NumericUpDown
    Private WithEvents ColourAdjust_Contrast As System.Windows.Forms.NumericUpDown
    Private WithEvents Label65 As System.Windows.Forms.Label
    Private WithEvents Label66 As System.Windows.Forms.Label
    Private WithEvents Label67 As System.Windows.Forms.Label
    Private WithEvents ColourAdjustBtn As System.Windows.Forms.Button
    Private WithEvents ReadMagTracks As System.Windows.Forms.Button
    Private WithEvents Track2Read As System.Windows.Forms.CheckBox
    Private WithEvents Track3Read As System.Windows.Forms.CheckBox
    Private WithEvents Track1Read As System.Windows.Forms.CheckBox
    Private WithEvents SDKBitsButton As System.Windows.Forms.Button
    Private WithEvents MoveFilmCombo As System.Windows.Forms.ComboBox
    Private WithEvents CardLocationButton As System.Windows.Forms.Button
    Private WithEvents Generation2GroupBox As System.Windows.Forms.GroupBox
    Private WithEvents ReadParamButton As System.Windows.Forms.Button
    Private WithEvents ParamCombo As System.Windows.Forms.ComboBox
    Private WithEvents Label68 As System.Windows.Forms.Label
    Private WithEvents PrinterID As System.Windows.Forms.Label
    Private WithEvents AllParamsButton As System.Windows.Forms.Button
    Private WithEvents HoloKotePreviewButton As System.Windows.Forms.Button
    Private WithEvents PrinterPrefs As System.Windows.Forms.Button
    Private WithEvents groupBox7 As System.Windows.Forms.GroupBox
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents PrintableAreaHeightUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents PrintableAreaBottomUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents PrintableAreaWidthUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents PrintableAreaLeftUpDown As System.Windows.Forms.NumericUpDown
    Private WithEvents Label70 As System.Windows.Forms.Label
    Private WithEvents Label71 As System.Windows.Forms.Label
    Private WithEvents Label72 As System.Windows.Forms.Label
    Private WithEvents PrintableAreaButton As System.Windows.Forms.Button
    Private WithEvents GroupBox19 As System.Windows.Forms.GroupBox
    Private WithEvents MagStartButton As System.Windows.Forms.Button
    Private WithEvents MagStartPosition As System.Windows.Forms.NumericUpDown
    Private WithEvents Label69 As System.Windows.Forms.Label
    Private WithEvents EncodingSetRadio As System.Windows.Forms.RadioButton
    Private WithEvents EncodingGetRadio As System.Windows.Forms.RadioButton
    Private WithEvents PrinterTypeButton As System.Windows.Forms.Button
    Private WithEvents nativePrint As System.Windows.Forms.CheckBox
    Private WithEvents SensorsButton As System.Windows.Forms.Button
    Private WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Private WithEvents Radio600DPI As System.Windows.Forms.RadioButton
    Private WithEvents ResolutionButton As System.Windows.Forms.Button
    Private WithEvents Radio300DPI As System.Windows.Forms.RadioButton
    Private WithEvents Functions600DPI As System.Windows.Forms.CheckBox
    Private WithEvents MoveFilmButton As System.Windows.Forms.Button
    Private WithEvents FeedMoveButton As System.Windows.Forms.Button
    Friend WithEvents Utils As System.Windows.Forms.TabPage
    Private WithEvents ClearUtilsMsgBoxButton As System.Windows.Forms.Button
    Private WithEvents UtilsMsgBox As System.Windows.Forms.TextBox
    Private WithEvents SendAPDUBox As System.Windows.Forms.TextBox
    Private WithEvents SendAPDUButton As System.Windows.Forms.Button

End Class

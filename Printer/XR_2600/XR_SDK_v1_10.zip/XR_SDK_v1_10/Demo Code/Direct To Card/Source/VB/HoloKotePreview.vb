﻿'/***************************************************************************/
'/**                                                                       **/
'/**                               MAGICARD                                **/
'/**                                                                       **/
'/***************************************************************************/
'/**                                                                       **/
'/**  PROJECT      : SDK VB Demo - DTC Printers                            **/
'/**                                                                       **/
'/**  MODULE NAME  : Main.vb                                               **/
'/**                                                                       **/
'/**  COPYRIGHT    : Magicard                                              **/
'/**                                                                       **/
'/***************************************************************************/

Public Class HKPreview
    Dim pBuff(10) As Bitmap

    Public Sub New(ByVal buff As Bitmap(), ByVal count As Integer)
        InitializeComponent()

        For i As Integer = 0 To count
            pBuff(i) = buff(i)
        Next
        slotNumber.Value = 1
        slotNumber.Maximum = count

        pictureBox.Image = pBuff(0)
    End Sub

    Private Sub slotNumber_ValueChanged(ByVal sender As System.Object,
                                        ByVal e As System.EventArgs) _
            Handles slotNumber.ValueChanged
        pictureBox.Image = pBuff(slotNumber.Value - 1)
    End Sub
End Class
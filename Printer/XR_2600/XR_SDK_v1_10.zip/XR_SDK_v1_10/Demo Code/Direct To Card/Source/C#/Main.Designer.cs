﻿namespace CSharpDemo
{
    partial class SDK_CSDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button ImageBackButton;
            this.ExitButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PrinterID = new System.Windows.Forms.Label();
            this.PrintDemo = new System.Windows.Forms.TabPage();
            this.Functions600DPI = new System.Windows.Forms.CheckBox();
            this.PrinterPrefs = new System.Windows.Forms.Button();
            this.nativePrint = new System.Windows.Forms.CheckBox();
            this.CardSide = new System.Windows.Forms.TabControl();
            this.Front = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Track3MagData = new System.Windows.Forms.TextBox();
            this.Track2MagData = new System.Windows.Forms.TextBox();
            this.Track1MagData = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MagDataEnabled = new System.Windows.Forms.CheckBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.ImageFrontResin = new System.Windows.Forms.CheckBox();
            this.ImageFrontEnabled = new System.Windows.Forms.CheckBox();
            this.ImageFrontButton = new System.Windows.Forms.Button();
            this.ImageFrontFileBox = new System.Windows.Forms.TextBox();
            this.ImageFrontP2UpDown = new System.Windows.Forms.NumericUpDown();
            this.label69 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.ImageFrontP1UpDown = new System.Windows.Forms.NumericUpDown();
            this.ImageFrontYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label79 = new System.Windows.Forms.Label();
            this.ImageFrontXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.LineFrontEnabled = new System.Windows.Forms.CheckBox();
            this.label89 = new System.Windows.Forms.Label();
            this.LineFrontWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.label90 = new System.Windows.Forms.Label();
            this.LineFrontStartYUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineFrontEndYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.LineFrontResin = new System.Windows.Forms.CheckBox();
            this.LineFrontEndXUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineFrontColourCombo = new System.Windows.Forms.ComboBox();
            this.LineFrontStartXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.ShapeFrontEnabled = new System.Windows.Forms.CheckBox();
            this.ShapeFrontFillCombo = new System.Windows.Forms.ComboBox();
            this.label97 = new System.Windows.Forms.Label();
            this.ShapeFrontWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeFrontOutlineCombo = new System.Windows.Forms.ComboBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.ShapeFrontBUpDown = new System.Windows.Forms.NumericUpDown();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.ShapeFrontResin = new System.Windows.Forms.CheckBox();
            this.ShapeFrontRUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeFrontTUpDown = new System.Windows.Forms.NumericUpDown();
            this.label102 = new System.Windows.Forms.Label();
            this.ShapeFrontLUpDown = new System.Windows.Forms.NumericUpDown();
            this.label103 = new System.Windows.Forms.Label();
            this.ShapeFrontCombo = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.TextFrontEnabled = new System.Windows.Forms.CheckBox();
            this.TextFrontResin = new System.Windows.Forms.CheckBox();
            this.TextFrontSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label125 = new System.Windows.Forms.Label();
            this.TextFrontYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label126 = new System.Windows.Forms.Label();
            this.TextFrontXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label127 = new System.Windows.Forms.Label();
            this.TextFrontStrikethrough = new System.Windows.Forms.CheckBox();
            this.TextFrontItalic = new System.Windows.Forms.CheckBox();
            this.TextFrontUnderline = new System.Windows.Forms.CheckBox();
            this.TextFrontBold = new System.Windows.Forms.CheckBox();
            this.TextFrontColourCombo = new System.Windows.Forms.ComboBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.TextFrontBox = new System.Windows.Forms.TextBox();
            this.Back = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ImageBackResin = new System.Windows.Forms.CheckBox();
            this.ImageBackEnabled = new System.Windows.Forms.CheckBox();
            this.ImageBackFileBox = new System.Windows.Forms.TextBox();
            this.ImageBackP2UpDown = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ImageBackP1UpDown = new System.Windows.Forms.NumericUpDown();
            this.ImageBackYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label54 = new System.Windows.Forms.Label();
            this.ImageBackXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.LineBackEnabled = new System.Windows.Forms.CheckBox();
            this.label58 = new System.Windows.Forms.Label();
            this.LineBackWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.label59 = new System.Windows.Forms.Label();
            this.LineBackStartYUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineBackEndYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.LineBackResin = new System.Windows.Forms.CheckBox();
            this.LineBackEndXUpDown = new System.Windows.Forms.NumericUpDown();
            this.LineBackColourCombo = new System.Windows.Forms.ComboBox();
            this.LineBackStartXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.ShapeBackEnabled = new System.Windows.Forms.CheckBox();
            this.ShapeBackFillCombo = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.ShapeBackWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeBackOutlineCombo = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.ShapeBackBUpDown = new System.Windows.Forms.NumericUpDown();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.ShapeBackResin = new System.Windows.Forms.CheckBox();
            this.ShapeBackRUpDown = new System.Windows.Forms.NumericUpDown();
            this.ShapeBackTUpDown = new System.Windows.Forms.NumericUpDown();
            this.label72 = new System.Windows.Forms.Label();
            this.ShapeBackLUpDown = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.ShapeBackCombo = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.TextBackEnabled = new System.Windows.Forms.CheckBox();
            this.TextBackResin = new System.Windows.Forms.CheckBox();
            this.TextBackSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label76 = new System.Windows.Forms.Label();
            this.TextBackYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label77 = new System.Windows.Forms.Label();
            this.TextBackXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label81 = new System.Windows.Forms.Label();
            this.TextBackStrikethrough = new System.Windows.Forms.CheckBox();
            this.TextBackItalic = new System.Windows.Forms.CheckBox();
            this.TextBackUnderline = new System.Windows.Forms.CheckBox();
            this.TextBackBold = new System.Windows.Forms.CheckBox();
            this.TextBackColourCombo = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.TextBackBox = new System.Windows.Forms.TextBox();
            this.CardBack = new System.Windows.Forms.CheckBox();
            this.CardFront = new System.Windows.Forms.CheckBox();
            this.PrintButton = new System.Windows.Forms.Button();
            this.DriverSettings2 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.ResinOptionsButton = new System.Windows.Forms.Button();
            this.bPolygons_KResin = new System.Windows.Forms.CheckBox();
            this.bBitmaps_KResin = new System.Windows.Forms.CheckBox();
            this.bText_Kresin = new System.Windows.Forms.CheckBox();
            this.bPics_UseYMC = new System.Windows.Forms.CheckBox();
            this.bBlack_YMC = new System.Windows.Forms.CheckBox();
            this.ResinOptionsSideCombo = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.ColourAdjust_WhiteRef = new System.Windows.Forms.NumericUpDown();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.ColourAdjust_BlackRef = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Illuminant = new System.Windows.Forms.ComboBox();
            this.label118 = new System.Windows.Forms.Label();
            this.ColourAdjust_Negative = new System.Windows.Forms.CheckBox();
            this.ColourAdjust_DarkPic = new System.Windows.Forms.CheckBox();
            this.ColourAdjust_Blue = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Green = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Red = new System.Windows.Forms.NumericUpDown();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.ColourAdjust_Tint = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Colour = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Brightness = new System.Windows.Forms.NumericUpDown();
            this.ColourAdjust_Contrast = new System.Windows.Forms.NumericUpDown();
            this.label111 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.ColourAdjustBtn = new System.Windows.Forms.Button();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label86 = new System.Windows.Forms.Label();
            this.ColourAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.ColourAreaNo = new System.Windows.Forms.NumericUpDown();
            this.ColourAreaSideCombo = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.ColourAreaCorrectionCombo = new System.Windows.Forms.ComboBox();
            this.label106 = new System.Windows.Forms.Label();
            this.ColourAreaButton = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.HoloPatchPositionUpDown = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.ColourHole = new System.Windows.Forms.CheckBox();
            this.HoloPatchButton = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.HoloKotePreviewButton = new System.Windows.Forms.Button();
            this.HoloKoteMapUpDown = new System.Windows.Forms.NumericUpDown();
            this.HoloKoteImageUpDown = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.HoloKoteSideCombo = new System.Windows.Forms.ComboBox();
            this.NoCustomKey = new System.Windows.Forms.CheckBox();
            this.label49 = new System.Windows.Forms.Label();
            this.HoloKoteRotationCombo = new System.Windows.Forms.ComboBox();
            this.UseLaminate = new System.Windows.Forms.CheckBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.HoloKoteButton = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.Rotate = new System.Windows.Forms.CheckBox();
            this.Overcoat = new System.Windows.Forms.CheckBox();
            this.CardSettingsSideCombo = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.OrientationCombo = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.ColourFormatCombo = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.CardSettingsButton = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.CardSizeCombo = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.CopyCountUpDown = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.DuplexCombo = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.PrintSettingsButton = new System.Windows.Forms.Button();
            this.ClearDriver2MsgBoxButton = new System.Windows.Forms.Button();
            this.Driver2MsgBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Driver2SetRadio = new System.Windows.Forms.RadioButton();
            this.Driver2GetRadio = new System.Windows.Forms.RadioButton();
            this.DriverSettings1 = new System.Windows.Forms.TabPage();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.Radio600DPI = new System.Windows.Forms.RadioButton();
            this.ResolutionButton = new System.Windows.Forms.Button();
            this.Radio300DPI = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label122 = new System.Windows.Forms.Label();
            this.PrintableAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.PrintableAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.PrintableAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.PrintableAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.PrintableAreaButton = new System.Windows.Forms.Button();
            this.GUIPrinter = new System.Windows.Forms.CheckBox();
            this.GUIUser = new System.Windows.Forms.CheckBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.EraseBeforePrint = new System.Windows.Forms.CheckBox();
            this.EraseEndPowerLabel = new System.Windows.Forms.Label();
            this.WritePowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.ErasePowerEndUpDown = new System.Windows.Forms.NumericUpDown();
            this.WritePowerLabel = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.EraseAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.label37 = new System.Windows.Forms.Label();
            this.EraseAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ErasePowerStartUpDown = new System.Windows.Forms.NumericUpDown();
            this.EraseAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.EraseAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.RewritableButton = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.AreaHoleTypeCombo = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.AreaHoleHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.AreaHoleNoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.AreaHoleSideCombo = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.AreaHoleBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.AreaHoleWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.AreaHoleLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.AreaHoleButton = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.ResinAreaHeightUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaNoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.ResinAreaSideCombo = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.ResinAreaBottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaWidthUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinAreaLeftUpDown = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.ResinAreaButton = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.OvercoatPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.ResinPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.YMCPowerUpDown = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.PowerLevelButton = new System.Windows.Forms.Button();
            this.PrintSpeedButton = new System.Windows.Forms.Button();
            this.PrintSpeedCombo = new System.Windows.Forms.ComboBox();
            this.ColourCorrectionButton = new System.Windows.Forms.Button();
            this.CorrectionCombo = new System.Windows.Forms.ComboBox();
            this.SharpnessUpDown = new System.Windows.Forms.NumericUpDown();
            this.GUIControlButton = new System.Windows.Forms.Button();
            this.SharpnessButton = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.Driver1SetRadio = new System.Windows.Forms.RadioButton();
            this.Driver1GetRadio = new System.Windows.Forms.RadioButton();
            this.ClearDriver1MsgBoxButton = new System.Windows.Forms.Button();
            this.Driver1MsgBox = new System.Windows.Forms.TextBox();
            this.MagEncoding = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.MagStartButton = new System.Windows.Forms.Button();
            this.StartPosn = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.EncodingSetRadio = new System.Windows.Forms.RadioButton();
            this.EncodingGetRadio = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.ReadMagTracks = new System.Windows.Forms.Button();
            this.Track2Read = new System.Windows.Forms.CheckBox();
            this.Track3Read = new System.Windows.Forms.CheckBox();
            this.Track1Read = new System.Windows.Forms.CheckBox();
            this.EncodingBox = new System.Windows.Forms.TextBox();
            this.ReadMagButton = new System.Windows.Forms.Button();
            this.ClearEncodingBoxButton = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label112 = new System.Windows.Forms.Label();
            this.LRCLabel = new System.Windows.Forms.Label();
            this.ParityLabel = new System.Windows.Forms.Label();
            this.BitsPerInchLabel = new System.Windows.Forms.Label();
            this.BitsPerCharLabel = new System.Windows.Forms.Label();
            this.Track3SettingsLabel = new System.Windows.Forms.Label();
            this.Track2SettingsLabel = new System.Windows.Forms.Label();
            this.Track1SettingsLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.JIS2Label = new System.Windows.Forms.Label();
            this.Track3Label = new System.Windows.Forms.Label();
            this.Track2Label = new System.Windows.Forms.Label();
            this.Track1Data = new System.Windows.Forms.TextBox();
            this.Track2Data = new System.Windows.Forms.TextBox();
            this.Track3Data = new System.Windows.Forms.TextBox();
            this.Track1Write = new System.Windows.Forms.CheckBox();
            this.Track2Write = new System.Windows.Forms.CheckBox();
            this.Track3Write = new System.Windows.Forms.CheckBox();
            this.EncodingTypeCombo = new System.Windows.Forms.ComboBox();
            this.CoercivityCombo = new System.Windows.Forms.ComboBox();
            this.Verify = new System.Windows.Forms.CheckBox();
            this.T1_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T1_BPICombo = new System.Windows.Forms.ComboBox();
            this.T1_ParityCombo = new System.Windows.Forms.ComboBox();
            this.T1_LRCCombo = new System.Windows.Forms.ComboBox();
            this.T2_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T2_BPICombo = new System.Windows.Forms.ComboBox();
            this.T2_ParityCombo = new System.Windows.Forms.ComboBox();
            this.T2_LRCCombo = new System.Windows.Forms.ComboBox();
            this.T3_BPCCombo = new System.Windows.Forms.ComboBox();
            this.T3_BPICombo = new System.Windows.Forms.ComboBox();
            this.T3_ParityCombo = new System.Windows.Forms.ComboBox();
            this.T3_LRCCombo = new System.Windows.Forms.ComboBox();
            this.EncodeMagButton = new System.Windows.Forms.Button();
            this.Track1Label = new System.Windows.Forms.Label();
            this.Information = new System.Windows.Forms.TabPage();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.Pwd2Label = new System.Windows.Forms.Label();
            this.Pwd1Label = new System.Windows.Forms.Label();
            this.PasswordButton = new System.Windows.Forms.Button();
            this.Password2 = new System.Windows.Forms.TextBox();
            this.Password1 = new System.Windows.Forms.TextBox();
            this.PwdCommandCombo = new System.Windows.Forms.ComboBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.SensorsButton = new System.Windows.Forms.Button();
            this.PrinterTypeButton = new System.Windows.Forms.Button();
            this.SDKBitsButton = new System.Windows.Forms.Button();
            this.PrinterModelButton = new System.Windows.Forms.Button();
            this.ConnectionTypeButton = new System.Windows.Forms.Button();
            this.SDKVersionButton = new System.Windows.Forms.Button();
            this.ClearMsgBoxButton = new System.Windows.Forms.Button();
            this.LastMessageButton = new System.Windows.Forms.Button();
            this.InfoMsgBox = new System.Windows.Forms.TextBox();
            this.PrinterInfoButton = new System.Windows.Forms.Button();
            this.PrinterStatusButton = new System.Windows.Forms.Button();
            this.Generation2GroupBox = new System.Windows.Forms.GroupBox();
            this.ReadParamButton = new System.Windows.Forms.Button();
            this.label121 = new System.Windows.Forms.Label();
            this.AllParamsButton = new System.Windows.Forms.Button();
            this.ParamCombo = new System.Windows.Forms.ComboBox();
            this.Main = new System.Windows.Forms.TabPage();
            this.GenCmdGroupBox = new System.Windows.Forms.GroupBox();
            this.GenCommandButton = new System.Windows.Forms.Button();
            this.GenCommandBox = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.EraseCount = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.EraseArea_TopRYBox = new System.Windows.Forms.NumericUpDown();
            this.EraseArea_TopRXBox = new System.Windows.Forms.NumericUpDown();
            this.EraseArea_BotLYBox = new System.Windows.Forms.NumericUpDown();
            this.EraseArea_BotLXBox = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.EraseCardButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ErrorResponseButton = new System.Windows.Forms.Button();
            this.ErrorResponseCombo = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ClearPrinterMsgButton = new System.Windows.Forms.Button();
            this.PrinterMsgBox = new System.Windows.Forms.TextBox();
            this.HandFeedCombo = new System.Windows.Forms.ComboBox();
            this.HorzEjectCombo = new System.Windows.Forms.ComboBox();
            this.HorzEjectButton = new System.Windows.Forms.Button();
            this.HandFeedButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.PrinterSetRadio = new System.Windows.Forms.RadioButton();
            this.PrinterGetRadio = new System.Windows.Forms.RadioButton();
            this.IPGroupBox = new System.Windows.Forms.GroupBox();
            this.IPGatewayLabel = new System.Windows.Forms.Label();
            this.IPSubnetLabel = new System.Windows.Forms.Label();
            this.IPAddressLabel = new System.Windows.Forms.Label();
            this.IPGatewayBox = new System.Windows.Forms.TextBox();
            this.IPSubnetBox = new System.Windows.Forms.TextBox();
            this.IPAddressBox = new System.Windows.Forms.TextBox();
            this.IPSettingsButton = new System.Windows.Forms.Button();
            this.IPModeLabel = new System.Windows.Forms.Label();
            this.IPModeCombo = new System.Windows.Forms.ComboBox();
            this.SmartOffsetBox = new System.Windows.Forms.NumericUpDown();
            this.SmartOffsetButton = new System.Windows.Forms.Button();
            this.SmartModeButton = new System.Windows.Forms.Button();
            this.SmartModeCombo = new System.Windows.Forms.ComboBox();
            this.EraseSpeedButton = new System.Windows.Forms.Button();
            this.EraseSpeedCombo = new System.Windows.Forms.ComboBox();
            this.EjectModeButton = new System.Windows.Forms.Button();
            this.EjectModeCombo = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SessionConfigCombo = new System.Windows.Forms.ComboBox();
            this.OpenSessionButton = new System.Windows.Forms.Button();
            this.CloseSessionButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.FeedMoveButton = new System.Windows.Forms.Button();
            this.MoveFilmButton = new System.Windows.Forms.Button();
            this.CardLocationButton = new System.Windows.Forms.Button();
            this.MoveFilmCombo = new System.Windows.Forms.ComboBox();
            this.FeedMoveCombo = new System.Windows.Forms.ComboBox();
            this.RestartButton = new System.Windows.Forms.Button();
            this.EjectCardButton = new System.Windows.Forms.Button();
            this.TestCardButton = new System.Windows.Forms.Button();
            this.FlipCardButton = new System.Windows.Forms.Button();
            this.CleanPrinterButton = new System.Windows.Forms.Button();
            this.TabControl = new System.Windows.Forms.TabControl();
            this.Utils = new System.Windows.Forms.TabPage();
            this.ClearUtilsMsgBoxButton = new System.Windows.Forms.Button();
            this.SendAPDUButton = new System.Windows.Forms.Button();
            this.UtilsMsgBox = new System.Windows.Forms.TextBox();
            this.SendAPDUBox = new System.Windows.Forms.TextBox();
            ImageBackButton = new System.Windows.Forms.Button();
            this.PrintDemo.SuspendLayout();
            this.CardSide.SuspendLayout();
            this.Front.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP2UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP1UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontXUpDown)).BeginInit();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndXUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartXUpDown)).BeginInit();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontBUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontRUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontTUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontLUpDown)).BeginInit();
            this.groupBox33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontSizeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).BeginInit();
            this.Back.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP2UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP1UpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackXUpDown)).BeginInit();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndXUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartXUpDown)).BeginInit();
            this.groupBox21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackBUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackRUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackTUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackLUpDown)).BeginInit();
            this.groupBox22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackSizeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackXUpDown)).BeginInit();
            this.DriverSettings2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_WhiteRef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_BlackRef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Blue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Tint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Colour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Brightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Contrast)).BeginInit();
            this.groupBox23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaLeftUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaNo)).BeginInit();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloPatchPositionUpDown)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteMapUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteImageUpDown)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CopyCountUpDown)).BeginInit();
            this.DriverSettings1.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaLeftUpDown)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WritePowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErasePowerEndUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErasePowerStartUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaLeftUpDown)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleNoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleLeftUpDown)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaHeightUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaNoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaBottomUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaWidthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaLeftUpDown)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OvercoatPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YMCPowerUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpnessUpDown)).BeginInit();
            this.MagEncoding.SuspendLayout();
            this.groupBox31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StartPosn)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.Information.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.Generation2GroupBox.SuspendLayout();
            this.Main.SuspendLayout();
            this.GenCmdGroupBox.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EraseCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_TopRYBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_TopRXBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_BotLYBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_BotLXBox)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.IPGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SmartOffsetBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.TabControl.SuspendLayout();
            this.Utils.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImageBackButton
            // 
            ImageBackButton.Enabled = false;
            ImageBackButton.Location = new System.Drawing.Point(533, 12);
            ImageBackButton.Margin = new System.Windows.Forms.Padding(4);
            ImageBackButton.Name = "ImageBackButton";
            ImageBackButton.Size = new System.Drawing.Size(37, 30);
            ImageBackButton.TabIndex = 70;
            ImageBackButton.Text = "...";
            ImageBackButton.UseVisualStyleBackColor = true;
            ImageBackButton.Click += new System.EventHandler(this.ImageBackButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(520, 736);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(99, 30);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(135, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 25;
            // 
            // PrinterID
            // 
            this.PrinterID.AutoSize = true;
            this.PrinterID.Location = new System.Drawing.Point(12, 743);
            this.PrinterID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PrinterID.Name = "PrinterID";
            this.PrinterID.Size = new System.Drawing.Size(54, 17);
            this.PrinterID.TabIndex = 11;
            this.PrinterID.Text = "Printer:";
            this.PrinterID.Visible = false;
            // 
            // PrintDemo
            // 
            this.PrintDemo.Controls.Add(this.Functions600DPI);
            this.PrintDemo.Controls.Add(this.PrinterPrefs);
            this.PrintDemo.Controls.Add(this.nativePrint);
            this.PrintDemo.Controls.Add(this.CardSide);
            this.PrintDemo.Controls.Add(this.CardBack);
            this.PrintDemo.Controls.Add(this.CardFront);
            this.PrintDemo.Controls.Add(this.PrintButton);
            this.PrintDemo.Location = new System.Drawing.Point(4, 25);
            this.PrintDemo.Margin = new System.Windows.Forms.Padding(4);
            this.PrintDemo.Name = "PrintDemo";
            this.PrintDemo.Padding = new System.Windows.Forms.Padding(4);
            this.PrintDemo.Size = new System.Drawing.Size(621, 700);
            this.PrintDemo.TabIndex = 7;
            this.PrintDemo.Text = "Print Demo";
            this.PrintDemo.UseVisualStyleBackColor = true;
            // 
            // Functions600DPI
            // 
            this.Functions600DPI.AutoSize = true;
            this.Functions600DPI.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Functions600DPI.Location = new System.Drawing.Point(416, 33);
            this.Functions600DPI.Margin = new System.Windows.Forms.Padding(4);
            this.Functions600DPI.Name = "Functions600DPI";
            this.Functions600DPI.Size = new System.Drawing.Size(161, 21);
            this.Functions600DPI.TabIndex = 89;
            this.Functions600DPI.Text = "Use 600 DPI Printing";
            this.Functions600DPI.UseVisualStyleBackColor = true;
            // 
            // PrinterPrefs
            // 
            this.PrinterPrefs.Location = new System.Drawing.Point(11, 650);
            this.PrinterPrefs.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterPrefs.Name = "PrinterPrefs";
            this.PrinterPrefs.Size = new System.Drawing.Size(144, 30);
            this.PrinterPrefs.TabIndex = 37;
            this.PrinterPrefs.Text = "Printer Preferences";
            this.PrinterPrefs.UseVisualStyleBackColor = true;
            this.PrinterPrefs.Visible = false;
            this.PrinterPrefs.Click += new System.EventHandler(this.PrinterPrefs_Click);
            // 
            // nativePrint
            // 
            this.nativePrint.AutoSize = true;
            this.nativePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.nativePrint.Location = new System.Drawing.Point(228, 655);
            this.nativePrint.Margin = new System.Windows.Forms.Padding(4);
            this.nativePrint.Name = "nativePrint";
            this.nativePrint.Size = new System.Drawing.Size(151, 21);
            this.nativePrint.TabIndex = 88;
            this.nativePrint.Text = "Use Native Printing";
            this.nativePrint.UseVisualStyleBackColor = true;
            this.nativePrint.CheckedChanged += new System.EventHandler(this.nativePrint_CheckedChanged);
            // 
            // CardSide
            // 
            this.CardSide.Controls.Add(this.Front);
            this.CardSide.Controls.Add(this.Back);
            this.CardSide.Location = new System.Drawing.Point(5, 34);
            this.CardSide.Margin = new System.Windows.Forms.Padding(4);
            this.CardSide.Name = "CardSide";
            this.CardSide.SelectedIndex = 0;
            this.CardSide.Size = new System.Drawing.Size(601, 607);
            this.CardSide.TabIndex = 68;
            // 
            // Front
            // 
            this.Front.Controls.Add(this.groupBox18);
            this.Front.Controls.Add(this.groupBox24);
            this.Front.Controls.Add(this.groupBox25);
            this.Front.Controls.Add(this.groupBox26);
            this.Front.Controls.Add(this.groupBox33);
            this.Front.Location = new System.Drawing.Point(4, 25);
            this.Front.Margin = new System.Windows.Forms.Padding(4);
            this.Front.Name = "Front";
            this.Front.Padding = new System.Windows.Forms.Padding(4);
            this.Front.Size = new System.Drawing.Size(593, 578);
            this.Front.TabIndex = 0;
            this.Front.Text = "Front";
            this.Front.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Track3MagData);
            this.groupBox18.Controls.Add(this.Track2MagData);
            this.groupBox18.Controls.Add(this.Track1MagData);
            this.groupBox18.Controls.Add(this.label11);
            this.groupBox18.Controls.Add(this.label10);
            this.groupBox18.Controls.Add(this.label6);
            this.groupBox18.Controls.Add(this.MagDataEnabled);
            this.groupBox18.Location = new System.Drawing.Point(4, 436);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox18.Size = new System.Drawing.Size(583, 132);
            this.groupBox18.TabIndex = 88;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Magnetic Encoding";
            // 
            // Track3MagData
            // 
            this.Track3MagData.Location = new System.Drawing.Point(75, 96);
            this.Track3MagData.Margin = new System.Windows.Forms.Padding(4);
            this.Track3MagData.Name = "Track3MagData";
            this.Track3MagData.Size = new System.Drawing.Size(499, 22);
            this.Track3MagData.TabIndex = 91;
            // 
            // Track2MagData
            // 
            this.Track2MagData.Location = new System.Drawing.Point(75, 66);
            this.Track2MagData.Margin = new System.Windows.Forms.Padding(4);
            this.Track2MagData.Name = "Track2MagData";
            this.Track2MagData.Size = new System.Drawing.Size(499, 22);
            this.Track2MagData.TabIndex = 90;
            // 
            // Track1MagData
            // 
            this.Track1MagData.Location = new System.Drawing.Point(75, 37);
            this.Track1MagData.Margin = new System.Windows.Forms.Padding(4);
            this.Track1MagData.Name = "Track1MagData";
            this.Track1MagData.Size = new System.Drawing.Size(499, 22);
            this.Track1MagData.TabIndex = 89;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 101);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 17);
            this.label11.TabIndex = 88;
            this.label11.Text = "Track 3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 71);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 17);
            this.label10.TabIndex = 87;
            this.label10.Text = "Track 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 42);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 17);
            this.label6.TabIndex = 86;
            this.label6.Text = "Track 1";
            // 
            // MagDataEnabled
            // 
            this.MagDataEnabled.AutoSize = true;
            this.MagDataEnabled.Location = new System.Drawing.Point(8, 17);
            this.MagDataEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.MagDataEnabled.Name = "MagDataEnabled";
            this.MagDataEnabled.Size = new System.Drawing.Size(82, 21);
            this.MagDataEnabled.TabIndex = 85;
            this.MagDataEnabled.Text = "Enabled";
            this.MagDataEnabled.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.ImageFrontResin);
            this.groupBox24.Controls.Add(this.ImageFrontEnabled);
            this.groupBox24.Controls.Add(this.ImageFrontButton);
            this.groupBox24.Controls.Add(this.ImageFrontFileBox);
            this.groupBox24.Controls.Add(this.ImageFrontP2UpDown);
            this.groupBox24.Controls.Add(this.label69);
            this.groupBox24.Controls.Add(this.label78);
            this.groupBox24.Controls.Add(this.ImageFrontP1UpDown);
            this.groupBox24.Controls.Add(this.ImageFrontYUpDown);
            this.groupBox24.Controls.Add(this.label79);
            this.groupBox24.Controls.Add(this.ImageFrontXUpDown);
            this.groupBox24.Controls.Add(this.label80);
            this.groupBox24.Controls.Add(this.label87);
            this.groupBox24.Controls.Add(this.label88);
            this.groupBox24.Location = new System.Drawing.Point(4, 336);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox24.Size = new System.Drawing.Size(583, 92);
            this.groupBox24.TabIndex = 87;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Image";
            // 
            // ImageFrontResin
            // 
            this.ImageFrontResin.AutoSize = true;
            this.ImageFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ImageFrontResin.Location = new System.Drawing.Point(475, 50);
            this.ImageFrontResin.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontResin.Name = "ImageFrontResin";
            this.ImageFrontResin.Size = new System.Drawing.Size(95, 21);
            this.ImageFrontResin.TabIndex = 87;
            this.ImageFrontResin.Text = "Use Resin";
            this.ImageFrontResin.UseVisualStyleBackColor = true;
            // 
            // ImageFrontEnabled
            // 
            this.ImageFrontEnabled.AutoSize = true;
            this.ImageFrontEnabled.Location = new System.Drawing.Point(8, 17);
            this.ImageFrontEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontEnabled.Name = "ImageFrontEnabled";
            this.ImageFrontEnabled.Size = new System.Drawing.Size(82, 21);
            this.ImageFrontEnabled.TabIndex = 85;
            this.ImageFrontEnabled.Text = "Enabled";
            this.ImageFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // ImageFrontButton
            // 
            this.ImageFrontButton.Location = new System.Drawing.Point(533, 12);
            this.ImageFrontButton.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontButton.Name = "ImageFrontButton";
            this.ImageFrontButton.Size = new System.Drawing.Size(37, 30);
            this.ImageFrontButton.TabIndex = 70;
            this.ImageFrontButton.Text = "...";
            this.ImageFrontButton.UseVisualStyleBackColor = true;
            this.ImageFrontButton.Click += new System.EventHandler(this.ImageFrontButton_Click);
            // 
            // ImageFrontFileBox
            // 
            this.ImageFrontFileBox.Location = new System.Drawing.Point(169, 15);
            this.ImageFrontFileBox.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontFileBox.Name = "ImageFrontFileBox";
            this.ImageFrontFileBox.Size = new System.Drawing.Size(363, 22);
            this.ImageFrontFileBox.TabIndex = 83;
            // 
            // ImageFrontP2UpDown
            // 
            this.ImageFrontP2UpDown.Location = new System.Drawing.Point(344, 49);
            this.ImageFrontP2UpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontP2UpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ImageFrontP2UpDown.Name = "ImageFrontP2UpDown";
            this.ImageFrontP2UpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageFrontP2UpDown.TabIndex = 82;
            this.ImageFrontP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(317, 54);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(25, 17);
            this.label69.TabIndex = 81;
            this.label69.Text = "P2";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(231, 54);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(25, 17);
            this.label78.TabIndex = 80;
            this.label78.Text = "P1";
            // 
            // ImageFrontP1UpDown
            // 
            this.ImageFrontP1UpDown.Location = new System.Drawing.Point(257, 49);
            this.ImageFrontP1UpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontP1UpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ImageFrontP1UpDown.Name = "ImageFrontP1UpDown";
            this.ImageFrontP1UpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageFrontP1UpDown.TabIndex = 78;
            this.ImageFrontP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ImageFrontYUpDown
            // 
            this.ImageFrontYUpDown.Location = new System.Drawing.Point(171, 49);
            this.ImageFrontYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ImageFrontYUpDown.Name = "ImageFrontYUpDown";
            this.ImageFrontYUpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageFrontYUpDown.TabIndex = 76;
            this.ImageFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(152, 54);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(17, 17);
            this.label79.TabIndex = 75;
            this.label79.Text = "Y";
            // 
            // ImageFrontXUpDown
            // 
            this.ImageFrontXUpDown.Location = new System.Drawing.Point(92, 49);
            this.ImageFrontXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageFrontXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ImageFrontXUpDown.Name = "ImageFrontXUpDown";
            this.ImageFrontXUpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageFrontXUpDown.TabIndex = 74;
            this.ImageFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(75, 54);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(17, 17);
            this.label80.TabIndex = 73;
            this.label80.Text = "X";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(8, 54);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(62, 17);
            this.label87.TabIndex = 33;
            this.label87.Text = "Position:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(121, 20);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(30, 17);
            this.label88.TabIndex = 32;
            this.label88.Text = "File";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.LineFrontEnabled);
            this.groupBox25.Controls.Add(this.label89);
            this.groupBox25.Controls.Add(this.LineFrontWidthUpDown);
            this.groupBox25.Controls.Add(this.label90);
            this.groupBox25.Controls.Add(this.LineFrontStartYUpDown);
            this.groupBox25.Controls.Add(this.LineFrontEndYUpDown);
            this.groupBox25.Controls.Add(this.label91);
            this.groupBox25.Controls.Add(this.label92);
            this.groupBox25.Controls.Add(this.label93);
            this.groupBox25.Controls.Add(this.label94);
            this.groupBox25.Controls.Add(this.LineFrontResin);
            this.groupBox25.Controls.Add(this.LineFrontEndXUpDown);
            this.groupBox25.Controls.Add(this.LineFrontColourCombo);
            this.groupBox25.Controls.Add(this.LineFrontStartXUpDown);
            this.groupBox25.Controls.Add(this.label95);
            this.groupBox25.Controls.Add(this.label96);
            this.groupBox25.Location = new System.Drawing.Point(4, 224);
            this.groupBox25.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox25.Size = new System.Drawing.Size(583, 105);
            this.groupBox25.TabIndex = 86;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Line";
            // 
            // LineFrontEnabled
            // 
            this.LineFrontEnabled.AutoSize = true;
            this.LineFrontEnabled.Checked = true;
            this.LineFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LineFrontEnabled.Location = new System.Drawing.Point(8, 17);
            this.LineFrontEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontEnabled.Name = "LineFrontEnabled";
            this.LineFrontEnabled.Size = new System.Drawing.Size(82, 21);
            this.LineFrontEnabled.TabIndex = 84;
            this.LineFrontEnabled.Text = "Enabled";
            this.LineFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(251, 78);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(37, 17);
            this.label89.TabIndex = 82;
            this.label89.Text = "End:";
            // 
            // LineFrontWidthUpDown
            // 
            this.LineFrontWidthUpDown.Location = new System.Drawing.Point(312, 39);
            this.LineFrontWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.LineFrontWidthUpDown.Name = "LineFrontWidthUpDown";
            this.LineFrontWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineFrontWidthUpDown.TabIndex = 81;
            this.LineFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(268, 44);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(44, 17);
            this.label90.TabIndex = 80;
            this.label90.Text = "Width";
            // 
            // LineFrontStartYUpDown
            // 
            this.LineFrontStartYUpDown.Location = new System.Drawing.Point(153, 73);
            this.LineFrontStartYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontStartYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.LineFrontStartYUpDown.Name = "LineFrontStartYUpDown";
            this.LineFrontStartYUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineFrontStartYUpDown.TabIndex = 76;
            this.LineFrontStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineFrontEndYUpDown
            // 
            this.LineFrontEndYUpDown.Location = new System.Drawing.Point(393, 73);
            this.LineFrontEndYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontEndYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.LineFrontEndYUpDown.Name = "LineFrontEndYUpDown";
            this.LineFrontEndYUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineFrontEndYUpDown.TabIndex = 82;
            this.LineFrontEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(8, 76);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(42, 17);
            this.label91.TabIndex = 80;
            this.label91.Text = "Start:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(375, 78);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(17, 17);
            this.label92.TabIndex = 81;
            this.label92.Text = "Y";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(56, 78);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(17, 17);
            this.label93.TabIndex = 73;
            this.label93.Text = "X";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(293, 78);
            this.label94.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(17, 17);
            this.label94.TabIndex = 80;
            this.label94.Text = "X";
            // 
            // LineFrontResin
            // 
            this.LineFrontResin.AutoSize = true;
            this.LineFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LineFrontResin.Location = new System.Drawing.Point(475, 17);
            this.LineFrontResin.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontResin.Name = "LineFrontResin";
            this.LineFrontResin.Size = new System.Drawing.Size(95, 21);
            this.LineFrontResin.TabIndex = 79;
            this.LineFrontResin.Text = "Use Resin";
            this.LineFrontResin.UseVisualStyleBackColor = true;
            // 
            // LineFrontEndXUpDown
            // 
            this.LineFrontEndXUpDown.Location = new System.Drawing.Point(312, 73);
            this.LineFrontEndXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontEndXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.LineFrontEndXUpDown.Name = "LineFrontEndXUpDown";
            this.LineFrontEndXUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineFrontEndXUpDown.TabIndex = 78;
            this.LineFrontEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineFrontColourCombo
            // 
            this.LineFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LineFrontColourCombo.Location = new System.Drawing.Point(75, 39);
            this.LineFrontColourCombo.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontColourCombo.Name = "LineFrontColourCombo";
            this.LineFrontColourCombo.Size = new System.Drawing.Size(184, 24);
            this.LineFrontColourCombo.TabIndex = 34;
            // 
            // LineFrontStartXUpDown
            // 
            this.LineFrontStartXUpDown.Location = new System.Drawing.Point(75, 73);
            this.LineFrontStartXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineFrontStartXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.LineFrontStartXUpDown.Name = "LineFrontStartXUpDown";
            this.LineFrontStartXUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineFrontStartXUpDown.TabIndex = 74;
            this.LineFrontStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(8, 44);
            this.label95.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(49, 17);
            this.label95.TabIndex = 32;
            this.label95.Text = "Colour";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(135, 78);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(17, 17);
            this.label96.TabIndex = 75;
            this.label96.Text = "Y";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.ShapeFrontEnabled);
            this.groupBox26.Controls.Add(this.ShapeFrontFillCombo);
            this.groupBox26.Controls.Add(this.label97);
            this.groupBox26.Controls.Add(this.ShapeFrontWidthUpDown);
            this.groupBox26.Controls.Add(this.ShapeFrontOutlineCombo);
            this.groupBox26.Controls.Add(this.label98);
            this.groupBox26.Controls.Add(this.label99);
            this.groupBox26.Controls.Add(this.ShapeFrontBUpDown);
            this.groupBox26.Controls.Add(this.label100);
            this.groupBox26.Controls.Add(this.label101);
            this.groupBox26.Controls.Add(this.ShapeFrontResin);
            this.groupBox26.Controls.Add(this.ShapeFrontRUpDown);
            this.groupBox26.Controls.Add(this.ShapeFrontTUpDown);
            this.groupBox26.Controls.Add(this.label102);
            this.groupBox26.Controls.Add(this.ShapeFrontLUpDown);
            this.groupBox26.Controls.Add(this.label103);
            this.groupBox26.Controls.Add(this.ShapeFrontCombo);
            this.groupBox26.Controls.Add(this.label104);
            this.groupBox26.Controls.Add(this.label105);
            this.groupBox26.Location = new System.Drawing.Point(4, 112);
            this.groupBox26.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox26.Size = new System.Drawing.Size(583, 105);
            this.groupBox26.TabIndex = 85;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Shape";
            // 
            // ShapeFrontEnabled
            // 
            this.ShapeFrontEnabled.AutoSize = true;
            this.ShapeFrontEnabled.Checked = true;
            this.ShapeFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ShapeFrontEnabled.Location = new System.Drawing.Point(8, 17);
            this.ShapeFrontEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontEnabled.Name = "ShapeFrontEnabled";
            this.ShapeFrontEnabled.Size = new System.Drawing.Size(82, 21);
            this.ShapeFrontEnabled.TabIndex = 83;
            this.ShapeFrontEnabled.Text = "Enabled";
            this.ShapeFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // ShapeFrontFillCombo
            // 
            this.ShapeFrontFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontFillCombo.Items.AddRange(new object[] {
            "Red",
            "Green",
            "Blue",
            "Cyan",
            "Magenta",
            "Yellow",
            "White",
            "Black",
            "Transparent"});
            this.ShapeFrontFillCombo.Location = new System.Drawing.Point(335, 74);
            this.ShapeFrontFillCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontFillCombo.Name = "ShapeFrontFillCombo";
            this.ShapeFrontFillCombo.Size = new System.Drawing.Size(168, 24);
            this.ShapeFrontFillCombo.TabIndex = 81;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(309, 79);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(25, 17);
            this.label97.TabIndex = 80;
            this.label97.Text = "Fill";
            // 
            // ShapeFrontWidthUpDown
            // 
            this.ShapeFrontWidthUpDown.Location = new System.Drawing.Point(235, 74);
            this.ShapeFrontWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ShapeFrontWidthUpDown.Name = "ShapeFrontWidthUpDown";
            this.ShapeFrontWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeFrontWidthUpDown.TabIndex = 81;
            this.ShapeFrontWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeFrontOutlineCombo
            // 
            this.ShapeFrontOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontOutlineCombo.Location = new System.Drawing.Point(69, 74);
            this.ShapeFrontOutlineCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontOutlineCombo.Name = "ShapeFrontOutlineCombo";
            this.ShapeFrontOutlineCombo.Size = new System.Drawing.Size(112, 24);
            this.ShapeFrontOutlineCombo.TabIndex = 81;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(191, 79);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(44, 17);
            this.label98.TabIndex = 80;
            this.label98.Text = "Width";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(8, 79);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(53, 17);
            this.label99.TabIndex = 80;
            this.label99.Text = "Outline";
            // 
            // ShapeFrontBUpDown
            // 
            this.ShapeFrontBUpDown.Location = new System.Drawing.Point(504, 46);
            this.ShapeFrontBUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontBUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ShapeFrontBUpDown.Name = "ShapeFrontBUpDown";
            this.ShapeFrontBUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeFrontBUpDown.TabIndex = 82;
            this.ShapeFrontBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(485, 50);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(17, 17);
            this.label100.TabIndex = 81;
            this.label100.Text = "B";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(405, 50);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(18, 17);
            this.label101.TabIndex = 80;
            this.label101.Text = "R";
            // 
            // ShapeFrontResin
            // 
            this.ShapeFrontResin.AutoSize = true;
            this.ShapeFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShapeFrontResin.Location = new System.Drawing.Point(475, 17);
            this.ShapeFrontResin.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontResin.Name = "ShapeFrontResin";
            this.ShapeFrontResin.Size = new System.Drawing.Size(95, 21);
            this.ShapeFrontResin.TabIndex = 79;
            this.ShapeFrontResin.Text = "Use Resin";
            this.ShapeFrontResin.UseVisualStyleBackColor = true;
            // 
            // ShapeFrontRUpDown
            // 
            this.ShapeFrontRUpDown.Location = new System.Drawing.Point(425, 46);
            this.ShapeFrontRUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontRUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ShapeFrontRUpDown.Name = "ShapeFrontRUpDown";
            this.ShapeFrontRUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeFrontRUpDown.TabIndex = 78;
            this.ShapeFrontRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeFrontTUpDown
            // 
            this.ShapeFrontTUpDown.Location = new System.Drawing.Point(345, 46);
            this.ShapeFrontTUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontTUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ShapeFrontTUpDown.Name = "ShapeFrontTUpDown";
            this.ShapeFrontTUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeFrontTUpDown.TabIndex = 76;
            this.ShapeFrontTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(327, 50);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(17, 17);
            this.label102.TabIndex = 75;
            this.label102.Text = "T";
            // 
            // ShapeFrontLUpDown
            // 
            this.ShapeFrontLUpDown.Location = new System.Drawing.Point(267, 46);
            this.ShapeFrontLUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontLUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ShapeFrontLUpDown.Name = "ShapeFrontLUpDown";
            this.ShapeFrontLUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeFrontLUpDown.TabIndex = 74;
            this.ShapeFrontLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(249, 50);
            this.label103.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(16, 17);
            this.label103.TabIndex = 73;
            this.label103.Text = "L";
            // 
            // ShapeFrontCombo
            // 
            this.ShapeFrontCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeFrontCombo.Location = new System.Drawing.Point(69, 46);
            this.ShapeFrontCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeFrontCombo.Name = "ShapeFrontCombo";
            this.ShapeFrontCombo.Size = new System.Drawing.Size(112, 24);
            this.ShapeFrontCombo.TabIndex = 34;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(187, 50);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(62, 17);
            this.label104.TabIndex = 33;
            this.label104.Text = "Position:";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(8, 50);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(49, 17);
            this.label105.TabIndex = 32;
            this.label105.Text = "Shape";
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.TextFrontEnabled);
            this.groupBox33.Controls.Add(this.TextFrontResin);
            this.groupBox33.Controls.Add(this.TextFrontSizeUpDown);
            this.groupBox33.Controls.Add(this.label125);
            this.groupBox33.Controls.Add(this.TextFrontYUpDown);
            this.groupBox33.Controls.Add(this.label126);
            this.groupBox33.Controls.Add(this.TextFrontXUpDown);
            this.groupBox33.Controls.Add(this.label127);
            this.groupBox33.Controls.Add(this.TextFrontStrikethrough);
            this.groupBox33.Controls.Add(this.TextFrontItalic);
            this.groupBox33.Controls.Add(this.TextFrontUnderline);
            this.groupBox33.Controls.Add(this.TextFrontBold);
            this.groupBox33.Controls.Add(this.TextFrontColourCombo);
            this.groupBox33.Controls.Add(this.label128);
            this.groupBox33.Controls.Add(this.label129);
            this.groupBox33.Controls.Add(this.label130);
            this.groupBox33.Controls.Add(this.TextFrontBox);
            this.groupBox33.Location = new System.Drawing.Point(4, 0);
            this.groupBox33.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox33.Size = new System.Drawing.Size(583, 105);
            this.groupBox33.TabIndex = 1;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Text";
            // 
            // TextFrontEnabled
            // 
            this.TextFrontEnabled.AutoSize = true;
            this.TextFrontEnabled.Checked = true;
            this.TextFrontEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TextFrontEnabled.Location = new System.Drawing.Point(8, 17);
            this.TextFrontEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontEnabled.Name = "TextFrontEnabled";
            this.TextFrontEnabled.Size = new System.Drawing.Size(82, 21);
            this.TextFrontEnabled.TabIndex = 80;
            this.TextFrontEnabled.Text = "Enabled";
            this.TextFrontEnabled.UseVisualStyleBackColor = true;
            // 
            // TextFrontResin
            // 
            this.TextFrontResin.AutoSize = true;
            this.TextFrontResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextFrontResin.Location = new System.Drawing.Point(475, 76);
            this.TextFrontResin.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontResin.Name = "TextFrontResin";
            this.TextFrontResin.Size = new System.Drawing.Size(95, 21);
            this.TextFrontResin.TabIndex = 79;
            this.TextFrontResin.Text = "Use Resin";
            this.TextFrontResin.UseVisualStyleBackColor = true;
            // 
            // TextFrontSizeUpDown
            // 
            this.TextFrontSizeUpDown.Location = new System.Drawing.Point(321, 74);
            this.TextFrontSizeUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontSizeUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.TextFrontSizeUpDown.Name = "TextFrontSizeUpDown";
            this.TextFrontSizeUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextFrontSizeUpDown.TabIndex = 78;
            this.TextFrontSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(285, 79);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(35, 17);
            this.label125.TabIndex = 77;
            this.label125.Text = "Size";
            // 
            // TextFrontYUpDown
            // 
            this.TextFrontYUpDown.Location = new System.Drawing.Point(192, 74);
            this.TextFrontYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.TextFrontYUpDown.Name = "TextFrontYUpDown";
            this.TextFrontYUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextFrontYUpDown.TabIndex = 76;
            this.TextFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(165, 79);
            this.label126.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(17, 17);
            this.label126.TabIndex = 75;
            this.label126.Text = "Y";
            // 
            // TextFrontXUpDown
            // 
            this.TextFrontXUpDown.Location = new System.Drawing.Point(97, 74);
            this.TextFrontXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.TextFrontXUpDown.Name = "TextFrontXUpDown";
            this.TextFrontXUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextFrontXUpDown.TabIndex = 74;
            this.TextFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(71, 79);
            this.label127.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(17, 17);
            this.label127.TabIndex = 73;
            this.label127.Text = "X";
            // 
            // TextFrontStrikethrough
            // 
            this.TextFrontStrikethrough.AutoSize = true;
            this.TextFrontStrikethrough.Location = new System.Drawing.Point(456, 48);
            this.TextFrontStrikethrough.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontStrikethrough.Name = "TextFrontStrikethrough";
            this.TextFrontStrikethrough.Size = new System.Drawing.Size(115, 21);
            this.TextFrontStrikethrough.TabIndex = 72;
            this.TextFrontStrikethrough.Text = "Strikethrough";
            this.TextFrontStrikethrough.UseVisualStyleBackColor = true;
            // 
            // TextFrontItalic
            // 
            this.TextFrontItalic.AutoSize = true;
            this.TextFrontItalic.Location = new System.Drawing.Point(376, 48);
            this.TextFrontItalic.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontItalic.Name = "TextFrontItalic";
            this.TextFrontItalic.Size = new System.Drawing.Size(58, 21);
            this.TextFrontItalic.TabIndex = 71;
            this.TextFrontItalic.Text = "Italic";
            this.TextFrontItalic.UseVisualStyleBackColor = true;
            // 
            // TextFrontUnderline
            // 
            this.TextFrontUnderline.AutoSize = true;
            this.TextFrontUnderline.Location = new System.Drawing.Point(268, 48);
            this.TextFrontUnderline.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontUnderline.Name = "TextFrontUnderline";
            this.TextFrontUnderline.Size = new System.Drawing.Size(91, 21);
            this.TextFrontUnderline.TabIndex = 70;
            this.TextFrontUnderline.Text = "Underline";
            this.TextFrontUnderline.UseVisualStyleBackColor = true;
            // 
            // TextFrontBold
            // 
            this.TextFrontBold.AutoSize = true;
            this.TextFrontBold.Location = new System.Drawing.Point(192, 48);
            this.TextFrontBold.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontBold.Name = "TextFrontBold";
            this.TextFrontBold.Size = new System.Drawing.Size(58, 21);
            this.TextFrontBold.TabIndex = 69;
            this.TextFrontBold.Text = "Bold";
            this.TextFrontBold.UseVisualStyleBackColor = true;
            // 
            // TextFrontColourCombo
            // 
            this.TextFrontColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TextFrontColourCombo.Location = new System.Drawing.Point(71, 46);
            this.TextFrontColourCombo.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontColourCombo.Name = "TextFrontColourCombo";
            this.TextFrontColourCombo.Size = new System.Drawing.Size(112, 24);
            this.TextFrontColourCombo.TabIndex = 34;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(8, 79);
            this.label128.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(62, 17);
            this.label128.TabIndex = 33;
            this.label128.Text = "Position:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(8, 50);
            this.label129.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(49, 17);
            this.label129.TabIndex = 32;
            this.label129.Text = "Colour";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(147, 20);
            this.label130.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(35, 17);
            this.label130.TabIndex = 31;
            this.label130.Text = "Text";
            // 
            // TextFrontBox
            // 
            this.TextFrontBox.Location = new System.Drawing.Point(192, 15);
            this.TextFrontBox.Margin = new System.Windows.Forms.Padding(4);
            this.TextFrontBox.Name = "TextFrontBox";
            this.TextFrontBox.Size = new System.Drawing.Size(381, 22);
            this.TextFrontBox.TabIndex = 14;
            this.TextFrontBox.Text = "Front - First Line of C# Text";
            // 
            // Back
            // 
            this.Back.Controls.Add(this.groupBox19);
            this.Back.Controls.Add(this.groupBox20);
            this.Back.Controls.Add(this.groupBox21);
            this.Back.Controls.Add(this.groupBox22);
            this.Back.Location = new System.Drawing.Point(4, 25);
            this.Back.Margin = new System.Windows.Forms.Padding(4);
            this.Back.Name = "Back";
            this.Back.Padding = new System.Windows.Forms.Padding(4);
            this.Back.Size = new System.Drawing.Size(593, 578);
            this.Back.TabIndex = 1;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.ImageBackResin);
            this.groupBox19.Controls.Add(this.ImageBackEnabled);
            this.groupBox19.Controls.Add(ImageBackButton);
            this.groupBox19.Controls.Add(this.ImageBackFileBox);
            this.groupBox19.Controls.Add(this.ImageBackP2UpDown);
            this.groupBox19.Controls.Add(this.label14);
            this.groupBox19.Controls.Add(this.label15);
            this.groupBox19.Controls.Add(this.ImageBackP1UpDown);
            this.groupBox19.Controls.Add(this.ImageBackYUpDown);
            this.groupBox19.Controls.Add(this.label54);
            this.groupBox19.Controls.Add(this.ImageBackXUpDown);
            this.groupBox19.Controls.Add(this.label55);
            this.groupBox19.Controls.Add(this.label56);
            this.groupBox19.Controls.Add(this.label57);
            this.groupBox19.Location = new System.Drawing.Point(4, 336);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox19.Size = new System.Drawing.Size(583, 92);
            this.groupBox19.TabIndex = 91;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Image";
            // 
            // ImageBackResin
            // 
            this.ImageBackResin.AutoSize = true;
            this.ImageBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ImageBackResin.Enabled = false;
            this.ImageBackResin.Location = new System.Drawing.Point(475, 52);
            this.ImageBackResin.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackResin.Name = "ImageBackResin";
            this.ImageBackResin.Size = new System.Drawing.Size(95, 21);
            this.ImageBackResin.TabIndex = 86;
            this.ImageBackResin.Text = "Use Resin";
            this.ImageBackResin.UseVisualStyleBackColor = true;
            // 
            // ImageBackEnabled
            // 
            this.ImageBackEnabled.AutoSize = true;
            this.ImageBackEnabled.Enabled = false;
            this.ImageBackEnabled.Location = new System.Drawing.Point(8, 17);
            this.ImageBackEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackEnabled.Name = "ImageBackEnabled";
            this.ImageBackEnabled.Size = new System.Drawing.Size(82, 21);
            this.ImageBackEnabled.TabIndex = 85;
            this.ImageBackEnabled.Text = "Enabled";
            this.ImageBackEnabled.UseVisualStyleBackColor = true;
            // 
            // ImageBackFileBox
            // 
            this.ImageBackFileBox.Enabled = false;
            this.ImageBackFileBox.Location = new System.Drawing.Point(169, 15);
            this.ImageBackFileBox.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackFileBox.Name = "ImageBackFileBox";
            this.ImageBackFileBox.Size = new System.Drawing.Size(363, 22);
            this.ImageBackFileBox.TabIndex = 83;
            // 
            // ImageBackP2UpDown
            // 
            this.ImageBackP2UpDown.Enabled = false;
            this.ImageBackP2UpDown.Location = new System.Drawing.Point(344, 49);
            this.ImageBackP2UpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackP2UpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ImageBackP2UpDown.Name = "ImageBackP2UpDown";
            this.ImageBackP2UpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageBackP2UpDown.TabIndex = 82;
            this.ImageBackP2UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(317, 54);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(25, 17);
            this.label14.TabIndex = 81;
            this.label14.Text = "P2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(231, 54);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 17);
            this.label15.TabIndex = 80;
            this.label15.Text = "P1";
            // 
            // ImageBackP1UpDown
            // 
            this.ImageBackP1UpDown.Enabled = false;
            this.ImageBackP1UpDown.Location = new System.Drawing.Point(257, 49);
            this.ImageBackP1UpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackP1UpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ImageBackP1UpDown.Name = "ImageBackP1UpDown";
            this.ImageBackP1UpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageBackP1UpDown.TabIndex = 78;
            this.ImageBackP1UpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ImageBackYUpDown
            // 
            this.ImageBackYUpDown.Enabled = false;
            this.ImageBackYUpDown.Location = new System.Drawing.Point(171, 49);
            this.ImageBackYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ImageBackYUpDown.Name = "ImageBackYUpDown";
            this.ImageBackYUpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageBackYUpDown.TabIndex = 76;
            this.ImageBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(152, 54);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(17, 17);
            this.label54.TabIndex = 75;
            this.label54.Text = "Y";
            // 
            // ImageBackXUpDown
            // 
            this.ImageBackXUpDown.Enabled = false;
            this.ImageBackXUpDown.Location = new System.Drawing.Point(92, 49);
            this.ImageBackXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ImageBackXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ImageBackXUpDown.Name = "ImageBackXUpDown";
            this.ImageBackXUpDown.Size = new System.Drawing.Size(60, 22);
            this.ImageBackXUpDown.TabIndex = 74;
            this.ImageBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(75, 54);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(17, 17);
            this.label55.TabIndex = 73;
            this.label55.Text = "X";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(8, 54);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(62, 17);
            this.label56.TabIndex = 33;
            this.label56.Text = "Position:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(121, 20);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(30, 17);
            this.label57.TabIndex = 32;
            this.label57.Text = "File";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.LineBackEnabled);
            this.groupBox20.Controls.Add(this.label58);
            this.groupBox20.Controls.Add(this.LineBackWidthUpDown);
            this.groupBox20.Controls.Add(this.label59);
            this.groupBox20.Controls.Add(this.LineBackStartYUpDown);
            this.groupBox20.Controls.Add(this.LineBackEndYUpDown);
            this.groupBox20.Controls.Add(this.label60);
            this.groupBox20.Controls.Add(this.label61);
            this.groupBox20.Controls.Add(this.label62);
            this.groupBox20.Controls.Add(this.label63);
            this.groupBox20.Controls.Add(this.LineBackResin);
            this.groupBox20.Controls.Add(this.LineBackEndXUpDown);
            this.groupBox20.Controls.Add(this.LineBackColourCombo);
            this.groupBox20.Controls.Add(this.LineBackStartXUpDown);
            this.groupBox20.Controls.Add(this.label64);
            this.groupBox20.Controls.Add(this.label65);
            this.groupBox20.Location = new System.Drawing.Point(4, 224);
            this.groupBox20.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox20.Size = new System.Drawing.Size(583, 105);
            this.groupBox20.TabIndex = 90;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Line";
            // 
            // LineBackEnabled
            // 
            this.LineBackEnabled.AutoSize = true;
            this.LineBackEnabled.Enabled = false;
            this.LineBackEnabled.Location = new System.Drawing.Point(8, 17);
            this.LineBackEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackEnabled.Name = "LineBackEnabled";
            this.LineBackEnabled.Size = new System.Drawing.Size(82, 21);
            this.LineBackEnabled.TabIndex = 84;
            this.LineBackEnabled.Text = "Enabled";
            this.LineBackEnabled.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(251, 78);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(37, 17);
            this.label58.TabIndex = 82;
            this.label58.Text = "End:";
            // 
            // LineBackWidthUpDown
            // 
            this.LineBackWidthUpDown.Enabled = false;
            this.LineBackWidthUpDown.Location = new System.Drawing.Point(312, 39);
            this.LineBackWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.LineBackWidthUpDown.Name = "LineBackWidthUpDown";
            this.LineBackWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineBackWidthUpDown.TabIndex = 81;
            this.LineBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(268, 44);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(44, 17);
            this.label59.TabIndex = 80;
            this.label59.Text = "Width";
            // 
            // LineBackStartYUpDown
            // 
            this.LineBackStartYUpDown.Enabled = false;
            this.LineBackStartYUpDown.Location = new System.Drawing.Point(153, 73);
            this.LineBackStartYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackStartYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.LineBackStartYUpDown.Name = "LineBackStartYUpDown";
            this.LineBackStartYUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineBackStartYUpDown.TabIndex = 76;
            this.LineBackStartYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineBackEndYUpDown
            // 
            this.LineBackEndYUpDown.Enabled = false;
            this.LineBackEndYUpDown.Location = new System.Drawing.Point(393, 73);
            this.LineBackEndYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackEndYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.LineBackEndYUpDown.Name = "LineBackEndYUpDown";
            this.LineBackEndYUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineBackEndYUpDown.TabIndex = 82;
            this.LineBackEndYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(8, 76);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(42, 17);
            this.label60.TabIndex = 80;
            this.label60.Text = "Start:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(375, 78);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(17, 17);
            this.label61.TabIndex = 81;
            this.label61.Text = "Y";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(56, 78);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(17, 17);
            this.label62.TabIndex = 73;
            this.label62.Text = "X";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(293, 78);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(17, 17);
            this.label63.TabIndex = 80;
            this.label63.Text = "X";
            // 
            // LineBackResin
            // 
            this.LineBackResin.AutoSize = true;
            this.LineBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LineBackResin.Enabled = false;
            this.LineBackResin.Location = new System.Drawing.Point(475, 17);
            this.LineBackResin.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackResin.Name = "LineBackResin";
            this.LineBackResin.Size = new System.Drawing.Size(95, 21);
            this.LineBackResin.TabIndex = 79;
            this.LineBackResin.Text = "Use Resin";
            this.LineBackResin.UseVisualStyleBackColor = true;
            // 
            // LineBackEndXUpDown
            // 
            this.LineBackEndXUpDown.Enabled = false;
            this.LineBackEndXUpDown.Location = new System.Drawing.Point(312, 73);
            this.LineBackEndXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackEndXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.LineBackEndXUpDown.Name = "LineBackEndXUpDown";
            this.LineBackEndXUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineBackEndXUpDown.TabIndex = 78;
            this.LineBackEndXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LineBackColourCombo
            // 
            this.LineBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LineBackColourCombo.Enabled = false;
            this.LineBackColourCombo.Location = new System.Drawing.Point(75, 39);
            this.LineBackColourCombo.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackColourCombo.Name = "LineBackColourCombo";
            this.LineBackColourCombo.Size = new System.Drawing.Size(184, 24);
            this.LineBackColourCombo.TabIndex = 34;
            // 
            // LineBackStartXUpDown
            // 
            this.LineBackStartXUpDown.Enabled = false;
            this.LineBackStartXUpDown.Location = new System.Drawing.Point(75, 73);
            this.LineBackStartXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.LineBackStartXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.LineBackStartXUpDown.Name = "LineBackStartXUpDown";
            this.LineBackStartXUpDown.Size = new System.Drawing.Size(60, 22);
            this.LineBackStartXUpDown.TabIndex = 74;
            this.LineBackStartXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(8, 44);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(49, 17);
            this.label64.TabIndex = 32;
            this.label64.Text = "Colour";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(135, 78);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(17, 17);
            this.label65.TabIndex = 75;
            this.label65.Text = "Y";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.ShapeBackEnabled);
            this.groupBox21.Controls.Add(this.ShapeBackFillCombo);
            this.groupBox21.Controls.Add(this.label66);
            this.groupBox21.Controls.Add(this.ShapeBackWidthUpDown);
            this.groupBox21.Controls.Add(this.ShapeBackOutlineCombo);
            this.groupBox21.Controls.Add(this.label67);
            this.groupBox21.Controls.Add(this.label68);
            this.groupBox21.Controls.Add(this.ShapeBackBUpDown);
            this.groupBox21.Controls.Add(this.label70);
            this.groupBox21.Controls.Add(this.label71);
            this.groupBox21.Controls.Add(this.ShapeBackResin);
            this.groupBox21.Controls.Add(this.ShapeBackRUpDown);
            this.groupBox21.Controls.Add(this.ShapeBackTUpDown);
            this.groupBox21.Controls.Add(this.label72);
            this.groupBox21.Controls.Add(this.ShapeBackLUpDown);
            this.groupBox21.Controls.Add(this.label73);
            this.groupBox21.Controls.Add(this.ShapeBackCombo);
            this.groupBox21.Controls.Add(this.label74);
            this.groupBox21.Controls.Add(this.label75);
            this.groupBox21.Location = new System.Drawing.Point(4, 112);
            this.groupBox21.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox21.Size = new System.Drawing.Size(583, 105);
            this.groupBox21.TabIndex = 89;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Shape";
            // 
            // ShapeBackEnabled
            // 
            this.ShapeBackEnabled.AutoSize = true;
            this.ShapeBackEnabled.Enabled = false;
            this.ShapeBackEnabled.Location = new System.Drawing.Point(8, 17);
            this.ShapeBackEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackEnabled.Name = "ShapeBackEnabled";
            this.ShapeBackEnabled.Size = new System.Drawing.Size(82, 21);
            this.ShapeBackEnabled.TabIndex = 83;
            this.ShapeBackEnabled.Text = "Enabled";
            this.ShapeBackEnabled.UseVisualStyleBackColor = true;
            // 
            // ShapeBackFillCombo
            // 
            this.ShapeBackFillCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackFillCombo.Enabled = false;
            this.ShapeBackFillCombo.Items.AddRange(new object[] {
            "Red",
            "Green",
            "Blue",
            "Cyan",
            "Magenta",
            "Yellow",
            "White",
            "Black",
            "Transparent"});
            this.ShapeBackFillCombo.Location = new System.Drawing.Point(335, 74);
            this.ShapeBackFillCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackFillCombo.Name = "ShapeBackFillCombo";
            this.ShapeBackFillCombo.Size = new System.Drawing.Size(168, 24);
            this.ShapeBackFillCombo.TabIndex = 81;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(309, 79);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(25, 17);
            this.label66.TabIndex = 80;
            this.label66.Text = "Fill";
            // 
            // ShapeBackWidthUpDown
            // 
            this.ShapeBackWidthUpDown.Enabled = false;
            this.ShapeBackWidthUpDown.Location = new System.Drawing.Point(235, 74);
            this.ShapeBackWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackWidthUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ShapeBackWidthUpDown.Name = "ShapeBackWidthUpDown";
            this.ShapeBackWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeBackWidthUpDown.TabIndex = 81;
            this.ShapeBackWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeBackOutlineCombo
            // 
            this.ShapeBackOutlineCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackOutlineCombo.Enabled = false;
            this.ShapeBackOutlineCombo.Location = new System.Drawing.Point(69, 74);
            this.ShapeBackOutlineCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackOutlineCombo.Name = "ShapeBackOutlineCombo";
            this.ShapeBackOutlineCombo.Size = new System.Drawing.Size(112, 24);
            this.ShapeBackOutlineCombo.TabIndex = 81;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(191, 79);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(44, 17);
            this.label67.TabIndex = 80;
            this.label67.Text = "Width";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(8, 79);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(53, 17);
            this.label68.TabIndex = 80;
            this.label68.Text = "Outline";
            // 
            // ShapeBackBUpDown
            // 
            this.ShapeBackBUpDown.Enabled = false;
            this.ShapeBackBUpDown.Location = new System.Drawing.Point(504, 46);
            this.ShapeBackBUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackBUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ShapeBackBUpDown.Name = "ShapeBackBUpDown";
            this.ShapeBackBUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeBackBUpDown.TabIndex = 82;
            this.ShapeBackBUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(485, 50);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(17, 17);
            this.label70.TabIndex = 81;
            this.label70.Text = "B";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(405, 50);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(18, 17);
            this.label71.TabIndex = 80;
            this.label71.Text = "R";
            // 
            // ShapeBackResin
            // 
            this.ShapeBackResin.AutoSize = true;
            this.ShapeBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShapeBackResin.Enabled = false;
            this.ShapeBackResin.Location = new System.Drawing.Point(475, 17);
            this.ShapeBackResin.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackResin.Name = "ShapeBackResin";
            this.ShapeBackResin.Size = new System.Drawing.Size(95, 21);
            this.ShapeBackResin.TabIndex = 79;
            this.ShapeBackResin.Text = "Use Resin";
            this.ShapeBackResin.UseVisualStyleBackColor = true;
            // 
            // ShapeBackRUpDown
            // 
            this.ShapeBackRUpDown.Enabled = false;
            this.ShapeBackRUpDown.Location = new System.Drawing.Point(425, 46);
            this.ShapeBackRUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackRUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ShapeBackRUpDown.Name = "ShapeBackRUpDown";
            this.ShapeBackRUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeBackRUpDown.TabIndex = 78;
            this.ShapeBackRUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ShapeBackTUpDown
            // 
            this.ShapeBackTUpDown.Enabled = false;
            this.ShapeBackTUpDown.Location = new System.Drawing.Point(345, 46);
            this.ShapeBackTUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackTUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ShapeBackTUpDown.Name = "ShapeBackTUpDown";
            this.ShapeBackTUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeBackTUpDown.TabIndex = 76;
            this.ShapeBackTUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(327, 50);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(17, 17);
            this.label72.TabIndex = 75;
            this.label72.Text = "T";
            // 
            // ShapeBackLUpDown
            // 
            this.ShapeBackLUpDown.Enabled = false;
            this.ShapeBackLUpDown.Location = new System.Drawing.Point(267, 46);
            this.ShapeBackLUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackLUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ShapeBackLUpDown.Name = "ShapeBackLUpDown";
            this.ShapeBackLUpDown.Size = new System.Drawing.Size(60, 22);
            this.ShapeBackLUpDown.TabIndex = 74;
            this.ShapeBackLUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(249, 50);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(16, 17);
            this.label73.TabIndex = 73;
            this.label73.Text = "L";
            // 
            // ShapeBackCombo
            // 
            this.ShapeBackCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ShapeBackCombo.Enabled = false;
            this.ShapeBackCombo.Location = new System.Drawing.Point(69, 46);
            this.ShapeBackCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ShapeBackCombo.Name = "ShapeBackCombo";
            this.ShapeBackCombo.Size = new System.Drawing.Size(112, 24);
            this.ShapeBackCombo.TabIndex = 34;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(187, 50);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(62, 17);
            this.label74.TabIndex = 33;
            this.label74.Text = "Position:";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(8, 50);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(49, 17);
            this.label75.TabIndex = 32;
            this.label75.Text = "Shape";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.TextBackEnabled);
            this.groupBox22.Controls.Add(this.TextBackResin);
            this.groupBox22.Controls.Add(this.TextBackSizeUpDown);
            this.groupBox22.Controls.Add(this.label76);
            this.groupBox22.Controls.Add(this.TextBackYUpDown);
            this.groupBox22.Controls.Add(this.label77);
            this.groupBox22.Controls.Add(this.TextBackXUpDown);
            this.groupBox22.Controls.Add(this.label81);
            this.groupBox22.Controls.Add(this.TextBackStrikethrough);
            this.groupBox22.Controls.Add(this.TextBackItalic);
            this.groupBox22.Controls.Add(this.TextBackUnderline);
            this.groupBox22.Controls.Add(this.TextBackBold);
            this.groupBox22.Controls.Add(this.TextBackColourCombo);
            this.groupBox22.Controls.Add(this.label82);
            this.groupBox22.Controls.Add(this.label83);
            this.groupBox22.Controls.Add(this.label84);
            this.groupBox22.Controls.Add(this.TextBackBox);
            this.groupBox22.Location = new System.Drawing.Point(4, 0);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox22.Size = new System.Drawing.Size(583, 105);
            this.groupBox22.TabIndex = 88;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Text";
            // 
            // TextBackEnabled
            // 
            this.TextBackEnabled.AutoSize = true;
            this.TextBackEnabled.Enabled = false;
            this.TextBackEnabled.Location = new System.Drawing.Point(8, 17);
            this.TextBackEnabled.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackEnabled.Name = "TextBackEnabled";
            this.TextBackEnabled.Size = new System.Drawing.Size(82, 21);
            this.TextBackEnabled.TabIndex = 80;
            this.TextBackEnabled.Text = "Enabled";
            this.TextBackEnabled.UseVisualStyleBackColor = true;
            // 
            // TextBackResin
            // 
            this.TextBackResin.AutoSize = true;
            this.TextBackResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackResin.Enabled = false;
            this.TextBackResin.Location = new System.Drawing.Point(475, 76);
            this.TextBackResin.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackResin.Name = "TextBackResin";
            this.TextBackResin.Size = new System.Drawing.Size(95, 21);
            this.TextBackResin.TabIndex = 79;
            this.TextBackResin.Text = "Use Resin";
            this.TextBackResin.UseVisualStyleBackColor = true;
            // 
            // TextBackSizeUpDown
            // 
            this.TextBackSizeUpDown.Enabled = false;
            this.TextBackSizeUpDown.Location = new System.Drawing.Point(321, 74);
            this.TextBackSizeUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackSizeUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.TextBackSizeUpDown.Name = "TextBackSizeUpDown";
            this.TextBackSizeUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextBackSizeUpDown.TabIndex = 78;
            this.TextBackSizeUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(285, 79);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(35, 17);
            this.label76.TabIndex = 77;
            this.label76.Text = "Size";
            // 
            // TextBackYUpDown
            // 
            this.TextBackYUpDown.Enabled = false;
            this.TextBackYUpDown.Location = new System.Drawing.Point(192, 74);
            this.TextBackYUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.TextBackYUpDown.Name = "TextBackYUpDown";
            this.TextBackYUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextBackYUpDown.TabIndex = 76;
            this.TextBackYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(165, 79);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(17, 17);
            this.label77.TabIndex = 75;
            this.label77.Text = "Y";
            // 
            // TextBackXUpDown
            // 
            this.TextBackXUpDown.Enabled = false;
            this.TextBackXUpDown.Location = new System.Drawing.Point(97, 74);
            this.TextBackXUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.TextBackXUpDown.Name = "TextBackXUpDown";
            this.TextBackXUpDown.Size = new System.Drawing.Size(60, 22);
            this.TextBackXUpDown.TabIndex = 74;
            this.TextBackXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(71, 79);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(17, 17);
            this.label81.TabIndex = 73;
            this.label81.Text = "X";
            // 
            // TextBackStrikethrough
            // 
            this.TextBackStrikethrough.AutoSize = true;
            this.TextBackStrikethrough.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackStrikethrough.Enabled = false;
            this.TextBackStrikethrough.Location = new System.Drawing.Point(456, 48);
            this.TextBackStrikethrough.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackStrikethrough.Name = "TextBackStrikethrough";
            this.TextBackStrikethrough.Size = new System.Drawing.Size(115, 21);
            this.TextBackStrikethrough.TabIndex = 72;
            this.TextBackStrikethrough.Text = "Strikethrough";
            this.TextBackStrikethrough.UseVisualStyleBackColor = true;
            // 
            // TextBackItalic
            // 
            this.TextBackItalic.AutoSize = true;
            this.TextBackItalic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackItalic.Enabled = false;
            this.TextBackItalic.Location = new System.Drawing.Point(376, 48);
            this.TextBackItalic.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackItalic.Name = "TextBackItalic";
            this.TextBackItalic.Size = new System.Drawing.Size(58, 21);
            this.TextBackItalic.TabIndex = 71;
            this.TextBackItalic.Text = "Italic";
            this.TextBackItalic.UseVisualStyleBackColor = true;
            // 
            // TextBackUnderline
            // 
            this.TextBackUnderline.AutoSize = true;
            this.TextBackUnderline.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackUnderline.Enabled = false;
            this.TextBackUnderline.Location = new System.Drawing.Point(268, 48);
            this.TextBackUnderline.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackUnderline.Name = "TextBackUnderline";
            this.TextBackUnderline.Size = new System.Drawing.Size(91, 21);
            this.TextBackUnderline.TabIndex = 70;
            this.TextBackUnderline.Text = "Underline";
            this.TextBackUnderline.UseVisualStyleBackColor = true;
            // 
            // TextBackBold
            // 
            this.TextBackBold.AutoSize = true;
            this.TextBackBold.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TextBackBold.Enabled = false;
            this.TextBackBold.Location = new System.Drawing.Point(192, 48);
            this.TextBackBold.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackBold.Name = "TextBackBold";
            this.TextBackBold.Size = new System.Drawing.Size(58, 21);
            this.TextBackBold.TabIndex = 69;
            this.TextBackBold.Text = "Bold";
            this.TextBackBold.UseVisualStyleBackColor = true;
            // 
            // TextBackColourCombo
            // 
            this.TextBackColourCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TextBackColourCombo.Enabled = false;
            this.TextBackColourCombo.Location = new System.Drawing.Point(71, 46);
            this.TextBackColourCombo.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackColourCombo.Name = "TextBackColourCombo";
            this.TextBackColourCombo.Size = new System.Drawing.Size(112, 24);
            this.TextBackColourCombo.TabIndex = 34;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(8, 79);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(62, 17);
            this.label82.TabIndex = 33;
            this.label82.Text = "Position:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(8, 50);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(49, 17);
            this.label83.TabIndex = 32;
            this.label83.Text = "Colour";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(147, 20);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(35, 17);
            this.label84.TabIndex = 31;
            this.label84.Text = "Text";
            // 
            // TextBackBox
            // 
            this.TextBackBox.Enabled = false;
            this.TextBackBox.Location = new System.Drawing.Point(192, 15);
            this.TextBackBox.Margin = new System.Windows.Forms.Padding(4);
            this.TextBackBox.Name = "TextBackBox";
            this.TextBackBox.Size = new System.Drawing.Size(381, 22);
            this.TextBackBox.TabIndex = 14;
            this.TextBackBox.Text = "Back - First Line of C# Text";
            // 
            // CardBack
            // 
            this.CardBack.AutoSize = true;
            this.CardBack.Location = new System.Drawing.Point(331, 10);
            this.CardBack.Margin = new System.Windows.Forms.Padding(4);
            this.CardBack.Name = "CardBack";
            this.CardBack.Size = new System.Drawing.Size(95, 21);
            this.CardBack.TabIndex = 67;
            this.CardBack.Text = "Card Back";
            this.CardBack.UseVisualStyleBackColor = true;
            this.CardBack.CheckedChanged += new System.EventHandler(this.CardBackCheck_CheckedChanged);
            // 
            // CardFront
            // 
            this.CardFront.AutoSize = true;
            this.CardFront.Checked = true;
            this.CardFront.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CardFront.Location = new System.Drawing.Point(187, 10);
            this.CardFront.Margin = new System.Windows.Forms.Padding(4);
            this.CardFront.Name = "CardFront";
            this.CardFront.Size = new System.Drawing.Size(97, 21);
            this.CardFront.TabIndex = 66;
            this.CardFront.Text = "Card Front";
            this.CardFront.UseVisualStyleBackColor = true;
            this.CardFront.CheckedChanged += new System.EventHandler(this.CardFront_CheckedChanged);
            // 
            // PrintButton
            // 
            this.PrintButton.Location = new System.Drawing.Point(481, 650);
            this.PrintButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(120, 30);
            this.PrintButton.TabIndex = 17;
            this.PrintButton.Text = "Print";
            this.PrintButton.UseVisualStyleBackColor = true;
            this.PrintButton.Click += new System.EventHandler(this.PrintButton_Click);
            // 
            // DriverSettings2
            // 
            this.DriverSettings2.Controls.Add(this.groupBox6);
            this.DriverSettings2.Controls.Add(this.groupBox29);
            this.DriverSettings2.Controls.Add(this.groupBox23);
            this.DriverSettings2.Controls.Add(this.groupBox17);
            this.DriverSettings2.Controls.Add(this.groupBox16);
            this.DriverSettings2.Controls.Add(this.groupBox15);
            this.DriverSettings2.Controls.Add(this.groupBox14);
            this.DriverSettings2.Controls.Add(this.ClearDriver2MsgBoxButton);
            this.DriverSettings2.Controls.Add(this.Driver2MsgBox);
            this.DriverSettings2.Controls.Add(this.label17);
            this.DriverSettings2.Controls.Add(this.Driver2SetRadio);
            this.DriverSettings2.Controls.Add(this.Driver2GetRadio);
            this.DriverSettings2.Location = new System.Drawing.Point(4, 25);
            this.DriverSettings2.Margin = new System.Windows.Forms.Padding(4);
            this.DriverSettings2.Name = "DriverSettings2";
            this.DriverSettings2.Padding = new System.Windows.Forms.Padding(4);
            this.DriverSettings2.Size = new System.Drawing.Size(621, 700);
            this.DriverSettings2.TabIndex = 6;
            this.DriverSettings2.Text = "Driver 2";
            this.DriverSettings2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.ResinOptionsButton);
            this.groupBox6.Controls.Add(this.bPolygons_KResin);
            this.groupBox6.Controls.Add(this.bBitmaps_KResin);
            this.groupBox6.Controls.Add(this.bText_Kresin);
            this.groupBox6.Controls.Add(this.bPics_UseYMC);
            this.groupBox6.Controls.Add(this.bBlack_YMC);
            this.groupBox6.Controls.Add(this.ResinOptionsSideCombo);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Location = new System.Drawing.Point(269, 228);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(340, 144);
            this.groupBox6.TabIndex = 69;
            this.groupBox6.TabStop = false;
            // 
            // ResinOptionsButton
            // 
            this.ResinOptionsButton.Location = new System.Drawing.Point(113, 110);
            this.ResinOptionsButton.Margin = new System.Windows.Forms.Padding(4);
            this.ResinOptionsButton.Name = "ResinOptionsButton";
            this.ResinOptionsButton.Size = new System.Drawing.Size(120, 30);
            this.ResinOptionsButton.TabIndex = 66;
            this.ResinOptionsButton.Text = "Resin Options";
            this.ResinOptionsButton.UseVisualStyleBackColor = true;
            this.ResinOptionsButton.Click += new System.EventHandler(this.ResinOptionsButton_Click);
            // 
            // bPolygons_KResin
            // 
            this.bPolygons_KResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bPolygons_KResin.Enabled = false;
            this.bPolygons_KResin.Location = new System.Drawing.Point(163, 80);
            this.bPolygons_KResin.Margin = new System.Windows.Forms.Padding(4);
            this.bPolygons_KResin.Name = "bPolygons_KResin";
            this.bPolygons_KResin.Size = new System.Drawing.Size(177, 21);
            this.bPolygons_KResin.TabIndex = 70;
            this.bPolygons_KResin.Text = "Bk Polygons in K-resin";
            this.bPolygons_KResin.UseVisualStyleBackColor = true;
            // 
            // bBitmaps_KResin
            // 
            this.bBitmaps_KResin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBitmaps_KResin.Enabled = false;
            this.bBitmaps_KResin.Location = new System.Drawing.Point(163, 52);
            this.bBitmaps_KResin.Margin = new System.Windows.Forms.Padding(4);
            this.bBitmaps_KResin.Name = "bBitmaps_KResin";
            this.bBitmaps_KResin.Size = new System.Drawing.Size(177, 21);
            this.bBitmaps_KResin.TabIndex = 69;
            this.bBitmaps_KResin.Text = "Mono Bmps in K-resin";
            this.bBitmaps_KResin.UseVisualStyleBackColor = true;
            // 
            // bText_Kresin
            // 
            this.bText_Kresin.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bText_Kresin.Enabled = false;
            this.bText_Kresin.Location = new System.Drawing.Point(163, 23);
            this.bText_Kresin.Margin = new System.Windows.Forms.Padding(4);
            this.bText_Kresin.Name = "bText_Kresin";
            this.bText_Kresin.Size = new System.Drawing.Size(177, 21);
            this.bText_Kresin.TabIndex = 68;
            this.bText_Kresin.Text = "Black test in K-resin";
            this.bText_Kresin.UseVisualStyleBackColor = true;
            // 
            // bPics_UseYMC
            // 
            this.bPics_UseYMC.AutoSize = true;
            this.bPics_UseYMC.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bPics_UseYMC.Enabled = false;
            this.bPics_UseYMC.Location = new System.Drawing.Point(7, 80);
            this.bPics_UseYMC.Margin = new System.Windows.Forms.Padding(4);
            this.bPics_UseYMC.Name = "bPics_UseYMC";
            this.bPics_UseYMC.Size = new System.Drawing.Size(143, 21);
            this.bPics_UseYMC.TabIndex = 67;
            this.bPics_UseYMC.Text = "Pictures Use YMC";
            this.bPics_UseYMC.UseVisualStyleBackColor = true;
            // 
            // bBlack_YMC
            // 
            this.bBlack_YMC.AutoSize = true;
            this.bBlack_YMC.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bBlack_YMC.Enabled = false;
            this.bBlack_YMC.Location = new System.Drawing.Point(7, 52);
            this.bBlack_YMC.Margin = new System.Windows.Forms.Padding(4);
            this.bBlack_YMC.Name = "bBlack_YMC";
            this.bBlack_YMC.Size = new System.Drawing.Size(130, 21);
            this.bBlack_YMC.TabIndex = 66;
            this.bBlack_YMC.Text = "All Black is YMC";
            this.bBlack_YMC.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bBlack_YMC.UseVisualStyleBackColor = true;
            // 
            // ResinOptionsSideCombo
            // 
            this.ResinOptionsSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResinOptionsSideCombo.FormattingEnabled = true;
            this.ResinOptionsSideCombo.Location = new System.Drawing.Point(53, 18);
            this.ResinOptionsSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ResinOptionsSideCombo.Name = "ResinOptionsSideCombo";
            this.ResinOptionsSideCombo.Size = new System.Drawing.Size(80, 24);
            this.ResinOptionsSideCombo.TabIndex = 65;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(7, 23);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(36, 17);
            this.label41.TabIndex = 64;
            this.label41.Text = "Side";
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.ColourAdjust_WhiteRef);
            this.groupBox29.Controls.Add(this.label120);
            this.groupBox29.Controls.Add(this.label119);
            this.groupBox29.Controls.Add(this.ColourAdjust_BlackRef);
            this.groupBox29.Controls.Add(this.ColourAdjust_Illuminant);
            this.groupBox29.Controls.Add(this.label118);
            this.groupBox29.Controls.Add(this.ColourAdjust_Negative);
            this.groupBox29.Controls.Add(this.ColourAdjust_DarkPic);
            this.groupBox29.Controls.Add(this.ColourAdjust_Blue);
            this.groupBox29.Controls.Add(this.ColourAdjust_Green);
            this.groupBox29.Controls.Add(this.ColourAdjust_Red);
            this.groupBox29.Controls.Add(this.label115);
            this.groupBox29.Controls.Add(this.label116);
            this.groupBox29.Controls.Add(this.label117);
            this.groupBox29.Controls.Add(this.label110);
            this.groupBox29.Controls.Add(this.ColourAdjust_Tint);
            this.groupBox29.Controls.Add(this.ColourAdjust_Colour);
            this.groupBox29.Controls.Add(this.ColourAdjust_Brightness);
            this.groupBox29.Controls.Add(this.ColourAdjust_Contrast);
            this.groupBox29.Controls.Add(this.label111);
            this.groupBox29.Controls.Add(this.label113);
            this.groupBox29.Controls.Add(this.label114);
            this.groupBox29.Controls.Add(this.ColourAdjustBtn);
            this.groupBox29.Location = new System.Drawing.Point(269, 7);
            this.groupBox29.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox29.Size = new System.Drawing.Size(341, 220);
            this.groupBox29.TabIndex = 62;
            this.groupBox29.TabStop = false;
            // 
            // ColourAdjust_WhiteRef
            // 
            this.ColourAdjust_WhiteRef.Enabled = false;
            this.ColourAdjust_WhiteRef.Location = new System.Drawing.Point(241, 158);
            this.ColourAdjust_WhiteRef.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_WhiteRef.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ColourAdjust_WhiteRef.Minimum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.ColourAdjust_WhiteRef.Name = "ColourAdjust_WhiteRef";
            this.ColourAdjust_WhiteRef.Size = new System.Drawing.Size(81, 22);
            this.ColourAdjust_WhiteRef.TabIndex = 81;
            this.ColourAdjust_WhiteRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_WhiteRef.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(171, 162);
            this.label120.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(70, 17);
            this.label120.TabIndex = 80;
            this.label120.Text = "White Ref";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(5, 162);
            this.label119.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(68, 17);
            this.label119.TabIndex = 79;
            this.label119.Text = "Black Ref";
            // 
            // ColourAdjust_BlackRef
            // 
            this.ColourAdjust_BlackRef.Enabled = false;
            this.ColourAdjust_BlackRef.Location = new System.Drawing.Point(81, 158);
            this.ColourAdjust_BlackRef.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_BlackRef.Maximum = new decimal(new int[] {
            4000,
            0,
            0,
            0});
            this.ColourAdjust_BlackRef.Name = "ColourAdjust_BlackRef";
            this.ColourAdjust_BlackRef.Size = new System.Drawing.Size(81, 22);
            this.ColourAdjust_BlackRef.TabIndex = 78;
            this.ColourAdjust_BlackRef.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Illuminant
            // 
            this.ColourAdjust_Illuminant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAdjust_Illuminant.Enabled = false;
            this.ColourAdjust_Illuminant.FormattingEnabled = true;
            this.ColourAdjust_Illuminant.Location = new System.Drawing.Point(99, 127);
            this.ColourAdjust_Illuminant.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Illuminant.Name = "ColourAdjust_Illuminant";
            this.ColourAdjust_Illuminant.Size = new System.Drawing.Size(207, 24);
            this.ColourAdjust_Illuminant.TabIndex = 77;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(21, 130);
            this.label118.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(67, 17);
            this.label118.TabIndex = 76;
            this.label118.Text = "Illuminant";
            // 
            // ColourAdjust_Negative
            // 
            this.ColourAdjust_Negative.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ColourAdjust_Negative.Enabled = false;
            this.ColourAdjust_Negative.Location = new System.Drawing.Point(191, 103);
            this.ColourAdjust_Negative.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Negative.Name = "ColourAdjust_Negative";
            this.ColourAdjust_Negative.Size = new System.Drawing.Size(107, 23);
            this.ColourAdjust_Negative.TabIndex = 75;
            this.ColourAdjust_Negative.Text = "Negative";
            this.ColourAdjust_Negative.UseVisualStyleBackColor = true;
            // 
            // ColourAdjust_DarkPic
            // 
            this.ColourAdjust_DarkPic.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ColourAdjust_DarkPic.Enabled = false;
            this.ColourAdjust_DarkPic.Location = new System.Drawing.Point(27, 103);
            this.ColourAdjust_DarkPic.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_DarkPic.Name = "ColourAdjust_DarkPic";
            this.ColourAdjust_DarkPic.Size = new System.Drawing.Size(113, 21);
            this.ColourAdjust_DarkPic.TabIndex = 74;
            this.ColourAdjust_DarkPic.Text = "Dark Picture";
            this.ColourAdjust_DarkPic.UseVisualStyleBackColor = true;
            // 
            // ColourAdjust_Blue
            // 
            this.ColourAdjust_Blue.Enabled = false;
            this.ColourAdjust_Blue.Location = new System.Drawing.Point(216, 74);
            this.ColourAdjust_Blue.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Blue.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Blue.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Blue.Name = "ColourAdjust_Blue";
            this.ColourAdjust_Blue.Size = new System.Drawing.Size(81, 22);
            this.ColourAdjust_Blue.TabIndex = 73;
            this.ColourAdjust_Blue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Blue.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // ColourAdjust_Green
            // 
            this.ColourAdjust_Green.Enabled = false;
            this.ColourAdjust_Green.Location = new System.Drawing.Point(135, 74);
            this.ColourAdjust_Green.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Green.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Green.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Green.Name = "ColourAdjust_Green";
            this.ColourAdjust_Green.Size = new System.Drawing.Size(81, 22);
            this.ColourAdjust_Green.TabIndex = 72;
            this.ColourAdjust_Green.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Green.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // ColourAdjust_Red
            // 
            this.ColourAdjust_Red.Enabled = false;
            this.ColourAdjust_Red.Location = new System.Drawing.Point(53, 74);
            this.ColourAdjust_Red.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Red.Maximum = new decimal(new int[] {
            65000,
            0,
            0,
            0});
            this.ColourAdjust_Red.Minimum = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            this.ColourAdjust_Red.Name = "ColourAdjust_Red";
            this.ColourAdjust_Red.Size = new System.Drawing.Size(81, 22);
            this.ColourAdjust_Red.TabIndex = 69;
            this.ColourAdjust_Red.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAdjust_Red.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(237, 57);
            this.label115.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(17, 17);
            this.label115.TabIndex = 71;
            this.label115.Text = "B";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(159, 57);
            this.label116.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(19, 17);
            this.label116.TabIndex = 70;
            this.label116.Text = "G";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(73, 57);
            this.label117.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(18, 17);
            this.label117.TabIndex = 68;
            this.label117.Text = "R";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(247, 11);
            this.label110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(32, 17);
            this.label110.TabIndex = 67;
            this.label110.Text = "Tint";
            // 
            // ColourAdjust_Tint
            // 
            this.ColourAdjust_Tint.Enabled = false;
            this.ColourAdjust_Tint.Location = new System.Drawing.Point(233, 27);
            this.ColourAdjust_Tint.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Tint.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Tint.Name = "ColourAdjust_Tint";
            this.ColourAdjust_Tint.Size = new System.Drawing.Size(60, 22);
            this.ColourAdjust_Tint.TabIndex = 66;
            this.ColourAdjust_Tint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Colour
            // 
            this.ColourAdjust_Colour.Enabled = false;
            this.ColourAdjust_Colour.Location = new System.Drawing.Point(173, 27);
            this.ColourAdjust_Colour.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Colour.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Colour.Name = "ColourAdjust_Colour";
            this.ColourAdjust_Colour.Size = new System.Drawing.Size(60, 22);
            this.ColourAdjust_Colour.TabIndex = 65;
            this.ColourAdjust_Colour.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Brightness
            // 
            this.ColourAdjust_Brightness.Enabled = false;
            this.ColourAdjust_Brightness.Location = new System.Drawing.Point(113, 27);
            this.ColourAdjust_Brightness.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Brightness.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Brightness.Name = "ColourAdjust_Brightness";
            this.ColourAdjust_Brightness.Size = new System.Drawing.Size(60, 22);
            this.ColourAdjust_Brightness.TabIndex = 64;
            this.ColourAdjust_Brightness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAdjust_Contrast
            // 
            this.ColourAdjust_Contrast.Enabled = false;
            this.ColourAdjust_Contrast.Location = new System.Drawing.Point(53, 27);
            this.ColourAdjust_Contrast.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjust_Contrast.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.ColourAdjust_Contrast.Name = "ColourAdjust_Contrast";
            this.ColourAdjust_Contrast.Size = new System.Drawing.Size(60, 22);
            this.ColourAdjust_Contrast.TabIndex = 60;
            this.ColourAdjust_Contrast.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(179, 11);
            this.label111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(49, 17);
            this.label111.TabIndex = 63;
            this.label111.Text = "Colour";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(120, 11);
            this.label113.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(45, 17);
            this.label113.TabIndex = 62;
            this.label113.Text = "Bright";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(52, 11);
            this.label114.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(61, 17);
            this.label114.TabIndex = 61;
            this.label114.Text = "Contrast";
            // 
            // ColourAdjustBtn
            // 
            this.ColourAdjustBtn.Location = new System.Drawing.Point(113, 183);
            this.ColourAdjustBtn.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAdjustBtn.Name = "ColourAdjustBtn";
            this.ColourAdjustBtn.Size = new System.Drawing.Size(120, 30);
            this.ColourAdjustBtn.TabIndex = 50;
            this.ColourAdjustBtn.Text = "Colour Adjust";
            this.ColourAdjustBtn.UseVisualStyleBackColor = true;
            this.ColourAdjustBtn.Click += new System.EventHandler(this.ColourAdjustBtn_Click);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label86);
            this.groupBox23.Controls.Add(this.ColourAreaHeightUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaBottomUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaWidthUpDown);
            this.groupBox23.Controls.Add(this.ColourAreaLeftUpDown);
            this.groupBox23.Controls.Add(this.label107);
            this.groupBox23.Controls.Add(this.label108);
            this.groupBox23.Controls.Add(this.label109);
            this.groupBox23.Controls.Add(this.ColourAreaNo);
            this.groupBox23.Controls.Add(this.ColourAreaSideCombo);
            this.groupBox23.Controls.Add(this.label85);
            this.groupBox23.Controls.Add(this.ColourAreaCorrectionCombo);
            this.groupBox23.Controls.Add(this.label106);
            this.groupBox23.Controls.Add(this.ColourAreaButton);
            this.groupBox23.Location = new System.Drawing.Point(11, 542);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox23.Size = new System.Drawing.Size(255, 151);
            this.groupBox23.TabIndex = 68;
            this.groupBox23.TabStop = false;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(204, 71);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(18, 17);
            this.label86.TabIndex = 78;
            this.label86.Text = "H";
            // 
            // ColourAreaHeightUpDown
            // 
            this.ColourAreaHeightUpDown.Enabled = false;
            this.ColourAreaHeightUpDown.Location = new System.Drawing.Point(184, 90);
            this.ColourAreaHeightUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaHeightUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ColourAreaHeightUpDown.Name = "ColourAreaHeightUpDown";
            this.ColourAreaHeightUpDown.Size = new System.Drawing.Size(60, 22);
            this.ColourAreaHeightUpDown.TabIndex = 77;
            this.ColourAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaBottomUpDown
            // 
            this.ColourAreaBottomUpDown.Enabled = false;
            this.ColourAreaBottomUpDown.Location = new System.Drawing.Point(124, 90);
            this.ColourAreaBottomUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaBottomUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ColourAreaBottomUpDown.Name = "ColourAreaBottomUpDown";
            this.ColourAreaBottomUpDown.Size = new System.Drawing.Size(60, 22);
            this.ColourAreaBottomUpDown.TabIndex = 76;
            this.ColourAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaWidthUpDown
            // 
            this.ColourAreaWidthUpDown.Enabled = false;
            this.ColourAreaWidthUpDown.Location = new System.Drawing.Point(64, 90);
            this.ColourAreaWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaWidthUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ColourAreaWidthUpDown.Name = "ColourAreaWidthUpDown";
            this.ColourAreaWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.ColourAreaWidthUpDown.TabIndex = 75;
            this.ColourAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ColourAreaLeftUpDown
            // 
            this.ColourAreaLeftUpDown.Enabled = false;
            this.ColourAreaLeftUpDown.Location = new System.Drawing.Point(4, 90);
            this.ColourAreaLeftUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaLeftUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ColourAreaLeftUpDown.Name = "ColourAreaLeftUpDown";
            this.ColourAreaLeftUpDown.Size = new System.Drawing.Size(60, 22);
            this.ColourAreaLeftUpDown.TabIndex = 71;
            this.ColourAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(144, 71);
            this.label107.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(17, 17);
            this.label107.TabIndex = 74;
            this.label107.Text = "B";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(81, 71);
            this.label108.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(21, 17);
            this.label108.TabIndex = 73;
            this.label108.Text = "W";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(25, 71);
            this.label109.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(16, 17);
            this.label109.TabIndex = 72;
            this.label109.Text = "L";
            // 
            // ColourAreaNo
            // 
            this.ColourAreaNo.Location = new System.Drawing.Point(181, 15);
            this.ColourAreaNo.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaNo.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.ColourAreaNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ColourAreaNo.Name = "ColourAreaNo";
            this.ColourAreaNo.Size = new System.Drawing.Size(65, 22);
            this.ColourAreaNo.TabIndex = 70;
            this.ColourAreaNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ColourAreaNo.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ColourAreaNo.ValueChanged += new System.EventHandler(this.ColourArea_Changed);
            // 
            // ColourAreaSideCombo
            // 
            this.ColourAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAreaSideCombo.FormattingEnabled = true;
            this.ColourAreaSideCombo.Location = new System.Drawing.Point(49, 15);
            this.ColourAreaSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaSideCombo.Name = "ColourAreaSideCombo";
            this.ColourAreaSideCombo.Size = new System.Drawing.Size(111, 24);
            this.ColourAreaSideCombo.TabIndex = 63;
            this.ColourAreaSideCombo.SelectedIndexChanged += new System.EventHandler(this.ColourArea_Changed);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(8, 20);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(36, 17);
            this.label85.TabIndex = 62;
            this.label85.Text = "Side";
            // 
            // ColourAreaCorrectionCombo
            // 
            this.ColourAreaCorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourAreaCorrectionCombo.Enabled = false;
            this.ColourAreaCorrectionCombo.FormattingEnabled = true;
            this.ColourAreaCorrectionCombo.Location = new System.Drawing.Point(112, 46);
            this.ColourAreaCorrectionCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaCorrectionCombo.Name = "ColourAreaCorrectionCombo";
            this.ColourAreaCorrectionCombo.Size = new System.Drawing.Size(133, 24);
            this.ColourAreaCorrectionCombo.TabIndex = 56;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(8, 50);
            this.label106.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(73, 17);
            this.label106.TabIndex = 56;
            this.label106.Text = "Correction";
            // 
            // ColourAreaButton
            // 
            this.ColourAreaButton.Location = new System.Drawing.Point(72, 119);
            this.ColourAreaButton.Margin = new System.Windows.Forms.Padding(4);
            this.ColourAreaButton.Name = "ColourAreaButton";
            this.ColourAreaButton.Size = new System.Drawing.Size(120, 30);
            this.ColourAreaButton.TabIndex = 50;
            this.ColourAreaButton.Text = "Colour Area";
            this.ColourAreaButton.UseVisualStyleBackColor = true;
            this.ColourAreaButton.Click += new System.EventHandler(this.ColourAreaButton_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.HoloPatchPositionUpDown);
            this.groupBox17.Controls.Add(this.label53);
            this.groupBox17.Controls.Add(this.ColourHole);
            this.groupBox17.Controls.Add(this.HoloPatchButton);
            this.groupBox17.Location = new System.Drawing.Point(11, 458);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox17.Size = new System.Drawing.Size(255, 82);
            this.groupBox17.TabIndex = 67;
            this.groupBox17.TabStop = false;
            // 
            // HoloPatchPositionUpDown
            // 
            this.HoloPatchPositionUpDown.Enabled = false;
            this.HoloPatchPositionUpDown.Location = new System.Drawing.Point(67, 15);
            this.HoloPatchPositionUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.HoloPatchPositionUpDown.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.HoloPatchPositionUpDown.Name = "HoloPatchPositionUpDown";
            this.HoloPatchPositionUpDown.Size = new System.Drawing.Size(65, 22);
            this.HoloPatchPositionUpDown.TabIndex = 62;
            this.HoloPatchPositionUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.HoloPatchPositionUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(8, 20);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(58, 17);
            this.label53.TabIndex = 68;
            this.label53.Text = "Position";
            // 
            // ColourHole
            // 
            this.ColourHole.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ColourHole.Enabled = false;
            this.ColourHole.Location = new System.Drawing.Point(137, 16);
            this.ColourHole.Margin = new System.Windows.Forms.Padding(4);
            this.ColourHole.Name = "ColourHole";
            this.ColourHole.Size = new System.Drawing.Size(109, 21);
            this.ColourHole.TabIndex = 66;
            this.ColourHole.Text = "Colour Hole";
            this.ColourHole.UseVisualStyleBackColor = true;
            // 
            // HoloPatchButton
            // 
            this.HoloPatchButton.Location = new System.Drawing.Point(77, 47);
            this.HoloPatchButton.Margin = new System.Windows.Forms.Padding(4);
            this.HoloPatchButton.Name = "HoloPatchButton";
            this.HoloPatchButton.Size = new System.Drawing.Size(120, 30);
            this.HoloPatchButton.TabIndex = 50;
            this.HoloPatchButton.Text = "HoloPatch";
            this.HoloPatchButton.UseVisualStyleBackColor = true;
            this.HoloPatchButton.Click += new System.EventHandler(this.HoloPatchButton_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.HoloKotePreviewButton);
            this.groupBox16.Controls.Add(this.HoloKoteMapUpDown);
            this.groupBox16.Controls.Add(this.HoloKoteImageUpDown);
            this.groupBox16.Controls.Add(this.label52);
            this.groupBox16.Controls.Add(this.HoloKoteSideCombo);
            this.groupBox16.Controls.Add(this.NoCustomKey);
            this.groupBox16.Controls.Add(this.label49);
            this.groupBox16.Controls.Add(this.HoloKoteRotationCombo);
            this.groupBox16.Controls.Add(this.UseLaminate);
            this.groupBox16.Controls.Add(this.label50);
            this.groupBox16.Controls.Add(this.label51);
            this.groupBox16.Controls.Add(this.HoloKoteButton);
            this.groupBox16.Location = new System.Drawing.Point(11, 272);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox16.Size = new System.Drawing.Size(255, 185);
            this.groupBox16.TabIndex = 66;
            this.groupBox16.TabStop = false;
            // 
            // HoloKotePreviewButton
            // 
            this.HoloKotePreviewButton.Location = new System.Drawing.Point(112, 148);
            this.HoloKotePreviewButton.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKotePreviewButton.Name = "HoloKotePreviewButton";
            this.HoloKotePreviewButton.Size = new System.Drawing.Size(135, 30);
            this.HoloKotePreviewButton.TabIndex = 82;
            this.HoloKotePreviewButton.Text = "HoloKote Preview";
            this.HoloKotePreviewButton.UseVisualStyleBackColor = true;
            this.HoloKotePreviewButton.Click += new System.EventHandler(this.HoloKotePreviewButton_Click);
            // 
            // HoloKoteMapUpDown
            // 
            this.HoloKoteMapUpDown.Enabled = false;
            this.HoloKoteMapUpDown.Hexadecimal = true;
            this.HoloKoteMapUpDown.Location = new System.Drawing.Point(112, 48);
            this.HoloKoteMapUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKoteMapUpDown.Maximum = new decimal(new int[] {
            16777215,
            0,
            0,
            0});
            this.HoloKoteMapUpDown.Name = "HoloKoteMapUpDown";
            this.HoloKoteMapUpDown.Size = new System.Drawing.Size(135, 22);
            this.HoloKoteMapUpDown.TabIndex = 69;
            this.HoloKoteMapUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // HoloKoteImageUpDown
            // 
            this.HoloKoteImageUpDown.Enabled = false;
            this.HoloKoteImageUpDown.Location = new System.Drawing.Point(193, 15);
            this.HoloKoteImageUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKoteImageUpDown.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.HoloKoteImageUpDown.Name = "HoloKoteImageUpDown";
            this.HoloKoteImageUpDown.Size = new System.Drawing.Size(53, 22);
            this.HoloKoteImageUpDown.TabIndex = 62;
            this.HoloKoteImageUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.HoloKoteImageUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(137, 20);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(46, 17);
            this.label52.TabIndex = 68;
            this.label52.Text = "Image";
            // 
            // HoloKoteSideCombo
            // 
            this.HoloKoteSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HoloKoteSideCombo.FormattingEnabled = true;
            this.HoloKoteSideCombo.Location = new System.Drawing.Point(49, 15);
            this.HoloKoteSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKoteSideCombo.Name = "HoloKoteSideCombo";
            this.HoloKoteSideCombo.Size = new System.Drawing.Size(80, 24);
            this.HoloKoteSideCombo.TabIndex = 63;
            this.HoloKoteSideCombo.SelectedIndexChanged += new System.EventHandler(this.HoloKoteSide_Changed);
            // 
            // NoCustomKey
            // 
            this.NoCustomKey.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.NoCustomKey.Enabled = false;
            this.NoCustomKey.Location = new System.Drawing.Point(8, 123);
            this.NoCustomKey.Margin = new System.Windows.Forms.Padding(4);
            this.NoCustomKey.Name = "NoCustomKey";
            this.NoCustomKey.Size = new System.Drawing.Size(133, 21);
            this.NoCustomKey.TabIndex = 67;
            this.NoCustomKey.Text = "No Custom Key";
            this.NoCustomKey.UseVisualStyleBackColor = true;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(8, 20);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(36, 17);
            this.label49.TabIndex = 62;
            this.label49.Text = "Side";
            // 
            // HoloKoteRotationCombo
            // 
            this.HoloKoteRotationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HoloKoteRotationCombo.Enabled = false;
            this.HoloKoteRotationCombo.FormattingEnabled = true;
            this.HoloKoteRotationCombo.Location = new System.Drawing.Point(112, 74);
            this.HoloKoteRotationCombo.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKoteRotationCombo.Name = "HoloKoteRotationCombo";
            this.HoloKoteRotationCombo.Size = new System.Drawing.Size(133, 24);
            this.HoloKoteRotationCombo.TabIndex = 61;
            // 
            // UseLaminate
            // 
            this.UseLaminate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.UseLaminate.Enabled = false;
            this.UseLaminate.Location = new System.Drawing.Point(8, 102);
            this.UseLaminate.Margin = new System.Windows.Forms.Padding(4);
            this.UseLaminate.Name = "UseLaminate";
            this.UseLaminate.Size = new System.Drawing.Size(133, 21);
            this.UseLaminate.TabIndex = 66;
            this.UseLaminate.Text = "Use Laminate";
            this.UseLaminate.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(8, 79);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(61, 17);
            this.label50.TabIndex = 60;
            this.label50.Text = "Rotation";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(8, 53);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(97, 17);
            this.label51.TabIndex = 56;
            this.label51.Text = "HoloKote Map";
            // 
            // HoloKoteButton
            // 
            this.HoloKoteButton.Location = new System.Drawing.Point(11, 148);
            this.HoloKoteButton.Margin = new System.Windows.Forms.Padding(4);
            this.HoloKoteButton.Name = "HoloKoteButton";
            this.HoloKoteButton.Size = new System.Drawing.Size(89, 30);
            this.HoloKoteButton.TabIndex = 50;
            this.HoloKoteButton.Text = "HoloKote";
            this.HoloKoteButton.UseVisualStyleBackColor = true;
            this.HoloKoteButton.Click += new System.EventHandler(this.HoloKoteButton_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Rotate);
            this.groupBox15.Controls.Add(this.Overcoat);
            this.groupBox15.Controls.Add(this.CardSettingsSideCombo);
            this.groupBox15.Controls.Add(this.label47);
            this.groupBox15.Controls.Add(this.OrientationCombo);
            this.groupBox15.Controls.Add(this.label44);
            this.groupBox15.Controls.Add(this.ColourFormatCombo);
            this.groupBox15.Controls.Add(this.label48);
            this.groupBox15.Controls.Add(this.CardSettingsButton);
            this.groupBox15.Location = new System.Drawing.Point(11, 134);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(255, 138);
            this.groupBox15.TabIndex = 62;
            this.groupBox15.TabStop = false;
            // 
            // Rotate
            // 
            this.Rotate.AutoSize = true;
            this.Rotate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Rotate.Enabled = false;
            this.Rotate.Location = new System.Drawing.Point(152, 17);
            this.Rotate.Margin = new System.Windows.Forms.Padding(4);
            this.Rotate.Name = "Rotate";
            this.Rotate.Size = new System.Drawing.Size(72, 21);
            this.Rotate.TabIndex = 65;
            this.Rotate.Text = "Rotate";
            this.Rotate.UseVisualStyleBackColor = true;
            // 
            // Overcoat
            // 
            this.Overcoat.AutoSize = true;
            this.Overcoat.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Overcoat.Enabled = false;
            this.Overcoat.Location = new System.Drawing.Point(8, 106);
            this.Overcoat.Margin = new System.Windows.Forms.Padding(4);
            this.Overcoat.Name = "Overcoat";
            this.Overcoat.Size = new System.Drawing.Size(88, 21);
            this.Overcoat.TabIndex = 64;
            this.Overcoat.Text = "Overcoat";
            this.Overcoat.UseVisualStyleBackColor = true;
            // 
            // CardSettingsSideCombo
            // 
            this.CardSettingsSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CardSettingsSideCombo.FormattingEnabled = true;
            this.CardSettingsSideCombo.Location = new System.Drawing.Point(49, 15);
            this.CardSettingsSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.CardSettingsSideCombo.Name = "CardSettingsSideCombo";
            this.CardSettingsSideCombo.Size = new System.Drawing.Size(80, 24);
            this.CardSettingsSideCombo.TabIndex = 63;
            this.CardSettingsSideCombo.SelectedIndexChanged += new System.EventHandler(this.CardSettingsSide_Changed);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(8, 20);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(36, 17);
            this.label47.TabIndex = 62;
            this.label47.Text = "Side";
            // 
            // OrientationCombo
            // 
            this.OrientationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrientationCombo.Enabled = false;
            this.OrientationCombo.FormattingEnabled = true;
            this.OrientationCombo.Location = new System.Drawing.Point(112, 73);
            this.OrientationCombo.Margin = new System.Windows.Forms.Padding(4);
            this.OrientationCombo.Name = "OrientationCombo";
            this.OrientationCombo.Size = new System.Drawing.Size(133, 24);
            this.OrientationCombo.TabIndex = 61;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(8, 78);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(78, 17);
            this.label44.TabIndex = 60;
            this.label44.Text = "Orientation";
            // 
            // ColourFormatCombo
            // 
            this.ColourFormatCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ColourFormatCombo.Enabled = false;
            this.ColourFormatCombo.FormattingEnabled = true;
            this.ColourFormatCombo.Location = new System.Drawing.Point(112, 46);
            this.ColourFormatCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ColourFormatCombo.Name = "ColourFormatCombo";
            this.ColourFormatCombo.Size = new System.Drawing.Size(133, 24);
            this.ColourFormatCombo.TabIndex = 56;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(8, 50);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(97, 17);
            this.label48.TabIndex = 56;
            this.label48.Text = "Colour Format";
            // 
            // CardSettingsButton
            // 
            this.CardSettingsButton.Location = new System.Drawing.Point(127, 101);
            this.CardSettingsButton.Margin = new System.Windows.Forms.Padding(4);
            this.CardSettingsButton.Name = "CardSettingsButton";
            this.CardSettingsButton.Size = new System.Drawing.Size(120, 30);
            this.CardSettingsButton.TabIndex = 50;
            this.CardSettingsButton.Text = "Card Settings";
            this.CardSettingsButton.UseVisualStyleBackColor = true;
            this.CardSettingsButton.Click += new System.EventHandler(this.CardSettingsButton_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.CardSizeCombo);
            this.groupBox14.Controls.Add(this.label43);
            this.groupBox14.Controls.Add(this.CopyCountUpDown);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.DuplexCombo);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.PrintSettingsButton);
            this.groupBox14.Location = new System.Drawing.Point(11, 27);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(255, 107);
            this.groupBox14.TabIndex = 61;
            this.groupBox14.TabStop = false;
            // 
            // CardSizeCombo
            // 
            this.CardSizeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CardSizeCombo.Enabled = false;
            this.CardSizeCombo.FormattingEnabled = true;
            this.CardSizeCombo.Location = new System.Drawing.Point(96, 38);
            this.CardSizeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.CardSizeCombo.Name = "CardSizeCombo";
            this.CardSizeCombo.Size = new System.Drawing.Size(149, 24);
            this.CardSizeCombo.TabIndex = 61;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(8, 43);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(69, 17);
            this.label43.TabIndex = 60;
            this.label43.Text = "Card Size";
            // 
            // CopyCountUpDown
            // 
            this.CopyCountUpDown.Enabled = false;
            this.CopyCountUpDown.Location = new System.Drawing.Point(43, 73);
            this.CopyCountUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.CopyCountUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.CopyCountUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CopyCountUpDown.Name = "CopyCountUpDown";
            this.CopyCountUpDown.Size = new System.Drawing.Size(65, 22);
            this.CopyCountUpDown.TabIndex = 56;
            this.CopyCountUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.CopyCountUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(8, 78);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(30, 17);
            this.label45.TabIndex = 57;
            this.label45.Text = "No:";
            // 
            // DuplexCombo
            // 
            this.DuplexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DuplexCombo.Enabled = false;
            this.DuplexCombo.FormattingEnabled = true;
            this.DuplexCombo.Location = new System.Drawing.Point(96, 11);
            this.DuplexCombo.Margin = new System.Windows.Forms.Padding(4);
            this.DuplexCombo.Name = "DuplexCombo";
            this.DuplexCombo.Size = new System.Drawing.Size(149, 24);
            this.DuplexCombo.TabIndex = 56;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(8, 16);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(92, 17);
            this.label46.TabIndex = 56;
            this.label46.Text = "Sides to Print";
            // 
            // PrintSettingsButton
            // 
            this.PrintSettingsButton.Location = new System.Drawing.Point(127, 70);
            this.PrintSettingsButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrintSettingsButton.Name = "PrintSettingsButton";
            this.PrintSettingsButton.Size = new System.Drawing.Size(120, 30);
            this.PrintSettingsButton.TabIndex = 50;
            this.PrintSettingsButton.Text = "Print Settings";
            this.PrintSettingsButton.UseVisualStyleBackColor = true;
            this.PrintSettingsButton.Click += new System.EventHandler(this.PrintSettingsButton_Click);
            // 
            // ClearDriver2MsgBoxButton
            // 
            this.ClearDriver2MsgBoxButton.Location = new System.Drawing.Point(393, 663);
            this.ClearDriver2MsgBoxButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearDriver2MsgBoxButton.Name = "ClearDriver2MsgBoxButton";
            this.ClearDriver2MsgBoxButton.Size = new System.Drawing.Size(120, 30);
            this.ClearDriver2MsgBoxButton.TabIndex = 48;
            this.ClearDriver2MsgBoxButton.Text = "Clear";
            this.ClearDriver2MsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearDriver2MsgBoxButton.Click += new System.EventHandler(this.ClearDriver2MsgBoxButton_Click);
            // 
            // Driver2MsgBox
            // 
            this.Driver2MsgBox.Location = new System.Drawing.Point(269, 379);
            this.Driver2MsgBox.Margin = new System.Windows.Forms.Padding(4);
            this.Driver2MsgBox.Multiline = true;
            this.Driver2MsgBox.Name = "Driver2MsgBox";
            this.Driver2MsgBox.ReadOnly = true;
            this.Driver2MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Driver2MsgBox.Size = new System.Drawing.Size(340, 276);
            this.Driver2MsgBox.TabIndex = 47;
            this.Driver2MsgBox.WordWrap = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(39, 7);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 17);
            this.label17.TabIndex = 46;
            this.label17.Text = "Action:";
            // 
            // Driver2SetRadio
            // 
            this.Driver2SetRadio.AutoSize = true;
            this.Driver2SetRadio.Location = new System.Drawing.Point(148, 5);
            this.Driver2SetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.Driver2SetRadio.Name = "Driver2SetRadio";
            this.Driver2SetRadio.Size = new System.Drawing.Size(50, 21);
            this.Driver2SetRadio.TabIndex = 45;
            this.Driver2SetRadio.Text = "Set";
            this.Driver2SetRadio.UseVisualStyleBackColor = true;
            this.Driver2SetRadio.CheckedChanged += new System.EventHandler(this.Driver2ActionSetRadio_CheckedChanged);
            // 
            // Driver2GetRadio
            // 
            this.Driver2GetRadio.AutoSize = true;
            this.Driver2GetRadio.Checked = true;
            this.Driver2GetRadio.Location = new System.Drawing.Point(92, 5);
            this.Driver2GetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.Driver2GetRadio.Name = "Driver2GetRadio";
            this.Driver2GetRadio.Size = new System.Drawing.Size(52, 21);
            this.Driver2GetRadio.TabIndex = 44;
            this.Driver2GetRadio.TabStop = true;
            this.Driver2GetRadio.Text = "Get";
            this.Driver2GetRadio.UseVisualStyleBackColor = true;
            this.Driver2GetRadio.CheckedChanged += new System.EventHandler(this.Driver2ActionGetRadio_CheckedChanged);
            // 
            // DriverSettings1
            // 
            this.DriverSettings1.Controls.Add(this.groupBox30);
            this.DriverSettings1.Controls.Add(this.groupBox7);
            this.DriverSettings1.Controls.Add(this.GUIPrinter);
            this.DriverSettings1.Controls.Add(this.GUIUser);
            this.DriverSettings1.Controls.Add(this.groupBox13);
            this.DriverSettings1.Controls.Add(this.groupBox12);
            this.DriverSettings1.Controls.Add(this.groupBox11);
            this.DriverSettings1.Controls.Add(this.groupBox10);
            this.DriverSettings1.Controls.Add(this.PrintSpeedButton);
            this.DriverSettings1.Controls.Add(this.PrintSpeedCombo);
            this.DriverSettings1.Controls.Add(this.ColourCorrectionButton);
            this.DriverSettings1.Controls.Add(this.CorrectionCombo);
            this.DriverSettings1.Controls.Add(this.SharpnessUpDown);
            this.DriverSettings1.Controls.Add(this.GUIControlButton);
            this.DriverSettings1.Controls.Add(this.SharpnessButton);
            this.DriverSettings1.Controls.Add(this.label16);
            this.DriverSettings1.Controls.Add(this.Driver1SetRadio);
            this.DriverSettings1.Controls.Add(this.Driver1GetRadio);
            this.DriverSettings1.Controls.Add(this.ClearDriver1MsgBoxButton);
            this.DriverSettings1.Controls.Add(this.Driver1MsgBox);
            this.DriverSettings1.Location = new System.Drawing.Point(4, 25);
            this.DriverSettings1.Margin = new System.Windows.Forms.Padding(4);
            this.DriverSettings1.Name = "DriverSettings1";
            this.DriverSettings1.Padding = new System.Windows.Forms.Padding(4);
            this.DriverSettings1.Size = new System.Drawing.Size(621, 700);
            this.DriverSettings1.TabIndex = 5;
            this.DriverSettings1.Text = "Driver 1";
            this.DriverSettings1.UseVisualStyleBackColor = true;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.Radio600DPI);
            this.groupBox30.Controls.Add(this.ResolutionButton);
            this.groupBox30.Controls.Add(this.Radio300DPI);
            this.groupBox30.Location = new System.Drawing.Point(277, 4);
            this.groupBox30.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox30.Size = new System.Drawing.Size(333, 76);
            this.groupBox30.TabIndex = 61;
            this.groupBox30.TabStop = false;
            // 
            // Radio600DPI
            // 
            this.Radio600DPI.AutoSize = true;
            this.Radio600DPI.Enabled = false;
            this.Radio600DPI.Location = new System.Drawing.Point(21, 43);
            this.Radio600DPI.Margin = new System.Windows.Forms.Padding(4);
            this.Radio600DPI.Name = "Radio600DPI";
            this.Radio600DPI.Size = new System.Drawing.Size(117, 21);
            this.Radio600DPI.TabIndex = 70;
            this.Radio600DPI.TabStop = true;
            this.Radio600DPI.Text = "600 x 300 DPI";
            this.Radio600DPI.UseVisualStyleBackColor = true;
            // 
            // ResolutionButton
            // 
            this.ResolutionButton.Enabled = false;
            this.ResolutionButton.Location = new System.Drawing.Point(193, 27);
            this.ResolutionButton.Margin = new System.Windows.Forms.Padding(4);
            this.ResolutionButton.Name = "ResolutionButton";
            this.ResolutionButton.Size = new System.Drawing.Size(101, 30);
            this.ResolutionButton.TabIndex = 50;
            this.ResolutionButton.Text = "Resolution";
            this.ResolutionButton.UseVisualStyleBackColor = true;
            this.ResolutionButton.Click += new System.EventHandler(this.ResolutionButton_Click);
            // 
            // Radio300DPI
            // 
            this.Radio300DPI.AutoSize = true;
            this.Radio300DPI.Checked = true;
            this.Radio300DPI.Enabled = false;
            this.Radio300DPI.Location = new System.Drawing.Point(21, 20);
            this.Radio300DPI.Margin = new System.Windows.Forms.Padding(4);
            this.Radio300DPI.Name = "Radio300DPI";
            this.Radio300DPI.Size = new System.Drawing.Size(117, 21);
            this.Radio300DPI.TabIndex = 69;
            this.Radio300DPI.TabStop = true;
            this.Radio300DPI.Text = "300 x 300 DPI";
            this.Radio300DPI.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label122);
            this.groupBox7.Controls.Add(this.PrintableAreaHeightUpDown);
            this.groupBox7.Controls.Add(this.PrintableAreaBottomUpDown);
            this.groupBox7.Controls.Add(this.PrintableAreaWidthUpDown);
            this.groupBox7.Controls.Add(this.PrintableAreaLeftUpDown);
            this.groupBox7.Controls.Add(this.label131);
            this.groupBox7.Controls.Add(this.label132);
            this.groupBox7.Controls.Add(this.label133);
            this.groupBox7.Controls.Add(this.PrintableAreaButton);
            this.groupBox7.Location = new System.Drawing.Point(277, 78);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(333, 103);
            this.groupBox7.TabIndex = 60;
            this.groupBox7.TabStop = false;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(255, 15);
            this.label122.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(18, 17);
            this.label122.TabIndex = 59;
            this.label122.Text = "H";
            // 
            // PrintableAreaHeightUpDown
            // 
            this.PrintableAreaHeightUpDown.Enabled = false;
            this.PrintableAreaHeightUpDown.Location = new System.Drawing.Point(235, 34);
            this.PrintableAreaHeightUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.PrintableAreaHeightUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.PrintableAreaHeightUpDown.Name = "PrintableAreaHeightUpDown";
            this.PrintableAreaHeightUpDown.Size = new System.Drawing.Size(60, 22);
            this.PrintableAreaHeightUpDown.TabIndex = 58;
            this.PrintableAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // PrintableAreaBottomUpDown
            // 
            this.PrintableAreaBottomUpDown.Enabled = false;
            this.PrintableAreaBottomUpDown.Location = new System.Drawing.Point(175, 34);
            this.PrintableAreaBottomUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.PrintableAreaBottomUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.PrintableAreaBottomUpDown.Name = "PrintableAreaBottomUpDown";
            this.PrintableAreaBottomUpDown.Size = new System.Drawing.Size(60, 22);
            this.PrintableAreaBottomUpDown.TabIndex = 54;
            this.PrintableAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // PrintableAreaWidthUpDown
            // 
            this.PrintableAreaWidthUpDown.Enabled = false;
            this.PrintableAreaWidthUpDown.Location = new System.Drawing.Point(115, 34);
            this.PrintableAreaWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.PrintableAreaWidthUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.PrintableAreaWidthUpDown.Name = "PrintableAreaWidthUpDown";
            this.PrintableAreaWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.PrintableAreaWidthUpDown.TabIndex = 53;
            this.PrintableAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // PrintableAreaLeftUpDown
            // 
            this.PrintableAreaLeftUpDown.Enabled = false;
            this.PrintableAreaLeftUpDown.Location = new System.Drawing.Point(55, 34);
            this.PrintableAreaLeftUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.PrintableAreaLeftUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.PrintableAreaLeftUpDown.Name = "PrintableAreaLeftUpDown";
            this.PrintableAreaLeftUpDown.Size = new System.Drawing.Size(60, 22);
            this.PrintableAreaLeftUpDown.TabIndex = 50;
            this.PrintableAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(195, 15);
            this.label131.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(17, 17);
            this.label131.TabIndex = 52;
            this.label131.Text = "B";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(132, 15);
            this.label132.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(21, 17);
            this.label132.TabIndex = 51;
            this.label132.Text = "W";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(76, 15);
            this.label133.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(16, 17);
            this.label133.TabIndex = 50;
            this.label133.Text = "L";
            // 
            // PrintableAreaButton
            // 
            this.PrintableAreaButton.Location = new System.Drawing.Point(117, 66);
            this.PrintableAreaButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrintableAreaButton.Name = "PrintableAreaButton";
            this.PrintableAreaButton.Size = new System.Drawing.Size(120, 30);
            this.PrintableAreaButton.TabIndex = 50;
            this.PrintableAreaButton.Text = "PrintableArea";
            this.PrintableAreaButton.UseVisualStyleBackColor = true;
            this.PrintableAreaButton.Click += new System.EventHandler(this.PrintableAreaButton_Click);
            // 
            // GUIPrinter
            // 
            this.GUIPrinter.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GUIPrinter.Enabled = false;
            this.GUIPrinter.Location = new System.Drawing.Point(192, 27);
            this.GUIPrinter.Margin = new System.Windows.Forms.Padding(4);
            this.GUIPrinter.Name = "GUIPrinter";
            this.GUIPrinter.Size = new System.Drawing.Size(76, 30);
            this.GUIPrinter.TabIndex = 68;
            this.GUIPrinter.Text = "Printer";
            this.GUIPrinter.UseVisualStyleBackColor = true;
            // 
            // GUIUser
            // 
            this.GUIUser.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GUIUser.Enabled = false;
            this.GUIUser.Location = new System.Drawing.Point(128, 27);
            this.GUIUser.Margin = new System.Windows.Forms.Padding(4);
            this.GUIUser.Name = "GUIUser";
            this.GUIUser.Size = new System.Drawing.Size(64, 30);
            this.GUIUser.TabIndex = 67;
            this.GUIUser.Text = "User";
            this.GUIUser.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label40);
            this.groupBox13.Controls.Add(this.EraseBeforePrint);
            this.groupBox13.Controls.Add(this.EraseEndPowerLabel);
            this.groupBox13.Controls.Add(this.WritePowerUpDown);
            this.groupBox13.Controls.Add(this.ErasePowerEndUpDown);
            this.groupBox13.Controls.Add(this.WritePowerLabel);
            this.groupBox13.Controls.Add(this.label34);
            this.groupBox13.Controls.Add(this.label35);
            this.groupBox13.Controls.Add(this.EraseAreaHeightUpDown);
            this.groupBox13.Controls.Add(this.label37);
            this.groupBox13.Controls.Add(this.EraseAreaWidthUpDown);
            this.groupBox13.Controls.Add(this.ErasePowerStartUpDown);
            this.groupBox13.Controls.Add(this.EraseAreaBottomUpDown);
            this.groupBox13.Controls.Add(this.EraseAreaLeftUpDown);
            this.groupBox13.Controls.Add(this.label36);
            this.groupBox13.Controls.Add(this.label38);
            this.groupBox13.Controls.Add(this.label39);
            this.groupBox13.Controls.Add(this.RewritableButton);
            this.groupBox13.Location = new System.Drawing.Point(7, 505);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(255, 192);
            this.groupBox13.TabIndex = 62;
            this.groupBox13.TabStop = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(8, 76);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(51, 17);
            this.label40.TabIndex = 67;
            this.label40.Text = "Power:";
            // 
            // EraseBeforePrint
            // 
            this.EraseBeforePrint.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EraseBeforePrint.Location = new System.Drawing.Point(8, 117);
            this.EraseBeforePrint.Margin = new System.Windows.Forms.Padding(4);
            this.EraseBeforePrint.Name = "EraseBeforePrint";
            this.EraseBeforePrint.Size = new System.Drawing.Size(116, 37);
            this.EraseBeforePrint.TabIndex = 66;
            this.EraseBeforePrint.Text = "Erase Before Print";
            this.EraseBeforePrint.UseVisualStyleBackColor = true;
            // 
            // EraseEndPowerLabel
            // 
            this.EraseEndPowerLabel.AutoSize = true;
            this.EraseEndPowerLabel.Location = new System.Drawing.Point(128, 97);
            this.EraseEndPowerLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EraseEndPowerLabel.Name = "EraseEndPowerLabel";
            this.EraseEndPowerLabel.Size = new System.Drawing.Size(33, 17);
            this.EraseEndPowerLabel.TabIndex = 65;
            this.EraseEndPowerLabel.Text = "End";
            // 
            // WritePowerUpDown
            // 
            this.WritePowerUpDown.Enabled = false;
            this.WritePowerUpDown.Location = new System.Drawing.Point(179, 118);
            this.WritePowerUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.WritePowerUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.WritePowerUpDown.Name = "WritePowerUpDown";
            this.WritePowerUpDown.Size = new System.Drawing.Size(65, 22);
            this.WritePowerUpDown.TabIndex = 63;
            this.WritePowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ErasePowerEndUpDown
            // 
            this.ErasePowerEndUpDown.Enabled = false;
            this.ErasePowerEndUpDown.Location = new System.Drawing.Point(179, 92);
            this.ErasePowerEndUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ErasePowerEndUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ErasePowerEndUpDown.Name = "ErasePowerEndUpDown";
            this.ErasePowerEndUpDown.Size = new System.Drawing.Size(65, 22);
            this.ErasePowerEndUpDown.TabIndex = 64;
            this.ErasePowerEndUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // WritePowerLabel
            // 
            this.WritePowerLabel.AutoSize = true;
            this.WritePowerLabel.Location = new System.Drawing.Point(128, 123);
            this.WritePowerLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WritePowerLabel.Name = "WritePowerLabel";
            this.WritePowerLabel.Size = new System.Drawing.Size(41, 17);
            this.WritePowerLabel.TabIndex = 62;
            this.WritePowerLabel.Text = "Write";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(25, 27);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(16, 17);
            this.label34.TabIndex = 60;
            this.label34.Text = "L";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(204, 27);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(18, 17);
            this.label35.TabIndex = 59;
            this.label35.Text = "H";
            // 
            // EraseAreaHeightUpDown
            // 
            this.EraseAreaHeightUpDown.Enabled = false;
            this.EraseAreaHeightUpDown.Location = new System.Drawing.Point(184, 48);
            this.EraseAreaHeightUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.EraseAreaHeightUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.EraseAreaHeightUpDown.Name = "EraseAreaHeightUpDown";
            this.EraseAreaHeightUpDown.Size = new System.Drawing.Size(60, 22);
            this.EraseAreaHeightUpDown.TabIndex = 58;
            this.EraseAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(8, 6);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(79, 17);
            this.label37.TabIndex = 56;
            this.label37.Text = "Erase Area";
            // 
            // EraseAreaWidthUpDown
            // 
            this.EraseAreaWidthUpDown.Enabled = false;
            this.EraseAreaWidthUpDown.Location = new System.Drawing.Point(124, 48);
            this.EraseAreaWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.EraseAreaWidthUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.EraseAreaWidthUpDown.Name = "EraseAreaWidthUpDown";
            this.EraseAreaWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.EraseAreaWidthUpDown.TabIndex = 54;
            this.EraseAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ErasePowerStartUpDown
            // 
            this.ErasePowerStartUpDown.Enabled = false;
            this.ErasePowerStartUpDown.Location = new System.Drawing.Point(60, 92);
            this.ErasePowerStartUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ErasePowerStartUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.ErasePowerStartUpDown.Name = "ErasePowerStartUpDown";
            this.ErasePowerStartUpDown.Size = new System.Drawing.Size(65, 22);
            this.ErasePowerStartUpDown.TabIndex = 56;
            this.ErasePowerStartUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // EraseAreaBottomUpDown
            // 
            this.EraseAreaBottomUpDown.Enabled = false;
            this.EraseAreaBottomUpDown.Location = new System.Drawing.Point(64, 48);
            this.EraseAreaBottomUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.EraseAreaBottomUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.EraseAreaBottomUpDown.Name = "EraseAreaBottomUpDown";
            this.EraseAreaBottomUpDown.Size = new System.Drawing.Size(60, 22);
            this.EraseAreaBottomUpDown.TabIndex = 53;
            this.EraseAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // EraseAreaLeftUpDown
            // 
            this.EraseAreaLeftUpDown.Enabled = false;
            this.EraseAreaLeftUpDown.Location = new System.Drawing.Point(4, 48);
            this.EraseAreaLeftUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.EraseAreaLeftUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.EraseAreaLeftUpDown.Name = "EraseAreaLeftUpDown";
            this.EraseAreaLeftUpDown.Size = new System.Drawing.Size(60, 22);
            this.EraseAreaLeftUpDown.TabIndex = 50;
            this.EraseAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(8, 97);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(38, 17);
            this.label36.TabIndex = 57;
            this.label36.Text = "Start";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(144, 27);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(17, 17);
            this.label38.TabIndex = 52;
            this.label38.Text = "B";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(81, 27);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(21, 17);
            this.label39.TabIndex = 51;
            this.label39.Text = "W";
            // 
            // RewritableButton
            // 
            this.RewritableButton.Location = new System.Drawing.Point(76, 153);
            this.RewritableButton.Margin = new System.Windows.Forms.Padding(4);
            this.RewritableButton.Name = "RewritableButton";
            this.RewritableButton.Size = new System.Drawing.Size(120, 30);
            this.RewritableButton.TabIndex = 50;
            this.RewritableButton.Text = "Rewritable";
            this.RewritableButton.UseVisualStyleBackColor = true;
            this.RewritableButton.Click += new System.EventHandler(this.RewritableButton_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.AreaHoleTypeCombo);
            this.groupBox12.Controls.Add(this.label33);
            this.groupBox12.Controls.Add(this.label27);
            this.groupBox12.Controls.Add(this.AreaHoleHeightUpDown);
            this.groupBox12.Controls.Add(this.AreaHoleNoUpDown);
            this.groupBox12.Controls.Add(this.label28);
            this.groupBox12.Controls.Add(this.AreaHoleSideCombo);
            this.groupBox12.Controls.Add(this.label29);
            this.groupBox12.Controls.Add(this.AreaHoleBottomUpDown);
            this.groupBox12.Controls.Add(this.AreaHoleWidthUpDown);
            this.groupBox12.Controls.Add(this.AreaHoleLeftUpDown);
            this.groupBox12.Controls.Add(this.label30);
            this.groupBox12.Controls.Add(this.label31);
            this.groupBox12.Controls.Add(this.label32);
            this.groupBox12.Controls.Add(this.AreaHoleButton);
            this.groupBox12.Location = new System.Drawing.Point(7, 358);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(255, 146);
            this.groupBox12.TabIndex = 60;
            this.groupBox12.TabStop = false;
            // 
            // AreaHoleTypeCombo
            // 
            this.AreaHoleTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AreaHoleTypeCombo.FormattingEnabled = true;
            this.AreaHoleTypeCombo.Location = new System.Drawing.Point(49, 37);
            this.AreaHoleTypeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleTypeCombo.Name = "AreaHoleTypeCombo";
            this.AreaHoleTypeCombo.Size = new System.Drawing.Size(80, 24);
            this.AreaHoleTypeCombo.TabIndex = 61;
            this.AreaHoleTypeCombo.SelectedIndexChanged += new System.EventHandler(this.AreaHole_Changed);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 42);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(40, 17);
            this.label33.TabIndex = 60;
            this.label33.Text = "Type";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(204, 66);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(18, 17);
            this.label27.TabIndex = 59;
            this.label27.Text = "H";
            // 
            // AreaHoleHeightUpDown
            // 
            this.AreaHoleHeightUpDown.Enabled = false;
            this.AreaHoleHeightUpDown.Location = new System.Drawing.Point(184, 85);
            this.AreaHoleHeightUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleHeightUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.AreaHoleHeightUpDown.Name = "AreaHoleHeightUpDown";
            this.AreaHoleHeightUpDown.Size = new System.Drawing.Size(60, 22);
            this.AreaHoleHeightUpDown.TabIndex = 58;
            this.AreaHoleHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AreaHoleNoUpDown
            // 
            this.AreaHoleNoUpDown.Location = new System.Drawing.Point(179, 37);
            this.AreaHoleNoUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleNoUpDown.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.AreaHoleNoUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.AreaHoleNoUpDown.Name = "AreaHoleNoUpDown";
            this.AreaHoleNoUpDown.Size = new System.Drawing.Size(65, 22);
            this.AreaHoleNoUpDown.TabIndex = 56;
            this.AreaHoleNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.AreaHoleNoUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.AreaHoleNoUpDown.ValueChanged += new System.EventHandler(this.AreaHole_Changed);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(139, 42);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 17);
            this.label28.TabIndex = 57;
            this.label28.Text = "No.";
            // 
            // AreaHoleSideCombo
            // 
            this.AreaHoleSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AreaHoleSideCombo.FormattingEnabled = true;
            this.AreaHoleSideCombo.Location = new System.Drawing.Point(49, 11);
            this.AreaHoleSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleSideCombo.Name = "AreaHoleSideCombo";
            this.AreaHoleSideCombo.Size = new System.Drawing.Size(80, 24);
            this.AreaHoleSideCombo.TabIndex = 56;
            this.AreaHoleSideCombo.SelectedIndexChanged += new System.EventHandler(this.AreaHole_Changed);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(8, 16);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 17);
            this.label29.TabIndex = 56;
            this.label29.Text = "Side";
            // 
            // AreaHoleBottomUpDown
            // 
            this.AreaHoleBottomUpDown.Enabled = false;
            this.AreaHoleBottomUpDown.Location = new System.Drawing.Point(124, 85);
            this.AreaHoleBottomUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleBottomUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.AreaHoleBottomUpDown.Name = "AreaHoleBottomUpDown";
            this.AreaHoleBottomUpDown.Size = new System.Drawing.Size(60, 22);
            this.AreaHoleBottomUpDown.TabIndex = 54;
            this.AreaHoleBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AreaHoleWidthUpDown
            // 
            this.AreaHoleWidthUpDown.Enabled = false;
            this.AreaHoleWidthUpDown.Location = new System.Drawing.Point(64, 85);
            this.AreaHoleWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleWidthUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.AreaHoleWidthUpDown.Name = "AreaHoleWidthUpDown";
            this.AreaHoleWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.AreaHoleWidthUpDown.TabIndex = 53;
            this.AreaHoleWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AreaHoleLeftUpDown
            // 
            this.AreaHoleLeftUpDown.Enabled = false;
            this.AreaHoleLeftUpDown.Location = new System.Drawing.Point(4, 85);
            this.AreaHoleLeftUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleLeftUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.AreaHoleLeftUpDown.Name = "AreaHoleLeftUpDown";
            this.AreaHoleLeftUpDown.Size = new System.Drawing.Size(60, 22);
            this.AreaHoleLeftUpDown.TabIndex = 50;
            this.AreaHoleLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(144, 66);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 17);
            this.label30.TabIndex = 52;
            this.label30.Text = "B";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(81, 66);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(21, 17);
            this.label31.TabIndex = 51;
            this.label31.Text = "W";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(25, 66);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(16, 17);
            this.label32.TabIndex = 50;
            this.label32.Text = "L";
            // 
            // AreaHoleButton
            // 
            this.AreaHoleButton.Location = new System.Drawing.Point(76, 112);
            this.AreaHoleButton.Margin = new System.Windows.Forms.Padding(4);
            this.AreaHoleButton.Name = "AreaHoleButton";
            this.AreaHoleButton.Size = new System.Drawing.Size(120, 30);
            this.AreaHoleButton.TabIndex = 50;
            this.AreaHoleButton.Text = "Area/Hole";
            this.AreaHoleButton.UseVisualStyleBackColor = true;
            this.AreaHoleButton.Click += new System.EventHandler(this.AreaHoleButton_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label26);
            this.groupBox11.Controls.Add(this.ResinAreaHeightUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaNoUpDown);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Controls.Add(this.ResinAreaSideCombo);
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.ResinAreaBottomUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaWidthUpDown);
            this.groupBox11.Controls.Add(this.ResinAreaLeftUpDown);
            this.groupBox11.Controls.Add(this.label21);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Controls.Add(this.ResinAreaButton);
            this.groupBox11.Location = new System.Drawing.Point(7, 238);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(255, 121);
            this.groupBox11.TabIndex = 55;
            this.groupBox11.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(204, 41);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(18, 17);
            this.label26.TabIndex = 59;
            this.label26.Text = "H";
            // 
            // ResinAreaHeightUpDown
            // 
            this.ResinAreaHeightUpDown.Enabled = false;
            this.ResinAreaHeightUpDown.Location = new System.Drawing.Point(184, 59);
            this.ResinAreaHeightUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaHeightUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ResinAreaHeightUpDown.Name = "ResinAreaHeightUpDown";
            this.ResinAreaHeightUpDown.Size = new System.Drawing.Size(60, 22);
            this.ResinAreaHeightUpDown.TabIndex = 58;
            this.ResinAreaHeightUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaNoUpDown
            // 
            this.ResinAreaNoUpDown.Location = new System.Drawing.Point(179, 11);
            this.ResinAreaNoUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaNoUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.ResinAreaNoUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ResinAreaNoUpDown.Name = "ResinAreaNoUpDown";
            this.ResinAreaNoUpDown.Size = new System.Drawing.Size(65, 22);
            this.ResinAreaNoUpDown.TabIndex = 56;
            this.ResinAreaNoUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ResinAreaNoUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(139, 16);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(30, 17);
            this.label25.TabIndex = 57;
            this.label25.Text = "No.";
            // 
            // ResinAreaSideCombo
            // 
            this.ResinAreaSideCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResinAreaSideCombo.FormattingEnabled = true;
            this.ResinAreaSideCombo.Location = new System.Drawing.Point(49, 11);
            this.ResinAreaSideCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaSideCombo.Name = "ResinAreaSideCombo";
            this.ResinAreaSideCombo.Size = new System.Drawing.Size(80, 24);
            this.ResinAreaSideCombo.TabIndex = 56;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(8, 16);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 17);
            this.label24.TabIndex = 56;
            this.label24.Text = "Side";
            // 
            // ResinAreaBottomUpDown
            // 
            this.ResinAreaBottomUpDown.Enabled = false;
            this.ResinAreaBottomUpDown.Location = new System.Drawing.Point(124, 59);
            this.ResinAreaBottomUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaBottomUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.ResinAreaBottomUpDown.Name = "ResinAreaBottomUpDown";
            this.ResinAreaBottomUpDown.Size = new System.Drawing.Size(60, 22);
            this.ResinAreaBottomUpDown.TabIndex = 54;
            this.ResinAreaBottomUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaWidthUpDown
            // 
            this.ResinAreaWidthUpDown.Enabled = false;
            this.ResinAreaWidthUpDown.Location = new System.Drawing.Point(64, 59);
            this.ResinAreaWidthUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaWidthUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ResinAreaWidthUpDown.Name = "ResinAreaWidthUpDown";
            this.ResinAreaWidthUpDown.Size = new System.Drawing.Size(60, 22);
            this.ResinAreaWidthUpDown.TabIndex = 53;
            this.ResinAreaWidthUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinAreaLeftUpDown
            // 
            this.ResinAreaLeftUpDown.Enabled = false;
            this.ResinAreaLeftUpDown.Location = new System.Drawing.Point(4, 59);
            this.ResinAreaLeftUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaLeftUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.ResinAreaLeftUpDown.Name = "ResinAreaLeftUpDown";
            this.ResinAreaLeftUpDown.Size = new System.Drawing.Size(60, 22);
            this.ResinAreaLeftUpDown.TabIndex = 50;
            this.ResinAreaLeftUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(144, 41);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(17, 17);
            this.label21.TabIndex = 52;
            this.label21.Text = "B";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(81, 41);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(21, 17);
            this.label22.TabIndex = 51;
            this.label22.Text = "W";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(25, 41);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(16, 17);
            this.label23.TabIndex = 50;
            this.label23.Text = "L";
            // 
            // ResinAreaButton
            // 
            this.ResinAreaButton.Location = new System.Drawing.Point(76, 86);
            this.ResinAreaButton.Margin = new System.Windows.Forms.Padding(4);
            this.ResinAreaButton.Name = "ResinAreaButton";
            this.ResinAreaButton.Size = new System.Drawing.Size(120, 30);
            this.ResinAreaButton.TabIndex = 50;
            this.ResinAreaButton.Text = "ResinArea";
            this.ResinAreaButton.UseVisualStyleBackColor = true;
            this.ResinAreaButton.Click += new System.EventHandler(this.ResinAreaButton_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.OvercoatPowerUpDown);
            this.groupBox10.Controls.Add(this.ResinPowerUpDown);
            this.groupBox10.Controls.Add(this.YMCPowerUpDown);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.PowerLevelButton);
            this.groupBox10.Location = new System.Drawing.Point(7, 145);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(255, 94);
            this.groupBox10.TabIndex = 49;
            this.groupBox10.TabStop = false;
            // 
            // OvercoatPowerUpDown
            // 
            this.OvercoatPowerUpDown.Enabled = false;
            this.OvercoatPowerUpDown.Location = new System.Drawing.Point(167, 32);
            this.OvercoatPowerUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.OvercoatPowerUpDown.Name = "OvercoatPowerUpDown";
            this.OvercoatPowerUpDown.Size = new System.Drawing.Size(81, 22);
            this.OvercoatPowerUpDown.TabIndex = 54;
            this.OvercoatPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ResinPowerUpDown
            // 
            this.ResinPowerUpDown.Enabled = false;
            this.ResinPowerUpDown.Location = new System.Drawing.Point(85, 32);
            this.ResinPowerUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.ResinPowerUpDown.Name = "ResinPowerUpDown";
            this.ResinPowerUpDown.Size = new System.Drawing.Size(81, 22);
            this.ResinPowerUpDown.TabIndex = 53;
            this.ResinPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // YMCPowerUpDown
            // 
            this.YMCPowerUpDown.Enabled = false;
            this.YMCPowerUpDown.Location = new System.Drawing.Point(4, 32);
            this.YMCPowerUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.YMCPowerUpDown.Name = "YMCPowerUpDown";
            this.YMCPowerUpDown.Size = new System.Drawing.Size(81, 22);
            this.YMCPowerUpDown.TabIndex = 50;
            this.YMCPowerUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(176, 14);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 17);
            this.label20.TabIndex = 52;
            this.label20.Text = "Overcoat";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(109, 14);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 17);
            this.label19.TabIndex = 51;
            this.label19.Text = "K";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(24, 14);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 17);
            this.label18.TabIndex = 50;
            this.label18.Text = "YMC";
            // 
            // PowerLevelButton
            // 
            this.PowerLevelButton.Location = new System.Drawing.Point(76, 59);
            this.PowerLevelButton.Margin = new System.Windows.Forms.Padding(4);
            this.PowerLevelButton.Name = "PowerLevelButton";
            this.PowerLevelButton.Size = new System.Drawing.Size(120, 30);
            this.PowerLevelButton.TabIndex = 50;
            this.PowerLevelButton.Text = "Power Level";
            this.PowerLevelButton.UseVisualStyleBackColor = true;
            this.PowerLevelButton.Click += new System.EventHandler(this.PowerLevelButton_Click);
            // 
            // PrintSpeedButton
            // 
            this.PrintSpeedButton.Enabled = false;
            this.PrintSpeedButton.Location = new System.Drawing.Point(7, 116);
            this.PrintSpeedButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrintSpeedButton.Name = "PrintSpeedButton";
            this.PrintSpeedButton.Size = new System.Drawing.Size(120, 30);
            this.PrintSpeedButton.TabIndex = 47;
            this.PrintSpeedButton.Text = "Print Speed";
            this.PrintSpeedButton.UseVisualStyleBackColor = true;
            this.PrintSpeedButton.Click += new System.EventHandler(this.PrintSpeedButton_Click);
            // 
            // PrintSpeedCombo
            // 
            this.PrintSpeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PrintSpeedCombo.Enabled = false;
            this.PrintSpeedCombo.FormattingEnabled = true;
            this.PrintSpeedCombo.Location = new System.Drawing.Point(135, 118);
            this.PrintSpeedCombo.Margin = new System.Windows.Forms.Padding(4);
            this.PrintSpeedCombo.Name = "PrintSpeedCombo";
            this.PrintSpeedCombo.Size = new System.Drawing.Size(125, 24);
            this.PrintSpeedCombo.TabIndex = 48;
            // 
            // ColourCorrectionButton
            // 
            this.ColourCorrectionButton.Location = new System.Drawing.Point(7, 86);
            this.ColourCorrectionButton.Margin = new System.Windows.Forms.Padding(4);
            this.ColourCorrectionButton.Name = "ColourCorrectionButton";
            this.ColourCorrectionButton.Size = new System.Drawing.Size(120, 30);
            this.ColourCorrectionButton.TabIndex = 45;
            this.ColourCorrectionButton.Text = "Colour Corr.";
            this.ColourCorrectionButton.UseVisualStyleBackColor = true;
            this.ColourCorrectionButton.Click += new System.EventHandler(this.ColourCorrectionButton_Click);
            // 
            // CorrectionCombo
            // 
            this.CorrectionCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CorrectionCombo.Enabled = false;
            this.CorrectionCombo.FormattingEnabled = true;
            this.CorrectionCombo.Location = new System.Drawing.Point(135, 89);
            this.CorrectionCombo.Margin = new System.Windows.Forms.Padding(4);
            this.CorrectionCombo.Name = "CorrectionCombo";
            this.CorrectionCombo.Size = new System.Drawing.Size(125, 24);
            this.CorrectionCombo.TabIndex = 46;
            // 
            // SharpnessUpDown
            // 
            this.SharpnessUpDown.Enabled = false;
            this.SharpnessUpDown.Location = new System.Drawing.Point(135, 59);
            this.SharpnessUpDown.Margin = new System.Windows.Forms.Padding(4);
            this.SharpnessUpDown.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.SharpnessUpDown.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.SharpnessUpDown.Name = "SharpnessUpDown";
            this.SharpnessUpDown.ReadOnly = true;
            this.SharpnessUpDown.Size = new System.Drawing.Size(127, 22);
            this.SharpnessUpDown.TabIndex = 41;
            this.SharpnessUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // GUIControlButton
            // 
            this.GUIControlButton.Location = new System.Drawing.Point(7, 27);
            this.GUIControlButton.Margin = new System.Windows.Forms.Padding(4);
            this.GUIControlButton.Name = "GUIControlButton";
            this.GUIControlButton.Size = new System.Drawing.Size(120, 30);
            this.GUIControlButton.TabIndex = 42;
            this.GUIControlButton.Text = "GUI Control";
            this.GUIControlButton.UseVisualStyleBackColor = true;
            this.GUIControlButton.Click += new System.EventHandler(this.GUIControlButton_Click);
            // 
            // SharpnessButton
            // 
            this.SharpnessButton.Location = new System.Drawing.Point(7, 57);
            this.SharpnessButton.Margin = new System.Windows.Forms.Padding(4);
            this.SharpnessButton.Name = "SharpnessButton";
            this.SharpnessButton.Size = new System.Drawing.Size(120, 30);
            this.SharpnessButton.TabIndex = 44;
            this.SharpnessButton.Text = "Sharpness";
            this.SharpnessButton.UseVisualStyleBackColor = true;
            this.SharpnessButton.Click += new System.EventHandler(this.SharpnessButton_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(39, 7);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 17);
            this.label16.TabIndex = 40;
            this.label16.Text = "Action:";
            // 
            // Driver1SetRadio
            // 
            this.Driver1SetRadio.AutoSize = true;
            this.Driver1SetRadio.Location = new System.Drawing.Point(148, 5);
            this.Driver1SetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.Driver1SetRadio.Name = "Driver1SetRadio";
            this.Driver1SetRadio.Size = new System.Drawing.Size(50, 21);
            this.Driver1SetRadio.TabIndex = 39;
            this.Driver1SetRadio.TabStop = true;
            this.Driver1SetRadio.Text = "Set";
            this.Driver1SetRadio.UseVisualStyleBackColor = true;
            this.Driver1SetRadio.CheckedChanged += new System.EventHandler(this.Driver1ActionSetRadio_CheckedChanged);
            // 
            // Driver1GetRadio
            // 
            this.Driver1GetRadio.AutoSize = true;
            this.Driver1GetRadio.Checked = true;
            this.Driver1GetRadio.Location = new System.Drawing.Point(92, 5);
            this.Driver1GetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.Driver1GetRadio.Name = "Driver1GetRadio";
            this.Driver1GetRadio.Size = new System.Drawing.Size(52, 21);
            this.Driver1GetRadio.TabIndex = 38;
            this.Driver1GetRadio.TabStop = true;
            this.Driver1GetRadio.Text = "Get";
            this.Driver1GetRadio.UseVisualStyleBackColor = true;
            this.Driver1GetRadio.CheckedChanged += new System.EventHandler(this.Driver1ActionGetRadio_CheckedChanged);
            // 
            // ClearDriver1MsgBoxButton
            // 
            this.ClearDriver1MsgBoxButton.Location = new System.Drawing.Point(393, 663);
            this.ClearDriver1MsgBoxButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearDriver1MsgBoxButton.Name = "ClearDriver1MsgBoxButton";
            this.ClearDriver1MsgBoxButton.Size = new System.Drawing.Size(120, 30);
            this.ClearDriver1MsgBoxButton.TabIndex = 37;
            this.ClearDriver1MsgBoxButton.Text = "Clear";
            this.ClearDriver1MsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearDriver1MsgBoxButton.Click += new System.EventHandler(this.ClearDriver1MsgBoxButton_Click);
            // 
            // Driver1MsgBox
            // 
            this.Driver1MsgBox.Location = new System.Drawing.Point(276, 188);
            this.Driver1MsgBox.Margin = new System.Windows.Forms.Padding(4);
            this.Driver1MsgBox.Multiline = true;
            this.Driver1MsgBox.Name = "Driver1MsgBox";
            this.Driver1MsgBox.ReadOnly = true;
            this.Driver1MsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Driver1MsgBox.Size = new System.Drawing.Size(333, 467);
            this.Driver1MsgBox.TabIndex = 11;
            this.Driver1MsgBox.WordWrap = false;
            // 
            // MagEncoding
            // 
            this.MagEncoding.Controls.Add(this.groupBox31);
            this.MagEncoding.Controls.Add(this.groupBox8);
            this.MagEncoding.Controls.Add(this.groupBox9);
            this.MagEncoding.Location = new System.Drawing.Point(4, 25);
            this.MagEncoding.Margin = new System.Windows.Forms.Padding(4);
            this.MagEncoding.Name = "MagEncoding";
            this.MagEncoding.Padding = new System.Windows.Forms.Padding(4);
            this.MagEncoding.Size = new System.Drawing.Size(621, 700);
            this.MagEncoding.TabIndex = 0;
            this.MagEncoding.Text = "Encoding";
            this.MagEncoding.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.MagStartButton);
            this.groupBox31.Controls.Add(this.StartPosn);
            this.groupBox31.Controls.Add(this.label9);
            this.groupBox31.Controls.Add(this.EncodingSetRadio);
            this.groupBox31.Controls.Add(this.EncodingGetRadio);
            this.groupBox31.Location = new System.Drawing.Point(4, 9);
            this.groupBox31.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox31.Size = new System.Drawing.Size(608, 62);
            this.groupBox31.TabIndex = 17;
            this.groupBox31.TabStop = false;
            // 
            // MagStartButton
            // 
            this.MagStartButton.Location = new System.Drawing.Point(432, 25);
            this.MagStartButton.Margin = new System.Windows.Forms.Padding(4);
            this.MagStartButton.Name = "MagStartButton";
            this.MagStartButton.Size = new System.Drawing.Size(151, 30);
            this.MagStartButton.TabIndex = 32;
            this.MagStartButton.Text = "Mag Start";
            this.MagStartButton.UseVisualStyleBackColor = true;
            this.MagStartButton.Click += new System.EventHandler(this.MagStartButton_Click);
            // 
            // StartPosn
            // 
            this.StartPosn.Enabled = false;
            this.StartPosn.Location = new System.Drawing.Point(259, 27);
            this.StartPosn.Margin = new System.Windows.Forms.Padding(4);
            this.StartPosn.Maximum = new decimal(new int[] {
            85000,
            0,
            0,
            0});
            this.StartPosn.Name = "StartPosn";
            this.StartPosn.Size = new System.Drawing.Size(141, 22);
            this.StartPosn.TabIndex = 63;
            this.StartPosn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(155, 32);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 17);
            this.label9.TabIndex = 62;
            this.label9.Text = "Start Position";
            // 
            // EncodingSetRadio
            // 
            this.EncodingSetRadio.AutoSize = true;
            this.EncodingSetRadio.Location = new System.Drawing.Point(87, 30);
            this.EncodingSetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.EncodingSetRadio.Name = "EncodingSetRadio";
            this.EncodingSetRadio.Size = new System.Drawing.Size(50, 21);
            this.EncodingSetRadio.TabIndex = 41;
            this.EncodingSetRadio.TabStop = true;
            this.EncodingSetRadio.Text = "Set";
            this.EncodingSetRadio.UseVisualStyleBackColor = true;
            this.EncodingSetRadio.CheckedChanged += new System.EventHandler(this.EncodingSetRadio_CheckedChanged);
            // 
            // EncodingGetRadio
            // 
            this.EncodingGetRadio.AutoSize = true;
            this.EncodingGetRadio.Checked = true;
            this.EncodingGetRadio.Location = new System.Drawing.Point(31, 30);
            this.EncodingGetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.EncodingGetRadio.Name = "EncodingGetRadio";
            this.EncodingGetRadio.Size = new System.Drawing.Size(52, 21);
            this.EncodingGetRadio.TabIndex = 40;
            this.EncodingGetRadio.TabStop = true;
            this.EncodingGetRadio.Text = "Get";
            this.EncodingGetRadio.UseVisualStyleBackColor = true;
            this.EncodingGetRadio.CheckedChanged += new System.EventHandler(this.EncodingGetRadio_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.ReadMagTracks);
            this.groupBox8.Controls.Add(this.Track2Read);
            this.groupBox8.Controls.Add(this.Track3Read);
            this.groupBox8.Controls.Add(this.Track1Read);
            this.groupBox8.Controls.Add(this.EncodingBox);
            this.groupBox8.Controls.Add(this.ReadMagButton);
            this.groupBox8.Controls.Add(this.ClearEncodingBoxButton);
            this.groupBox8.Location = new System.Drawing.Point(4, 357);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(603, 340);
            this.groupBox8.TabIndex = 15;
            this.groupBox8.TabStop = false;
            // 
            // ReadMagTracks
            // 
            this.ReadMagTracks.Location = new System.Drawing.Point(265, 16);
            this.ReadMagTracks.Margin = new System.Windows.Forms.Padding(4);
            this.ReadMagTracks.Name = "ReadMagTracks";
            this.ReadMagTracks.Size = new System.Drawing.Size(151, 30);
            this.ReadMagTracks.TabIndex = 31;
            this.ReadMagTracks.Text = "ReadMagTracks";
            this.ReadMagTracks.UseVisualStyleBackColor = true;
            this.ReadMagTracks.Click += new System.EventHandler(this.ReadMagTracks_Click);
            // 
            // Track2Read
            // 
            this.Track2Read.AutoSize = true;
            this.Track2Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track2Read.Checked = true;
            this.Track2Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track2Read.Location = new System.Drawing.Point(93, 21);
            this.Track2Read.Margin = new System.Windows.Forms.Padding(4);
            this.Track2Read.Name = "Track2Read";
            this.Track2Read.Size = new System.Drawing.Size(78, 21);
            this.Track2Read.TabIndex = 30;
            this.Track2Read.Text = "Track 2";
            this.Track2Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Track2Read.UseVisualStyleBackColor = true;
            // 
            // Track3Read
            // 
            this.Track3Read.AutoSize = true;
            this.Track3Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track3Read.Checked = true;
            this.Track3Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track3Read.Location = new System.Drawing.Point(173, 21);
            this.Track3Read.Margin = new System.Windows.Forms.Padding(4);
            this.Track3Read.Name = "Track3Read";
            this.Track3Read.Size = new System.Drawing.Size(78, 21);
            this.Track3Read.TabIndex = 29;
            this.Track3Read.Text = "Track 3";
            this.Track3Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Track3Read.UseVisualStyleBackColor = true;
            // 
            // Track1Read
            // 
            this.Track1Read.AutoSize = true;
            this.Track1Read.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track1Read.Checked = true;
            this.Track1Read.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track1Read.Location = new System.Drawing.Point(11, 21);
            this.Track1Read.Margin = new System.Windows.Forms.Padding(4);
            this.Track1Read.Name = "Track1Read";
            this.Track1Read.Size = new System.Drawing.Size(78, 21);
            this.Track1Read.TabIndex = 28;
            this.Track1Read.Text = "Track 1";
            this.Track1Read.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Track1Read.UseVisualStyleBackColor = true;
            // 
            // EncodingBox
            // 
            this.EncodingBox.Location = new System.Drawing.Point(8, 53);
            this.EncodingBox.Margin = new System.Windows.Forms.Padding(4);
            this.EncodingBox.Multiline = true;
            this.EncodingBox.Name = "EncodingBox";
            this.EncodingBox.ReadOnly = true;
            this.EncodingBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.EncodingBox.Size = new System.Drawing.Size(591, 244);
            this.EncodingBox.TabIndex = 8;
            this.EncodingBox.WordWrap = false;
            // 
            // ReadMagButton
            // 
            this.ReadMagButton.Location = new System.Drawing.Point(449, 16);
            this.ReadMagButton.Margin = new System.Windows.Forms.Padding(4);
            this.ReadMagButton.Name = "ReadMagButton";
            this.ReadMagButton.Size = new System.Drawing.Size(151, 30);
            this.ReadMagButton.TabIndex = 11;
            this.ReadMagButton.Text = "ReadMag";
            this.ReadMagButton.UseVisualStyleBackColor = true;
            this.ReadMagButton.Click += new System.EventHandler(this.ReadMagButton_Click);
            // 
            // ClearEncodingBoxButton
            // 
            this.ClearEncodingBoxButton.Location = new System.Drawing.Point(239, 304);
            this.ClearEncodingBoxButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearEncodingBoxButton.Name = "ClearEncodingBoxButton";
            this.ClearEncodingBoxButton.Size = new System.Drawing.Size(120, 30);
            this.ClearEncodingBoxButton.TabIndex = 12;
            this.ClearEncodingBoxButton.Text = "Clear";
            this.ClearEncodingBoxButton.UseVisualStyleBackColor = true;
            this.ClearEncodingBoxButton.Click += new System.EventHandler(this.ClearEncodingBoxButton_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label112);
            this.groupBox9.Controls.Add(this.LRCLabel);
            this.groupBox9.Controls.Add(this.ParityLabel);
            this.groupBox9.Controls.Add(this.BitsPerInchLabel);
            this.groupBox9.Controls.Add(this.BitsPerCharLabel);
            this.groupBox9.Controls.Add(this.Track3SettingsLabel);
            this.groupBox9.Controls.Add(this.Track2SettingsLabel);
            this.groupBox9.Controls.Add(this.Track1SettingsLabel);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.JIS2Label);
            this.groupBox9.Controls.Add(this.Track3Label);
            this.groupBox9.Controls.Add(this.Track2Label);
            this.groupBox9.Controls.Add(this.Track1Data);
            this.groupBox9.Controls.Add(this.Track2Data);
            this.groupBox9.Controls.Add(this.Track3Data);
            this.groupBox9.Controls.Add(this.Track1Write);
            this.groupBox9.Controls.Add(this.Track2Write);
            this.groupBox9.Controls.Add(this.Track3Write);
            this.groupBox9.Controls.Add(this.EncodingTypeCombo);
            this.groupBox9.Controls.Add(this.CoercivityCombo);
            this.groupBox9.Controls.Add(this.Verify);
            this.groupBox9.Controls.Add(this.T1_BPCCombo);
            this.groupBox9.Controls.Add(this.T1_BPICombo);
            this.groupBox9.Controls.Add(this.T1_ParityCombo);
            this.groupBox9.Controls.Add(this.T1_LRCCombo);
            this.groupBox9.Controls.Add(this.T2_BPCCombo);
            this.groupBox9.Controls.Add(this.T2_BPICombo);
            this.groupBox9.Controls.Add(this.T2_ParityCombo);
            this.groupBox9.Controls.Add(this.T2_LRCCombo);
            this.groupBox9.Controls.Add(this.T3_BPCCombo);
            this.groupBox9.Controls.Add(this.T3_BPICombo);
            this.groupBox9.Controls.Add(this.T3_ParityCombo);
            this.groupBox9.Controls.Add(this.T3_LRCCombo);
            this.groupBox9.Controls.Add(this.EncodeMagButton);
            this.groupBox9.Controls.Add(this.Track1Label);
            this.groupBox9.Location = new System.Drawing.Point(4, 70);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(608, 287);
            this.groupBox9.TabIndex = 16;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Encoding";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(177, 25);
            this.label112.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(69, 17);
            this.label112.TabIndex = 60;
            this.label112.Text = "Coercivity";
            // 
            // LRCLabel
            // 
            this.LRCLabel.AutoSize = true;
            this.LRCLabel.Location = new System.Drawing.Point(527, 135);
            this.LRCLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LRCLabel.Name = "LRCLabel";
            this.LRCLabel.Size = new System.Drawing.Size(35, 17);
            this.LRCLabel.TabIndex = 59;
            this.LRCLabel.Text = "LRC";
            // 
            // ParityLabel
            // 
            this.ParityLabel.AutoSize = true;
            this.ParityLabel.Location = new System.Drawing.Point(395, 135);
            this.ParityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ParityLabel.Name = "ParityLabel";
            this.ParityLabel.Size = new System.Drawing.Size(44, 17);
            this.ParityLabel.TabIndex = 58;
            this.ParityLabel.Text = "Parity";
            // 
            // BitsPerInchLabel
            // 
            this.BitsPerInchLabel.AutoSize = true;
            this.BitsPerInchLabel.Location = new System.Drawing.Point(243, 135);
            this.BitsPerInchLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BitsPerInchLabel.Name = "BitsPerInchLabel";
            this.BitsPerInchLabel.Size = new System.Drawing.Size(87, 17);
            this.BitsPerInchLabel.TabIndex = 57;
            this.BitsPerInchLabel.Text = "Bits Per Inch";
            // 
            // BitsPerCharLabel
            // 
            this.BitsPerCharLabel.AutoSize = true;
            this.BitsPerCharLabel.Location = new System.Drawing.Point(112, 135);
            this.BitsPerCharLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BitsPerCharLabel.Name = "BitsPerCharLabel";
            this.BitsPerCharLabel.Size = new System.Drawing.Size(91, 17);
            this.BitsPerCharLabel.TabIndex = 56;
            this.BitsPerCharLabel.Text = "Bits Per Char";
            // 
            // Track3SettingsLabel
            // 
            this.Track3SettingsLabel.AutoSize = true;
            this.Track3SettingsLabel.Enabled = false;
            this.Track3SettingsLabel.Location = new System.Drawing.Point(11, 226);
            this.Track3SettingsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track3SettingsLabel.Name = "Track3SettingsLabel";
            this.Track3SettingsLabel.Size = new System.Drawing.Size(56, 17);
            this.Track3SettingsLabel.TabIndex = 55;
            this.Track3SettingsLabel.Text = "Track 3";
            // 
            // Track2SettingsLabel
            // 
            this.Track2SettingsLabel.AutoSize = true;
            this.Track2SettingsLabel.Enabled = false;
            this.Track2SettingsLabel.Location = new System.Drawing.Point(11, 193);
            this.Track2SettingsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track2SettingsLabel.Name = "Track2SettingsLabel";
            this.Track2SettingsLabel.Size = new System.Drawing.Size(56, 17);
            this.Track2SettingsLabel.TabIndex = 54;
            this.Track2SettingsLabel.Text = "Track 2";
            // 
            // Track1SettingsLabel
            // 
            this.Track1SettingsLabel.AutoSize = true;
            this.Track1SettingsLabel.Location = new System.Drawing.Point(11, 160);
            this.Track1SettingsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track1SettingsLabel.Name = "Track1SettingsLabel";
            this.Track1SettingsLabel.Size = new System.Drawing.Size(56, 17);
            this.Track1SettingsLabel.TabIndex = 53;
            this.Track1SettingsLabel.Text = "Track 1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 25);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 17);
            this.label13.TabIndex = 52;
            this.label13.Text = "Type";
            // 
            // JIS2Label
            // 
            this.JIS2Label.AutoSize = true;
            this.JIS2Label.Location = new System.Drawing.Point(11, 54);
            this.JIS2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.JIS2Label.Name = "JIS2Label";
            this.JIS2Label.Size = new System.Drawing.Size(38, 17);
            this.JIS2Label.TabIndex = 51;
            this.JIS2Label.Text = "Data";
            this.JIS2Label.Visible = false;
            // 
            // Track3Label
            // 
            this.Track3Label.AutoSize = true;
            this.Track3Label.Enabled = false;
            this.Track3Label.Location = new System.Drawing.Point(11, 111);
            this.Track3Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track3Label.Name = "Track3Label";
            this.Track3Label.Size = new System.Drawing.Size(56, 17);
            this.Track3Label.TabIndex = 50;
            this.Track3Label.Text = "Track 3";
            // 
            // Track2Label
            // 
            this.Track2Label.AutoSize = true;
            this.Track2Label.Enabled = false;
            this.Track2Label.Location = new System.Drawing.Point(11, 82);
            this.Track2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track2Label.Name = "Track2Label";
            this.Track2Label.Size = new System.Drawing.Size(56, 17);
            this.Track2Label.TabIndex = 48;
            this.Track2Label.Text = "Track 2";
            // 
            // Track1Data
            // 
            this.Track1Data.Location = new System.Drawing.Point(105, 50);
            this.Track1Data.Margin = new System.Windows.Forms.Padding(4);
            this.Track1Data.Name = "Track1Data";
            this.Track1Data.Size = new System.Drawing.Size(493, 22);
            this.Track1Data.TabIndex = 18;
            this.Track1Data.Text = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
            // 
            // Track2Data
            // 
            this.Track2Data.Enabled = false;
            this.Track2Data.Location = new System.Drawing.Point(105, 79);
            this.Track2Data.Margin = new System.Windows.Forms.Padding(4);
            this.Track2Data.Name = "Track2Data";
            this.Track2Data.Size = new System.Drawing.Size(493, 22);
            this.Track2Data.TabIndex = 13;
            // 
            // Track3Data
            // 
            this.Track3Data.Enabled = false;
            this.Track3Data.Location = new System.Drawing.Point(105, 107);
            this.Track3Data.Margin = new System.Windows.Forms.Padding(4);
            this.Track3Data.Name = "Track3Data";
            this.Track3Data.Size = new System.Drawing.Size(493, 22);
            this.Track3Data.TabIndex = 19;
            // 
            // Track1Write
            // 
            this.Track1Write.AutoSize = true;
            this.Track1Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track1Write.Checked = true;
            this.Track1Write.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Track1Write.Location = new System.Drawing.Point(75, 53);
            this.Track1Write.Margin = new System.Windows.Forms.Padding(4);
            this.Track1Write.Name = "Track1Write";
            this.Track1Write.Size = new System.Drawing.Size(18, 17);
            this.Track1Write.TabIndex = 14;
            this.Track1Write.UseVisualStyleBackColor = true;
            this.Track1Write.CheckedChanged += new System.EventHandler(this.Track1Write_CheckedChanged);
            // 
            // Track2Write
            // 
            this.Track2Write.AutoSize = true;
            this.Track2Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track2Write.Location = new System.Drawing.Point(75, 81);
            this.Track2Write.Margin = new System.Windows.Forms.Padding(4);
            this.Track2Write.Name = "Track2Write";
            this.Track2Write.Size = new System.Drawing.Size(18, 17);
            this.Track2Write.TabIndex = 16;
            this.Track2Write.UseVisualStyleBackColor = true;
            this.Track2Write.CheckedChanged += new System.EventHandler(this.Track2Write_CheckedChanged);
            // 
            // Track3Write
            // 
            this.Track3Write.AutoSize = true;
            this.Track3Write.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Track3Write.Location = new System.Drawing.Point(75, 110);
            this.Track3Write.Margin = new System.Windows.Forms.Padding(4);
            this.Track3Write.Name = "Track3Write";
            this.Track3Write.Size = new System.Drawing.Size(18, 17);
            this.Track3Write.TabIndex = 17;
            this.Track3Write.UseVisualStyleBackColor = true;
            this.Track3Write.CheckedChanged += new System.EventHandler(this.Track3Write_CheckedChanged);
            // 
            // EncodingTypeCombo
            // 
            this.EncodingTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EncodingTypeCombo.Location = new System.Drawing.Point(63, 20);
            this.EncodingTypeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.EncodingTypeCombo.Name = "EncodingTypeCombo";
            this.EncodingTypeCombo.Size = new System.Drawing.Size(77, 24);
            this.EncodingTypeCombo.TabIndex = 24;
            this.EncodingTypeCombo.SelectedIndexChanged += new System.EventHandler(this.EncodingTypeBox_SelectedIndexChanged);
            // 
            // CoercivityCombo
            // 
            this.CoercivityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoercivityCombo.Location = new System.Drawing.Point(259, 20);
            this.CoercivityCombo.Margin = new System.Windows.Forms.Padding(4);
            this.CoercivityCombo.Name = "CoercivityCombo";
            this.CoercivityCombo.Size = new System.Drawing.Size(153, 24);
            this.CoercivityCombo.TabIndex = 26;
            // 
            // Verify
            // 
            this.Verify.AutoSize = true;
            this.Verify.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Verify.Checked = true;
            this.Verify.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Verify.Location = new System.Drawing.Point(465, 22);
            this.Verify.Margin = new System.Windows.Forms.Padding(4);
            this.Verify.Name = "Verify";
            this.Verify.Size = new System.Drawing.Size(66, 21);
            this.Verify.TabIndex = 27;
            this.Verify.Text = "Verify";
            this.Verify.UseVisualStyleBackColor = true;
            // 
            // T1_BPCCombo
            // 
            this.T1_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPCCombo.Location = new System.Drawing.Point(105, 155);
            this.T1_BPCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T1_BPCCombo.Name = "T1_BPCCombo";
            this.T1_BPCCombo.Size = new System.Drawing.Size(103, 24);
            this.T1_BPCCombo.TabIndex = 28;
            // 
            // T1_BPICombo
            // 
            this.T1_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPICombo.Location = new System.Drawing.Point(235, 155);
            this.T1_BPICombo.Margin = new System.Windows.Forms.Padding(4);
            this.T1_BPICombo.Name = "T1_BPICombo";
            this.T1_BPICombo.Size = new System.Drawing.Size(103, 24);
            this.T1_BPICombo.TabIndex = 33;
            // 
            // T1_ParityCombo
            // 
            this.T1_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_ParityCombo.Enabled = false;
            this.T1_ParityCombo.Location = new System.Drawing.Point(364, 155);
            this.T1_ParityCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T1_ParityCombo.Name = "T1_ParityCombo";
            this.T1_ParityCombo.Size = new System.Drawing.Size(103, 24);
            this.T1_ParityCombo.TabIndex = 34;
            // 
            // T1_LRCCombo
            // 
            this.T1_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_LRCCombo.Enabled = false;
            this.T1_LRCCombo.Location = new System.Drawing.Point(493, 155);
            this.T1_LRCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T1_LRCCombo.Name = "T1_LRCCombo";
            this.T1_LRCCombo.Size = new System.Drawing.Size(103, 24);
            this.T1_LRCCombo.TabIndex = 35;
            // 
            // T2_BPCCombo
            // 
            this.T2_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPCCombo.Enabled = false;
            this.T2_BPCCombo.Location = new System.Drawing.Point(105, 188);
            this.T2_BPCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T2_BPCCombo.Name = "T2_BPCCombo";
            this.T2_BPCCombo.Size = new System.Drawing.Size(103, 24);
            this.T2_BPCCombo.TabIndex = 36;
            // 
            // T2_BPICombo
            // 
            this.T2_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPICombo.Enabled = false;
            this.T2_BPICombo.Location = new System.Drawing.Point(235, 188);
            this.T2_BPICombo.Margin = new System.Windows.Forms.Padding(4);
            this.T2_BPICombo.Name = "T2_BPICombo";
            this.T2_BPICombo.Size = new System.Drawing.Size(103, 24);
            this.T2_BPICombo.TabIndex = 38;
            // 
            // T2_ParityCombo
            // 
            this.T2_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_ParityCombo.Enabled = false;
            this.T2_ParityCombo.Location = new System.Drawing.Point(364, 188);
            this.T2_ParityCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T2_ParityCombo.Name = "T2_ParityCombo";
            this.T2_ParityCombo.Size = new System.Drawing.Size(103, 24);
            this.T2_ParityCombo.TabIndex = 40;
            // 
            // T2_LRCCombo
            // 
            this.T2_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_LRCCombo.Enabled = false;
            this.T2_LRCCombo.Location = new System.Drawing.Point(493, 188);
            this.T2_LRCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T2_LRCCombo.Name = "T2_LRCCombo";
            this.T2_LRCCombo.Size = new System.Drawing.Size(103, 24);
            this.T2_LRCCombo.TabIndex = 42;
            // 
            // T3_BPCCombo
            // 
            this.T3_BPCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_BPCCombo.Enabled = false;
            this.T3_BPCCombo.Location = new System.Drawing.Point(105, 222);
            this.T3_BPCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T3_BPCCombo.Name = "T3_BPCCombo";
            this.T3_BPCCombo.Size = new System.Drawing.Size(103, 24);
            this.T3_BPCCombo.TabIndex = 37;
            // 
            // T3_BPICombo
            // 
            this.T3_BPICombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_BPICombo.Enabled = false;
            this.T3_BPICombo.Location = new System.Drawing.Point(235, 222);
            this.T3_BPICombo.Margin = new System.Windows.Forms.Padding(4);
            this.T3_BPICombo.Name = "T3_BPICombo";
            this.T3_BPICombo.Size = new System.Drawing.Size(103, 24);
            this.T3_BPICombo.TabIndex = 39;
            // 
            // T3_ParityCombo
            // 
            this.T3_ParityCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_ParityCombo.Enabled = false;
            this.T3_ParityCombo.Location = new System.Drawing.Point(364, 222);
            this.T3_ParityCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T3_ParityCombo.Name = "T3_ParityCombo";
            this.T3_ParityCombo.Size = new System.Drawing.Size(103, 24);
            this.T3_ParityCombo.TabIndex = 41;
            // 
            // T3_LRCCombo
            // 
            this.T3_LRCCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T3_LRCCombo.Enabled = false;
            this.T3_LRCCombo.Location = new System.Drawing.Point(493, 222);
            this.T3_LRCCombo.Margin = new System.Windows.Forms.Padding(4);
            this.T3_LRCCombo.Name = "T3_LRCCombo";
            this.T3_LRCCombo.Size = new System.Drawing.Size(103, 24);
            this.T3_LRCCombo.TabIndex = 43;
            // 
            // EncodeMagButton
            // 
            this.EncodeMagButton.Location = new System.Drawing.Point(181, 250);
            this.EncodeMagButton.Margin = new System.Windows.Forms.Padding(4);
            this.EncodeMagButton.Name = "EncodeMagButton";
            this.EncodeMagButton.Size = new System.Drawing.Size(245, 30);
            this.EncodeMagButton.TabIndex = 10;
            this.EncodeMagButton.Text = "EncodeMag";
            this.EncodeMagButton.UseVisualStyleBackColor = true;
            this.EncodeMagButton.Click += new System.EventHandler(this.EncodeMagButton_Click);
            // 
            // Track1Label
            // 
            this.Track1Label.AutoSize = true;
            this.Track1Label.Location = new System.Drawing.Point(11, 54);
            this.Track1Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Track1Label.Name = "Track1Label";
            this.Track1Label.Size = new System.Drawing.Size(56, 17);
            this.Track1Label.TabIndex = 61;
            this.Track1Label.Text = "Track 1";
            // 
            // Information
            // 
            this.Information.Controls.Add(this.groupBox28);
            this.Information.Controls.Add(this.groupBox27);
            this.Information.Location = new System.Drawing.Point(4, 25);
            this.Information.Margin = new System.Windows.Forms.Padding(4);
            this.Information.Name = "Information";
            this.Information.Padding = new System.Windows.Forms.Padding(4);
            this.Information.Size = new System.Drawing.Size(621, 700);
            this.Information.TabIndex = 3;
            this.Information.Text = "Information";
            this.Information.UseVisualStyleBackColor = true;
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.Pwd2Label);
            this.groupBox28.Controls.Add(this.Pwd1Label);
            this.groupBox28.Controls.Add(this.PasswordButton);
            this.groupBox28.Controls.Add(this.Password2);
            this.groupBox28.Controls.Add(this.Password1);
            this.groupBox28.Controls.Add(this.PwdCommandCombo);
            this.groupBox28.Location = new System.Drawing.Point(1, 2);
            this.groupBox28.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox28.Size = new System.Drawing.Size(613, 70);
            this.groupBox28.TabIndex = 15;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Password";
            // 
            // Pwd2Label
            // 
            this.Pwd2Label.AutoSize = true;
            this.Pwd2Label.Location = new System.Drawing.Point(323, 28);
            this.Pwd2Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pwd2Label.Name = "Pwd2Label";
            this.Pwd2Label.Size = new System.Drawing.Size(25, 17);
            this.Pwd2Label.TabIndex = 39;
            this.Pwd2Label.Text = "P2";
            // 
            // Pwd1Label
            // 
            this.Pwd1Label.AutoSize = true;
            this.Pwd1Label.Location = new System.Drawing.Point(167, 28);
            this.Pwd1Label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pwd1Label.Name = "Pwd1Label";
            this.Pwd1Label.Size = new System.Drawing.Size(25, 17);
            this.Pwd1Label.TabIndex = 38;
            this.Pwd1Label.Text = "P1";
            // 
            // PasswordButton
            // 
            this.PasswordButton.Enabled = false;
            this.PasswordButton.Location = new System.Drawing.Point(492, 21);
            this.PasswordButton.Margin = new System.Windows.Forms.Padding(4);
            this.PasswordButton.Name = "PasswordButton";
            this.PasswordButton.Size = new System.Drawing.Size(101, 30);
            this.PasswordButton.TabIndex = 21;
            this.PasswordButton.Text = "Send";
            this.PasswordButton.UseVisualStyleBackColor = true;
            this.PasswordButton.Click += new System.EventHandler(this.PasswordButton_Click);
            // 
            // Password2
            // 
            this.Password2.Enabled = false;
            this.Password2.Location = new System.Drawing.Point(357, 23);
            this.Password2.Margin = new System.Windows.Forms.Padding(4);
            this.Password2.Name = "Password2";
            this.Password2.Size = new System.Drawing.Size(112, 22);
            this.Password2.TabIndex = 20;
            // 
            // Password1
            // 
            this.Password1.Enabled = false;
            this.Password1.Location = new System.Drawing.Point(201, 23);
            this.Password1.Margin = new System.Windows.Forms.Padding(4);
            this.Password1.Name = "Password1";
            this.Password1.Size = new System.Drawing.Size(112, 22);
            this.Password1.TabIndex = 19;
            // 
            // PwdCommandCombo
            // 
            this.PwdCommandCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PwdCommandCombo.Enabled = false;
            this.PwdCommandCombo.FormattingEnabled = true;
            this.PwdCommandCombo.Location = new System.Drawing.Point(16, 23);
            this.PwdCommandCombo.Margin = new System.Windows.Forms.Padding(4);
            this.PwdCommandCombo.Name = "PwdCommandCombo";
            this.PwdCommandCombo.Size = new System.Drawing.Size(141, 24);
            this.PwdCommandCombo.TabIndex = 18;
            this.PwdCommandCombo.SelectedIndexChanged += new System.EventHandler(this.PasswordCombo_SelectedIndexChanged);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.SensorsButton);
            this.groupBox27.Controls.Add(this.PrinterTypeButton);
            this.groupBox27.Controls.Add(this.SDKBitsButton);
            this.groupBox27.Controls.Add(this.PrinterModelButton);
            this.groupBox27.Controls.Add(this.ConnectionTypeButton);
            this.groupBox27.Controls.Add(this.SDKVersionButton);
            this.groupBox27.Controls.Add(this.ClearMsgBoxButton);
            this.groupBox27.Controls.Add(this.LastMessageButton);
            this.groupBox27.Controls.Add(this.InfoMsgBox);
            this.groupBox27.Controls.Add(this.PrinterInfoButton);
            this.groupBox27.Controls.Add(this.PrinterStatusButton);
            this.groupBox27.Controls.Add(this.Generation2GroupBox);
            this.groupBox27.Location = new System.Drawing.Point(1, 80);
            this.groupBox27.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox27.Size = new System.Drawing.Size(613, 613);
            this.groupBox27.TabIndex = 14;
            this.groupBox27.TabStop = false;
            // 
            // SensorsButton
            // 
            this.SensorsButton.Location = new System.Drawing.Point(19, 313);
            this.SensorsButton.Margin = new System.Windows.Forms.Padding(4);
            this.SensorsButton.Name = "SensorsButton";
            this.SensorsButton.Size = new System.Drawing.Size(189, 30);
            this.SensorsButton.TabIndex = 44;
            this.SensorsButton.Text = "Sensors";
            this.SensorsButton.UseVisualStyleBackColor = true;
            this.SensorsButton.Click += new System.EventHandler(this.SensorsButton_Click);
            // 
            // PrinterTypeButton
            // 
            this.PrinterTypeButton.Location = new System.Drawing.Point(19, 128);
            this.PrinterTypeButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterTypeButton.Name = "PrinterTypeButton";
            this.PrinterTypeButton.Size = new System.Drawing.Size(189, 30);
            this.PrinterTypeButton.TabIndex = 43;
            this.PrinterTypeButton.Text = "PrinterType";
            this.PrinterTypeButton.UseVisualStyleBackColor = true;
            this.PrinterTypeButton.Click += new System.EventHandler(this.PrinterTypeButton_Click);
            // 
            // SDKBitsButton
            // 
            this.SDKBitsButton.Location = new System.Drawing.Point(19, 54);
            this.SDKBitsButton.Margin = new System.Windows.Forms.Padding(4);
            this.SDKBitsButton.Name = "SDKBitsButton";
            this.SDKBitsButton.Size = new System.Drawing.Size(189, 30);
            this.SDKBitsButton.TabIndex = 14;
            this.SDKBitsButton.Text = "SDKBits";
            this.SDKBitsButton.UseVisualStyleBackColor = true;
            this.SDKBitsButton.Click += new System.EventHandler(this.SDKBitsButton_Click);
            // 
            // PrinterModelButton
            // 
            this.PrinterModelButton.Location = new System.Drawing.Point(19, 165);
            this.PrinterModelButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterModelButton.Name = "PrinterModelButton";
            this.PrinterModelButton.Size = new System.Drawing.Size(189, 30);
            this.PrinterModelButton.TabIndex = 13;
            this.PrinterModelButton.Text = "PrinterModel";
            this.PrinterModelButton.UseVisualStyleBackColor = true;
            this.PrinterModelButton.Click += new System.EventHandler(this.PrinterModelButton_Click);
            // 
            // ConnectionTypeButton
            // 
            this.ConnectionTypeButton.Location = new System.Drawing.Point(19, 91);
            this.ConnectionTypeButton.Margin = new System.Windows.Forms.Padding(4);
            this.ConnectionTypeButton.Name = "ConnectionTypeButton";
            this.ConnectionTypeButton.Size = new System.Drawing.Size(189, 30);
            this.ConnectionTypeButton.TabIndex = 12;
            this.ConnectionTypeButton.Text = "ConnectionType";
            this.ConnectionTypeButton.UseVisualStyleBackColor = true;
            this.ConnectionTypeButton.Click += new System.EventHandler(this.ConnectionTypeButton_Click);
            // 
            // SDKVersionButton
            // 
            this.SDKVersionButton.Location = new System.Drawing.Point(19, 17);
            this.SDKVersionButton.Margin = new System.Windows.Forms.Padding(4);
            this.SDKVersionButton.Name = "SDKVersionButton";
            this.SDKVersionButton.Size = new System.Drawing.Size(189, 30);
            this.SDKVersionButton.TabIndex = 11;
            this.SDKVersionButton.Text = "SDKVersion";
            this.SDKVersionButton.UseVisualStyleBackColor = true;
            this.SDKVersionButton.Click += new System.EventHandler(this.SDKVersionButton_Click);
            // 
            // ClearMsgBoxButton
            // 
            this.ClearMsgBoxButton.Location = new System.Drawing.Point(353, 580);
            this.ClearMsgBoxButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearMsgBoxButton.Name = "ClearMsgBoxButton";
            this.ClearMsgBoxButton.Size = new System.Drawing.Size(120, 30);
            this.ClearMsgBoxButton.TabIndex = 10;
            this.ClearMsgBoxButton.Text = "Clear";
            this.ClearMsgBoxButton.UseVisualStyleBackColor = true;
            this.ClearMsgBoxButton.Click += new System.EventHandler(this.ClearMsgBoxButton_Click);
            // 
            // LastMessageButton
            // 
            this.LastMessageButton.Location = new System.Drawing.Point(19, 276);
            this.LastMessageButton.Margin = new System.Windows.Forms.Padding(4);
            this.LastMessageButton.Name = "LastMessageButton";
            this.LastMessageButton.Size = new System.Drawing.Size(189, 30);
            this.LastMessageButton.TabIndex = 9;
            this.LastMessageButton.Text = "LastMessage";
            this.LastMessageButton.UseVisualStyleBackColor = true;
            this.LastMessageButton.Click += new System.EventHandler(this.LastMessageButton_Click);
            // 
            // InfoMsgBox
            // 
            this.InfoMsgBox.Location = new System.Drawing.Point(219, 17);
            this.InfoMsgBox.Margin = new System.Windows.Forms.Padding(4);
            this.InfoMsgBox.Multiline = true;
            this.InfoMsgBox.Name = "InfoMsgBox";
            this.InfoMsgBox.ReadOnly = true;
            this.InfoMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InfoMsgBox.Size = new System.Drawing.Size(388, 554);
            this.InfoMsgBox.TabIndex = 7;
            // 
            // PrinterInfoButton
            // 
            this.PrinterInfoButton.Location = new System.Drawing.Point(19, 239);
            this.PrinterInfoButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterInfoButton.Name = "PrinterInfoButton";
            this.PrinterInfoButton.Size = new System.Drawing.Size(189, 30);
            this.PrinterInfoButton.TabIndex = 0;
            this.PrinterInfoButton.Text = "PrinterInfo";
            this.PrinterInfoButton.UseVisualStyleBackColor = true;
            this.PrinterInfoButton.Click += new System.EventHandler(this.PrinterInfoButton_Click);
            // 
            // PrinterStatusButton
            // 
            this.PrinterStatusButton.Location = new System.Drawing.Point(19, 202);
            this.PrinterStatusButton.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterStatusButton.Name = "PrinterStatusButton";
            this.PrinterStatusButton.Size = new System.Drawing.Size(189, 30);
            this.PrinterStatusButton.TabIndex = 1;
            this.PrinterStatusButton.Text = "PrinterStatus";
            this.PrinterStatusButton.UseVisualStyleBackColor = true;
            this.PrinterStatusButton.Click += new System.EventHandler(this.PrinterStatusButton_Click);
            // 
            // Generation2GroupBox
            // 
            this.Generation2GroupBox.Controls.Add(this.ReadParamButton);
            this.Generation2GroupBox.Controls.Add(this.label121);
            this.Generation2GroupBox.Controls.Add(this.AllParamsButton);
            this.Generation2GroupBox.Controls.Add(this.ParamCombo);
            this.Generation2GroupBox.Location = new System.Drawing.Point(8, 432);
            this.Generation2GroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.Generation2GroupBox.Name = "Generation2GroupBox";
            this.Generation2GroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.Generation2GroupBox.Size = new System.Drawing.Size(203, 170);
            this.Generation2GroupBox.TabIndex = 21;
            this.Generation2GroupBox.TabStop = false;
            this.Generation2GroupBox.Text = "Generation 2 Settings";
            // 
            // ReadParamButton
            // 
            this.ReadParamButton.Location = new System.Drawing.Point(16, 89);
            this.ReadParamButton.Margin = new System.Windows.Forms.Padding(4);
            this.ReadParamButton.Name = "ReadParamButton";
            this.ReadParamButton.Size = new System.Drawing.Size(169, 30);
            this.ReadParamButton.TabIndex = 22;
            this.ReadParamButton.Text = "Read";
            this.ReadParamButton.UseVisualStyleBackColor = true;
            this.ReadParamButton.Click += new System.EventHandler(this.ReadParamButton_Click);
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(64, 31);
            this.label121.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(74, 17);
            this.label121.TabIndex = 40;
            this.label121.Text = "Parameter";
            // 
            // AllParamsButton
            // 
            this.AllParamsButton.Location = new System.Drawing.Point(16, 126);
            this.AllParamsButton.Margin = new System.Windows.Forms.Padding(4);
            this.AllParamsButton.Name = "AllParamsButton";
            this.AllParamsButton.Size = new System.Drawing.Size(169, 30);
            this.AllParamsButton.TabIndex = 42;
            this.AllParamsButton.Text = "All Params";
            this.AllParamsButton.UseVisualStyleBackColor = true;
            this.AllParamsButton.Click += new System.EventHandler(this.AllParamsButton_Click);
            // 
            // ParamCombo
            // 
            this.ParamCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ParamCombo.FormattingEnabled = true;
            this.ParamCombo.Location = new System.Drawing.Point(16, 55);
            this.ParamCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ParamCombo.Name = "ParamCombo";
            this.ParamCombo.Size = new System.Drawing.Size(168, 24);
            this.ParamCombo.TabIndex = 41;
            // 
            // Main
            // 
            this.Main.Controls.Add(this.GenCmdGroupBox);
            this.Main.Controls.Add(this.groupBox5);
            this.Main.Controls.Add(this.groupBox4);
            this.Main.Controls.Add(this.groupBox3);
            this.Main.Controls.Add(this.groupBox1);
            this.Main.Controls.Add(this.groupBox2);
            this.Main.Location = new System.Drawing.Point(4, 25);
            this.Main.Margin = new System.Windows.Forms.Padding(4);
            this.Main.Name = "Main";
            this.Main.Size = new System.Drawing.Size(621, 700);
            this.Main.TabIndex = 2;
            this.Main.Text = "Printer";
            this.Main.UseVisualStyleBackColor = true;
            // 
            // GenCmdGroupBox
            // 
            this.GenCmdGroupBox.Controls.Add(this.GenCommandButton);
            this.GenCmdGroupBox.Controls.Add(this.GenCommandBox);
            this.GenCmdGroupBox.Location = new System.Drawing.Point(7, 60);
            this.GenCmdGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.GenCmdGroupBox.Name = "GenCmdGroupBox";
            this.GenCmdGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.GenCmdGroupBox.Size = new System.Drawing.Size(361, 53);
            this.GenCmdGroupBox.TabIndex = 100;
            this.GenCmdGroupBox.TabStop = false;
            this.GenCmdGroupBox.Text = "General Command";
            // 
            // GenCommandButton
            // 
            this.GenCommandButton.Enabled = false;
            this.GenCommandButton.Location = new System.Drawing.Point(285, 17);
            this.GenCommandButton.Margin = new System.Windows.Forms.Padding(4);
            this.GenCommandButton.Name = "GenCommandButton";
            this.GenCommandButton.Size = new System.Drawing.Size(65, 30);
            this.GenCommandButton.TabIndex = 25;
            this.GenCommandButton.Text = "Send";
            this.GenCommandButton.UseVisualStyleBackColor = true;
            this.GenCommandButton.Click += new System.EventHandler(this.GenCommandButton_Click);
            // 
            // GenCommandBox
            // 
            this.GenCommandBox.Enabled = false;
            this.GenCommandBox.Location = new System.Drawing.Point(4, 20);
            this.GenCommandBox.Margin = new System.Windows.Forms.Padding(4);
            this.GenCommandBox.Name = "GenCommandBox";
            this.GenCommandBox.Size = new System.Drawing.Size(272, 22);
            this.GenCommandBox.TabIndex = 18;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.EraseCount);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.EraseArea_TopRYBox);
            this.groupBox5.Controls.Add(this.EraseArea_TopRXBox);
            this.groupBox5.Controls.Add(this.EraseArea_BotLYBox);
            this.groupBox5.Controls.Add(this.EraseArea_BotLXBox);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.EraseCardButton);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Location = new System.Drawing.Point(376, 114);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(233, 149);
            this.groupBox5.TabIndex = 27;
            this.groupBox5.TabStop = false;
            // 
            // EraseCount
            // 
            this.EraseCount.Enabled = false;
            this.EraseCount.Location = new System.Drawing.Point(69, 85);
            this.EraseCount.Margin = new System.Windows.Forms.Padding(4);
            this.EraseCount.Maximum = new decimal(new int[] {
            499,
            0,
            0,
            0});
            this.EraseCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.EraseCount.Name = "EraseCount";
            this.EraseCount.Size = new System.Drawing.Size(131, 22);
            this.EraseCount.TabIndex = 25;
            this.EraseCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EraseCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 90);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 17);
            this.label12.TabIndex = 39;
            this.label12.Text = "Count";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EraseArea_TopRYBox
            // 
            this.EraseArea_TopRYBox.Enabled = false;
            this.EraseArea_TopRYBox.Location = new System.Drawing.Point(136, 55);
            this.EraseArea_TopRYBox.Margin = new System.Windows.Forms.Padding(4);
            this.EraseArea_TopRYBox.Maximum = new decimal(new int[] {
            641,
            0,
            0,
            0});
            this.EraseArea_TopRYBox.Name = "EraseArea_TopRYBox";
            this.EraseArea_TopRYBox.Size = new System.Drawing.Size(64, 22);
            this.EraseArea_TopRYBox.TabIndex = 38;
            this.EraseArea_TopRYBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EraseArea_TopRYBox.Value = new decimal(new int[] {
            641,
            0,
            0,
            0});
            // 
            // EraseArea_TopRXBox
            // 
            this.EraseArea_TopRXBox.Enabled = false;
            this.EraseArea_TopRXBox.Location = new System.Drawing.Point(69, 55);
            this.EraseArea_TopRXBox.Margin = new System.Windows.Forms.Padding(4);
            this.EraseArea_TopRXBox.Maximum = new decimal(new int[] {
            1015,
            0,
            0,
            0});
            this.EraseArea_TopRXBox.Name = "EraseArea_TopRXBox";
            this.EraseArea_TopRXBox.Size = new System.Drawing.Size(64, 22);
            this.EraseArea_TopRXBox.TabIndex = 37;
            this.EraseArea_TopRXBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EraseArea_TopRXBox.Value = new decimal(new int[] {
            1015,
            0,
            0,
            0});
            // 
            // EraseArea_BotLYBox
            // 
            this.EraseArea_BotLYBox.Enabled = false;
            this.EraseArea_BotLYBox.Location = new System.Drawing.Point(136, 26);
            this.EraseArea_BotLYBox.Margin = new System.Windows.Forms.Padding(4);
            this.EraseArea_BotLYBox.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.EraseArea_BotLYBox.Name = "EraseArea_BotLYBox";
            this.EraseArea_BotLYBox.Size = new System.Drawing.Size(64, 22);
            this.EraseArea_BotLYBox.TabIndex = 36;
            this.EraseArea_BotLYBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // EraseArea_BotLXBox
            // 
            this.EraseArea_BotLXBox.Enabled = false;
            this.EraseArea_BotLXBox.Location = new System.Drawing.Point(69, 26);
            this.EraseArea_BotLXBox.Margin = new System.Windows.Forms.Padding(4);
            this.EraseArea_BotLXBox.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.EraseArea_BotLXBox.Name = "EraseArea_BotLXBox";
            this.EraseArea_BotLXBox.Size = new System.Drawing.Size(64, 22);
            this.EraseArea_BotLXBox.TabIndex = 35;
            this.EraseArea_BotLXBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 60);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "Top R";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EraseCardButton
            // 
            this.EraseCardButton.Enabled = false;
            this.EraseCardButton.Location = new System.Drawing.Point(69, 112);
            this.EraseCardButton.Margin = new System.Windows.Forms.Padding(4);
            this.EraseCardButton.Name = "EraseCardButton";
            this.EraseCardButton.Size = new System.Drawing.Size(120, 30);
            this.EraseCardButton.TabIndex = 30;
            this.EraseCardButton.Text = "EraseCard";
            this.EraseCardButton.UseVisualStyleBackColor = true;
            this.EraseCardButton.Click += new System.EventHandler(this.EraseCardButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 31);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Bottom L";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Y";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(92, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "X";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ErrorResponseButton);
            this.groupBox4.Controls.Add(this.ErrorResponseCombo);
            this.groupBox4.Location = new System.Drawing.Point(376, 4);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(233, 110);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Error Handling";
            // 
            // ErrorResponseButton
            // 
            this.ErrorResponseButton.Enabled = false;
            this.ErrorResponseButton.Location = new System.Drawing.Point(63, 57);
            this.ErrorResponseButton.Margin = new System.Windows.Forms.Padding(4);
            this.ErrorResponseButton.Name = "ErrorResponseButton";
            this.ErrorResponseButton.Size = new System.Drawing.Size(120, 30);
            this.ErrorResponseButton.TabIndex = 22;
            this.ErrorResponseButton.Text = "ErrorResponse";
            this.ErrorResponseButton.UseVisualStyleBackColor = true;
            this.ErrorResponseButton.Click += new System.EventHandler(this.ErrorResponse_Click);
            // 
            // ErrorResponseCombo
            // 
            this.ErrorResponseCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ErrorResponseCombo.Enabled = false;
            this.ErrorResponseCombo.FormattingEnabled = true;
            this.ErrorResponseCombo.Location = new System.Drawing.Point(47, 23);
            this.ErrorResponseCombo.Margin = new System.Windows.Forms.Padding(4);
            this.ErrorResponseCombo.Name = "ErrorResponseCombo";
            this.ErrorResponseCombo.Size = new System.Drawing.Size(152, 24);
            this.ErrorResponseCombo.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ClearPrinterMsgButton);
            this.groupBox3.Controls.Add(this.PrinterMsgBox);
            this.groupBox3.Controls.Add(this.HandFeedCombo);
            this.groupBox3.Controls.Add(this.HorzEjectCombo);
            this.groupBox3.Controls.Add(this.HorzEjectButton);
            this.groupBox3.Controls.Add(this.HandFeedButton);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.PrinterSetRadio);
            this.groupBox3.Controls.Add(this.PrinterGetRadio);
            this.groupBox3.Controls.Add(this.IPGroupBox);
            this.groupBox3.Controls.Add(this.SmartOffsetBox);
            this.groupBox3.Controls.Add(this.SmartOffsetButton);
            this.groupBox3.Controls.Add(this.SmartModeButton);
            this.groupBox3.Controls.Add(this.SmartModeCombo);
            this.groupBox3.Controls.Add(this.EraseSpeedButton);
            this.groupBox3.Controls.Add(this.EraseSpeedCombo);
            this.groupBox3.Controls.Add(this.EjectModeButton);
            this.groupBox3.Controls.Add(this.EjectModeCombo);
            this.groupBox3.Location = new System.Drawing.Point(7, 263);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(603, 433);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Printer Config";
            // 
            // ClearPrinterMsgButton
            // 
            this.ClearPrinterMsgButton.Location = new System.Drawing.Point(383, 396);
            this.ClearPrinterMsgButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearPrinterMsgButton.Name = "ClearPrinterMsgButton";
            this.ClearPrinterMsgButton.Size = new System.Drawing.Size(120, 30);
            this.ClearPrinterMsgButton.TabIndex = 36;
            this.ClearPrinterMsgButton.Text = "Clear";
            this.ClearPrinterMsgButton.UseVisualStyleBackColor = true;
            this.ClearPrinterMsgButton.Click += new System.EventHandler(this.ClearPrinterMsgButton_Click);
            // 
            // PrinterMsgBox
            // 
            this.PrinterMsgBox.Location = new System.Drawing.Point(292, 14);
            this.PrinterMsgBox.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterMsgBox.Multiline = true;
            this.PrinterMsgBox.Name = "PrinterMsgBox";
            this.PrinterMsgBox.ReadOnly = true;
            this.PrinterMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.PrinterMsgBox.Size = new System.Drawing.Size(301, 374);
            this.PrinterMsgBox.TabIndex = 35;
            this.PrinterMsgBox.WordWrap = false;
            // 
            // HandFeedCombo
            // 
            this.HandFeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HandFeedCombo.Enabled = false;
            this.HandFeedCombo.FormattingEnabled = true;
            this.HandFeedCombo.Location = new System.Drawing.Point(128, 53);
            this.HandFeedCombo.Margin = new System.Windows.Forms.Padding(4);
            this.HandFeedCombo.Name = "HandFeedCombo";
            this.HandFeedCombo.Size = new System.Drawing.Size(140, 24);
            this.HandFeedCombo.TabIndex = 34;
            // 
            // HorzEjectCombo
            // 
            this.HorzEjectCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HorzEjectCombo.Enabled = false;
            this.HorzEjectCombo.FormattingEnabled = true;
            this.HorzEjectCombo.Location = new System.Drawing.Point(128, 171);
            this.HorzEjectCombo.Margin = new System.Windows.Forms.Padding(4);
            this.HorzEjectCombo.Name = "HorzEjectCombo";
            this.HorzEjectCombo.Size = new System.Drawing.Size(140, 24);
            this.HorzEjectCombo.TabIndex = 33;
            // 
            // HorzEjectButton
            // 
            this.HorzEjectButton.Enabled = false;
            this.HorzEjectButton.Location = new System.Drawing.Point(4, 169);
            this.HorzEjectButton.Margin = new System.Windows.Forms.Padding(4);
            this.HorzEjectButton.Name = "HorzEjectButton";
            this.HorzEjectButton.Size = new System.Drawing.Size(120, 30);
            this.HorzEjectButton.TabIndex = 32;
            this.HorzEjectButton.Text = "HorzEject";
            this.HorzEjectButton.UseVisualStyleBackColor = true;
            this.HorzEjectButton.Click += new System.EventHandler(this.HorzEjectButton_Click);
            // 
            // HandFeedButton
            // 
            this.HandFeedButton.Enabled = false;
            this.HandFeedButton.Location = new System.Drawing.Point(4, 50);
            this.HandFeedButton.Margin = new System.Windows.Forms.Padding(4);
            this.HandFeedButton.Name = "HandFeedButton";
            this.HandFeedButton.Size = new System.Drawing.Size(120, 30);
            this.HandFeedButton.TabIndex = 31;
            this.HandFeedButton.Text = "HandFeed";
            this.HandFeedButton.UseVisualStyleBackColor = true;
            this.HandFeedButton.Click += new System.EventHandler(this.HandFeedButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 28);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 17);
            this.label7.TabIndex = 30;
            this.label7.Text = "Action:";
            // 
            // PrinterSetRadio
            // 
            this.PrinterSetRadio.AutoSize = true;
            this.PrinterSetRadio.Enabled = false;
            this.PrinterSetRadio.Location = new System.Drawing.Point(117, 26);
            this.PrinterSetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterSetRadio.Name = "PrinterSetRadio";
            this.PrinterSetRadio.Size = new System.Drawing.Size(50, 21);
            this.PrinterSetRadio.TabIndex = 29;
            this.PrinterSetRadio.Text = "Set";
            this.PrinterSetRadio.UseVisualStyleBackColor = true;
            this.PrinterSetRadio.CheckedChanged += new System.EventHandler(this.PrinterActionSet_CheckedChanged);
            // 
            // PrinterGetRadio
            // 
            this.PrinterGetRadio.AutoSize = true;
            this.PrinterGetRadio.Checked = true;
            this.PrinterGetRadio.Enabled = false;
            this.PrinterGetRadio.Location = new System.Drawing.Point(61, 26);
            this.PrinterGetRadio.Margin = new System.Windows.Forms.Padding(4);
            this.PrinterGetRadio.Name = "PrinterGetRadio";
            this.PrinterGetRadio.Size = new System.Drawing.Size(52, 21);
            this.PrinterGetRadio.TabIndex = 28;
            this.PrinterGetRadio.TabStop = true;
            this.PrinterGetRadio.Text = "Get";
            this.PrinterGetRadio.UseVisualStyleBackColor = true;
            this.PrinterGetRadio.CheckedChanged += new System.EventHandler(this.PrinterActionGetRadio_CheckedChanged);
            // 
            // IPGroupBox
            // 
            this.IPGroupBox.Controls.Add(this.IPGatewayLabel);
            this.IPGroupBox.Controls.Add(this.IPSubnetLabel);
            this.IPGroupBox.Controls.Add(this.IPAddressLabel);
            this.IPGroupBox.Controls.Add(this.IPGatewayBox);
            this.IPGroupBox.Controls.Add(this.IPSubnetBox);
            this.IPGroupBox.Controls.Add(this.IPAddressBox);
            this.IPGroupBox.Controls.Add(this.IPSettingsButton);
            this.IPGroupBox.Controls.Add(this.IPModeLabel);
            this.IPGroupBox.Controls.Add(this.IPModeCombo);
            this.IPGroupBox.Location = new System.Drawing.Point(4, 228);
            this.IPGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.IPGroupBox.Name = "IPGroupBox";
            this.IPGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.IPGroupBox.Size = new System.Drawing.Size(280, 192);
            this.IPGroupBox.TabIndex = 27;
            this.IPGroupBox.TabStop = false;
            // 
            // IPGatewayLabel
            // 
            this.IPGatewayLabel.AutoSize = true;
            this.IPGatewayLabel.Location = new System.Drawing.Point(8, 121);
            this.IPGatewayLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IPGatewayLabel.Name = "IPGatewayLabel";
            this.IPGatewayLabel.Size = new System.Drawing.Size(63, 17);
            this.IPGatewayLabel.TabIndex = 44;
            this.IPGatewayLabel.Text = "Gateway";
            // 
            // IPSubnetLabel
            // 
            this.IPSubnetLabel.AutoSize = true;
            this.IPSubnetLabel.Location = new System.Drawing.Point(8, 87);
            this.IPSubnetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IPSubnetLabel.Name = "IPSubnetLabel";
            this.IPSubnetLabel.Size = new System.Drawing.Size(53, 17);
            this.IPSubnetLabel.TabIndex = 43;
            this.IPSubnetLabel.Text = "Subnet";
            // 
            // IPAddressLabel
            // 
            this.IPAddressLabel.AutoSize = true;
            this.IPAddressLabel.Location = new System.Drawing.Point(8, 54);
            this.IPAddressLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IPAddressLabel.Name = "IPAddressLabel";
            this.IPAddressLabel.Size = new System.Drawing.Size(54, 17);
            this.IPAddressLabel.TabIndex = 42;
            this.IPAddressLabel.Text = "IP Addr";
            // 
            // IPGatewayBox
            // 
            this.IPGatewayBox.Enabled = false;
            this.IPGatewayBox.Location = new System.Drawing.Point(91, 116);
            this.IPGatewayBox.Margin = new System.Windows.Forms.Padding(4);
            this.IPGatewayBox.Name = "IPGatewayBox";
            this.IPGatewayBox.Size = new System.Drawing.Size(173, 22);
            this.IPGatewayBox.TabIndex = 41;
            this.IPGatewayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSubnetBox
            // 
            this.IPSubnetBox.Enabled = false;
            this.IPSubnetBox.Location = new System.Drawing.Point(91, 82);
            this.IPSubnetBox.Margin = new System.Windows.Forms.Padding(4);
            this.IPSubnetBox.Name = "IPSubnetBox";
            this.IPSubnetBox.Size = new System.Drawing.Size(173, 22);
            this.IPSubnetBox.TabIndex = 40;
            this.IPSubnetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPAddressBox
            // 
            this.IPAddressBox.Enabled = false;
            this.IPAddressBox.Location = new System.Drawing.Point(91, 49);
            this.IPAddressBox.Margin = new System.Windows.Forms.Padding(4);
            this.IPAddressBox.Name = "IPAddressBox";
            this.IPAddressBox.Size = new System.Drawing.Size(173, 22);
            this.IPAddressBox.TabIndex = 26;
            this.IPAddressBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSettingsButton
            // 
            this.IPSettingsButton.Enabled = false;
            this.IPSettingsButton.Location = new System.Drawing.Point(84, 155);
            this.IPSettingsButton.Margin = new System.Windows.Forms.Padding(4);
            this.IPSettingsButton.Name = "IPSettingsButton";
            this.IPSettingsButton.Size = new System.Drawing.Size(120, 30);
            this.IPSettingsButton.TabIndex = 39;
            this.IPSettingsButton.Text = "IP Settings";
            this.IPSettingsButton.UseVisualStyleBackColor = true;
            this.IPSettingsButton.Click += new System.EventHandler(this.IPSettingsButton_Click);
            // 
            // IPModeLabel
            // 
            this.IPModeLabel.AutoSize = true;
            this.IPModeLabel.Location = new System.Drawing.Point(8, 20);
            this.IPModeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IPModeLabel.Name = "IPModeLabel";
            this.IPModeLabel.Size = new System.Drawing.Size(43, 17);
            this.IPModeLabel.TabIndex = 37;
            this.IPModeLabel.Text = "Mode";
            // 
            // IPModeCombo
            // 
            this.IPModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.IPModeCombo.Enabled = false;
            this.IPModeCombo.FormattingEnabled = true;
            this.IPModeCombo.Location = new System.Drawing.Point(91, 15);
            this.IPModeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.IPModeCombo.Name = "IPModeCombo";
            this.IPModeCombo.Size = new System.Drawing.Size(173, 24);
            this.IPModeCombo.TabIndex = 38;
            // 
            // SmartOffsetBox
            // 
            this.SmartOffsetBox.Enabled = false;
            this.SmartOffsetBox.Location = new System.Drawing.Point(128, 112);
            this.SmartOffsetBox.Margin = new System.Windows.Forms.Padding(4);
            this.SmartOffsetBox.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.SmartOffsetBox.Name = "SmartOffsetBox";
            this.SmartOffsetBox.Size = new System.Drawing.Size(141, 22);
            this.SmartOffsetBox.TabIndex = 17;
            this.SmartOffsetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // SmartOffsetButton
            // 
            this.SmartOffsetButton.Enabled = false;
            this.SmartOffsetButton.Location = new System.Drawing.Point(4, 110);
            this.SmartOffsetButton.Margin = new System.Windows.Forms.Padding(4);
            this.SmartOffsetButton.Name = "SmartOffsetButton";
            this.SmartOffsetButton.Size = new System.Drawing.Size(120, 30);
            this.SmartOffsetButton.TabIndex = 25;
            this.SmartOffsetButton.Text = "SmartOffset";
            this.SmartOffsetButton.UseVisualStyleBackColor = true;
            this.SmartOffsetButton.Click += new System.EventHandler(this.SmartOffsetButton_Click);
            // 
            // SmartModeButton
            // 
            this.SmartModeButton.Enabled = false;
            this.SmartModeButton.Location = new System.Drawing.Point(4, 139);
            this.SmartModeButton.Margin = new System.Windows.Forms.Padding(4);
            this.SmartModeButton.Name = "SmartModeButton";
            this.SmartModeButton.Size = new System.Drawing.Size(120, 30);
            this.SmartModeButton.TabIndex = 23;
            this.SmartModeButton.Text = "SmartMode";
            this.SmartModeButton.UseVisualStyleBackColor = true;
            this.SmartModeButton.Click += new System.EventHandler(this.SmartModeButton_Click);
            // 
            // SmartModeCombo
            // 
            this.SmartModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SmartModeCombo.Enabled = false;
            this.SmartModeCombo.FormattingEnabled = true;
            this.SmartModeCombo.Location = new System.Drawing.Point(128, 142);
            this.SmartModeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.SmartModeCombo.Name = "SmartModeCombo";
            this.SmartModeCombo.Size = new System.Drawing.Size(140, 24);
            this.SmartModeCombo.TabIndex = 22;
            // 
            // EraseSpeedButton
            // 
            this.EraseSpeedButton.Enabled = false;
            this.EraseSpeedButton.Location = new System.Drawing.Point(4, 198);
            this.EraseSpeedButton.Margin = new System.Windows.Forms.Padding(4);
            this.EraseSpeedButton.Name = "EraseSpeedButton";
            this.EraseSpeedButton.Size = new System.Drawing.Size(120, 30);
            this.EraseSpeedButton.TabIndex = 26;
            this.EraseSpeedButton.Text = "EraseSpeed";
            this.EraseSpeedButton.UseVisualStyleBackColor = true;
            this.EraseSpeedButton.Click += new System.EventHandler(this.EraseSpeedButton_Click);
            // 
            // EraseSpeedCombo
            // 
            this.EraseSpeedCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EraseSpeedCombo.Enabled = false;
            this.EraseSpeedCombo.FormattingEnabled = true;
            this.EraseSpeedCombo.Location = new System.Drawing.Point(128, 201);
            this.EraseSpeedCombo.Margin = new System.Windows.Forms.Padding(4);
            this.EraseSpeedCombo.Name = "EraseSpeedCombo";
            this.EraseSpeedCombo.Size = new System.Drawing.Size(140, 24);
            this.EraseSpeedCombo.TabIndex = 26;
            // 
            // EjectModeButton
            // 
            this.EjectModeButton.Enabled = false;
            this.EjectModeButton.Location = new System.Drawing.Point(4, 80);
            this.EjectModeButton.Margin = new System.Windows.Forms.Padding(4);
            this.EjectModeButton.Name = "EjectModeButton";
            this.EjectModeButton.Size = new System.Drawing.Size(120, 30);
            this.EjectModeButton.TabIndex = 21;
            this.EjectModeButton.Text = "EjectMode";
            this.EjectModeButton.UseVisualStyleBackColor = true;
            this.EjectModeButton.Click += new System.EventHandler(this.EjectModeButton_Click);
            // 
            // EjectModeCombo
            // 
            this.EjectModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EjectModeCombo.Enabled = false;
            this.EjectModeCombo.FormattingEnabled = true;
            this.EjectModeCombo.Location = new System.Drawing.Point(128, 82);
            this.EjectModeCombo.Margin = new System.Windows.Forms.Padding(4);
            this.EjectModeCombo.Name = "EjectModeCombo";
            this.EjectModeCombo.Size = new System.Drawing.Size(140, 24);
            this.EjectModeCombo.TabIndex = 15;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SessionConfigCombo);
            this.groupBox1.Controls.Add(this.OpenSessionButton);
            this.groupBox1.Controls.Add(this.CloseSessionButton);
            this.groupBox1.Location = new System.Drawing.Point(7, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(361, 53);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // SessionConfigCombo
            // 
            this.SessionConfigCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SessionConfigCombo.FormattingEnabled = true;
            this.SessionConfigCombo.Location = new System.Drawing.Point(128, 18);
            this.SessionConfigCombo.Margin = new System.Windows.Forms.Padding(4);
            this.SessionConfigCombo.Name = "SessionConfigCombo";
            this.SessionConfigCombo.Size = new System.Drawing.Size(205, 24);
            this.SessionConfigCombo.TabIndex = 38;
            // 
            // OpenSessionButton
            // 
            this.OpenSessionButton.Location = new System.Drawing.Point(4, 16);
            this.OpenSessionButton.Margin = new System.Windows.Forms.Padding(4);
            this.OpenSessionButton.Name = "OpenSessionButton";
            this.OpenSessionButton.Size = new System.Drawing.Size(120, 30);
            this.OpenSessionButton.TabIndex = 2;
            this.OpenSessionButton.Text = "OpenSession";
            this.OpenSessionButton.UseVisualStyleBackColor = true;
            this.OpenSessionButton.Click += new System.EventHandler(this.OpenSession_Click);
            // 
            // CloseSessionButton
            // 
            this.CloseSessionButton.Location = new System.Drawing.Point(127, 16);
            this.CloseSessionButton.Margin = new System.Windows.Forms.Padding(4);
            this.CloseSessionButton.Name = "CloseSessionButton";
            this.CloseSessionButton.Size = new System.Drawing.Size(120, 30);
            this.CloseSessionButton.TabIndex = 3;
            this.CloseSessionButton.Text = "CloseSession";
            this.CloseSessionButton.UseVisualStyleBackColor = true;
            this.CloseSessionButton.Visible = false;
            this.CloseSessionButton.Click += new System.EventHandler(this.CloseSession_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.FeedMoveButton);
            this.groupBox2.Controls.Add(this.MoveFilmButton);
            this.groupBox2.Controls.Add(this.CardLocationButton);
            this.groupBox2.Controls.Add(this.MoveFilmCombo);
            this.groupBox2.Controls.Add(this.FeedMoveCombo);
            this.groupBox2.Controls.Add(this.RestartButton);
            this.groupBox2.Controls.Add(this.EjectCardButton);
            this.groupBox2.Controls.Add(this.TestCardButton);
            this.groupBox2.Controls.Add(this.FlipCardButton);
            this.groupBox2.Controls.Add(this.CleanPrinterButton);
            this.groupBox2.Location = new System.Drawing.Point(7, 114);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(361, 149);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Printer Control";
            // 
            // FeedMoveButton
            // 
            this.FeedMoveButton.Enabled = false;
            this.FeedMoveButton.Location = new System.Drawing.Point(4, 23);
            this.FeedMoveButton.Margin = new System.Windows.Forms.Padding(4);
            this.FeedMoveButton.Name = "FeedMoveButton";
            this.FeedMoveButton.Size = new System.Drawing.Size(108, 30);
            this.FeedMoveButton.TabIndex = 30;
            this.FeedMoveButton.Text = "FeedCard";
            this.FeedMoveButton.UseVisualStyleBackColor = true;
            this.FeedMoveButton.Click += new System.EventHandler(this.FeedMoveButton_Click);
            // 
            // MoveFilmButton
            // 
            this.MoveFilmButton.Enabled = false;
            this.MoveFilmButton.Location = new System.Drawing.Point(4, 53);
            this.MoveFilmButton.Margin = new System.Windows.Forms.Padding(4);
            this.MoveFilmButton.Name = "MoveFilmButton";
            this.MoveFilmButton.Size = new System.Drawing.Size(108, 30);
            this.MoveFilmButton.TabIndex = 29;
            this.MoveFilmButton.Text = "MoveFilm";
            this.MoveFilmButton.UseVisualStyleBackColor = true;
            this.MoveFilmButton.Click += new System.EventHandler(this.MoveFilmButton_Click);
            // 
            // CardLocationButton
            // 
            this.CardLocationButton.Enabled = false;
            this.CardLocationButton.Location = new System.Drawing.Point(4, 112);
            this.CardLocationButton.Margin = new System.Windows.Forms.Padding(4);
            this.CardLocationButton.Name = "CardLocationButton";
            this.CardLocationButton.Size = new System.Drawing.Size(108, 30);
            this.CardLocationButton.TabIndex = 27;
            this.CardLocationButton.Text = "CardLocation";
            this.CardLocationButton.UseVisualStyleBackColor = true;
            this.CardLocationButton.Click += new System.EventHandler(this.CardLocationButton_Click);
            // 
            // MoveFilmCombo
            // 
            this.MoveFilmCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MoveFilmCombo.Enabled = false;
            this.MoveFilmCombo.Location = new System.Drawing.Point(124, 55);
            this.MoveFilmCombo.Margin = new System.Windows.Forms.Padding(4);
            this.MoveFilmCombo.Name = "MoveFilmCombo";
            this.MoveFilmCombo.Size = new System.Drawing.Size(225, 24);
            this.MoveFilmCombo.TabIndex = 26;
            // 
            // FeedMoveCombo
            // 
            this.FeedMoveCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FeedMoveCombo.Enabled = false;
            this.FeedMoveCombo.Location = new System.Drawing.Point(124, 26);
            this.FeedMoveCombo.Margin = new System.Windows.Forms.Padding(4);
            this.FeedMoveCombo.Name = "FeedMoveCombo";
            this.FeedMoveCombo.Size = new System.Drawing.Size(225, 24);
            this.FeedMoveCombo.TabIndex = 23;
            // 
            // RestartButton
            // 
            this.RestartButton.Enabled = false;
            this.RestartButton.Location = new System.Drawing.Point(124, 112);
            this.RestartButton.Margin = new System.Windows.Forms.Padding(4);
            this.RestartButton.Name = "RestartButton";
            this.RestartButton.Size = new System.Drawing.Size(108, 30);
            this.RestartButton.TabIndex = 24;
            this.RestartButton.Text = "RestartPrinter";
            this.RestartButton.UseVisualStyleBackColor = true;
            this.RestartButton.Click += new System.EventHandler(this.RestartButton_Click);
            // 
            // EjectCardButton
            // 
            this.EjectCardButton.Enabled = false;
            this.EjectCardButton.Location = new System.Drawing.Point(4, 82);
            this.EjectCardButton.Margin = new System.Windows.Forms.Padding(4);
            this.EjectCardButton.Name = "EjectCardButton";
            this.EjectCardButton.Size = new System.Drawing.Size(108, 30);
            this.EjectCardButton.TabIndex = 19;
            this.EjectCardButton.Text = "EjectCard";
            this.EjectCardButton.UseVisualStyleBackColor = true;
            this.EjectCardButton.Click += new System.EventHandler(this.EjectCardButton_Click);
            // 
            // TestCardButton
            // 
            this.TestCardButton.Enabled = false;
            this.TestCardButton.Location = new System.Drawing.Point(244, 82);
            this.TestCardButton.Margin = new System.Windows.Forms.Padding(4);
            this.TestCardButton.Name = "TestCardButton";
            this.TestCardButton.Size = new System.Drawing.Size(108, 30);
            this.TestCardButton.TabIndex = 23;
            this.TestCardButton.Text = "PrintTestCard";
            this.TestCardButton.UseVisualStyleBackColor = true;
            this.TestCardButton.Click += new System.EventHandler(this.PrintTestCardButton_Click);
            // 
            // FlipCardButton
            // 
            this.FlipCardButton.Enabled = false;
            this.FlipCardButton.Location = new System.Drawing.Point(124, 82);
            this.FlipCardButton.Margin = new System.Windows.Forms.Padding(4);
            this.FlipCardButton.Name = "FlipCardButton";
            this.FlipCardButton.Size = new System.Drawing.Size(108, 30);
            this.FlipCardButton.TabIndex = 22;
            this.FlipCardButton.Text = "FlipCard";
            this.FlipCardButton.UseVisualStyleBackColor = true;
            this.FlipCardButton.Click += new System.EventHandler(this.FlipCardButton_Click);
            // 
            // CleanPrinterButton
            // 
            this.CleanPrinterButton.Enabled = false;
            this.CleanPrinterButton.Location = new System.Drawing.Point(244, 112);
            this.CleanPrinterButton.Margin = new System.Windows.Forms.Padding(4);
            this.CleanPrinterButton.Name = "CleanPrinterButton";
            this.CleanPrinterButton.Size = new System.Drawing.Size(108, 30);
            this.CleanPrinterButton.TabIndex = 20;
            this.CleanPrinterButton.Text = "CleanPrinter";
            this.CleanPrinterButton.UseVisualStyleBackColor = true;
            this.CleanPrinterButton.Click += new System.EventHandler(this.CleanPrinterButton_Click);
            // 
            // TabControl
            // 
            this.TabControl.Controls.Add(this.Main);
            this.TabControl.Controls.Add(this.Information);
            this.TabControl.Controls.Add(this.MagEncoding);
            this.TabControl.Controls.Add(this.DriverSettings1);
            this.TabControl.Controls.Add(this.DriverSettings2);
            this.TabControl.Controls.Add(this.PrintDemo);
            this.TabControl.Controls.Add(this.Utils);
            this.TabControl.Location = new System.Drawing.Point(4, 0);
            this.TabControl.Margin = new System.Windows.Forms.Padding(4);
            this.TabControl.Multiline = true;
            this.TabControl.Name = "TabControl";
            this.TabControl.SelectedIndex = 0;
            this.TabControl.Size = new System.Drawing.Size(629, 729);
            this.TabControl.TabIndex = 10;
            this.TabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);
            // 
            // Utils
            // 
            this.Utils.Controls.Add(this.ClearUtilsMsgBoxButton);
            this.Utils.Controls.Add(this.SendAPDUButton);
            this.Utils.Controls.Add(this.UtilsMsgBox);
            this.Utils.Controls.Add(this.SendAPDUBox);
            this.Utils.Location = new System.Drawing.Point(4, 25);
            this.Utils.Name = "Utils";
            this.Utils.Padding = new System.Windows.Forms.Padding(3);
            this.Utils.Size = new System.Drawing.Size(621, 700);
            this.Utils.TabIndex = 8;
            this.Utils.Text = "Utils";
            this.Utils.UseVisualStyleBackColor = true;
            // 
            // ClearUtilsMsgBoxButton
            // 
            this.ClearUtilsMsgBoxButton.Location = new System.Drawing.Point(250, 500);
            this.ClearUtilsMsgBoxButton.Margin = new System.Windows.Forms.Padding(4);
            this.ClearUtilsMsgBoxButton.Name = "ClearUtilsMsgBoxButton";
            this.ClearUtilsMsgBoxButton.Size = new System.Drawing.Size(120, 30);
            this.ClearUtilsMsgBoxButton.TabIndex = 49;
            this.ClearUtilsMsgBoxButton.Text = "Clear";
            this.ClearUtilsMsgBoxButton.UseVisualStyleBackColor = true;
            // 
            // SendAPDUButton
            // 
            this.SendAPDUButton.Location = new System.Drawing.Point(420, 95);
            this.SendAPDUButton.Margin = new System.Windows.Forms.Padding(4);
            this.SendAPDUButton.Name = "SendAPDUButton";
            this.SendAPDUButton.Size = new System.Drawing.Size(120, 30);
            this.SendAPDUButton.TabIndex = 2;
            this.SendAPDUButton.Text = "Send APDU";
            this.SendAPDUButton.UseVisualStyleBackColor = true;
            this.SendAPDUButton.Click += new System.EventHandler(this.SendAPDUButton_Click);
            // 
            // UtilsMsgBox
            // 
            this.UtilsMsgBox.Location = new System.Drawing.Point(140, 212);
            this.UtilsMsgBox.Margin = new System.Windows.Forms.Padding(4);
            this.UtilsMsgBox.Multiline = true;
            this.UtilsMsgBox.Name = "UtilsMsgBox";
            this.UtilsMsgBox.ReadOnly = true;
            this.UtilsMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.UtilsMsgBox.Size = new System.Drawing.Size(340, 276);
            this.UtilsMsgBox.TabIndex = 48;
            this.UtilsMsgBox.WordWrap = false;
            // 
            // SendAPDUBox
            // 
            this.SendAPDUBox.Location = new System.Drawing.Point(20, 78);
            this.SendAPDUBox.Margin = new System.Windows.Forms.Padding(4);
            this.SendAPDUBox.Multiline = true;
            this.SendAPDUBox.Name = "SendAPDUBox";
            this.SendAPDUBox.Size = new System.Drawing.Size(381, 66);
            this.SendAPDUBox.TabIndex = 2;
            // 
            // SDK_CSDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 780);
            this.Controls.Add(this.PrinterID);
            this.Controls.Add(this.TabControl);
            this.Controls.Add(this.ExitButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SDK_CSDemo";
            this.Text = "DTC SDK C# Demo (32 bit)";
            this.PrintDemo.ResumeLayout(false);
            this.PrintDemo.PerformLayout();
            this.CardSide.ResumeLayout(false);
            this.Front.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP2UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontP1UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageFrontXUpDown)).EndInit();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontEndXUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineFrontStartXUpDown)).EndInit();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontBUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontRUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontTUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeFrontLUpDown)).EndInit();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontSizeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).EndInit();
            this.Back.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP2UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackP1UpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageBackXUpDown)).EndInit();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackEndXUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LineBackStartXUpDown)).EndInit();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackBUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackRUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackTUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShapeBackLUpDown)).EndInit();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackSizeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextBackXUpDown)).EndInit();
            this.DriverSettings2.ResumeLayout(false);
            this.DriverSettings2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_WhiteRef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_BlackRef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Blue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Tint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Colour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Brightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAdjust_Contrast)).EndInit();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaLeftUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ColourAreaNo)).EndInit();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloPatchPositionUpDown)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteMapUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoloKoteImageUpDown)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CopyCountUpDown)).EndInit();
            this.DriverSettings1.ResumeLayout(false);
            this.DriverSettings1.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrintableAreaLeftUpDown)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WritePowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErasePowerEndUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErasePowerStartUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseAreaLeftUpDown)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleNoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AreaHoleLeftUpDown)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaHeightUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaNoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaBottomUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaWidthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinAreaLeftUpDown)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OvercoatPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ResinPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YMCPowerUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SharpnessUpDown)).EndInit();
            this.MagEncoding.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StartPosn)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.Information.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.Generation2GroupBox.ResumeLayout(false);
            this.Generation2GroupBox.PerformLayout();
            this.Main.ResumeLayout(false);
            this.GenCmdGroupBox.ResumeLayout(false);
            this.GenCmdGroupBox.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EraseCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_TopRYBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_TopRXBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_BotLYBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EraseArea_BotLXBox)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.IPGroupBox.ResumeLayout(false);
            this.IPGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SmartOffsetBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.TabControl.ResumeLayout(false);
            this.Utils.ResumeLayout(false);
            this.Utils.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label PrinterID;
        private System.Windows.Forms.TabPage PrintDemo;
        private System.Windows.Forms.CheckBox Functions600DPI;
        private System.Windows.Forms.Button PrinterPrefs;
        private System.Windows.Forms.CheckBox nativePrint;
        private System.Windows.Forms.TabControl CardSide;
        private System.Windows.Forms.TabPage Front;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox Track3MagData;
        private System.Windows.Forms.TextBox Track2MagData;
        private System.Windows.Forms.TextBox Track1MagData;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox MagDataEnabled;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.CheckBox ImageFrontResin;
        private System.Windows.Forms.CheckBox ImageFrontEnabled;
        private System.Windows.Forms.Button ImageFrontButton;
        private System.Windows.Forms.TextBox ImageFrontFileBox;
        private System.Windows.Forms.NumericUpDown ImageFrontP2UpDown;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.NumericUpDown ImageFrontP1UpDown;
        private System.Windows.Forms.NumericUpDown ImageFrontYUpDown;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.NumericUpDown ImageFrontXUpDown;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.CheckBox LineFrontEnabled;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.NumericUpDown LineFrontWidthUpDown;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown LineFrontStartYUpDown;
        private System.Windows.Forms.NumericUpDown LineFrontEndYUpDown;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.CheckBox LineFrontResin;
        private System.Windows.Forms.NumericUpDown LineFrontEndXUpDown;
        private System.Windows.Forms.ComboBox LineFrontColourCombo;
        private System.Windows.Forms.NumericUpDown LineFrontStartXUpDown;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.CheckBox ShapeFrontEnabled;
        private System.Windows.Forms.ComboBox ShapeFrontFillCombo;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.NumericUpDown ShapeFrontWidthUpDown;
        private System.Windows.Forms.ComboBox ShapeFrontOutlineCombo;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.NumericUpDown ShapeFrontBUpDown;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.CheckBox ShapeFrontResin;
        private System.Windows.Forms.NumericUpDown ShapeFrontRUpDown;
        private System.Windows.Forms.NumericUpDown ShapeFrontTUpDown;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.NumericUpDown ShapeFrontLUpDown;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.ComboBox ShapeFrontCombo;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.CheckBox TextFrontEnabled;
        private System.Windows.Forms.CheckBox TextFrontResin;
        private System.Windows.Forms.NumericUpDown TextFrontSizeUpDown;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.NumericUpDown TextFrontYUpDown;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.NumericUpDown TextFrontXUpDown;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.CheckBox TextFrontStrikethrough;
        private System.Windows.Forms.CheckBox TextFrontItalic;
        private System.Windows.Forms.CheckBox TextFrontUnderline;
        private System.Windows.Forms.CheckBox TextFrontBold;
        private System.Windows.Forms.ComboBox TextFrontColourCombo;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox TextFrontBox;
        private System.Windows.Forms.TabPage Back;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox ImageBackResin;
        private System.Windows.Forms.CheckBox ImageBackEnabled;
        private System.Windows.Forms.TextBox ImageBackFileBox;
        private System.Windows.Forms.NumericUpDown ImageBackP2UpDown;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown ImageBackP1UpDown;
        private System.Windows.Forms.NumericUpDown ImageBackYUpDown;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.NumericUpDown ImageBackXUpDown;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.CheckBox LineBackEnabled;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.NumericUpDown LineBackWidthUpDown;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.NumericUpDown LineBackStartYUpDown;
        private System.Windows.Forms.NumericUpDown LineBackEndYUpDown;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.CheckBox LineBackResin;
        private System.Windows.Forms.NumericUpDown LineBackEndXUpDown;
        private System.Windows.Forms.ComboBox LineBackColourCombo;
        private System.Windows.Forms.NumericUpDown LineBackStartXUpDown;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.CheckBox ShapeBackEnabled;
        private System.Windows.Forms.ComboBox ShapeBackFillCombo;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.NumericUpDown ShapeBackWidthUpDown;
        private System.Windows.Forms.ComboBox ShapeBackOutlineCombo;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown ShapeBackBUpDown;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.CheckBox ShapeBackResin;
        private System.Windows.Forms.NumericUpDown ShapeBackRUpDown;
        private System.Windows.Forms.NumericUpDown ShapeBackTUpDown;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown ShapeBackLUpDown;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox ShapeBackCombo;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.CheckBox TextBackEnabled;
        private System.Windows.Forms.CheckBox TextBackResin;
        private System.Windows.Forms.NumericUpDown TextBackSizeUpDown;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.NumericUpDown TextBackYUpDown;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.NumericUpDown TextBackXUpDown;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.CheckBox TextBackStrikethrough;
        private System.Windows.Forms.CheckBox TextBackItalic;
        private System.Windows.Forms.CheckBox TextBackUnderline;
        private System.Windows.Forms.CheckBox TextBackBold;
        private System.Windows.Forms.ComboBox TextBackColourCombo;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox TextBackBox;
        private System.Windows.Forms.CheckBox CardBack;
        private System.Windows.Forms.CheckBox CardFront;
        private System.Windows.Forms.Button PrintButton;
        private System.Windows.Forms.TabPage DriverSettings2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button ResinOptionsButton;
        private System.Windows.Forms.CheckBox bPolygons_KResin;
        private System.Windows.Forms.CheckBox bBitmaps_KResin;
        private System.Windows.Forms.CheckBox bText_Kresin;
        private System.Windows.Forms.CheckBox bPics_UseYMC;
        private System.Windows.Forms.CheckBox bBlack_YMC;
        private System.Windows.Forms.ComboBox ResinOptionsSideCombo;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.NumericUpDown ColourAdjust_WhiteRef;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.NumericUpDown ColourAdjust_BlackRef;
        private System.Windows.Forms.ComboBox ColourAdjust_Illuminant;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.CheckBox ColourAdjust_Negative;
        private System.Windows.Forms.CheckBox ColourAdjust_DarkPic;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Blue;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Green;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Red;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Tint;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Colour;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Brightness;
        private System.Windows.Forms.NumericUpDown ColourAdjust_Contrast;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Button ColourAdjustBtn;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.NumericUpDown ColourAreaHeightUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown ColourAreaLeftUpDown;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.NumericUpDown ColourAreaNo;
        private System.Windows.Forms.ComboBox ColourAreaSideCombo;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.ComboBox ColourAreaCorrectionCombo;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Button ColourAreaButton;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.NumericUpDown HoloPatchPositionUpDown;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.CheckBox ColourHole;
        private System.Windows.Forms.Button HoloPatchButton;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button HoloKotePreviewButton;
        private System.Windows.Forms.NumericUpDown HoloKoteMapUpDown;
        private System.Windows.Forms.NumericUpDown HoloKoteImageUpDown;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox HoloKoteSideCombo;
        private System.Windows.Forms.CheckBox NoCustomKey;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.ComboBox HoloKoteRotationCombo;
        private System.Windows.Forms.CheckBox UseLaminate;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button HoloKoteButton;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.CheckBox Rotate;
        private System.Windows.Forms.CheckBox Overcoat;
        private System.Windows.Forms.ComboBox CardSettingsSideCombo;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox OrientationCombo;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox ColourFormatCombo;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button CardSettingsButton;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox CardSizeCombo;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown CopyCountUpDown;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox DuplexCombo;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button PrintSettingsButton;
        private System.Windows.Forms.Button ClearDriver2MsgBoxButton;
        private System.Windows.Forms.TextBox Driver2MsgBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton Driver2SetRadio;
        private System.Windows.Forms.RadioButton Driver2GetRadio;
        private System.Windows.Forms.TabPage DriverSettings1;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton Radio600DPI;
        private System.Windows.Forms.Button ResolutionButton;
        private System.Windows.Forms.RadioButton Radio300DPI;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.NumericUpDown PrintableAreaHeightUpDown;
        private System.Windows.Forms.NumericUpDown PrintableAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown PrintableAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown PrintableAreaLeftUpDown;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Button PrintableAreaButton;
        private System.Windows.Forms.CheckBox GUIPrinter;
        private System.Windows.Forms.CheckBox GUIUser;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.CheckBox EraseBeforePrint;
        private System.Windows.Forms.Label EraseEndPowerLabel;
        private System.Windows.Forms.NumericUpDown WritePowerUpDown;
        private System.Windows.Forms.NumericUpDown ErasePowerEndUpDown;
        private System.Windows.Forms.Label WritePowerLabel;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown EraseAreaHeightUpDown;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown EraseAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown ErasePowerStartUpDown;
        private System.Windows.Forms.NumericUpDown EraseAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown EraseAreaLeftUpDown;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button RewritableButton;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ComboBox AreaHoleTypeCombo;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown AreaHoleHeightUpDown;
        private System.Windows.Forms.NumericUpDown AreaHoleNoUpDown;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox AreaHoleSideCombo;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown AreaHoleBottomUpDown;
        private System.Windows.Forms.NumericUpDown AreaHoleWidthUpDown;
        private System.Windows.Forms.NumericUpDown AreaHoleLeftUpDown;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button AreaHoleButton;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown ResinAreaHeightUpDown;
        private System.Windows.Forms.NumericUpDown ResinAreaNoUpDown;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox ResinAreaSideCombo;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown ResinAreaBottomUpDown;
        private System.Windows.Forms.NumericUpDown ResinAreaWidthUpDown;
        private System.Windows.Forms.NumericUpDown ResinAreaLeftUpDown;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button ResinAreaButton;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown OvercoatPowerUpDown;
        private System.Windows.Forms.NumericUpDown ResinPowerUpDown;
        private System.Windows.Forms.NumericUpDown YMCPowerUpDown;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button PowerLevelButton;
        private System.Windows.Forms.Button PrintSpeedButton;
        private System.Windows.Forms.ComboBox PrintSpeedCombo;
        private System.Windows.Forms.Button ColourCorrectionButton;
        private System.Windows.Forms.ComboBox CorrectionCombo;
        private System.Windows.Forms.NumericUpDown SharpnessUpDown;
        private System.Windows.Forms.Button GUIControlButton;
        private System.Windows.Forms.Button SharpnessButton;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton Driver1SetRadio;
        private System.Windows.Forms.RadioButton Driver1GetRadio;
        private System.Windows.Forms.Button ClearDriver1MsgBoxButton;
        private System.Windows.Forms.TextBox Driver1MsgBox;
        private System.Windows.Forms.TabPage MagEncoding;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.Button MagStartButton;
        private System.Windows.Forms.NumericUpDown StartPosn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton EncodingSetRadio;
        private System.Windows.Forms.RadioButton EncodingGetRadio;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button ReadMagTracks;
        private System.Windows.Forms.CheckBox Track2Read;
        private System.Windows.Forms.CheckBox Track3Read;
        private System.Windows.Forms.CheckBox Track1Read;
        private System.Windows.Forms.TextBox EncodingBox;
        private System.Windows.Forms.Button ReadMagButton;
        private System.Windows.Forms.Button ClearEncodingBoxButton;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label LRCLabel;
        private System.Windows.Forms.Label ParityLabel;
        private System.Windows.Forms.Label BitsPerInchLabel;
        private System.Windows.Forms.Label BitsPerCharLabel;
        private System.Windows.Forms.Label Track3SettingsLabel;
        private System.Windows.Forms.Label Track2SettingsLabel;
        private System.Windows.Forms.Label Track1SettingsLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label JIS2Label;
        private System.Windows.Forms.Label Track3Label;
        private System.Windows.Forms.Label Track2Label;
        private System.Windows.Forms.TextBox Track1Data;
        private System.Windows.Forms.TextBox Track2Data;
        private System.Windows.Forms.TextBox Track3Data;
        private System.Windows.Forms.CheckBox Track1Write;
        private System.Windows.Forms.CheckBox Track2Write;
        private System.Windows.Forms.CheckBox Track3Write;
        private System.Windows.Forms.ComboBox EncodingTypeCombo;
        private System.Windows.Forms.ComboBox CoercivityCombo;
        private System.Windows.Forms.CheckBox Verify;
        private System.Windows.Forms.ComboBox T1_BPCCombo;
        private System.Windows.Forms.ComboBox T1_BPICombo;
        private System.Windows.Forms.ComboBox T1_ParityCombo;
        private System.Windows.Forms.ComboBox T1_LRCCombo;
        private System.Windows.Forms.ComboBox T2_BPCCombo;
        private System.Windows.Forms.ComboBox T2_BPICombo;
        private System.Windows.Forms.ComboBox T2_ParityCombo;
        private System.Windows.Forms.ComboBox T2_LRCCombo;
        private System.Windows.Forms.ComboBox T3_BPCCombo;
        private System.Windows.Forms.ComboBox T3_BPICombo;
        private System.Windows.Forms.ComboBox T3_ParityCombo;
        private System.Windows.Forms.ComboBox T3_LRCCombo;
        private System.Windows.Forms.Button EncodeMagButton;
        private System.Windows.Forms.Label Track1Label;
        private System.Windows.Forms.TabPage Information;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.Label Pwd2Label;
        private System.Windows.Forms.Label Pwd1Label;
        private System.Windows.Forms.Button PasswordButton;
        private System.Windows.Forms.TextBox Password2;
        private System.Windows.Forms.TextBox Password1;
        private System.Windows.Forms.ComboBox PwdCommandCombo;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Button SensorsButton;
        private System.Windows.Forms.Button PrinterTypeButton;
        private System.Windows.Forms.Button SDKBitsButton;
        private System.Windows.Forms.Button PrinterModelButton;
        private System.Windows.Forms.Button ConnectionTypeButton;
        private System.Windows.Forms.Button SDKVersionButton;
        private System.Windows.Forms.Button ClearMsgBoxButton;
        private System.Windows.Forms.Button LastMessageButton;
        private System.Windows.Forms.TextBox InfoMsgBox;
        private System.Windows.Forms.Button PrinterInfoButton;
        private System.Windows.Forms.Button PrinterStatusButton;
        private System.Windows.Forms.GroupBox Generation2GroupBox;
        private System.Windows.Forms.Button ReadParamButton;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Button AllParamsButton;
        private System.Windows.Forms.ComboBox ParamCombo;
        private System.Windows.Forms.TabPage Main;
        private System.Windows.Forms.GroupBox GenCmdGroupBox;
        private System.Windows.Forms.Button GenCommandButton;
        private System.Windows.Forms.TextBox GenCommandBox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown EraseCount;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown EraseArea_TopRYBox;
        private System.Windows.Forms.NumericUpDown EraseArea_TopRXBox;
        private System.Windows.Forms.NumericUpDown EraseArea_BotLYBox;
        private System.Windows.Forms.NumericUpDown EraseArea_BotLXBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button EraseCardButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button ErrorResponseButton;
        private System.Windows.Forms.ComboBox ErrorResponseCombo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ClearPrinterMsgButton;
        private System.Windows.Forms.TextBox PrinterMsgBox;
        private System.Windows.Forms.ComboBox HandFeedCombo;
        private System.Windows.Forms.ComboBox HorzEjectCombo;
        private System.Windows.Forms.Button HorzEjectButton;
        private System.Windows.Forms.Button HandFeedButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton PrinterSetRadio;
        private System.Windows.Forms.RadioButton PrinterGetRadio;
        private System.Windows.Forms.GroupBox IPGroupBox;
        private System.Windows.Forms.Label IPGatewayLabel;
        private System.Windows.Forms.Label IPSubnetLabel;
        private System.Windows.Forms.Label IPAddressLabel;
        private System.Windows.Forms.TextBox IPGatewayBox;
        private System.Windows.Forms.TextBox IPSubnetBox;
        private System.Windows.Forms.TextBox IPAddressBox;
        private System.Windows.Forms.Button IPSettingsButton;
        private System.Windows.Forms.Label IPModeLabel;
        private System.Windows.Forms.ComboBox IPModeCombo;
        private System.Windows.Forms.NumericUpDown SmartOffsetBox;
        private System.Windows.Forms.Button SmartOffsetButton;
        private System.Windows.Forms.Button SmartModeButton;
        private System.Windows.Forms.ComboBox SmartModeCombo;
        private System.Windows.Forms.Button EraseSpeedButton;
        private System.Windows.Forms.ComboBox EraseSpeedCombo;
        private System.Windows.Forms.Button EjectModeButton;
        private System.Windows.Forms.ComboBox EjectModeCombo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox SessionConfigCombo;
        private System.Windows.Forms.Button OpenSessionButton;
        private System.Windows.Forms.Button CloseSessionButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button FeedMoveButton;
        private System.Windows.Forms.Button MoveFilmButton;
        private System.Windows.Forms.Button CardLocationButton;
        private System.Windows.Forms.ComboBox MoveFilmCombo;
        private System.Windows.Forms.ComboBox FeedMoveCombo;
        private System.Windows.Forms.Button RestartButton;
        private System.Windows.Forms.Button EjectCardButton;
        private System.Windows.Forms.Button TestCardButton;
        private System.Windows.Forms.Button FlipCardButton;
        private System.Windows.Forms.Button CleanPrinterButton;
        private System.Windows.Forms.TabControl TabControl;
        private System.Windows.Forms.TabPage Utils;
        private System.Windows.Forms.TextBox SendAPDUBox;
        private System.Windows.Forms.TextBox UtilsMsgBox;
        private System.Windows.Forms.Button SendAPDUButton;
        private System.Windows.Forms.Button ClearUtilsMsgBoxButton;
    }
}


﻿namespace CSharpDemo 
{
    partial class HKPreview
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.slotNumber = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Slot No.";
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(7, 4);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(259, 166);
            this.pictureBox.TabIndex = 3;
            this.pictureBox.TabStop = false;
            // 
            // slotNumber
            // 
            this.slotNumber.Location = new System.Drawing.Point(54, 176);
            this.slotNumber.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.slotNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.slotNumber.Name = "slotNumber";
            this.slotNumber.Size = new System.Drawing.Size(48, 20);
            this.slotNumber.TabIndex = 36;
            this.slotNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.slotNumber.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.slotNumber.ValueChanged += new System.EventHandler(this.slotNumber_ValueChanged);
            // 
            // HKPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 203);
            this.Controls.Add(this.slotNumber);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.label1);
            this.Name = "HKPreview";
            this.Text = "HoloKote Preview";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.NumericUpDown slotNumber;
	}
}
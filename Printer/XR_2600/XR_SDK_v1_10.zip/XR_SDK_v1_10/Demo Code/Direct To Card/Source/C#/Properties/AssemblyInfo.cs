﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
#if (x86)
[assembly: AssemblyTitle("DTC SDK C# Demo (32 bit)")]
#else
[assembly: AssemblyTitle("DTC SDK C# Demo (64 bit)")]
#endif
[assembly: AssemblyDescription("DTC C# Demo for Magicard SDK")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Magicard Ltd.")]
[assembly: AssemblyProduct("DTC SDK C# Demo")]
[assembly: AssemblyCopyright("Copyright ©2022 Magicard Ltd.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("dd525497-7f07-4aff-9395-23ed4814a909")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.1.5.2")]
[assembly: AssemblyFileVersion("2.1.5.2")]
[assembly: NeutralResourcesLanguageAttribute("en-GB")]

#pragma once
#include "afxwin.h"

// CInfoPage dialog
class CInfoPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CInfoPage)

public:
	CInfoPage();
	virtual ~CInfoPage();
	virtual BOOL OnInitDialog();
	virtual BOOL OnSetActive();

// Dialog Data
	enum { IDD = IDD_INFOPAGE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedSDKVersionBtn();
	afx_msg void OnBnClickedConnectionTypeBtn();
	afx_msg void OnBnClickedLastMessageBtn();
	afx_msg void OnBnClickedPrinterStatusBtn();
	afx_msg void OnBnClickedPrinterInfoBtn();
	afx_msg void OnBnClickedPrinterModelBtn();
	afx_msg void OnBnClickedPwdSendBtn();
	afx_msg void OnCbnSelchangePwdcmdCombo();
	afx_msg void OnBnClickedInfoMsgClrBtn();
	afx_msg void OnBnClickedSDKBitsBtn();
	afx_msg void OnBnClickedParamBtn();
	afx_msg void OnBnClickedAllParamsBtn();
	afx_msg void OnBnClickedBtnPrintertype();
	afx_msg void OnBnClickedBtnSensors();

private:
	CMainSheet *Parent;
	PRINTER_INFO PrinterInfo;
	CButton ConnectionType;
	CButton SDKVersion;
	CEdit InfoMessage;
	CButton PrinterModelBtn;

	void OutputBurstMessage(TCHAR *str);
	void AddInfoMessage(CString pMessage);
	CString TrueFalseString(BOOL Bool);
	void Get360Param(void *ptr);

public:
	CEdit Password1Edit;
	CEdit Password2Edit;
	CComboBox PasswordCombo;
	CStatic Password1Label;
	CStatic Password2Label;
	CButton LastMessageBtn;
	CButton PrinterInfoBtn;
	CButton PasswordBtn;
	CButton ParamBtn;
	CComboBox ParamCombo;
	CStatic Generation2GroupBox;
	CStatic ParameterLabel;
	CButton AllParamsBtn;
};

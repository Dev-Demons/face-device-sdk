#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CHoloKotePreview dialog

class CHoloKotePreview : public CDialog
{
#define NUM_HOLOKOTES 10

	DECLARE_DYNAMIC(CHoloKotePreview)

public:
	CHoloKotePreview(char *pBuff, 
					 int   slotCount, 
					 CWnd* pParent = NULL);   // standard constructor
	virtual ~CHoloKotePreview();
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_HOLOKOTEPREVIEW };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

private:
	afx_msg void OnCbnSelchangeSlotnumber();

	void DisplayBitmap(int number);

	char *m_pBuff;
	int   m_size;
	int   m_slotno;
	int   m_slotcount;

	CComboBox m_SlotNumber;
	CStatic			ctlBmp;
};

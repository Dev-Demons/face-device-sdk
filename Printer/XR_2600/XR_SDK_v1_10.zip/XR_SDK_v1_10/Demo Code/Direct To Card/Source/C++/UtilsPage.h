#pragma once
#include "afxwin.h"

// CInfoPage dialog
class CUtilsPage : public CPropertyPage
{
	DECLARE_DYNAMIC(CUtilsPage)

public:
	CUtilsPage();
	virtual ~CUtilsPage();
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_UTILS };

	afx_msg void OnBnClickedBtnUtilsmsgClr();
	afx_msg void OnBnClickedBtnEnableLogging();
	afx_msg void OnBnClickedBtnDisableLogging();
	afx_msg void onBnClickedBtnSendAPDU();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

private:
	CMainSheet *Parent;
	CEdit APDUCommandBox;
	CButton SendAPDUBtn;
	CEdit UtilsMessage;

	void AddUtilsMessage(CString pMessage);
};

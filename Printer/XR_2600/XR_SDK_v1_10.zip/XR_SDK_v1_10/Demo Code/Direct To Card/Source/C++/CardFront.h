#pragma once
#include "afxwin.h"

// CCardFront dialog

class CCardFront : public CDialog
{
	DECLARE_DYNAMIC(CCardFront)

public:
	CCardFront(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCardFront();
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_CARDFRONT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	afx_msg void OnBnClickedFilename();

public:
	void EnableGetSetControls(BOOL bControl);

	CEdit Text;
	CComboBox TextColour;
	CEdit TextSize;
	CEdit TextLeft;
	CButton TextBold;
	CButton TextItalic;
	CButton TextUnderline;
	CButton TextStrikeout;
	CEdit TextTop;
	CEdit TextBottom;
	CEdit TextRight;
	CEdit TextX;
	CEdit TextY;
	CButton TextResin;
	CSpinButtonCtrl TextSize_Spin;
	CComboBox Shape;
	CComboBox ShapePen;
	CComboBox ShapeBrush;
	CEdit ShapeLeft;
	CEdit ShapeTop;
	CEdit ShapeRight;
	CEdit ShapeBottom;
	CEdit ShapePenWidth;
	CSpinButtonCtrl ShapePen_Spin;
	CButton ShapeResin;
	CComboBox LineColour;
	CEdit LineWidth;
	CEdit LineStartX;
	CEdit LineStartY;
	CEdit LineEndX;
	CEdit LineEndY;
	CButton LineResin;
	CSpinButtonCtrl LineSpin;
    CString Image;
	CEdit ImageLeft;
	CEdit ImageTop;
	CEdit ImageP1;
	CEdit ImageP2;
	CEdit ImageFilename;
	CButton ImageFilenameBtn;
	CButton ImageResin;

	CEdit Mag1Data;
	CEdit Mag2Data;
	CEdit Mag3Data;
	CButton TextEnabled;
	CButton ShapeEnabled;
	CButton LineEnabled;
	CButton ImageEnabled;
	CButton MagDataEnabled;
};

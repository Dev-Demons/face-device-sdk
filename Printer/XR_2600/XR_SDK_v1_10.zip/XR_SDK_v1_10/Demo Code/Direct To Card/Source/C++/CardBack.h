#pragma once
#include "afxwin.h"

// CCardBack dialog

class CCardBack : public CDialog
{
	DECLARE_DYNAMIC(CCardBack)

public:
	CCardBack(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCardBack();
	virtual BOOL OnInitDialog();

// Dialog Data
	enum { IDD = IDD_CARDBACK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

public:
	void EnableGetSetControls(BOOL bControl);
	afx_msg void OnBnClickedFilename();

	CButton TextResin;
	CEdit Text;
	CComboBox TextColour;
	CEdit TextSize;
	CEdit TextLeft;
	CEdit TextX;
	CEdit TextY;
	CButton TextBold;
	CButton TextItalic;
	CButton TextUnderline;
	CButton TextStrikeout;
	CSpinButtonCtrl TextSize_Spin;
	CComboBox Shape;
	CComboBox ShapePen;
	CComboBox ShapeBrush;
	CEdit ShapeLeft;
	CEdit ShapeTop;
	CEdit ShapeRight;
	CEdit ShapeBottom;
	CEdit ShapePenWidth;
	CButton ShapeResin;
	CSpinButtonCtrl ShapePen_Spin;
	CComboBox LineColour;
	CEdit LineWidth;
	CEdit LineStartX;
	CEdit LineStartY;
	CEdit LineEndX;
	CEdit LineEndY;
	CButton LineResin;
	CSpinButtonCtrl LineSpin;
    CString Image;
	CEdit ImageLeft;
	CEdit ImageTop;
	CEdit ImageP1;
	CEdit ImageP2;
	CEdit ImageFilename;
	CButton ImageFilenameBtn;

	CButton TextEnabled;
	CButton ShapeEnabled;
	CButton LineEnabled;
	CButton ImageEnabled;
	CButton ImageResin;
};

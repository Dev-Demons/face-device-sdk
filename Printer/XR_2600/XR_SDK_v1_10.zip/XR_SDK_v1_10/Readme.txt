This SDK Package is made up of a number of separate components, each with
its own discrete version number.
For amendment records, see the changelogs in each separate component.

SDK V1.10
=========
Released: 26/01/2022

Component                Version
---------                -------
SDK DLL (MagAPI)         3.2.6.0
.Net Shim                2.2.3.3
Java Shim                1.2.3.0
DTC C++ Demo             2.1.6.0
DTC C# Demo              2.1.5.2
DTC Visual Basic Demo    2.1.5.1
DTC Java Demo            1.1.4.0
Ultima C++ Demo          1.0.5.1
Ultima C# Demo           1.0.5.1
Ultima Visual Basic Demo 1.0.5.1
Ultima Java Demo         1.0.4.0
User Guide               1.10

================================================================================

SDK V1.09
=========
Released: 26/11/2019

Component                Version
---------                -------
SDK DLL (MagAPI)         3.2.2.0
.Net Shim                2.2.2.0
Java Shim                1.2.1.0
DTC C++ Demo             2.1.4.0
DTC C# Demo              2.1.4.0
DTC Visual Basic Demo    2.1.4.0
DTC Java Demo            1.1.3.0
Ultima C++ Demo          1.0.4.0
Ultima C# Demo           1.0.4.0
Ultima Visual Basic Demo 1.0.4.0
Ultima Java Demo         1.0.3.0
User Guide               1.09

================================================================================

SDK V1.08
=========
Released: 4/7/2019

Component                Version
---------                -------
SDK DLL (MagAPI)         3.2.1.0
.Net Shim                2.2.1.0
Java Shim                1.2.0.0
DTC C++ Demo             2.1.3.0
DTC C# Demo              2.1.3.0
DTC Visual Basic Demo    2.1.3.0
DTC Java Demo            1.1.2.0
Ultima C++ Demo          1.0.3.0
Ultima C# Demo           1.0.3.0
Ultima Visual Basic Demo 1.0.3.0
Ultima Java Demo         1.0.2.0
User Guide               1.08

================================================================================

SDK V1.07
=========
Released: 4/6/2019
N.B. Requires driver version 2.0.43 or later

Component                Version
---------                -------
SDK DLL (MagAPI)         3.2.0.0
.Net Shim                2.2.0.0
Java Shim                1.2.0.0
DTC C++ Demo             2.1.2.0
DTC C# Demo              2.1.2.0
DTC Visual Basic Demo    2.1.2.0
DTC Java Demo            1.1.2.0
Ultima C++ Demo          1.0.2.0
Ultima C# Demo           1.0.2.0
Ultima Visual Basic Demo 1.0.2.0
Ultima Java Demo         1.0.2.0
User Guide               1.06

================================================================================

SDK V1.06
=========
Released: 16/8/2018

Component                Version
---------                -------
SDK DLL (MagAPI)         3.1.2.0
.Net Shim                2.1.0.0
Java Shim                1.1.0.0
DTC C++ Demo             2.1.1.0
DTC C# Demo              2.1.1.0
DTC Visual Basic Demo    2.1.1.0
DTC Java Demo            1.1.0.0
Ultima C++ Demo          1.0.1.0
Ultima C# Demo           1.0.1.0
Ultima Visual Basic Demo 1.0.1.0
Ultima Java Demo         1.0.1.0
User Guide               1.05

--------------------------------------------------------------------------------

SDK V1.05
=========
Released: 29/6/2018

Component                Version
---------                -------
SDK DLL (MagAPI)         3.1.0.0
.Net Shim                2.1.0.0
Java Shim                1.1.0.0
DTC C++ Demo             2.1.0.0
DTC C# Demo              2.1.0.0
DTC Visual Basic Demo    2.1.0.0
DTC Java Demo            1.1.0.0
Ultima C++ Demo          1.0.1.0
Ultima C# Demo           1.0.1.0
Ultima Visual Basic Demo 1.0.1.0
Ultima Java Demo         1.0.1.0
User Guide               1.04

--------------------------------------------------------------------------------

SDK V1.04
=========
Released: 3/11/2017

Component               Version
---------               -------
SDK DLL (MagAPI)        3.0.4.0
.Net Shim               2.0.1.0
Java Shim               1.0.1.0
DTC C++ Demo            2.0.1.0
DTC C# Demo             2.0.1.0
DTC Visual Basic Demo   2.0.1.0
DTC Java Demo           1.0.1.0
Helix C++ Demo          1.0.0.0
Helix C# Demo           1.0.0.0
Helix Visual Basic Demo 1.0.0.0
Helix Java Demo         1.0.0.0
User Guide              1.03

--------------------------------------------------------------------------------

SDK V1.03
=========
Released: 2/12/2016

Component               Version
---------               -------
SDK DLL (MagAPI)        3.0.3.0
.Net Shim               2.0.1.0
Java Shim               1.0.1.0
DTC C++ Demo            2.0.1.0
DTC C# Demo             2.0.1.0
DTC Visual Basic Demo   2.0.1.0
DTC Java Demo           1.0.1.0
Helix C++ Demo          1.0.0.0
Helix C# Demo           1.0.0.0
Helix Visual Basic Demo 1.0.0.0
Helix Java Demo         1.0.0.0
User Guide              1.03

--------------------------------------------------------------------------------

SDK V1.02
=========
Released: 2/12/2016

Component               Version
---------               -------
SDK DLL (MagAPI)        3.0.2.0
.Net Shim               2.0.1.0
Java Shim               1.0.1.0
DTC C++ Demo            2.0.1.0
DTC C# Demo             2.0.1.0
DTC Visual Basic Demo   2.0.1.0
DTC Java Demo           1.0.1.0
Helix C++ Demo          1.0.0.0
Helix C# Demo           1.0.0.0
Helix Visual Basic Demo 1.0.0.0
Helix Java Demo         1.0.0.0
User Guide              1.02

--------------------------------------------------------------------------------

SDK V1.01
=========
Released: 6/7/2016

Component               Version
---------               -------
SDK DLL (MagAPI)        3.0.1.0
.Net Shim               2.0.0.0
Java Shim               1.0.0.0
C++ Demo                2.0.0.0
C# Demo                 2.0.0.0
Visual Basic Demo       2.0.0.0
Java Demo               1.0.0.0
User Guide              1.01

--------------------------------------------------------------------------------

SDK V1.00
=========
Released: 21/10/2015

Component               Version
---------               --------
SDK DLL (MagAPI)        3.0.0.0
C++ Demo                2.0.0.0
.Net Shim               2.0.0.0
C# Demo                 2.0.0.0
Visual Basic Demo       2.0.0.0
Java Shim               1.0.0.0
Java Demo               1.0.0.0
User Guide              1.00